package com.abstergo.app.labs.chem

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ==============================================================================
// ESTÉTICA QUÍMICA LABS: VIDRIO LÍQUIDO Y ESPECTROSCOPÍA (60 FPS, CLARO/OSCURO)
// ==============================================================================

@Composable
fun chemIsDark(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

@Composable
fun chemCanvasBg(): Color = if (chemIsDark()) Color(0xFF0A0E14) else Color(0xFFF3F6FA)

@Composable
fun chemGlassSurface(): Color = if (chemIsDark()) Color(0xFF131A24) else Color(0xFFFFFFFF)

@Composable
fun chemGlassBorder(accent: Color? = null): Color {
    val dark = chemIsDark()
    return when {
        accent != null -> accent.copy(alpha = if (dark) 0.42f else 0.32f)
        dark -> Color(0x28FFFFFF)
        else -> Color(0x1E0F172A)
    }
}

@Composable
fun chemPrimaryAccent(): Color = if (chemIsDark()) Color(0xFF38BDF8) else Color(0xFF0284C7)

/** Calcula el color de una celda según el modo de mapa de calor activo. */
fun elementCellColor(el: ChemElement, mode: ChemColorMode, tempC: Double, dark: Boolean): Color {
    return when (mode) {
        ChemColorMode.FAMILY -> el.category.color(dark)
        ChemColorMode.BLOCK -> when (el.block) {
            "s" -> if (dark) Color(0xFFFF6B6B) else Color(0xFFDC2626)
            "p" -> if (dark) Color(0xFFFACC15) else Color(0xFFCA8A04)
            "d" -> if (dark) Color(0xFF4DABF7) else Color(0xFF2563EB)
            else -> if (dark) Color(0xFF34D399) else Color(0xFF059669)
        }
        ChemColorMode.STATE -> when (el.phaseAtCelsius(tempC)) {
            "Sólido" -> if (dark) Color(0xFF60A5FA) else Color(0xFF2563EB)
            "Líquido" -> if (dark) Color(0xFF22D3EE) else Color(0xFF0891B2)
            "Gas" -> if (dark) Color(0xFFFB923C) else Color(0xFFEA580C)
            else -> if (dark) Color(0xFF94A3B8) else Color(0xFF64748B)
        }
        ChemColorMode.ELECTRONEGATIVITY -> {
            val en = el.electronegativity ?: return if (dark) Color(0xFF475569) else Color(0xFF94A3B8)
            val t = ((en - 0.7) / (3.98 - 0.7)).toFloat().coerceIn(0f, 1f)
            lerpColor(Color(0xFF38BDF8), Color(0xFFF43F5E), t)
        }
        ChemColorMode.RADIUS -> {
            val r = el.radiusPm ?: return if (dark) Color(0xFF475569) else Color(0xFF94A3B8)
            val t = ((r - 31f) / (300f - 31f)).coerceIn(0f, 1f)
            lerpColor(Color(0xFF34D399), Color(0xFFA855F7), t)
        }
        ChemColorMode.RADIOACTIVITY -> {
            if (el.radioactive) {
                if (dark) Color(0xFFFB7185) else Color(0xFFE11D48)
            } else {
                if (dark) Color(0xFF34D399) else Color(0xFF059669)
            }
        }
    }
}

private fun lerpColor(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = 1f
)

fun parseHexColorOrNull(hex: String): Color? {
    val clean = hex.trim().removePrefix("#")
    if (clean.length != 6) return null
    return try {
        Color(("FF$clean").toLong(16))
    } catch (_: Exception) {
        null
    }
}

/** Convierte una longitud de onda visible (380–780 nm) a su color RGB aproximado de espectroscopía. */
fun wavelengthToColor(nm: Int): Color {
    val w = nm.toFloat().coerceIn(380f, 780f)
    val (r, g, b) = when {
        w < 440f -> Triple(-(w - 440f) / 60f, 0f, 1f)
        w < 490f -> Triple(0f, (w - 440f) / 50f, 1f)
        w < 510f -> Triple(0f, 1f, -(w - 510f) / 20f)
        w < 580f -> Triple((w - 510f) / 70f, 1f, 0f)
        w < 645f -> Triple(1f, -(w - 645f) / 65f, 0f)
        else -> Triple(1f, 0f, 0f)
    }
    val factor = when {
        w < 420f -> 0.4f + 0.6f * (w - 380f) / 40f
        w > 700f -> 0.4f + 0.6f * (780f - w) / 80f
        else -> 1f
    }
    return Color((r * factor).coerceIn(0f, 1f), (g * factor).coerceIn(0f, 1f), (b * factor).coerceIn(0f, 1f), 1f)
}

// ==============================================================================
// ICONOS VECTORIALES PROPIOS DE QUÍMICA LABS (CERO EMOJIS DEL SISTEMA)
// ==============================================================================

enum class ChemIconKind {
    MENU,
    BACK,
    SEARCH,
    CLOSE,
    GRID,
    LIST,
    THERMO,
    STAR_OUTLINE,
    STAR_FILLED,
    COMPARE,
    NOTE,
    FLASK,
    ATOM,
    FLAME,
    RADIATION,
    NEXT,
    PREV,
    EXIT_LABS,
    MATH_SHORTCUT,
    SPARKLE
}

@Composable
fun ChemIcon(
    kind: ChemIconKind,
    color: Color,
    modifier: Modifier = Modifier,
    strokeWidth: Float = 6.5f
) {
    Canvas(modifier = modifier) {
        val sc = size.minDimension / 100f
        val st = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
        withTransform({ scale(sc, sc, Offset.Zero) }) {
            when (kind) {
                ChemIconKind.MENU -> {
                    drawLine(color, Offset(16f, 26f), Offset(84f, 26f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(16f, 50f), Offset(84f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(16f, 74f), Offset(64f, 74f), strokeWidth, StrokeCap.Round)
                }
                ChemIconKind.BACK, ChemIconKind.PREV -> {
                    val p = Path().apply { moveTo(64f, 18f); lineTo(32f, 50f); lineTo(64f, 82f) }
                    drawPath(p, color, style = st)
                }
                ChemIconKind.NEXT -> {
                    val p = Path().apply { moveTo(36f, 18f); lineTo(68f, 50f); lineTo(36f, 82f) }
                    drawPath(p, color, style = st)
                }
                ChemIconKind.SEARCH -> {
                    drawCircle(color, radius = 26f, center = Offset(44f, 44f), style = st)
                    drawLine(color, Offset(63f, 63f), Offset(84f, 84f), strokeWidth + 1f, StrokeCap.Round)
                }
                ChemIconKind.CLOSE -> {
                    drawLine(color, Offset(24f, 24f), Offset(76f, 76f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(76f, 24f), Offset(24f, 76f), strokeWidth, StrokeCap.Round)
                }
                ChemIconKind.GRID -> {
                    drawRoundRect(color, Offset(16f, 16f), Size(28f, 28f), CornerRadius(6f, 6f), style = st)
                    drawRoundRect(color, Offset(56f, 16f), Size(28f, 28f), CornerRadius(6f, 6f), style = st)
                    drawRoundRect(color, Offset(16f, 56f), Size(28f, 28f), CornerRadius(6f, 6f), style = st)
                    drawRoundRect(color, Offset(56f, 56f), Size(28f, 28f), CornerRadius(6f, 6f), style = st)
                }
                ChemIconKind.LIST -> {
                    for (y in listOf(28f, 50f, 72f)) {
                        drawCircle(color, radius = 5f, center = Offset(22f, y))
                        drawLine(color, Offset(36f, y), Offset(84f, y), strokeWidth, StrokeCap.Round)
                    }
                }
                ChemIconKind.THERMO -> {
                    drawRoundRect(color, Offset(40f, 14f), Size(20f, 48f), CornerRadius(10f, 10f), style = st)
                    drawCircle(color, radius = 16f, center = Offset(50f, 72f), style = st)
                    drawCircle(color, radius = 8f, center = Offset(50f, 72f))
                    drawLine(color, Offset(50f, 38f), Offset(50f, 66f), strokeWidth, StrokeCap.Round)
                }
                ChemIconKind.STAR_OUTLINE, ChemIconKind.STAR_FILLED -> {
                    val star = Path()
                    for (i in 0 until 10) {
                        val r = if (i % 2 == 0) 36f else 15f
                        val ang = -PI / 2.0 + i * PI / 5.0
                        val x = 50f + (r * cos(ang)).toFloat()
                        val y = 52f + (r * sin(ang)).toFloat()
                        if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
                    }
                    star.close()
                    if (kind == ChemIconKind.STAR_FILLED) drawPath(star, color)
                    else drawPath(star, color, style = st)
                }
                ChemIconKind.COMPARE -> {
                    drawLine(color, Offset(18f, 34f), Offset(78f, 34f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(62f, 20f), Offset(78f, 34f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(62f, 48f), Offset(78f, 34f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(82f, 66f), Offset(22f, 66f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(38f, 52f), Offset(22f, 66f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(38f, 80f), Offset(22f, 66f), strokeWidth, StrokeCap.Round)
                }
                ChemIconKind.NOTE -> {
                    drawRoundRect(color, Offset(20f, 14f), Size(60f, 72f), CornerRadius(10f, 10f), style = st)
                    drawLine(color, Offset(34f, 36f), Offset(66f, 36f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(34f, 52f), Offset(66f, 52f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(34f, 68f), Offset(52f, 68f), strokeWidth, StrokeCap.Round)
                }
                ChemIconKind.FLASK -> {
                    val p = Path().apply {
                        moveTo(36f, 16f); lineTo(64f, 16f)
                        moveTo(42f, 16f); lineTo(42f, 40f); lineTo(20f, 78f)
                        quadraticTo(17f, 84f, 24f, 84f); lineTo(76f, 84f)
                        quadraticTo(83f, 84f, 80f, 78f); lineTo(58f, 40f); lineTo(58f, 16f)
                    }
                    drawPath(p, color, style = st)
                    drawLine(color, Offset(30f, 64f), Offset(70f, 64f), strokeWidth - 1f, StrokeCap.Round)
                }
                ChemIconKind.ATOM -> {
                    drawCircle(color, radius = 8f, center = Offset(50f, 50f))
                    drawOval(color, Offset(14f, 34f), Size(72f, 32f), style = st)
                    withTransform({ rotate(60f, Offset(50f, 50f)) }) {
                        drawOval(color, Offset(14f, 34f), Size(72f, 32f), style = st)
                    }
                    withTransform({ rotate(120f, Offset(50f, 50f)) }) {
                        drawOval(color, Offset(14f, 34f), Size(72f, 32f), style = st)
                    }
                }
                ChemIconKind.FLAME -> {
                    val p = Path().apply {
                        moveTo(50f, 14f)
                        cubicTo(74f, 38f, 78f, 64f, 50f, 86f)
                        cubicTo(22f, 64f, 26f, 38f, 50f, 14f)
                        close()
                    }
                    drawPath(p, color, style = st)
                }
                ChemIconKind.RADIATION -> {
                    drawCircle(color, radius = 9f, center = Offset(50f, 50f))
                    for (deg in listOf(-30f, 90f, 210f)) {
                        drawArc(color, startAngle = deg, sweepAngle = 60f, useCenter = false, topLeft = Offset(18f, 18f), size = Size(64f, 64f), style = Stroke(12f, cap = StrokeCap.Butt))
                    }
                }
                ChemIconKind.EXIT_LABS -> {
                    val p = Path().apply {
                        moveTo(52f, 18f); lineTo(22f, 18f); lineTo(22f, 82f); lineTo(52f, 82f)
                    }
                    drawPath(p, color, style = st)
                    drawLine(color, Offset(44f, 50f), Offset(82f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(68f, 36f), Offset(82f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(68f, 64f), Offset(82f, 50f), strokeWidth, StrokeCap.Round)
                }
                ChemIconKind.MATH_SHORTCUT -> {
                    val p = Path().apply {
                        moveTo(74f, 20f); lineTo(26f, 20f); lineTo(54f, 50f); lineTo(26f, 80f); lineTo(74f, 80f)
                    }
                    drawPath(p, color, style = st)
                }
                ChemIconKind.SPARKLE -> {
                    val p = Path().apply {
                        moveTo(50f, 12f); quadraticTo(52f, 48f, 88f, 50f)
                        quadraticTo(52f, 52f, 50f, 88f)
                        quadraticTo(48f, 52f, 12f, 50f)
                        quadraticTo(48f, 48f, 50f, 12f); close()
                    }
                    drawPath(p, color)
                }
            }
        }
    }
}

// ==============================================================================
// HERO CON FOTO REAL DEL ELEMENTO + RESPALDO CIENTÍFICO PARA SINTÉTICOS (100-118)
// ==============================================================================

@Composable
fun ElementRealPhotoHero(
    element: ChemElement,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val photo by produceState<ImageBitmap?>(initialValue = null, element.z) {
        value = withContext(Dispatchers.IO) { ChemRepository.loadElementPhoto(ctx, element.z) }
    }
    val flameColor = remember(element.flameHex) { parseHexColorOrNull(element.flameHex) }
    val glowColor = flameColor ?: accent

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(225.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF0A0E15))
            .border(1.2.dp, chemGlassBorder(glowColor), RoundedCornerShape(24.dp))
    ) {
        if (photo != null) {
            Image(
                bitmap = photo!!,
                contentDescription = element.sampleCaption,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Degradado sutil inferior para legibilidad impecable
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        listOf(Color(0x33000000), Color(0x11000000), Color(0xCC06090F))
                    )
                )
            )
        } else {
            // Respaldo científico para sintéticos (100–118) o si no se bajaron fotos offline
            ScientificSpecimenBackdrop(element = element, glowColor = glowColor, modifier = Modifier.fillMaxSize())
        }

        // Insignia superior izquierda: número atómico + familia + radiactividad
        Row(
            Modifier.align(Alignment.TopStart).padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.clip(RoundedCornerShape(50))
                    .background(Color(0xAA0A0F18))
                    .border(1.dp, glowColor.copy(alpha = 0.65f), RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    "Z = ${element.z} · ${element.category.shortLabel}",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if (element.radioactive) {
                Row(
                    Modifier.clip(RoundedCornerShape(50))
                        .background(Color(0xCC991B1B))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ChemIcon(ChemIconKind.RADIATION, Color(0xFFFDE047), Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Radiactivo", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Insignia superior derecha: color de ensayo a la llama si aplica
        if (element.flameName.isNotBlank() && flameColor != null) {
            Row(
                Modifier.align(Alignment.TopEnd).padding(12.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xB80A0F18))
                    .border(1.dp, flameColor.copy(alpha = 0.8f), RoundedCornerShape(50))
                    .padding(horizontal = 9.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(flameColor))
                Spacer(Modifier.width(5.dp))
                Text("Llama", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Pie de foto estilo vidrio líquido con Símbolo, Nombre y descripción de muestra
        Row(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Box(
                Modifier.size(62.dp).clip(RoundedCornerShape(16.dp))
                    .background(glowColor.copy(alpha = 0.22f))
                    .border(1.5.dp, glowColor.copy(alpha = 0.85f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    element.symbol,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(element.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "${element.latin}  ·  ${element.massText} u",
                    color = Color(0xFFD6E2F0),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (element.sampleCaption.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Text(
                        if (photo != null) element.sampleCaption else element.appearance,
                        color = Color(0xFFB3C3D6),
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/** Fondo procedural limpio para elementos sintéticos (Z=100..118) o sin foto descargada. */
@Composable
private fun ScientificSpecimenBackdrop(element: ChemElement, glowColor: Color, modifier: Modifier) {
    val dominantSpec = remember(element.spectrumNm, glowColor) {
        element.spectrumNm.lastOrNull()?.let { wavelengthToColor(it) } ?: glowColor
    }
    Canvas(modifier = modifier) {
        val w = size.width; val h = size.height
        drawRect(
            Brush.radialGradient(
                colors = listOf(dominantSpec.copy(alpha = 0.38f), Color(0xFF0E1520), Color(0xFF070B11)),
                center = Offset(w * 0.68f, h * 0.36f),
                radius = w * 0.72f
            )
        )
        // Rejilla fina de espectroscopía
        val gridCol = Color(0x14FFFFFF)
        val step = 28f * density
        var x = step
        while (x < w) { drawLine(gridCol, Offset(x, 0f), Offset(x, h), 1f); x += step }
        var y = step
        while (y < h) { drawLine(gridCol, Offset(0f, y), Offset(w, y), 1f); y += step }

        // Silueta de laboratorio (tubo de plasma para gases, ampolla para líquidos, placa atómica para sintéticos/sólidos)
        val cx = w * 0.72f; val cy = h * 0.42f
        if (element.phase25 == "Gas") {
            // Tubo de descarga luminiscente
            drawRoundRect(
                color = dominantSpec.copy(alpha = 0.25f),
                topLeft = Offset(cx - 24.dp.toPx(), cy - 58.dp.toPx()),
                size = Size(48.dp.toPx(), 116.dp.toPx()),
                cornerRadius = CornerRadius(24.dp.toPx(), 24.dp.toPx())
            )
            drawLine(dominantSpec, Offset(cx, cy - 42.dp.toPx()), Offset(cx, cy + 42.dp.toPx()), strokeWidth = 10.dp.toPx(), cap = StrokeCap.Round)
            drawLine(Color.White.copy(alpha = 0.85f), Offset(cx, cy - 40.dp.toPx()), Offset(cx, cy + 40.dp.toPx()), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
            drawRoundRect(
                color = Color.White.copy(alpha = 0.45f),
                topLeft = Offset(cx - 24.dp.toPx(), cy - 58.dp.toPx()),
                size = Size(48.dp.toPx(), 116.dp.toPx()),
                cornerRadius = CornerRadius(24.dp.toPx(), 24.dp.toPx()),
                style = Stroke(2.dp.toPx())
            )
        } else {
            // Anillos atómicos orbitales de precisión
            for (rIdx in 1..3) {
                val r = (24 + rIdx * 18).dp.toPx()
                drawCircle(glowColor.copy(alpha = 0.42f - rIdx * 0.08f), radius = r, center = Offset(cx, cy), style = Stroke(2f))
            }
            drawCircle(glowColor.copy(alpha = 0.8f), radius = 12.dp.toPx(), center = Offset(cx, cy))
        }
    }
}

// ==============================================================================
// DIAGRAMA DE BOHR ANIMADO A 60 FPS + BARRA DE ESPECTRO DE EMISIÓN REAL
// ==============================================================================

@Composable
fun BohrAtomCanvas(
    element: ChemElement,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "bohr")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Restart),
        label = "orbit"
    )
    val dark = chemIsDark()
    val ringColor = if (dark) Color(0x38FFFFFF) else Color(0x280F172A)
    val innerDot = if (dark) Color(0xFFCBD5E1) else Color(0xFF475569)

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val maxR = size.minDimension * 0.45f
            val shellCount = element.shells.size.coerceAtLeast(1)
            val coreR = (size.minDimension * 0.11f).coerceAtLeast(14f)

            // Núcleo con brillo sutil
            drawCircle(accent.copy(alpha = 0.20f), radius = coreR * 1.45f, center = Offset(cx, cy))
            drawCircle(accent, radius = coreR, center = Offset(cx, cy))

            element.shells.forEachIndexed { idx, count ->
                val frac = (idx + 1).toFloat() / shellCount
                val r = coreR + 10f + (maxR - coreR - 10f) * frac
                val isValence = idx == element.shells.lastIndex
                drawCircle(
                    color = if (isValence) accent.copy(alpha = 0.65f) else ringColor,
                    radius = r,
                    center = Offset(cx, cy),
                    style = Stroke(width = if (isValence) 2.2f else 1.4f)
                )
                val speedMul = if (idx % 2 == 0) 1f else -1f
                val step = (2.0 * PI / count.coerceAtLeast(1))
                for (e in 0 until count) {
                    val ang = phase * speedMul * (1f / (idx + 1f)) + e * step
                    val ex = cx + (r * cos(ang)).toFloat()
                    val ey = cy + (r * sin(ang)).toFloat()
                    drawCircle(
                        color = if (isValence) accent else innerDot,
                        radius = if (isValence) 4.8f else 3.4f,
                        center = Offset(ex, ey)
                    )
                }
            }
        }
        Text(
            element.symbol,
            color = if (dark) Color(0xFF07111A) else Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 13.sp
        )
    }
}

@Composable
fun EmissionSpectrumBar(
    wavelengthsNm: List<Int>,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.fillMaxWidth().height(26.dp).clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF06080C))
                .border(1.dp, chemGlassBorder(), RoundedCornerShape(8.dp))
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width; val h = size.height
                // Referencia tenue del espectro continuo en el fondo
                for (nm in 380..760 step 4) {
                    val x = ((nm - 380f) / 380f) * w
                    drawLine(wavelengthToColor(nm).copy(alpha = 0.08f), Offset(x, 0f), Offset(x, h), strokeWidth = 3f)
                }
                // Líneas de emisión reales del elemento
                wavelengthsNm.forEach { nm ->
                    if (nm in 380..780) {
                        val x = ((nm - 380f) / 400f).coerceIn(0.02f, 0.98f) * w
                        val col = wavelengthToColor(nm)
                        drawLine(col.copy(alpha = 0.35f), Offset(x, 0f), Offset(x, h), strokeWidth = 7f)
                        drawLine(col, Offset(x, 0f), Offset(x, h), strokeWidth = 2.6f)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("380 nm (UV)", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Espectro de emisión", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("780 nm (IR)", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
