package com.abstergo.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.UUID

val RedColor = Color(0xFFE53935)

/** Bolita roja de "nuevo". */
@Composable
fun RedDot(modifier: Modifier = Modifier) {
    Box(modifier.size(10.dp).clip(CircleShape).background(RedColor))
}

@Composable
fun EntrenarTab(exercises: List<Exercise>, open: String?, onOpen: (String?) -> Unit, onChange: (List<Exercise>) -> Unit) {
    var detail by remember { mutableStateOf<String?>(null) }
    var adding by remember { mutableStateOf(false) }
    BackHandler(enabled = open != null) { onOpen(null) }
    // Al abrir un ejercicio nuevo, se quita su bolita roja
    LaunchedEffect(detail) {
        val id = detail ?: return@LaunchedEffect
        if (exercises.any { it.id == id && it.isNew }) {
            onChange(exercises.map { if (it.id == id) it.copy(isNew = false) else it })
        }
    }
    val groups = exercises.groupBy { it.subject }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (open == null) "Labs" else subjectLabel(open) + " Labs", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (open != null) {
                OutlinedButton({ onOpen(null) }, shape = RoundedCornerShape(14.dp)) { Text("Volver") }
                Spacer(Modifier.width(8.dp))
            }
            Button({ adding = true }, shape = RoundedCornerShape(14.dp)) { Text("Nuevo") }
        }
        if (open == null) {
            LabsDesktop(groups, onOpen)
        } else {
            val list = exercises.filter { it.subject == open }
            if (list.isEmpty()) {
                Text("Aún no hay ejercicios en este laboratorio. Toca Nuevo para crear uno o recíbelos desde Compartir.",
                    Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.id }) { e ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(30.dp).clip(CircleShape)
                                .background(if (e.done) MaterialTheme.colorScheme.primary else Color.Transparent)
                                .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                .clickable { onChange(exercises.map { if (it.id == e.id) it.copy(done = !it.done) else it }) },
                            contentAlignment = Alignment.Center
                        ) { if (e.done) Text("✓", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f).clickable { detail = e.id }) {
                            Text(
                                e.title, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                textDecoration = if (e.done) TextDecoration.LineThrough else null
                            )
                            if (e.text.isNotBlank()) {
                                Text(e.text, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        if (e.isNew) { Spacer(Modifier.width(10.dp)); RedDot() }
                    }
                }
            }
        }
    }

    val shown = exercises.firstOrNull { it.id == detail }
    if (shown != null) {
        AlertDialog(
            onDismissRequest = { detail = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text(shown.title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(subjectLabel(shown.subject), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(shown.text.ifBlank { "Sin enunciado." })
                }
            },
            confirmButton = { TextButton({ detail = null }) { Text("Cerrar") } },
            dismissButton = {
                TextButton({ onChange(exercises.filterNot { it.id == shown.id }); detail = null }) { Text("Eliminar") }
            }
        )
    }

    if (adding) {
        var subj by remember { mutableStateOf(open ?: "m") }
        var title by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Nuevo ejercicio") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SUBJECTS.forEach { (k, v) -> FilterChip(selected = subj == k, onClick = { subj = k }, label = { Text(v) }) }
                    }
                    OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Título") }, singleLine = true)
                    OutlinedTextField(body, { body = it }, Modifier.fillMaxWidth(), label = { Text("Enunciado") }, minLines = 3)
                }
            },
            confirmButton = {
                TextButton({
                    if (title.isNotBlank()) {
                        onChange(exercises + Exercise(UUID.randomUUID().toString(), subj, title.trim(), body.trim()))
                        adding = false
                    }
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton({ adding = false }) { Text("Cancelar") } }
        )
    }
}

// ---------- Escritorio de aplicaciones: un laboratorio por asignatura ----------
private val LAB_ICONS = mapOf(
    "q" to Pair("⚗️", 285f), "f" to Pair("⚛️", 215f), "m" to Pair("📐", 150f), "h" to Pair("📜", 35f),
    "cp" to Pair("🏛️", 350f), "i" to Pair("💬", 190f), "g" to Pair("🌍", 120f), "ll" to Pair("📖", 20f),
    "b" to Pair("🌱", 100f), "inf" to Pair("💻", 235f), "ef" to Pair("⚽", 5f), "dr" to Pair("🗣️", 300f),
    "ca" to Pair("🎨", 320f), "ac" to Pair("⭐", 50f), "fl" to Pair("🔧", 170f)
)

@Composable
private fun LabsDesktop(groups: Map<String, List<Exercise>>, onOpen: (String?) -> Unit) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    LazyVerticalGrid(
        columns = GridCells.Fixed(3), contentPadding = PaddingValues(20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        items(SUBJECTS.entries.toList(), key = { it.key }) { s ->
            val list = groups[s.key].orEmpty()
            val icon = LAB_ICONS[s.key] ?: Pair("🔬", 200f)
            Column(
                Modifier.clip(RoundedCornerShape(16.dp)).clickable { onOpen(s.key) }.padding(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box {
                    Box(
                        Modifier.size(68.dp).clip(RoundedCornerShape(20.dp))
                            .background(hsl(icon.second, if (dark) 0.38f else 0.65f, if (dark) 0.30f else 0.86f)),
                        contentAlignment = Alignment.Center
                    ) { Text(icon.first, fontSize = 34.sp) }
                    if (list.any { it.isNew }) RedDot(Modifier.align(Alignment.TopEnd))
                    if (list.isNotEmpty()) {
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) { Text("${list.size}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(s.value + " Labs", fontSize = 12.sp, lineHeight = 15.sp, maxLines = 2, textAlign = TextAlign.Center, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
