# Reglas del APK optimizado (R8). Si algún día falla la compilación por R8, en app/build.gradle.kts
# cambia isMinifyEnabled a false en el tipo "debug".
-ignorewarnings
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keep class com.abstergo.app.** { *; }
-dontwarn javax.annotation.**
-dontwarn org.checkerframework.**
-dontwarn com.google.errorprone.annotations.**
