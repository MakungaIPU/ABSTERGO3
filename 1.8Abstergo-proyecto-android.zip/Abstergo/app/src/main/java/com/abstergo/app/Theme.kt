package com.abstergo.app

import android.content.SharedPreferences
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import kotlin.math.abs

data class ThemeDef(val id: String, val name: String, val hue: Float, val neutral: Float)

val THEMES = listOf(
    ThemeDef("abstergo", "Abstergo", 145f, 0.22f),
    ThemeDef("oceano", "Océano", 212f, 0.25f),
    ThemeDef("violeta", "Violeta", 262f, 0.22f),
    ThemeDef("atardecer", "Atardecer", 22f, 0.30f),
    ThemeDef("rosa", "Rosa", 335f, 0.22f),
    ThemeDef("grafito", "Grafito", 220f, 0.05f)
)

fun hsl(h: Float, s: Float, l: Float): Color {
    val c = (1f - abs(2f * l - 1f)) * s
    val hp = (h % 360f) / 60f
    val x = c * (1f - abs(hp % 2f - 1f))
    val t = when {
        hp < 1f -> Triple(c, x, 0f)
        hp < 2f -> Triple(x, c, 0f)
        hp < 3f -> Triple(0f, c, x)
        hp < 4f -> Triple(0f, x, c)
        hp < 5f -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    val m = l - c / 2f
    return Color(t.first + m, t.second + m, t.third + m)
}

/** La tonalidad del color cambia según el modo claro u oscuro. */
fun schemeFor(t: ThemeDef, dark: Boolean): ColorScheme {
    val h = t.hue
    val n = t.neutral
    val acc = if (n < 0.1f) 0.10f else 0.62f
    return if (!dark) lightColorScheme(
        primary = hsl(h, acc, 0.30f), onPrimary = Color.White,
        primaryContainer = hsl(h, acc * 0.7f, 0.86f), onPrimaryContainer = hsl(h, acc, 0.14f),
        secondary = hsl(h, acc * 0.8f, 0.36f), onSecondary = Color.White,
        secondaryContainer = hsl(h, acc * 0.6f, 0.86f), onSecondaryContainer = hsl(h, acc, 0.14f),
        background = hsl(h, n, 0.965f), onBackground = hsl(h, n + 0.1f, 0.10f),
        surface = hsl(h, n, 0.925f), onSurface = hsl(h, n + 0.1f, 0.10f),
        surfaceVariant = hsl(h, n, 0.88f), onSurfaceVariant = hsl(h, n * 0.6f, 0.34f),
        outline = hsl(h, n * 0.6f, 0.55f), outlineVariant = hsl(h, n * 0.6f, 0.80f),
        error = Color(0xFFB3261E), onError = Color.White,
        surfaceContainerLowest = Color.White, surfaceContainerLow = hsl(h, n, 0.95f),
        surfaceContainer = hsl(h, n, 0.93f), surfaceContainerHigh = hsl(h, n, 0.90f),
        surfaceContainerHighest = hsl(h, n, 0.87f)
    ) else darkColorScheme(
        primary = hsl(h, if (n < 0.1f) 0.08f else 0.70f, 0.70f), onPrimary = hsl(h, 0.5f, 0.10f),
        primaryContainer = hsl(h, acc * 0.7f, 0.24f), onPrimaryContainer = hsl(h, acc, 0.88f),
        secondary = hsl(h, acc * 0.7f, 0.68f), onSecondary = hsl(h, 0.5f, 0.10f),
        secondaryContainer = hsl(h, acc * 0.5f, 0.26f), onSecondaryContainer = hsl(h, acc, 0.90f),
        background = hsl(h, n * 0.9f, 0.075f), onBackground = hsl(h, n * 0.8f, 0.93f),
        surface = hsl(h, n * 0.9f, 0.115f), onSurface = hsl(h, n * 0.8f, 0.93f),
        surfaceVariant = hsl(h, n * 0.8f, 0.17f), onSurfaceVariant = hsl(h, n * 0.5f, 0.72f),
        outline = hsl(h, n * 0.5f, 0.45f), outlineVariant = hsl(h, n * 0.5f, 0.28f),
        error = Color(0xFFF2B8B5), onError = Color(0xFF601410),
        surfaceContainerLowest = hsl(h, n, 0.05f), surfaceContainerLow = hsl(h, n, 0.09f),
        surfaceContainer = hsl(h, n, 0.125f), surfaceContainerHigh = hsl(h, n, 0.16f),
        surfaceContainerHighest = hsl(h, n, 0.20f)
    )
}

/** Formato de hora global (12 h / 24 h) usado por el horario. */
val TIME24 = mutableStateOf(false)

class Settings(private val prefs: SharedPreferences) {
    var mode by mutableStateOf(prefs.getString("mode", "system") ?: "system")
        private set
    var theme by mutableStateOf(prefs.getString("theme", "abstergo") ?: "abstergo")
        private set
    var scale by mutableStateOf(prefs.getFloat("scale", 1f))
        private set
    var time24 by mutableStateOf(prefs.getBoolean("time24", false))
        private set

    init { TIME24.value = time24 }

    fun changeMode(v: String) { mode = v; prefs.edit().putString("mode", v).apply() }
    fun changeTheme(v: String) { theme = v; prefs.edit().putString("theme", v).apply() }
    fun changeScale(v: Float) { scale = v; prefs.edit().putFloat("scale", v).apply() }
    fun changeTime24(v: Boolean) { time24 = v; TIME24.value = v; prefs.edit().putBoolean("time24", v).apply() }
    fun resetDefaults() { changeMode("system"); changeTheme("abstergo"); changeScale(1f); changeTime24(false) }
}
