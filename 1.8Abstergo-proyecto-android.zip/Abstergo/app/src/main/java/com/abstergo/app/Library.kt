package com.abstergo.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.Parcelable
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLDecoder
import java.util.UUID
import java.util.zip.ZipFile

data class LibItem(val id: String, val name: String, val ext: String, val file: String, val cover: String?, val cat: String = "Sin categoría", val isNew: Boolean = false)

/** Categorías manuales: se elige con "Mover a:" al mantener presionado un archivo. */
val LIB_CATS = listOf("Clases", "Libros", "Videos", "Documentos", "Tareas", "Exámenes", "Otros")

private fun libDir(ctx: Context) = File(ctx.filesDir, "library").also { it.mkdirs() }
private fun coverDir(ctx: Context) = File(libDir(ctx), "covers").also { it.mkdirs() }
private fun indexFile(ctx: Context) = File(ctx.filesDir, "library.json")
fun libFile(ctx: Context, item: LibItem) = File(libDir(ctx), item.file)
fun coverFile(ctx: Context, item: LibItem): File? = item.cover?.let { File(coverDir(ctx), it) }

fun loadLibrary(ctx: Context): List<LibItem> = try {
    val a = JSONArray(indexFile(ctx).readText())
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        LibItem(o.getString("id"), o.getString("name"), o.optString("ext"), o.getString("file"), if (o.has("cover")) o.getString("cover") else null, o.optString("cat", "Sin categoría"), o.optBoolean("new", false))
    }
} catch (e: Exception) { emptyList() }

private fun saveLibrary(ctx: Context, list: List<LibItem>) {
    val a = JSONArray()
    list.forEach { b ->
        val o = JSONObject().put("id", b.id).put("name", b.name).put("ext", b.ext).put("file", b.file).put("cat", b.cat).put("new", b.isNew)
        if (b.cover != null) o.put("cover", b.cover)
        a.put(o)
    }
    indexFile(ctx).writeText(a.toString())
}

/** Copia el archivo a la biblioteca y genera su portada (PDF, EPUB, Office con miniatura o imagen). */
fun importToLibrary(ctx: Context, uri: Uri): LibItem? = try {
    val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex("_display_name"); if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: "archivo"
    val ext = name.substringAfterLast('.', "").lowercase().take(8)
    val id = UUID.randomUUID().toString()
    val stored = if (ext.isEmpty()) id else "$id.$ext"
    val f = File(libDir(ctx), stored)
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    val item = LibItem(id, name.substringBeforeLast('.', name), ext, stored, makeCover(ctx, f, ext, id))
    saveLibrary(ctx, loadLibrary(ctx) + item)
    item
} catch (e: Exception) { null }

fun markLibSeen(ctx: Context, item: LibItem) {
    saveLibrary(ctx, loadLibrary(ctx).map { if (it.id == item.id) it.copy(isNew = false) else it })
}

/** Guarda en la biblioteca un archivo recibido por Wi-Fi Direct (lee exactamente `size` bytes). */
fun receiveToLibrary(ctx: Context, inp: java.io.InputStream, size: Long, fullName: String, cat: String): LibItem? = try {
    val ext = fullName.substringAfterLast('.', "").lowercase().take(8)
    val id = UUID.randomUUID().toString()
    val stored = if (ext.isEmpty()) id else "$id.$ext"
    val f = File(libDir(ctx), stored)
    f.outputStream().use { o ->
        val buf = ByteArray(64 * 1024)
        var left = size
        while (left > 0) {
            val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) throw java.io.EOFException()
            o.write(buf, 0, n)
            left -= n
        }
    }
    val item = LibItem(id, fullName.substringBeforeLast('.', fullName), ext, stored, makeCover(ctx, f, ext, id), cat, true)
    saveLibrary(ctx, loadLibrary(ctx) + item)
    item
} catch (e: Exception) { null }

/** Foto o imagen derecha: lee la orientación EXIF (las fotos de cámara vienen "de lado") y la aplica. */
fun uprightBitmap(f: File, maxDim: Int): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, o)
    if (o.outWidth <= 0) return null
    var s = 1
    while (o.outWidth / (s * 2) >= maxDim || o.outHeight / (s * 2) >= maxDim) s *= 2
    val bm = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    val orient = try {
        android.media.ExifInterface(f.path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)
    } catch (e: Exception) { 1 }
    val m = android.graphics.Matrix()
    when (orient) {
        2 -> m.postScale(-1f, 1f)
        3 -> m.postRotate(180f)
        4 -> m.postScale(1f, -1f)
        5 -> { m.postRotate(90f); m.postScale(-1f, 1f) }
        6 -> m.postRotate(90f)
        7 -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
        8 -> m.postRotate(-90f)
        else -> return bm
    }
    return Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
}

/** Guarda un archivo propio de la app (por ejemplo una foto de la cámara) en la biblioteca. */
fun addFileToLibrary(ctx: Context, src: File, displayName: String, cat: String): LibItem? = try {
    val ext = src.extension.lowercase().take(8)
    val id = UUID.randomUUID().toString()
    val stored = if (ext.isEmpty()) id else "$id.$ext"
    val dest = File(libDir(ctx), stored)
    src.copyTo(dest, overwrite = true)
    src.delete()
    val item = LibItem(id, displayName, ext, stored, makeCover(ctx, dest, ext, id), cat)
    saveLibrary(ctx, loadLibrary(ctx) + item)
    item
} catch (e: Exception) { null }

// ---------- Categorías personalizadas (se agregan con el "+" de la biblioteca) ----------
private fun appPrefs(ctx: Context) = ctx.getSharedPreferences("abstergo", Context.MODE_PRIVATE)

fun customCats(ctx: Context): List<String> = (appPrefs(ctx).getString("lib_cats", "") ?: "").split('\n').filter { it.isNotBlank() }
fun libCategories(ctx: Context): List<String> = LIB_CATS + customCats(ctx)

fun addCustomCat(ctx: Context, name: String): Boolean {
    val n = name.replace('\n', ' ').trim().take(30)
    if (n.isEmpty() || n == "Sin categoría" || n == "Todos" || libCategories(ctx).any { it.equals(n, ignoreCase = true) }) return false
    appPrefs(ctx).edit().putString("lib_cats", (customCats(ctx) + n).joinToString("\n")).apply()
    return true
}

fun deleteCustomCat(ctx: Context, name: String) {
    appPrefs(ctx).edit().putString("lib_cats", customCats(ctx).filterNot { it == name }.joinToString("\n")).apply()
    saveLibrary(ctx, loadLibrary(ctx).map { if (it.cat == name) it.copy(cat = "Sin categoría") else it })
}

fun moveLibItem(ctx: Context, item: LibItem, cat: String) {
    saveLibrary(ctx, loadLibrary(ctx).map { if (it.id == item.id) it.copy(cat = cat) else it })
}

fun deleteLibItem(ctx: Context, item: LibItem) {
    libFile(ctx, item).delete()
    coverFile(ctx, item)?.delete()
    saveLibrary(ctx, loadLibrary(ctx).filterNot { it.id == item.id })
}

fun openLibItem(ctx: Context, item: LibItem) {
    val f = libFile(ctx, item)
    if (!f.exists()) { Toast.makeText(ctx, "El archivo ya no existe.", Toast.LENGTH_SHORT).show(); return }
    val uri = FileProvider.getUriForFile(ctx, "com.abstergo.app.files", f)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(item.ext) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    val chooser = Intent.createChooser(view, "Abrir con")
        .putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf<Parcelable>(ComponentName(ctx, MainActivity::class.java)))
    try { ctx.startActivity(chooser) } catch (e: Exception) {
        Toast.makeText(ctx, "No hay una app que pueda abrir este archivo.", Toast.LENGTH_SHORT).show()
    }
}

// ---------- Portadas ----------
private fun makeCover(ctx: Context, f: File, ext: String, id: String): String? {
    val bmp: Bitmap? = try {
        when (ext) {
            "pdf" -> pdfCover(f)
            "epub" -> epubCover(f)
            "docx", "pptx", "xlsx" -> officeThumb(f)
            "jpg", "jpeg", "png", "webp", "heic", "heif" -> uprightBitmap(f, 800)
            "mp4", "mkv", "3gp", "webm", "mov" -> videoFrame(f)
            else -> null
        }
    } catch (e: Throwable) { null }
    if (bmp == null) return null
    val out = File(coverDir(ctx), "$id.jpg")
    out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
    return out.name
}

private fun videoFrame(f: File): Bitmap? {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(f.path)
        val fr = r.getFrameAtTime(1_000_000) ?: r.getFrameAtTime() ?: return null
        return Bitmap.createScaledBitmap(fr, 500, fr.height * 500 / fr.width, true)
    } finally { r.release() }
}

private fun decode(b: ByteArray): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(b, 0, b.size, o)
    var s = 1
    while (o.outWidth / (s * 2) >= 500) s *= 2
    val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
    return if (bm.width > 500) Bitmap.createScaledBitmap(bm, 500, bm.height * 500 / bm.width, true) else bm
}

private fun pdfCover(f: File): Bitmap? {
    val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    val r = PdfRenderer(pfd)
    try {
        if (r.pageCount == 0) return null
        val p = r.openPage(0)
        try {
            val h = (500f * p.height / p.width).toInt().coerceAtLeast(1)
            val bm = Bitmap.createBitmap(500, h, Bitmap.Config.ARGB_8888)
            Canvas(bm).drawColor(android.graphics.Color.WHITE)
            p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bm
        } finally { p.close() }
    } finally { r.close(); pfd.close() }
}

private fun epubCover(f: File): Bitmap? {
    val z = ZipFile(f)
    try {
        fun text(n: String): String? = z.getEntry(n)?.let { z.getInputStream(it).readBytes().toString(Charsets.UTF_8) }
        val container = text("META-INF/container.xml") ?: return null
        val opfPath = Regex("full-path=\"([^\"]+)\"").find(container)?.groupValues?.get(1) ?: return null
        val opf = text(opfPath) ?: return null
        val dir = if (opfPath.contains('/')) opfPath.substringBeforeLast('/') + "/" else ""
        val items = Regex("<item\\b[^>]*>").findAll(opf).map { it.value }.toList()
        fun attr(tag: String, a: String): String? = Regex("\\b$a=\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
        var href = items.firstOrNull { attr(it, "properties")?.contains("cover-image") == true }?.let { attr(it, "href") }
        if (href == null) {
            val cid = Regex("<meta\\b[^>]*name=\"cover\"[^>]*>").find(opf)?.value?.let { attr(it, "content") }
            if (cid != null) href = items.firstOrNull { attr(it, "id") == cid }?.let { attr(it, "href") }
        }
        if (href == null) return null
        val entry = z.getEntry(dir + URLDecoder.decode(href, "UTF-8")) ?: return null
        return decode(z.getInputStream(entry).readBytes())
    } finally { z.close() }
}

private fun officeThumb(f: File): Bitmap? {
    val z = ZipFile(f)
    try {
        val e = z.getEntry("docProps/thumbnail.jpeg") ?: z.getEntry("docProps/thumbnail.png") ?: z.getEntry("docProps/thumbnail.jpg")
        return if (e == null) null else decode(z.getInputStream(e).readBytes())
    } finally { z.close() }
}
