package com.abstergo.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import kotlin.concurrent.thread

const val P2P_PORT = 8988
private const val MAX_BYTES = 8 * 1024 * 1024

// ---------- Receptor: crea la red Wi-Fi Direct y espera el envío ----------
@SuppressLint("MissingPermission")
class P2pReceiver(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onReady(qrText: String)
        fun onReceiving()
        fun onPayload(json: String, inp: DataInputStream): Received?
        fun onDone(r: Received)
        fun onError(msg: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var mgr: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var server: ServerSocket? = null
    @Volatile private var stopped = false
    @Volatile private var finished = false
    private val token = (1..8).map { "abcdefghjkmnpqrstuvwxyz23456789".random() }.joinToString("")

    private fun fail(msg: String) { if (!stopped) main.post { cb.onError(msg) } }

    fun start() {
        val m = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (m == null) { fail("Este teléfono no soporta Wi‑Fi Direct."); return }
        val ch = m.initialize(ctx, Looper.getMainLooper(), null)
        if (ch == null) { fail("No se pudo iniciar Wi‑Fi Direct."); return }
        mgr = m; channel = ch
        startServer()
        try {
            m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { create(m, ch) }
                override fun onFailure(reason: Int) { create(m, ch) }
            })
        } catch (e: SecurityException) {
            fail("Falta el permiso de dispositivos cercanos o ubicación.")
        }
    }

    private fun create(m: WifiP2pManager, ch: WifiP2pManager.Channel) {
        try {
            m.createGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { fetch(m, ch, 0) }
                override fun onFailure(reason: Int) {
                    fail("No se pudo crear la red Wi‑Fi Direct (código $reason). Activa el Wi‑Fi y la ubicación e inténtalo de nuevo.")
                }
            })
        } catch (e: SecurityException) {
            fail("Falta el permiso de dispositivos cercanos o ubicación.")
        }
    }

    private fun fetch(m: WifiP2pManager, ch: WifiP2pManager.Channel, n: Int) {
        if (stopped) return
        try {
            m.requestGroupInfo(ch) { g ->
                val pass = g?.passphrase
                if (g != null && !pass.isNullOrEmpty()) {
                    val qr = JSONObject().put("s", g.networkName).put("p", pass)
                        .put("h", "192.168.49.1").put("t", token).toString()
                    main.post { if (!stopped) cb.onReady(qr) }
                } else if (n < 6) {
                    main.postDelayed({ fetch(m, ch, n + 1) }, 600)
                } else fail("No se pudo obtener los datos de la red.")
            }
        } catch (e: SecurityException) {
            fail("Falta el permiso de dispositivos cercanos o ubicación.")
        }
    }

    private fun startServer() {
        thread(isDaemon = true) {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(P2P_PORT))
                server = ss
                while (!stopped && !finished) {
                    val s = ss.accept()
                    try { handle(s) } catch (e: Exception) { /* espera otra conexión */ } finally { s.close() }
                }
            } catch (e: Exception) {
                if (!stopped) fail("Error de red: ${e.message}")
            }
        }
    }

    private fun handle(s: java.net.Socket) {
        s.soTimeout = 20000
        val inp = DataInputStream(s.getInputStream())
        val out = DataOutputStream(s.getOutputStream())
        if (inp.readUTF() != token) { out.writeUTF("NO"); return }
        main.post { cb.onReceiving() }
        val n = inp.readInt()
        if (n <= 0 || n > MAX_BYTES) { out.writeUTF("NO"); return }
        val buf = ByteArray(n)
        inp.readFully(buf)
        val r = cb.onPayload(String(buf, Charsets.UTF_8), inp)
        if (r != null) {
            out.writeUTF("OK"); out.flush()
            finished = true
            main.post { cb.onDone(r) }
        } else {
            out.writeUTF("NO")
            fail("Lo que llegó no es válido.")
        }
    }

    fun stop() {
        stopped = true
        try { server?.close() } catch (_: Exception) {}
        val m = mgr; val c = channel
        if (m != null && c != null) { try { m.removeGroup(c, null) } catch (_: Exception) {} }
    }
}

// ---------- Emisor: escanea el QR, se conecta y envía ----------
object P2pSender {
    fun send(ctx: Context, qrText: String, payload: ByteArray, files: List<java.io.File>, onStatus: (String) -> Unit, onResult: (String?) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        fun finish(err: String?) { main.post { onResult(err) } }
        if (Build.VERSION.SDK_INT < 29) { finish("Enviar requiere Android 10 o superior."); return }
        val q = try { JSONObject(qrText) } catch (e: Exception) { finish("Ese código QR no es de Abstergo."); return }
        val ssid = q.optString("s"); val pass = q.optString("p")
        val host = q.optString("h"); val token = q.optString("t")
        if (ssid.isEmpty() || pass.isEmpty() || host.isEmpty() || token.isEmpty()) { finish("Ese código QR no es de Abstergo."); return }
        main.post { onStatus("Conectando… acepta la conexión si el teléfono lo pide") }
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(spec).build()
        val callback = object : ConnectivityManager.NetworkCallback() {
            var used = false
            override fun onAvailable(network: Network) {
                if (used) return
                used = true
                thread(isDaemon = true) {
                    var err: String? = null
                    try {
                        main.post { onStatus("Enviando…") }
                        val s = network.socketFactory.createSocket()
                        s.connect(InetSocketAddress(host, P2P_PORT), 10000)
                        s.soTimeout = 20000
                        val out = DataOutputStream(s.getOutputStream())
                        val inp = DataInputStream(s.getInputStream())
                        out.writeUTF(token); out.writeInt(payload.size); out.write(payload)
                        for (file in files) { out.writeLong(file.length()); file.inputStream().use { it.copyTo(out) } }
                        out.flush()
                        s.soTimeout = 180000
                        if (inp.readUTF() != "OK") err = "El otro dispositivo rechazó el envío."
                        s.close()
                    } catch (e: Exception) {
                        err = "No se pudo enviar: ${e.message}"
                    }
                    try { cm.unregisterNetworkCallback(this) } catch (_: Exception) {}
                    finish(err)
                }
            }
            override fun onUnavailable() {
                try { cm.unregisterNetworkCallback(this) } catch (_: Exception) {}
                finish("No se pudo conectar. Revisa que el otro dispositivo siga mostrando el código QR.")
            }
        }
        cm.requestNetwork(req, callback, 40000)
    }
}

fun qrBitmap(text: String, size: Int = 640): ImageBitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
    return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888).asImageBitmap()
}

// ---------- Pantalla Compartir ----------
sealed class Xfer {
    object Idle : Xfer()
    object Starting : Xfer()
    class Ready(val qr: ImageBitmap) : Xfer()
    class Busy(val text: String) : Xfer()
    class Done(val title: String, val sender: String?, val dests: List<Dest>) : Xfer()
    class Fail(val msg: String) : Xfer()
}

private class ShareCat(val id: String, val label: String, val symbol: Int)
private val SHARE_CATS = listOf(
    ShareCat("h", "Horarios", 0), ShareCat("b", "Biblioteca", 7),
    ShareCat("c", "Calendario", 4), ShareCat("e", "Entrenamientos", 3)
)

@Composable
fun ShareScreen(
    profile: Profile, schedules: List<Schedule>, exercises: List<Exercise>, library: List<LibItem>,
    onApplied: () -> Unit, onOpenDest: (Dest) -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var cat by remember { mutableStateOf("h") }
    var fab by remember { mutableStateOf(false) }
    var x by remember { mutableStateOf<Xfer>(Xfer.Idle) }
    val holder = remember { arrayOfNulls<P2pReceiver>(1) }
    var selS by remember { mutableStateOf(setOf<String>()) }
    var selE by remember { mutableStateOf(setOf<String>()) }
    var selL by remember { mutableStateOf(setOf<String>()) }
    DisposableEffect(Unit) { onDispose { holder[0]?.stop() } }

    fun reset() { holder[0]?.stop(); holder[0] = null; fab = false; x = Xfer.Idle }
    BackHandler { if (x === Xfer.Idle) onBack() else reset() }

    fun startReceive() {
        x = Xfer.Starting
        val r = P2pReceiver(ctx, object : P2pReceiver.Callback {
            override fun onReady(qrText: String) { x = Xfer.Ready(qrBitmap(qrText)) }
            override fun onReceiving() { x = Xfer.Busy("Recibiendo…") }
            override fun onPayload(json: String, inp: DataInputStream): Received? = applyPayload(ctx, json, inp)
            override fun onDone(r: Received) { onApplied(); x = Xfer.Done("¡Transferencia exitosa!", r.sender, r.dests) }
            override fun onError(msg: String) { x = Xfer.Fail(msg) }
        })
        holder[0] = r
        r.start()
    }

    fun doSend(code: String) {
        val sch = schedules.filter { "${it.date}|${it.group}" in selS }
        val ex = exercises.filter { it.subject in selE }
        val books = library.filter { it.id in selL }
        x = Xfer.Busy("Preparando…")
        val bytes = buildPayload(profile.name, sch, ex, books).toByteArray(Charsets.UTF_8)
        P2pSender.send(ctx, code, bytes, books.map { libFile(ctx, it) }, { s -> x = Xfer.Busy(s) }, { err ->
            x = if (err == null) Xfer.Done("¡Enviado con éxito!", null, emptyList()) else Xfer.Fail(err)
        })
    }

    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) startReceive() else x = Xfer.Fail("Sin ese permiso no puedo crear la red Wi‑Fi Direct.")
    }
    var scanning by remember { mutableStateOf(false) }
    if (scanning) {
        BackHandler { scanning = false }
        QrScanner({ code -> scanning = false; doSend(code) }, { scanning = false })
        return
    }

    fun countOf(id: String) = when (id) { "h" -> selS.size; "b" -> selL.size; "e" -> selE.size; else -> 0 }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Compartir", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton({ if (x === Xfer.Idle) onBack() else reset() }, shape = RoundedCornerShape(14.dp)) {
                Text(if (x === Xfer.Idle) "Volver" else "Cancelar")
            }
        }
        Spacer(Modifier.height(14.dp))
        when (val s = x) {
            Xfer.Idle -> {
                // Categorías
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SHARE_CATS.forEach { c -> CatTile(c, cat == c.id, countOf(c.id)) { cat = c.id } }
                }
                Spacer(Modifier.height(12.dp))
                // Contenido de la categoría elegida
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (cat) {
                        "h" -> PickList(
                            "No tienes horarios guardados.",
                            schedules.sortedByDescending { it.date.toEpochDay() }.map { "${it.date}|${it.group}" to "${dateText(it.date)} (grupo ${it.group})" },
                            selS
                        ) { selS = it }
                        "b" -> PickList(
                            "Tu biblioteca está vacía.",
                            library.map { b -> b.id to (b.name + (if (b.ext.isNotEmpty()) ".${b.ext}" else "") + " · ${b.cat}") },
                            selL
                        ) { selL = it }
                        "e" -> {
                            val groups = exercises.groupBy { it.subject }
                            PickList(
                                "Aún no tienes ejercicios.",
                                groups.keys.sortedBy { subjectLabel(it) }.map { k -> k to "${subjectLabel(k)} (${groups.getValue(k).size} ejercicios)" },
                                selE
                            ) { selE = it }
                        }
                        else -> Text("Aún no hay eventos del calendario para compartir.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                // Botón redondo: al tocarlo muestra Enviar / Recibir con iconos
                Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AnimatedVisibility(visible = fab, enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
                        Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(36.dp)) {
                            RoundOption(8, "Enviar") {
                                fab = false
                                if (selS.isEmpty() && selE.isEmpty() && selL.isEmpty()) {
                                    Toast.makeText(ctx, "Primero marca lo que quieres enviar.", Toast.LENGTH_SHORT).show()
                                } else scanning = true
                            }
                            RoundOption(9, "Recibir") { fab = false; permLauncher.launch(perms) }
                        }
                    }
                    Box(
                        Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable { fab = !fab },
                        contentAlignment = Alignment.Center
                    ) {
                        if (fab) Text("✕", color = MaterialTheme.colorScheme.onPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        else LineSymbol(6, 1f, MaterialTheme.colorScheme.onPrimary, Modifier.size(30.dp), 5f)
                    }
                }
            }
            Xfer.Starting -> Centered { CircularProgressIndicator(); Spacer(Modifier.height(16.dp)); Text("Creando la red Wi‑Fi Direct…") }
            is Xfer.Busy -> Centered { CircularProgressIndicator(); Spacer(Modifier.height(16.dp)); Text(s.text, textAlign = TextAlign.Center) }
            is Xfer.Ready -> Centered {
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White).padding(14.dp)) {
                    Image(s.qr, "Código QR", Modifier.size(260.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text("Pide al otro dispositivo que toque Enviar y escanee este código.", textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text("Activa el Wi‑Fi en los dos teléfonos.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            is Xfer.Done -> DonePane(s, onOpenDest) { reset() }
            is Xfer.Fail -> Centered {
                Text("No se pudo completar", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(s.msg, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(20.dp))
                Button({ reset() }, shape = RoundedCornerShape(14.dp)) { Text("Reintentar") }
            }
        }
    }
}

@Composable
private fun CatTile(c: ShareCat, selected: Boolean, count: Int, onClick: () -> Unit) {
    val fg = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground
    Column(
        Modifier.width(100.dp).clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
            .clickable { onClick() }.padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
            LineSymbol(c.symbol, 1f, fg, Modifier.size(32.dp), 5f)
            if (count > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).offset(x = 10.dp, y = (-6).dp).size(18.dp).clip(CircleShape)
                        .background(if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$count", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(c.label, fontSize = 12.sp, color = fg, maxLines = 1)
    }
}

@Composable
private fun RoundOption(symbol: Int, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onClick() }) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) { LineSymbol(symbol, 1f, MaterialTheme.colorScheme.onBackground, Modifier.size(28.dp), 5f) }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp)
    }
}

/** Lista con casillas: cada elemento es (clave, texto). */
@Composable
private fun PickList(emptyText: String, all: List<Pair<String, String>>, selected: Set<String>, onChange: (Set<String>) -> Unit) {
    if (all.isEmpty()) {
        Text(emptyText, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val allSelected = all.all { it.first in selected }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            TextButton({ onChange(if (allSelected) selected - all.map { it.first }.toSet() else selected + all.map { it.first }) }) {
                Text(if (allSelected) "Quitar todo" else "Seleccionar todo")
            }
        }
        items(all) { (k, label) ->
            PickRow(label, k in selected) { onChange(if (k in selected) selected - k else selected + k) }
        }
    }
}

@Composable
private fun ColumnScope.Centered(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center, content = content
    )
}

@Composable
private fun PickRow(text: String, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable { onToggle() }.padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked, { onToggle() })
        Text(text, Modifier.weight(1f))
    }
}

@Composable
private fun ColumnScope.DonePane(s: Xfer.Done, onOpen: (Dest) -> Unit, onClose: () -> Unit) {
    var go by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { go = true }
    val p by animateFloatAsState(if (go) 1f else 0f, tween(1000), label = "ok")
    var seen by remember { mutableStateOf(setOf<Int>()) }
    Column(
        Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        LineSymbol(5, p, MaterialTheme.colorScheme.primary, Modifier.size(130.dp), 4f)
        Spacer(Modifier.height(16.dp))
        Text(s.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        if (s.sender != null) Text("De: ${s.sender}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (s.dests.isNotEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text("Llegó a:", fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Start))
            Spacer(Modifier.height(6.dp))
            s.dests.forEachIndexed { i, d ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable { seen = seen + i; onOpen(d) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(d.label, Modifier.weight(1f))
                    if (i !in seen) RedDot()
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClose, shape = RoundedCornerShape(14.dp)) { Text("Listo") }
    }
}
