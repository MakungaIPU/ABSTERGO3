package com.abstergo.app

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Cámara propia de Abstergo, pensada para fotografiar la pizarra: máxima calidad, la mayor resolución
 * disponible en 4:3, enfoque continuo, toque para enfocar, zoom y flash. Las fotos se guardan solo en
 * la biblioteca de la app (nunca en la galería del teléfono).
 */
@Composable
fun CameraScreen(onClose: () -> Unit, onSaved: (LibItem) -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) req.launch(Manifest.permission.CAMERA) }
    BackHandler { onClose() }
    if (!granted) {
        Column(Modifier.fillMaxSize().background(Color.Black).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Necesito permiso de cámara para tomar fotos.", color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClose, shape = RoundedCornerShape(14.dp)) { Text("Cerrar", color = Color.White) }
        }
        return
    }

    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val selector = remember {
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY).build()
    }
    val capture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setResolutionSelector(selector).build()
    }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var flash by remember { mutableStateOf(ImageCapture.FLASH_MODE_OFF) }
    var zoom by remember { mutableStateOf(0f) }
    var shot by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            val p = future.get()
            provider = p
            val preview = Preview.Builder().setResolutionSelector(selector).build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            p.unbindAll()
            camera = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { provider?.unbindAll() }
    }
    LaunchedEffect(flash) { capture.flashMode = flash }
    LaunchedEffect(zoom, camera) { camera?.cameraControl?.setLinearZoom(zoom) }

    fun focusAt(o: Offset) {
        val c = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(o.x, o.y)
        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
    }

    fun take() {
        if (busy) return
        busy = true
        val f = File(ctx.cacheDir, "shot_${System.currentTimeMillis()}.jpg")
        capture.takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) { busy = false; shot = f }
                override fun onError(e: ImageCaptureException) {
                    busy = false
                    Toast.makeText(ctx, "No se pudo tomar la foto.", Toast.LENGTH_SHORT).show()
                }
            })
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { previewView })
        // Pellizcar para acercar; tocar para enfocar
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> if (z != 1f) zoom = (zoom + (z - 1f) * 0.6f).coerceIn(0f, 1f) } }
                .pointerInput(Unit) { detectTapGestures { o -> focusAt(o) } }
        )
        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0x99000000)).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Text("✕", color = Color.White, fontSize = 18.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000)).clickable {
                    flash = when (flash) {
                        ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                        ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                        else -> ImageCapture.FLASH_MODE_OFF
                    }
                }.padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    when (flash) { ImageCapture.FLASH_MODE_AUTO -> "Flash: automático"; ImageCapture.FLASH_MODE_ON -> "Flash: encendido"; else -> "Flash: apagado" },
                    color = Color.White, fontSize = 14.sp
                )
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Zoom", color = Color.White, fontSize = 12.sp)
            Slider(zoom, { zoom = it }, Modifier.fillMaxWidth(0.8f))
            Text("Para la pizarra deja el flash apagado: evita el reflejo.", color = Color(0xCCFFFFFF), fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.size(78.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape).padding(7.dp).clip(CircleShape)
                .background(if (busy) Color.Gray else Color.White).clickable(enabled = !busy) { take() })
        }
    }

    // Después de la foto: nombre y categoría de la biblioteca
    val taken = shot
    if (taken != null) {
        val cats = remember { libCategories(ctx) + "Sin categoría" }
        val prefs = remember { ctx.getSharedPreferences("abstergo", android.content.Context.MODE_PRIVATE) }
        var name by remember(taken) { mutableStateOf("Foto " + SimpleDateFormat("d MMM HH:mm", Locale("es")).format(Date())) }
        var cat by remember(taken) { mutableStateOf(prefs.getString("last_photo_cat", "Clases")?.takeIf { it in cats } ?: "Sin categoría") }
        val preview by produceState<ImageBitmap?>(null, taken) { value = withContext(Dispatchers.IO) { uprightBitmap(taken, 700)?.asImageBitmap() } }
        AlertDialog(
            onDismissRequest = { },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Guardar foto") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    preview?.let { Image(it, null, Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit) }
                    OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nombre") }, singleLine = true)
                    Text("Categoría", fontWeight = FontWeight.SemiBold)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        cats.forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
                    }
                }
            },
            confirmButton = {
                TextButton({
                    val n = name.trim().ifEmpty { "Foto" }
                    scope.launch {
                        val item = withContext(Dispatchers.IO) { addFileToLibrary(ctx, taken, n, cat) }
                        if (item != null) {
                            prefs.edit().putString("last_photo_cat", cat).apply()
                            onSaved(item)
                            Toast.makeText(ctx, "Guardada en Archivos", Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(ctx, "No se pudo guardar la foto.", Toast.LENGTH_SHORT).show()
                        shot = null
                    }
                }) { Text("Guardar") }
            },
            dismissButton = { TextButton({ taken.delete(); shot = null }) { Text("Descartar") } }
        )
    }
}
