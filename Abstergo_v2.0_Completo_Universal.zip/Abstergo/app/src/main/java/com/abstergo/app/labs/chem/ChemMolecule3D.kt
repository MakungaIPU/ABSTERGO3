package com.abstergo.app.labs.chem

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

// ==============================================================================
// MOTOR MOLECULAR 3D NATIVO (ESFERAS CPK CON BRILLO ESPECULAR + ENLACES 1/2/3)
// ==============================================================================

@Immutable
data class Atom3D(
    val symbol: String,
    val x: Double,
    val y: Double,
    val z: Double,
    val color: Color,
    val radius: Float = 1.0f
)

@Immutable
data class Bond3D(
    val a: Int,
    val b: Int,
    val order: Int = 1 // 1=simple, 2=doble, 3=triple, 0=red cristalina punteada
)

@Immutable
data class Molecule3DModel(
    val title: String,
    val subtitle: String,
    val atoms: List<Atom3D>,
    val bonds: List<Bond3D>
)

/** Colores estándar internacionales CPK para química orgánica, inorgánica y molecular. */
fun cpkColor(symbol: String, fallback: Color = Color(0xFF38BDF8)): Color = when (symbol) {
    "H" -> Color(0xFFF1F5F9)
    "C" -> Color(0xFF334155)
    "N" -> Color(0xFF3B82F6)
    "O" -> Color(0xFFEF4444)
    "F" -> Color(0xFF4ADE80)
    "Cl" -> Color(0xFF22C55E)
    "Br" -> Color(0xFFB45309)
    "I" -> Color(0xFF9333EA)
    "S" -> Color(0xFFFACC15)
    "P" -> Color(0xFFF97316)
    "Na", "K", "Li" -> Color(0xFFA855F7)
    "Ca", "Mg", "Ba" -> Color(0xFF10B981)
    "Fe" -> Color(0xFFD97706)
    "Cu" -> Color(0xFFEA580C)
    "Au" -> Color(0xFFEAB308)
    "Ag" -> Color(0xFFCBD5E1)
    "He", "Ne", "Ar", "Kr", "Xe", "Rn" -> Color(0xFF22D3EE)
    else -> fallback
}

internal fun atom(sym: String, x: Double, y: Double, z: Double): Atom3D =
    Atom3D(sym, x, y, z, cpkColor(sym), cpkRadius(sym))

fun cpkRadius(symbol: String): Float = when (symbol) {
    "H" -> 0.62f
    "C", "N", "O", "F" -> 0.96f
    "S", "P", "Cl", "Si" -> 1.12f
    "Br", "I", "Na", "K", "Ca", "Fe", "Cu" -> 1.22f
    else -> 1.05f
}

/**
 * Visor molecular 3D interactivo a 60 fps:
 * - Rotación fluida 360° con 1 dedo
 * - Auto-rotación opcional activable en 1 toque
 * - Ordenamiento por profundidad Z (painter's algorithm) y sombreado especular 3D realista
 * - Soporta enlaces simples, dobles, triples y aristas de celda cristalina
 */
@Composable
fun Molecule3DCanvas(
    model: Molecule3DModel,
    modifier: Modifier = Modifier,
    showLabels: Boolean = true
) {
    var yaw by remember(model) { mutableStateOf(0.55) }
    var pitch by remember(model) { mutableStateOf(0.32) }
    var autoSpin by remember(model) { mutableStateOf(true) }
    var zoom by remember(model) { mutableStateOf(1.0f) }

    LaunchedEffect(autoSpin, model) {
        while (autoSpin) {
            delay(24)
            yaw += 0.016
        }
    }

    val dark = chemIsDark()
    val bgColor = if (dark) Color(0xFF0A0F18) else Color(0xFFEEF3FA)
    val bondColor = if (dark) Color(0xFFCBD5E1) else Color(0xFF475569)
    val latticeColor = if (dark) Color(0x5538BDF8) else Color(0x660284C7)

    // Calcular centro y radio envolvente para encuadrar automáticamente cualquier molécula
    val (cxM, cyM, czM, maxDist) = remember(model) {
        if (model.atoms.isEmpty()) QuadD(0.0, 0.0, 0.0, 1.0)
        else {
            val ax = model.atoms.map { it.x }.average()
            val ay = model.atoms.map { it.y }.average()
            val az = model.atoms.map { it.z }.average()
            val md = model.atoms.maxOf {
                sqrt((it.x - ax) * (it.x - ax) + (it.y - ay) * (it.y - ay) + (it.z - az) * (it.z - az))
            }.coerceAtLeast(1.15)
            QuadD(ax, ay, az, md)
        }
    }

    val lightLblPaint = remember {
        Paint().apply {
            isAntiAlias = true
            color = Color.White.toArgb()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }
    val darkLblPaint = remember {
        Paint().apply {
            isAntiAlias = true
            color = Color(0xFF0F172A).toArgb()
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(bgColor)
            .border(1.dp, chemGlassBorder(), RoundedCornerShape(18.dp))
            .pointerInput(model) {
                detectDragGestures { _, drag ->
                    autoSpin = false
                    yaw += drag.x * 0.013
                    pitch = (pitch + drag.y * 0.013).coerceIn(-1.45, 1.45)
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            if (w <= 1f || h <= 1f || model.atoms.isEmpty()) return@Canvas
            val cx = w / 2f; val cy = h / 2f
            val baseScale = (minOf(w, h) * 0.34f / maxDist.toFloat()) * zoom
            val cyaw = cos(yaw); val syaw = sin(yaw)
            val cpitch = cos(pitch); val spitch = sin(pitch)

            data class ProjAtom(val idx: Int, val sx: Float, val sy: Float, val rz: Double, val persp: Float, val atom: Atom3D)

            val projected = model.atoms.mapIndexed { idx, atom ->
                val dx = atom.x - cxM
                val dy = atom.y - cyM
                val dz = atom.z - czM
                val x1 = dx * cyaw + dz * syaw
                val z1 = -dx * syaw + dz * cyaw
                val y2 = dy * cpitch - z1 * spitch
                val z2 = dy * spitch + z1 * cpitch
                val cam = maxDist * 3.8 + 2.4
                val persp = (cam / (cam - z2).coerceAtLeast(0.8)).toFloat()
                ProjAtom(idx, cx + (x1 * baseScale * persp).toFloat(), cy - (y2 * baseScale * persp).toFloat(), z2, persp, atom)
            }

            // Construir primitivas ordenadas por profundidad Z (enlaces y átomos intercalados correctamente!)
            val drawQueue = ArrayList<Pair<Double, () -> Unit>>(model.atoms.size + model.bonds.size)

            model.bonds.forEach { b ->
                if (b.a in projected.indices && b.b in projected.indices) {
                    val pa = projected[b.a]; val pb = projected[b.b]
                    val midZ = (pa.rz + pb.rz) * 0.5 - 0.02
                    drawQueue.add(midZ to {
                        val vx = pb.sx - pa.sx; val vy = pb.sy - pa.sy
                        val len = hypot(vx.toDouble(), vy.toDouble()).toFloat().coerceAtLeast(1f)
                        val nx = -vy / len; val ny = vx / len
                        val sw = ((minOf(w, h) * 0.026f) * ((pa.persp + pb.persp) * 0.5f) * zoom).coerceIn(2.5f, 11f)
                        when (b.order) {
                            0 -> drawLine(latticeColor, Offset(pa.sx, pa.sy), Offset(pb.sx, pb.sy), strokeWidth = 2.4f, cap = StrokeCap.Round)
                            1 -> drawLine(bondColor, Offset(pa.sx, pa.sy), Offset(pb.sx, pb.sy), strokeWidth = sw, cap = StrokeCap.Round)
                            2 -> {
                                val off = sw * 0.85f
                                drawLine(bondColor, Offset(pa.sx + nx * off, pa.sy + ny * off), Offset(pb.sx + nx * off, pb.sy + ny * off), strokeWidth = sw * 0.72f, cap = StrokeCap.Round)
                                drawLine(bondColor, Offset(pa.sx - nx * off, pa.sy - ny * off), Offset(pb.sx - nx * off, pb.sy - ny * off), strokeWidth = sw * 0.72f, cap = StrokeCap.Round)
                            }
                            else -> {
                                val off = sw * 1.15f
                                drawLine(bondColor, Offset(pa.sx, pa.sy), Offset(pb.sx, pb.sy), strokeWidth = sw * 0.62f, cap = StrokeCap.Round)
                                drawLine(bondColor, Offset(pa.sx + nx * off, pa.sy + ny * off), Offset(pb.sx + nx * off, pb.sy + ny * off), strokeWidth = sw * 0.62f, cap = StrokeCap.Round)
                                drawLine(bondColor, Offset(pa.sx - nx * off, pa.sy - ny * off), Offset(pb.sx - nx * off, pb.sy - ny * off), strokeWidth = sw * 0.62f, cap = StrokeCap.Round)
                            }
                        }
                    })
                }
            }

            val atomBaseR = (minOf(w, h) * 0.095f / (1f + model.atoms.size * 0.032f)).coerceIn(11f, 34f) * zoom
            projected.forEach { pa ->
                drawQueue.add(pa.rz to {
                    val r = (atomBaseR * pa.atom.radius * pa.persp).coerceIn(8f, 44f)
                    val center = Offset(pa.sx, pa.sy)
                    val col = pa.atom.color
                    // Sombra sutil + esfera 3D con brillo especular superior izquierdo
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(
                                    (col.red + 0.42f).coerceAtMost(1f),
                                    (col.green + 0.42f).coerceAtMost(1f),
                                    (col.blue + 0.42f).coerceAtMost(1f),
                                    1f
                                ),
                                col,
                                Color(col.red * 0.42f, col.green * 0.42f, col.blue * 0.42f, 1f)
                            ),
                            center = Offset(pa.sx - r * 0.30f, pa.sy - r * 0.30f),
                            radius = r * 1.38f
                        ),
                        radius = r,
                        center = center
                    )
                    if (showLabels && r >= 13f) {
                        val isLight = (col.red * 0.299f + col.green * 0.587f + col.blue * 0.114f) > 0.62f
                        val paint = if (isLight) darkLblPaint else lightLblPaint
                        paint.textSize = (r * 0.85f).coerceIn(16f, 32f)
                        drawContext.canvas.nativeCanvas.drawText(pa.atom.symbol, pa.sx, pa.sy + paint.textSize * 0.35f, paint)
                    }
                })
            }

            drawQueue.sortedBy { it.first }.forEach { it.second.invoke() }
        }

        // Etiqueta superior izquierda (nombre de estructura)
        Column(Modifier.align(Alignment.TopStart).padding(10.dp)) {
            Text(model.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            if (model.subtitle.isNotBlank()) {
                Text(model.subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Controles discretos abajo derecha (Girar / Zoom / Reset)
        Row(Modifier.align(Alignment.BottomEnd).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            MolHudBtn(if (autoSpin) "❚❚" else "▶") { autoSpin = !autoSpin }
            MolHudBtn("+") { zoom = (zoom * 1.18f).coerceAtMost(1.9f) }
            MolHudBtn("−") { zoom = (zoom * 0.85f).coerceAtLeast(0.55f) }
            MolHudBtn("↺") { yaw = 0.55; pitch = 0.32; zoom = 1.0f }
        }
    }
}

private data class QuadD(val a: Double, val b: Double, val c: Double, val d: Double)

@Composable
private fun MolHudBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).clip(RoundedCornerShape(8.dp))
            .background(chemGlassSurface().copy(alpha = 0.88f))
            .border(1.dp, chemGlassBorder(), RoundedCornerShape(8.dp))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

// ==============================================================================
// GENERADOR DE MOLÉCULA REAL O CELDA CRISTALINA 3D PARA CADA UNO DE LOS 118 ELEMENTOS
// ==============================================================================

fun buildElementStructure3D(el: ChemElement, accent: Color): Molecule3DModel {
    val col = cpkColor(el.symbol, accent)
    val rad = cpkRadius(el.symbol)
    val s = el.symbol

    // 1. Moléculas diatómicas reales (H2, N2, O2, F2, Cl2, Br2, I2)
    when (el.z) {
        1 -> return Molecule3DModel(
            "Molécula diatómica H₂",
            "Enlace covalente simple (74 pm)",
            listOf(Atom3D("H", -0.85, 0.0, 0.0, col, 0.9f), Atom3D("H", 0.85, 0.0, 0.0, col, 0.9f)),
            listOf(Bond3D(0, 1, 1))
        )
        7 -> return Molecule3DModel(
            "Molécula diatómica N₂",
            "Enlace covalente triple N≡N (110 pm)",
            listOf(Atom3D("N", -0.95, 0.0, 0.0, col, 1.05f), Atom3D("N", 0.95, 0.0, 0.0, col, 1.05f)),
            listOf(Bond3D(0, 1, 3))
        )
        8 -> return Molecule3DModel(
            "Molécula diatómica O₂",
            "Enlace covalente doble O=O (121 pm)",
            listOf(Atom3D("O", -0.95, 0.0, 0.0, col, 1.05f), Atom3D("O", 0.95, 0.0, 0.0, col, 1.05f)),
            listOf(Bond3D(0, 1, 2))
        )
        9, 17, 35, 53 -> {
            val len = when (el.z) { 9 -> "142 pm"; 17 -> "199 pm"; 35 -> "228 pm"; else -> "267 pm" }
            return Molecule3DModel(
                "Molécula diatómica ${s}₂",
                "Halógeno · Enlace simple $s—$s ($len)",
                listOf(Atom3D(s, -1.0, 0.0, 0.0, col, 1.08f), Atom3D(s, 1.0, 0.0, 0.0, col, 1.08f)),
                listOf(Bond3D(0, 1, 1))
            )
        }
        // 2. Fósforo blanco tetraédrico P4
        15 -> {
            val atoms = listOf(
                Atom3D("P", 1.0, 1.0, 1.0, col, 1.05f),
                Atom3D("P", 1.0, -1.0, -1.0, col, 1.05f),
                Atom3D("P", -1.0, 1.0, -1.0, col, 1.05f),
                Atom3D("P", -1.0, -1.0, 1.0, col, 1.05f)
            )
            val bonds = listOf(Bond3D(0, 1), Bond3D(0, 2), Bond3D(0, 3), Bond3D(1, 2), Bond3D(1, 3), Bond3D(2, 3))
            return Molecule3DModel("Molécula tetraédrica P₄", "Fósforo blanco · Ángulo 60°", atoms, bonds)
        }
        // 3. Azufre en corona S8
        16 -> {
            val atoms = (0 until 8).map { i ->
                val ang = 2.0 * PI * i / 8.0
                val y = if (i % 2 == 0) 0.42 else -0.42
                Atom3D("S", 1.55 * cos(ang), y, 1.55 * sin(ang), col, 0.96f)
            }
            val bonds = (0 until 8).map { i -> Bond3D(i, (i + 1) % 8, 1) }
            return Molecule3DModel("Anillo corona S₈", "Ciclooctaazufre · Ángulo 108°", atoms, bonds)
        }
        // 4. Carbono (estructura tetraédrica sp3 tipo diamante)
        6 -> {
            val atoms = listOf(
                Atom3D("C", 0.0, 0.0, 0.0, col, 1.05f),
                Atom3D("C", 1.0, 1.0, 1.0, col, 0.95f),
                Atom3D("C", 1.0, -1.0, -1.0, col, 0.95f),
                Atom3D("C", -1.0, 1.0, -1.0, col, 0.95f),
                Atom3D("C", -1.0, -1.0, 1.0, col, 0.95f)
            )
            return Molecule3DModel("Red tetraédrica (Diamante sp³)", "Ángulo exacto 109.5°", atoms, listOf(Bond3D(0, 1), Bond3D(0, 2), Bond3D(0, 3), Bond3D(0, 4)))
        }
        // 5. Gases nobles monoatómicos
        2, 10, 18, 36, 54, 86 -> {
            return Molecule3DModel(
                "Gas monoatómico $s",
                "Capa de valencia completa · Átomos libres",
                listOf(Atom3D(s, 0.0, 0.0, 0.0, col, 1.45f)),
                emptyList()
            )
        }
    }

    // 6. Celdas unitarias cristalinas reales para metales y metaloides sólidos
    val crys = el.crystal.lowercase()
    return when {
        "cuerpo" in crys || "bcc" in crys -> buildBccLattice(s, col, rad)
        "caras" in crys || "fcc" in crys -> buildFccLattice(s, col, rad)
        "hexagonal" in crys || "hcp" in crys -> buildHcpLattice(s, col, rad)
        "tetragonal" in crys -> buildBoxLattice(s, col, rad, 1.0, 1.35, 1.0, "Celda Tetragonal · $s")
        else -> buildBoxLattice(s, col, rad, 1.05, 1.05, 1.05, "Celda Cúbica (${el.crystal}) · $s")
    }
}

private fun buildBccLattice(sym: String, col: Color, rad: Float): Molecule3DModel {
    val corners = listOf(
        Triple(-1.0, -1.0, -1.0), Triple(1.0, -1.0, -1.0), Triple(1.0, 1.0, -1.0), Triple(-1.0, 1.0, -1.0),
        Triple(-1.0, -1.0, 1.0), Triple(1.0, -1.0, 1.0), Triple(1.0, 1.0, 1.0), Triple(-1.0, 1.0, 1.0)
    )
    val atoms = corners.map { (x, y, z) -> Atom3D(sym, x, y, z, col, rad * 0.85f) } +
        Atom3D(sym, 0.0, 0.0, 0.0, Color(0xFFFFFFFF).copy(alpha = 0.25f).let { col }, rad * 1.02f)
    val cubeEdges = listOf(
        Bond3D(0, 1, 0), Bond3D(1, 2, 0), Bond3D(2, 3, 0), Bond3D(3, 0, 0),
        Bond3D(4, 5, 0), Bond3D(5, 6, 0), Bond3D(6, 7, 0), Bond3D(7, 4, 0),
        Bond3D(0, 4, 0), Bond3D(1, 5, 0), Bond3D(2, 6, 0), Bond3D(3, 7, 0),
        Bond3D(8, 0, 1), Bond3D(8, 2, 1), Bond3D(8, 5, 1), Bond3D(8, 7, 1)
    )
    return Molecule3DModel("Celda Cúbica Centrada en Cuerpo (BCC)", "9 átomos · Coordinación 8", atoms, cubeEdges)
}

private fun buildFccLattice(sym: String, col: Color, rad: Float): Molecule3DModel {
    val pts = listOf(
        Triple(-1.0, -1.0, -1.0), Triple(1.0, -1.0, -1.0), Triple(1.0, 1.0, -1.0), Triple(-1.0, 1.0, -1.0),
        Triple(-1.0, -1.0, 1.0), Triple(1.0, -1.0, 1.0), Triple(1.0, 1.0, 1.0), Triple(-1.0, 1.0, 1.0),
        // 6 centros de caras
        Triple(0.0, 0.0, -1.0), Triple(0.0, 0.0, 1.0),
        Triple(-1.0, 0.0, 0.0), Triple(1.0, 0.0, 0.0),
        Triple(0.0, -1.0, 0.0), Triple(0.0, 1.0, 0.0)
    )
    val atoms = pts.mapIndexed { i, (x, y, z) -> Atom3D(sym, x, y, z, col, if (i >= 8) rad * 0.92f else rad * 0.78f) }
    val edges = listOf(
        Bond3D(0, 1, 0), Bond3D(1, 2, 0), Bond3D(2, 3, 0), Bond3D(3, 0, 0),
        Bond3D(4, 5, 0), Bond3D(5, 6, 0), Bond3D(6, 7, 0), Bond3D(7, 4, 0),
        Bond3D(0, 4, 0), Bond3D(1, 5, 0), Bond3D(2, 6, 0), Bond3D(3, 7, 0)
    )
    return Molecule3DModel("Celda Cúbica Centrada en Caras (FCC)", "14 átomos · Empaquetamiento 74%", atoms, edges)
}

private fun buildHcpLattice(sym: String, col: Color, rad: Float): Molecule3DModel {
    val atoms = ArrayList<Atom3D>()
    val r = 1.25; val hy = 1.05
    for (i in 0 until 6) {
        val a = 2.0 * PI * i / 6.0
        atoms.add(Atom3D(sym, r * cos(a), -hy, r * sin(a), col, rad * 0.80f))
    }
    for (i in 0 until 6) {
        val a = 2.0 * PI * i / 6.0
        atoms.add(Atom3D(sym, r * cos(a), hy, r * sin(a), col, rad * 0.80f))
    }
    // 3 átomos en plano intermedio
    for (i in 0 until 3) {
        val a = 2.0 * PI * i / 3.0 + PI / 6.0
        atoms.add(Atom3D(sym, r * 0.58 * cos(a), 0.0, r * 0.58 * sin(a), col, rad * 0.88f))
    }
    val edges = ArrayList<Bond3D>()
    for (i in 0 until 6) {
        edges.add(Bond3D(i, (i + 1) % 6, 0))
        edges.add(Bond3D(6 + i, 6 + (i + 1) % 6, 0))
        edges.add(Bond3D(i, 6 + i, 0))
    }
    return Molecule3DModel("Celda Hexagonal Compacta (HCP)", "Coordinación 12 · Empaquetamiento 74%", atoms, edges)
}

private fun buildBoxLattice(sym: String, col: Color, rad: Float, sx: Double, sy: Double, sz: Double, title: String): Molecule3DModel {
    val corners = listOf(
        Triple(-sx, -sy, -sz), Triple(sx, -sy, -sz), Triple(sx, sy, -sz), Triple(-sx, sy, -sz),
        Triple(-sx, -sy, sz), Triple(sx, -sy, sz), Triple(sx, sy, sz), Triple(-sx, sy, sz)
    )
    val atoms = corners.map { (x, y, z) -> Atom3D(sym, x, y, z, col, rad * 0.88f) }
    val edges = listOf(
        Bond3D(0, 1, 1), Bond3D(1, 2, 1), Bond3D(2, 3, 1), Bond3D(3, 0, 1),
        Bond3D(4, 5, 1), Bond3D(5, 6, 1), Bond3D(6, 7, 1), Bond3D(7, 4, 1),
        Bond3D(0, 4, 1), Bond3D(1, 5, 1), Bond3D(2, 6, 1), Bond3D(3, 7, 1)
    )
    return Molecule3DModel(title, "Estructura sólida elemental", atoms, edges)
}
