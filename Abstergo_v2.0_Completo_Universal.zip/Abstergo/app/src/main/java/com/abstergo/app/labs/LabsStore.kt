package com.abstergo.app.labs

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.Immutable
import com.abstergo.app.SUBJECTS
import com.abstergo.app.loadExercises
import com.abstergo.app.subjectLabel
import com.abstergo.app.writeTextAtomic
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Ejercicio interactivo de un Laboratorio de Asignatura (Matemática Labs y futuros Labs). */
@Immutable
data class LabExercise(
    val id: String,
    val subject: String,
    val title: String,
    val prompt: String,
    val expression: String,
    val mode: String = "AUTO",
    val hints: List<String> = emptyList(),
    val done: Boolean = false,
    val isNew: Boolean = false,
    val source: String = "local",
    val createdAt: Long = System.currentTimeMillis()
)

/** Entrada del historial automático de Photomath en Matemática Labs. */
@Immutable
data class PmHistoryEntry(
    val id: String,
    val expression: String,
    val answer: String,
    val category: String,
    val timestamp: Long
)

/** Paquete exportable/importable en formato propietario .abslab */
@Immutable
data class AbsLabPack(
    val version: Int,
    val subject: String,
    val packTitle: String,
    val author: String,
    val exercises: List<LabExercise>
)

@Immutable
data class LabSubjectMeta(
    val key: String,
    val title: String,
    val subtitle: String,
    val active: Boolean,
    val symbol: Int
)

/** Galería de Laboratorios por asignatura estilo APK (Matemática activo). */
val LAB_CATALOG = listOf(
    LabSubjectMeta(
        key = "m",
        title = "Matemática Labs",
        subtitle = "Clon de Photomath + Preuniversitario 10mo–12mo: Geometría 2D/3D, Funciones, Inecuaciones, Trigonometría, Complejos, Combinatoria, Inducción y Estadística",
        active = true,
        symbol = 13
    ),
    LabSubjectMeta("f", "Física Labs", "Cinemática, vectores y simulaciones (próxima versión)", false, 2),
    LabSubjectMeta(
        key = "q",
        title = "Química Labs",
        subtitle = "Tabla periódica 118 elementos + Moléculas 3D, Química Orgánica e Inorgánica (constructor táctil), pH, solubilidad y compuestos famosos",
        active = true,
        symbol = 3
    ),
    LabSubjectMeta("b", "Biología Labs", "Genética, esquemas y guías interactivas (próxima versión)", false, 7)
)

/** Ejercicios de muestra preuniversitarios para probar en Matemática Labs. */
val MATH_LAB_SAMPLES = listOf(
    LabExercise(
        id = "sample_quad_1",
        subject = "m",
        title = "Ecuación cuadrática (3 métodos)",
        prompt = "Compara Fórmula cuadrática, Factorización y Completando el cuadrado.",
        expression = "x^2 - 5x + 6 = 0",
        source = "sample"
    ),
    LabExercise(
        id = "sample_sys_1",
        subject = "m",
        title = "Sistema lineal 2×2 (Sustitución / Eliminación / Cramer)",
        prompt = "Halla el punto (x, y) donde se cortan ambas rectas.",
        expression = "x + y = 5; 2x - y = 1",
        source = "sample"
    ),
    LabExercise(
        id = "sample_frac_1",
        subject = "m",
        title = "Suma exacta de fracciones",
        prompt = "Mínimo común denominador y reducción exacta.",
        expression = "3/4 + 2/5",
        source = "sample"
    ),
    LabExercise(
        id = "sample_ineq_1",
        subject = "m",
        title = "Inecuación lineal con recta numérica",
        prompt = "Despeje con notación de intervalos y gráfica en la recta real.",
        expression = "-2x + 4 <= 10",
        source = "sample"
    ),
    LabExercise(
        id = "sample_calc_1",
        subject = "m",
        title = "Derivada simbólica paso a paso",
        prompt = "Primera y segunda derivada con gráfica comparativa.",
        expression = "d/dx(x^3 - 3x^2 + 2x)",
        source = "sample"
    )
)

private fun labsFile(ctx: Context): File = File(ctx.filesDir, "labs.json")
private fun pmHistoryFile(ctx: Context): File = File(ctx.filesDir, "photomath_history.json")

fun loadPmHistory(ctx: Context): List<PmHistoryEntry> {
    val f = pmHistoryFile(ctx)
    if (!f.exists()) return emptyList()
    return try {
        val arr = JSONArray(f.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            PmHistoryEntry(
                id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                expression = o.optString("expression"),
                answer = o.optString("answer"),
                category = o.optString("category"),
                timestamp = o.optLong("timestamp", 0L)
            )
        }.filter { it.expression.isNotBlank() }
    } catch (_: Exception) {
        emptyList()
    }
}

fun savePmHistory(ctx: Context, list: List<PmHistoryEntry>) {
    val arr = JSONArray()
    list.forEach { h ->
        arr.put(
            JSONObject()
                .put("id", h.id)
                .put("expression", h.expression)
                .put("answer", h.answer)
                .put("category", h.category)
                .put("timestamp", h.timestamp)
        )
    }
    writeTextAtomic(pmHistoryFile(ctx), arr.toString())
}

fun loadLabExercises(ctx: Context): List<LabExercise> {
    val file = labsFile(ctx)
    if (!file.exists()) {
        val legacy = loadExercises(ctx)
        if (legacy.isNotEmpty()) {
            val migrated = legacy.map { e ->
                LabExercise(
                    id = e.id,
                    subject = e.subject,
                    title = e.title,
                    prompt = e.text,
                    expression = extractFirstMathLine(e.text).ifBlank { e.title },
                    done = e.done,
                    isNew = e.isNew,
                    source = "migrated"
                )
            }
            saveLabExercises(ctx, migrated)
            return migrated
        }
        return emptyList()
    }
    return try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i -> parseLabExerciseJson(arr.getJSONObject(i)) }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveLabExercises(ctx: Context, list: List<LabExercise>) {
    val arr = JSONArray()
    list.forEach { e -> arr.put(toJsonObject(e)) }
    writeTextAtomic(labsFile(ctx), arr.toString())
}

internal fun parseLabExerciseJson(o: JSONObject, forceNew: Boolean = false, defaultSubject: String = "m"): LabExercise {
    val hintsArr = o.optJSONArray("hints")
    val hints = if (hintsArr != null) {
        (0 until hintsArr.length()).mapNotNull { idx -> hintsArr.optString(idx).takeIf { it.isNotBlank() } }
    } else emptyList()
    val rawSubj = o.optString("subject", defaultSubject).lowercase()
    val subj = if (rawSubj in SUBJECTS) rawSubj else defaultSubject
    val prompt = o.optString("prompt", o.optString("text", ""))
    val expr = o.optString("expression", "").ifBlank { extractFirstMathLine(prompt) }
    return LabExercise(
        id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
        subject = subj,
        title = o.optString("title", "Ejercicio").take(200).ifBlank { "Ejercicio" },
        prompt = prompt.take(5000),
        expression = expr.take(500),
        mode = o.optString("mode", "AUTO"),
        hints = hints,
        done = o.optBoolean("done", false),
        isNew = if (forceNew) true else o.optBoolean("new", false),
        source = o.optString("source", "local"),
        createdAt = o.optLong("createdAt", System.currentTimeMillis())
    )
}

internal fun toJsonObject(e: LabExercise): JSONObject {
    val hints = JSONArray()
    e.hints.forEach { hints.put(it) }
    return JSONObject()
        .put("id", e.id)
        .put("subject", e.subject)
        .put("title", e.title)
        .put("prompt", e.prompt)
        .put("expression", e.expression)
        .put("mode", e.mode)
        .put("hints", hints)
        .put("done", e.done)
        .put("new", e.isNew)
        .put("source", e.source)
        .put("createdAt", e.createdAt)
}

private fun extractFirstMathLine(text: String): String {
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    return lines.firstOrNull { line ->
        line.any { it in "=+-*/^√" } && line.any { it.isDigit() || it in "xyzt" }
    } ?: lines.firstOrNull().orEmpty()
}

// ==============================================================================
// Formato propietario .abslab (importación y exportación 100% offline)
// ==============================================================================
object AbsLabCodec {

    const val FORMAT_ID = "abstergo-lab"
    const val CURRENT_VERSION = 1

    fun isAbsLabFilename(name: String): Boolean =
        name.lowercase().endsWith(".abslab")

    fun parse(jsonText: String): AbsLabPack? {
        return try {
            val root = JSONObject(jsonText)
            if (root.optString("format") != FORMAT_ID && !root.has("exercises")) return null
            val version = root.optInt("version", 1)
            val rawSubj = root.optString("subject", "m").lowercase()
            val subject = if (rawSubj in SUBJECTS) rawSubj else "m"
            val packTitle = root.optString("title", "${subjectLabel(subject)} Labs").take(140)
            val author = root.optString("author", "Profesor").take(80)
            val arr = root.optJSONArray("exercises") ?: return null
            val items = ArrayList<LabExercise>(arr.length())
            for (i in 0 until minOf(arr.length(), 300)) {
                val eo = arr.optJSONObject(i) ?: continue
                val ex = parseLabExerciseJson(eo, forceNew = true, defaultSubject = subject).copy(source = "abslab")
                if (ex.title.isNotBlank() || ex.expression.isNotBlank()) {
                    items.add(ex)
                }
            }
            if (items.isEmpty()) null
            else AbsLabPack(version, subject, packTitle, author, items)
        } catch (_: Exception) {
            null
        }
    }

    fun encode(packTitle: String, subject: String, author: String, exercises: List<LabExercise>): String {
        val arr = JSONArray()
        exercises.forEach { arr.put(toJsonObject(it.copy(done = false, isNew = false))) }
        return JSONObject()
            .put("format", FORMAT_ID)
            .put("version", CURRENT_VERSION)
            .put("subject", subject)
            .put("title", packTitle)
            .put("author", author)
            .put("exportedAt", System.currentTimeMillis())
            .put("exercises", arr)
            .toString(2)
    }

    data class ImportResult(
        val ok: Boolean,
        val subject: String = "m",
        val packTitle: String = "",
        val addedCount: Int = 0,
        val error: String? = null
    )

    fun importFromUri(ctx: Context, uri: Uri): ImportResult {
        val raw = try {
            ctx.contentResolver.openInputStream(uri)?.use { inp ->
                val bytes = inp.readBytes()
                if (bytes.size > 4 * 1024 * 1024) return ImportResult(false, error = "El archivo .abslab supera el límite de 4 MB.")
                String(bytes, Charsets.UTF_8)
            } ?: return ImportResult(false, error = "No se pudo abrir el archivo .abslab.")
        } catch (e: Exception) {
            return ImportResult(false, error = "Error leyendo el archivo: ${e.message}")
        }
        val pack = parse(raw)
            ?: return ImportResult(false, error = "El archivo no tiene un formato .abslab válido.")
        val current = loadLabExercises(ctx)
        val knownIds = current.map { it.id }.toHashSet()
        val toAdd = pack.exercises.filter { it.id !in knownIds }
        val merged = if (toAdd.isEmpty()) {
            val cloned = pack.exercises.map { it.copy(id = UUID.randomUUID().toString(), isNew = true) }
            saveLabExercises(ctx, current + cloned)
            cloned.size
        } else {
            saveLabExercises(ctx, current + toAdd)
            toAdd.size
        }
        return ImportResult(ok = true, subject = pack.subject, packTitle = pack.packTitle, addedCount = merged)
    }
}
