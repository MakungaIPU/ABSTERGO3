package com.abstergo.app.labs.photomath

import android.content.res.Configuration
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private data class CalcKey(
    val label: String,
    val insert: String,
    val cursorBack: Int = 0,
    val accent: Boolean = false,
    val secondary: Boolean = false
)

private val QUICK_EXAMPLES = listOf(
    "x^2 - 5x + 6 = 0",
    "1/x + 1/(x+1) = 3/2",
    "(x - 2)/(x + 3) >= 0",
    "x + y = 5; 2x - y = 1",
    "2sin(x) - 1 = 0",
    "|2x - 1| <= 5",
    "C(10, 3)",
    "V(6, 2)",
    "(3 + 4i)/(1 - 2i)",
    "d/dx(x^3 - 3x^2 + 2)",
    "int(3x^2 + 2x, x, 0, 2)",
    "3/4 + 2/5"
)

/**
 * Calculadora inteligente estilo Photomath con estética de laboratorio Abstergo:
 * - Pizarra 2D con cuadrícula sutil de laboratorio y renderizado matemático real en vivo
 * - Respuesta instantánea flotante estilo Photomath (= resultado · Ver pasos ›)
 * - Teclado ergonómico por pestañas (Básico, Trig/Log, Cálculo/Combinatoria)
 */
@Composable
fun PmCalculatorScreen(
    initialInput: String,
    onBackToLabs: () -> Unit,
    onImportAbsLab: () -> Unit,
    onSolve: (String) -> Unit
) {
    var input by remember(initialInput) { mutableStateOf(initialInput) }
    var cursor by remember(initialInput) { mutableStateOf(initialInput.length) }
    var padTab by remember { mutableStateOf(0) } // 0 = Básico, 1 = Trig/Log, 2 = Cálc/Comb
    var livePreview by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(input) {
        if (input.isBlank()) {
            livePreview = null
            return@LaunchedEffect
        }
        delay(200)
        livePreview = withContext(Dispatchers.Default) { PmSolver.quickPreview(input) }
    }

    fun insertAtCursor(text: String, backSteps: Int = 0) {
        val pos = cursor.coerceIn(0, input.length)
        input = input.substring(0, pos) + text + input.substring(pos)
        cursor = (pos + text.length - backSteps).coerceIn(0, input.length)
    }

    fun backspace() {
        val pos = cursor.coerceIn(0, input.length)
        if (pos > 0) {
            input = input.substring(0, pos - 1) + input.substring(pos)
            cursor = pos - 1
        }
    }

    fun clearAll() {
        input = ""
        cursor = 0
        livePreview = null
    }

    val accent = labAccent()
    val onAccent = labOnAccent()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
    ) {
        // Cabecera limpia Abstergo Math Lab
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
                    .clickable { onBackToLabs() },
                contentAlignment = Alignment.Center
            ) {
                LabIcon(LabIconKind.BACK, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Matemática Labs", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("MOTOR PHOTOMATH · OFFLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = accent)
            }
            Row(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    .clickable { onImportAbsLab() }
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LabIcon(LabIconKind.PACK, accent, Modifier.size(15.dp))
                Spacer(Modifier.width(5.dp))
                Text(".abslab", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // Carrusel de ejemplos de 1 toque
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            QUICK_EXAMPLES.forEach { sample ->
                val active = input == sample
                Box(
                    Modifier.clip(RoundedCornerShape(50))
                        .background(if (active) accent.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (active) accent else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(50))
                        .clickable {
                            input = sample
                            cursor = sample.length
                        }
                        .padding(horizontal = 11.dp, vertical = 5.dp)
                ) {
                    Text(
                        sample,
                        fontSize = 11.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                        color = if (active) accent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Pizarra Blueprint 2D en vivo (estilo Photomath + estética laboratorio Abstergo)
        Box(
            Modifier.fillMaxWidth().weight(1f).padding(horizontal = 14.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(22.dp))
        ) {
            LabBlueprintGrid(Modifier.fillMaxSize())

            Column(
                Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Renderizado 2D grande
                Box(
                    Modifier.fillMaxWidth().weight(1f),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (input.isBlank()) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                "Escribe cualquier problema",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f)
                            )
                            Text(
                                "Ecuaciones, inecuaciones, fracciones, sistemas, derivadas, integrales, complejos o combinatoria.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        }
                    } else {
                        PmMathFormulaView(
                            text = input,
                            fontSize = 27.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Barra de cursor con flechas ◀ ▶
                val pos = cursor.coerceIn(0, input.length)
                val cursorLine = input.substring(0, pos) + "│" + input.substring(pos)
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.85f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        cursorLine,
                        modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                    Text(
                        "◀",
                        Modifier.clip(RoundedCornerShape(6.dp)).clickable { cursor = (cursor - 1).coerceAtLeast(0) }.padding(horizontal = 9.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "▶",
                        Modifier.clip(RoundedCornerShape(6.dp)).clickable { cursor = (cursor + 1).coerceAtMost(input.length) }.padding(horizontal = 9.dp, vertical = 2.dp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Píldora flotante de respuesta en vivo estilo Photomath
                AnimatedVisibility(visible = livePreview != null, enter = fadeIn(), exit = fadeOut()) {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 8.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(accent.copy(alpha = 0.14f))
                            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                            .clickable { if (input.isNotBlank()) onSolve(input) }
                            .padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("=", fontWeight = FontWeight.ExtraBold, color = accent, fontSize = 17.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            livePreview.orEmpty(),
                            modifier = Modifier.weight(1f),
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Box(
                            Modifier.clip(RoundedCornerShape(50)).background(accent).padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Ver pasos", color = onAccent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Selector de pestañas del teclado
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("123 Básico", "f(x) Trig · Log", "∫ Cálc · Comb").forEachIndexed { idx, label ->
                val sel = padTab == idx
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(if (sel) accent.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (sel) accent else Color.Transparent, RoundedCornerShape(12.dp))
                        .clickable { padTab = idx }
                        .padding(vertical = 7.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        fontSize = 12.sp,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                        color = if (sel) accent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Teclado matemático táctil
        Column(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val rows: List<List<CalcKey>> = when (padTab) {
                0 -> listOf(
                    listOf(
                        CalcKey("x", "x", secondary = true),
                        CalcKey("y", "y", secondary = true),
                        CalcKey("x²", "^2", secondary = true),
                        CalcKey("x^□", "^()", 1, secondary = true),
                        CalcKey("√□", "√()", 1, secondary = true),
                        CalcKey("□/□", "()/()", 4, secondary = true)
                    ),
                    listOf(
                        CalcKey("(", "(", secondary = true),
                        CalcKey(")", ")", secondary = true),
                        CalcKey("7", "7"),
                        CalcKey("8", "8"),
                        CalcKey("9", "9"),
                        CalcKey("÷", "/", secondary = true)
                    ),
                    listOf(
                        CalcKey("|□|", "||", 1, secondary = true),
                        CalcKey(";", "; ", secondary = true),
                        CalcKey("4", "4"),
                        CalcKey("5", "5"),
                        CalcKey("6", "6"),
                        CalcKey("×", "*", secondary = true)
                    ),
                    listOf(
                        CalcKey("=", " = ", secondary = true),
                        CalcKey("AC", "__CLEAR__", secondary = true),
                        CalcKey("1", "1"),
                        CalcKey("2", "2"),
                        CalcKey("3", "3"),
                        CalcKey("−", "-", secondary = true)
                    ),
                    listOf(
                        CalcKey("π", "π", secondary = true),
                        CalcKey("⌫", "__BACK__", secondary = true),
                        CalcKey("0", "0"),
                        CalcKey(".", "."),
                        CalcKey("+", "+", secondary = true),
                        CalcKey("Resolver", "__SOLVE__", accent = true)
                    )
                )
                1 -> listOf(
                    listOf(
                        CalcKey("sin", "sin()", 1, secondary = true),
                        CalcKey("cos", "cos()", 1, secondary = true),
                        CalcKey("tan", "tan()", 1, secondary = true),
                        CalcKey("log", "log()", 1, secondary = true),
                        CalcKey("ln", "ln()", 1, secondary = true)
                    ),
                    listOf(
                        CalcKey("asin", "asin()", 1, secondary = true),
                        CalcKey("acos", "acos()", 1, secondary = true),
                        CalcKey("atan", "atan()", 1, secondary = true),
                        CalcKey("log₂", "log_2()", 1, secondary = true),
                        CalcKey("e^x", "e^()", 1, secondary = true)
                    ),
                    listOf(
                        CalcKey("<", " < ", secondary = true),
                        CalcKey("≤", " <= ", secondary = true),
                        CalcKey(">", " > ", secondary = true),
                        CalcKey("≥", " >= ", secondary = true),
                        CalcKey("ⁿ√", "nthrt(3, )", 1, secondary = true)
                    ),
                    listOf(
                        CalcKey("π", "π"),
                        CalcKey("e", "e"),
                        CalcKey("i", "i"),
                        CalcKey("!", "!"),
                        CalcKey("z", "z")
                    ),
                    listOf(
                        CalcKey("AC", "__CLEAR__", secondary = true),
                        CalcKey("⌫", "__BACK__", secondary = true),
                        CalcKey("(", "("),
                        CalcKey(")", ")"),
                        CalcKey("Resolver", "__SOLVE__", accent = true)
                    )
                )
                else -> listOf(
                    listOf(
                        CalcKey("d/dx", "d/dx()", 1, secondary = true),
                        CalcKey("∫ dx", "int(, x)", 4, secondary = true),
                        CalcKey("∫[a,b]", "int(, x, 0, 1)", 10, secondary = true),
                        CalcKey("lim", "lim(x->0, )", 1, secondary = true)
                    ),
                    listOf(
                        CalcKey("C(n,k)", "C(, )", 3, secondary = true),
                        CalcKey("V(n,k)", "V(, )", 3, secondary = true),
                        CalcKey("P(n)", "P()", 1, secondary = true),
                        CalcKey("CR(n,k)", "CR(, )", 3, secondary = true)
                    ),
                    listOf(
                        CalcKey("∞", "inf", secondary = true),
                        CalcKey("→", "->", secondary = true),
                        CalcKey(",", ", ", secondary = true),
                        CalcKey(";", "; ", secondary = true)
                    ),
                    listOf(
                        CalcKey("AC", "__CLEAR__", secondary = true),
                        CalcKey("⌫", "__BACK__", secondary = true),
                        CalcKey("=", " = ", secondary = true),
                        CalcKey("Resolver", "__SOLVE__", accent = true)
                    )
                )
            }

            rows.forEach { row ->
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    row.forEach { key ->
                        val bg = when {
                            key.accent -> accent
                            key.secondary -> MaterialTheme.colorScheme.surfaceVariant
                            else -> MaterialTheme.colorScheme.background
                        }
                        val fg = when {
                            key.accent -> onAccent
                            else -> MaterialTheme.colorScheme.onSurface
                        }
                        Box(
                            Modifier.weight(1f).height(if (isLandscape) 34.dp else 44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(bg)
                                .clickable {
                                    when (key.insert) {
                                        "__CLEAR__" -> clearAll()
                                        "__BACK__" -> backspace()
                                        "__SOLVE__" -> if (input.isNotBlank()) onSolve(input)
                                        else -> insertAtCursor(key.insert, key.cursorBack)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                key.label,
                                fontSize = if (key.label.length > 4) 12.sp else 16.sp,
                                fontWeight = if (key.accent || !key.secondary) FontWeight.Bold else FontWeight.SemiBold,
                                color = fg,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
