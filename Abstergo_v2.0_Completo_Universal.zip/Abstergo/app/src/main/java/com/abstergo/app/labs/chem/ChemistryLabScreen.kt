package com.abstergo.app.labs.chem

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private enum class ChemDrawerTab(val title: String, val subtitle: String, val accentHex: Long, val icon: ChemIconKind) {
    PERIODIC_TABLE("Tabla Periódica", "118 elementos · Fotos, Bohr y 3D", 0xFF38BDF8L, ChemIconKind.GRID),
    ORGANIC("Química Orgánica", "Constructor táctil · IUPAC · Reacciones", 0xFF34D399L, ChemIconKind.ATOM),
    INORGANIC("Química Inorgánica", "Enlaces · Nomenclatura · pH · Redox", 0xFFF59E0BL, ChemIconKind.FLASK),
    FAMOUS_COMPOUNDS("Compuestos Famosos", "Moléculas 3D y cómo se forman", 0xFFF472B6L, ChemIconKind.SPARKLE)
}

private val ROMAN_HEADERS = listOf(
    "IA", "IIA", "IIIB", "IVB", "VB", "VIB", "VIIB",
    "VIIIB", "VIIIB", "VIIIB", "IB", "IIB",
    "IIIA", "IVA", "VA", "VIA", "VIIA", "VIIIA"
)

/**
 * Pantalla raíz de Química Labs dentro de Abstergo:
 * - Estética propia de Vidrio Líquido y Espectroscopía
 * - Menú desplegable lateral (3 rayitas arriba a la izquierda) para cambiar entre pestañas
 *   de Química Labs e ir directo a Notas de Química, Matemática Labs o volver a Labs
 * - Tabla Periódica completa (118 elementos), lista ordenable, ficha con foto real y comparador
 */
@Composable
fun ChemistryLabScreen(
    studentName: String,
    onBackToLabs: () -> Unit,
    onSwitchToMathLab: () -> Unit,
    onSaveNoteToAbstergo: (title: String, body: String) -> Unit,
    onOpenAbstergoNotes: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    val elements by produceState<List<ChemElement>>(initialValue = emptyList()) {
        value = withContext(Dispatchers.IO) { ChemRepository.loadElements(ctx) }
    }
    var userData by remember { mutableStateOf(ChemUserData()) }
    LaunchedEffect(Unit) {
        userData = withContext(Dispatchers.IO) { loadChemUserData(ctx) }
    }

    var activeTab by remember { mutableStateOf(ChemDrawerTab.PERIODIC_TABLE) }
    var selectedElement by remember { mutableStateOf<ChemElement?>(null) }
    var compareTarget by remember { mutableStateOf<ChemElement?>(null) }
    var tempUnit by remember { mutableStateOf(TempUnit.CELSIUS) }

    fun toggleFavorite(z: Int) {
        val nextFavs = if (z in userData.favorites) userData.favorites - z else userData.favorites + z
        val updated = userData.copy(favorites = nextFavs)
        userData = updated
        scope.launch(Dispatchers.IO) { saveChemUserData(ctx, updated) }
    }

    fun updateNote(z: Int, note: String) {
        val nextNotes = userData.notes.toMutableMap()
        if (note.isBlank()) nextNotes.remove(z) else nextNotes[z] = note
        val updated = userData.copy(notes = nextNotes)
        userData = updated
        scope.launch(Dispatchers.IO) { saveChemUserData(ctx, updated) }
    }

    // Subpantalla: Comparador lado a lado
    compareTarget?.let { cmp ->
        ChemCompareScreen(
            first = cmp,
            allElements = elements,
            tempUnit = tempUnit,
            onOpenElement = { el -> compareTarget = null; selectedElement = el },
            onBack = { compareTarget = null }
        )
        return
    }

    // Subpantalla: Ficha completa del elemento
    selectedElement?.let { el ->
        ChemElementDetailScreen(
            element = el,
            allElements = elements,
            isFavorite = el.z in userData.favorites,
            personalNote = userData.notes[el.z].orEmpty(),
            tempUnit = tempUnit,
            onTempUnitChange = { tempUnit = it },
            onNavigateElement = { selectedElement = it },
            onToggleFavorite = { toggleFavorite(el.z) },
            onSavePersonalNote = { txt -> updateNote(el.z, txt) },
            onSendToAbstergoNotes = { title, body ->
                onSaveNoteToAbstergo(title, body)
                Toast.makeText(ctx, "Ficha guardada en Notas de Abstergo (Química)", Toast.LENGTH_SHORT).show()
            },
            onStartCompare = { target -> compareTarget = target },
            onBack = { selectedElement = null }
        )
        return
    }

    BackHandler {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else {
            onBackToLabs()
        }
    }

    val accent = chemPrimaryAccent()
    val glass = chemGlassSurface()

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = drawerState.isOpen,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(292.dp),
                drawerContainerColor = glass,
                drawerContentColor = MaterialTheme.colorScheme.onSurface
            ) {
                Column(
                    Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Cabecera del desplegable con identidad Química Labs × Abstergo
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                            .background(accent.copy(alpha = 0.13f))
                            .border(1.dp, chemGlassBorder(accent), RoundedCornerShape(18.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ChemIcon(ChemIconKind.FLASK, accent, Modifier.size(22.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Química Labs", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Text(
                            "ABSTERGO · ${studentName.ifBlank { "ESTUDIANTE" }.uppercase()}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = accent,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "118 elementos · ${userData.favorites.size} favoritos",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.height(4.dp))
                    Text("HERRAMIENTAS", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 6.dp))

                    ChemDrawerTab.entries.forEach { tab ->
                        val sel = activeTab == tab
                        val tabCol = Color(tab.accentHex)
                        Row(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (sel) tabCol.copy(alpha = 0.17f) else Color.Transparent)
                                .border(1.dp, if (sel) chemGlassBorder(tabCol) else Color.Transparent, RoundedCornerShape(14.dp))
                                .clickable {
                                    activeTab = tab
                                    scope.launch { drawerState.close() }
                                }
                                .padding(horizontal = 12.dp, vertical = 11.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ChemIcon(tab.icon, if (sel) tabCol else MaterialTheme.colorScheme.onSurfaceVariant, Modifier.size(20.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(tab.title, fontSize = 14.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.SemiBold)
                                Text(tab.subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (sel) {
                                Box(Modifier.size(8.dp).clip(CircleShape).background(tabCol))
                            }
                        }
                    }

                    HorizontalDivider(color = chemGlassBorder(), modifier = Modifier.padding(vertical = 6.dp))
                    Text("CONECTADO A ABSTERGO", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 6.dp))

                    DrawerLinkRow(ChemIconKind.NOTE, "Notas de Química", "Ver tus fichas guardadas") {
                        scope.launch { drawerState.close() }
                        onOpenAbstergoNotes()
                    }
                    DrawerLinkRow(ChemIconKind.MATH_SHORTCUT, "Cambiar a Matemática Labs", "Motor Photomath 10mo–12mo") {
                        scope.launch { drawerState.close() }
                        onSwitchToMathLab()
                    }

                    Spacer(Modifier.height(10.dp))

                    // Botón claro de salida hacia la galería de Labs de Abstergo
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                            .clickable {
                                scope.launch { drawerState.close() }
                                onBackToLabs()
                            }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ChemIcon(ChemIconKind.EXIT_LABS, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Volver a Labs", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) {
        Box(Modifier.fillMaxSize().background(chemCanvasBg()).statusBarsPadding()) {
            when (activeTab) {
                ChemDrawerTab.PERIODIC_TABLE -> PeriodicTableWorkspace(
                    elements = elements,
                    favorites = userData.favorites,
                    tempUnit = tempUnit,
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    onSelectElement = { selectedElement = it },
                    onToggleFavorite = ::toggleFavorite,
                    onOpenCompare = { el -> compareTarget = el },
                    onQuickTab = { activeTab = it }
                )
                ChemDrawerTab.ORGANIC -> ChemOrganicLabScreen(
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    onSaveNoteToAbstergo = { title, body ->
                        onSaveNoteToAbstergo(title, body)
                        Toast.makeText(ctx, "Compuesto orgánico guardado en Notas de Abstergo", Toast.LENGTH_SHORT).show()
                    }
                )
                ChemDrawerTab.INORGANIC -> ChemInorganicLabScreen(
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    onSaveNoteToAbstergo = { title, body ->
                        onSaveNoteToAbstergo(title, body)
                        Toast.makeText(ctx, "Compuesto inorgánico guardado en Notas de Abstergo", Toast.LENGTH_SHORT).show()
                    }
                )
                ChemDrawerTab.FAMOUS_COMPOUNDS -> ChemFamousCompoundsScreen(
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    onSaveNoteToAbstergo = { title, body ->
                        onSaveNoteToAbstergo(title, body)
                        Toast.makeText(ctx, "Compuesto famoso guardado en Notas de Abstergo", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
private fun DrawerLinkRow(icon: ChemIconKind, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ChemIcon(icon, MaterialTheme.colorScheme.onSurfaceVariant, Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ==============================================================================
// ESPACIO DE TRABAJO DE LA TABLA PERIÓDICA INTERACTIVA (118 ELEMENTOS)
// ==============================================================================

@Composable
private fun PeriodicTableWorkspace(
    elements: List<ChemElement>,
    favorites: Set<Int>,
    tempUnit: TempUnit,
    onOpenDrawer: () -> Unit,
    onSelectElement: (ChemElement) -> Unit,
    onToggleFavorite: (Int) -> Unit,
    onOpenCompare: (ChemElement) -> Unit,
    onQuickTab: (ChemDrawerTab) -> Unit
) {
    val dark = chemIsDark()
    val accent = chemPrimaryAccent()
    val glass = chemGlassSurface()

    var showSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var listMode by remember { mutableStateOf(false) }
    var showTempBar by remember { mutableStateOf(false) }
    var tempC by remember { mutableStateOf(25.0) }
    var onlyFavorites by remember { mutableStateOf(false) }

    var colorMode by remember { mutableStateOf(ChemColorMode.FAMILY) }
    var cellMetric by remember { mutableStateOf(ChemCellMetric.MASS) }
    var filterCategory by remember { mutableStateOf<ChemCategory?>(null) }
    var sortMode by remember { mutableStateOf(ChemSortMode.ATOMIC_NUM) }
    var tableZoom by remember { mutableStateOf(1.0f) }

    val elementByGrid = remember(elements) {
        elements.associateBy { it.gridRow to it.gridCol }
    }

    val matchingSet = remember(elements, query, filterCategory, onlyFavorites, favorites) {
        elements.filter { el ->
            val okQ = el.matchesQuery(query)
            val okCat = filterCategory == null || el.category == filterCategory
            val okFav = !onlyFavorites || el.z in favorites
            okQ && okCat && okFav
        }.map { it.z }.toHashSet()
    }

    val isFiltering = query.isNotBlank() || filterCategory != null || onlyFavorites

    Column(Modifier.fillMaxSize().background(chemCanvasBg())) {
        // Barra superior de Química Labs con 3 rayitas (☰) arriba a la izquierda
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChemCircleBtn(ChemIconKind.MENU, MaterialTheme.colorScheme.onSurface, onClick = onOpenDrawer)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Tabla Periódica", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    if (showTempBar) "QUÍMICA LABS · ${tempC.roundToInt()} °C (${(tempC + 273.15).roundToInt()} K)"
                    else "QUÍMICA LABS · 118 ELEMENTOS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = accent
                )
            }
            ChemCircleBtn(
                ChemIconKind.SEARCH,
                if (showSearch || query.isNotBlank()) accent else MaterialTheme.colorScheme.onSurface
            ) {
                showSearch = !showSearch
                if (!showSearch) query = ""
            }
            Spacer(Modifier.width(6.dp))
            ChemCircleBtn(
                ChemIconKind.THERMO,
                if (showTempBar) accent else MaterialTheme.colorScheme.onSurface
            ) {
                showTempBar = !showTempBar
                if (showTempBar && colorMode == ChemColorMode.FAMILY) colorMode = ChemColorMode.STATE
            }
            Spacer(Modifier.width(6.dp))
            ChemCircleBtn(
                if (onlyFavorites) ChemIconKind.STAR_FILLED else ChemIconKind.STAR_OUTLINE,
                if (onlyFavorites) Color(0xFFFACC15) else MaterialTheme.colorScheme.onSurface
            ) { onlyFavorites = !onlyFavorites }
            Spacer(Modifier.width(6.dp))
            ChemCircleBtn(
                if (listMode) ChemIconKind.GRID else ChemIconKind.LIST,
                MaterialTheme.colorScheme.onSurface
            ) { listMode = !listMode }
        }

        // Buscador inteligente desplegable (nombre, símbolo, Z, usos u objeto cotidiano como "pantalla" o "batería")
        AnimatedVisibility(visible = showSearch) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                placeholder = { Text("Buscar por nombre, símbolo, Z o uso (ej: pantalla, batería, gas)…", fontSize = 12.sp) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        Box(Modifier.clickable { query = "" }.padding(8.dp)) {
                            ChemIcon(ChemIconKind.CLOSE, MaterialTheme.colorScheme.onSurfaceVariant, Modifier.size(16.dp))
                        }
                    }
                }
            )
        }

        // Barra interactiva de temperatura en vivo (-273 °C a 4000 °C)
        AnimatedVisibility(visible = showTempBar) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(glass)
                    .border(1.dp, chemGlassBorder(accent), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Temperatura: ${tempC.roundToInt()} °C  (${(tempC + 273.15).roundToInt()} K)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "25 °C",
                        fontSize = 11.sp,
                        color = accent,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { tempC = 25.0 }.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Slider(
                    value = tempC.toFloat(),
                    onValueChange = { tempC = it.toDouble() },
                    valueRange = -273f..4000f
                )
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(-200.0 to "-200°C", 0.0 to "0°C", 25.0 to "25°C", 30.0 to "30°C (Ga)", 100.0 to "100°C", 1000.0 to "1000°C", 3500.0 to "3500°C").forEach { (t, lbl) ->
                        val active = kotlin.math.abs(tempC - t) < 1.5
                        Box(
                            Modifier.clip(RoundedCornerShape(50))
                                .background(if (active) accent.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { tempC = t }
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) { Text(lbl, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Medium) }
                    }
                }
            }
        }

        // Accesos directos luminosos a los módulos de Química Labs (también en el menú ☰)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                Triple(ChemDrawerTab.ORGANIC, "Orgánica · Enlaces", Color(0xFF34D399)),
                Triple(ChemDrawerTab.INORGANIC, "Inorgánica · pH/Sales", Color(0xFFF59E0B)),
                Triple(ChemDrawerTab.FAMOUS_COMPOUNDS, "Compuestos Famosos 3D", Color(0xFFF472B6))
            ).forEach { (target, lbl, col) ->
                Row(
                    Modifier.clip(RoundedCornerShape(50))
                        .background(col.copy(alpha = if (dark) 0.16f else 0.12f))
                        .border(1.dp, col.copy(alpha = 0.55f), RoundedCornerShape(50))
                        .clickable { onQuickTab(target) }
                        .padding(horizontal = 11.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ChemIcon(target.icon, col, Modifier.size(13.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(lbl, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = col)
                }
            }
        }

        // Controles de coloreado (mapas de calor) + dato visible en celda / orden de lista
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!listMode) {
                ChemColorMode.entries.forEach { m ->
                    val sel = colorMode == m
                    CompactLabChip(m.label, sel, accent) { colorMode = m }
                }
                Box(Modifier.width(1.dp).height(18.dp).background(chemGlassBorder()))
                ChemCellMetric.entries.forEach { met ->
                    val sel = cellMetric == met
                    CompactLabChip("Celda: ${met.label}", sel, Color(0xFF34D399)) { cellMetric = met }
                }
            } else {
                ChemSortMode.entries.forEach { sm ->
                    CompactLabChip(sm.label, sortMode == sm, accent) { sortMode = sm }
                }
            }
        }

        // Leyenda / Filtro rápido por familias (toca una familia para resaltarla)
        if (colorMode == ChemColorMode.FAMILY || listMode) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (filterCategory != null) {
                    CompactLabChip("Todas ✕", true, accent) { filterCategory = null }
                }
                ChemCategory.entries.forEach { cat ->
                    val c = cat.color(dark)
                    val sel = filterCategory == cat
                    Row(
                        Modifier.clip(RoundedCornerShape(50))
                            .background(if (sel) c.copy(alpha = 0.24f) else glass)
                            .border(1.dp, if (sel) c else chemGlassBorder(), RoundedCornerShape(50))
                            .clickable { filterCategory = if (sel) null else cat }
                            .padding(horizontal = 9.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(c))
                        Spacer(Modifier.width(5.dp))
                        Text(cat.shortLabel, fontSize = 10.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
        } else if (colorMode == ChemColorMode.STATE) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StateLegendDot("Sólido", if (dark) Color(0xFF60A5FA) else Color(0xFF2563EB))
                StateLegendDot("Líquido", if (dark) Color(0xFF22D3EE) else Color(0xFF0891B2))
                StateLegendDot("Gas", if (dark) Color(0xFFFB923C) else Color(0xFFEA580C))
                StateLegendDot("Sintético", if (dark) Color(0xFF94A3B8) else Color(0xFF64748B))
            }
        } else if (colorMode == ChemColorMode.BLOCK) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StateLegendDot("Bloque s", if (dark) Color(0xFFFF6B6B) else Color(0xFFDC2626))
                StateLegendDot("Bloque p", if (dark) Color(0xFFFACC15) else Color(0xFFCA8A04))
                StateLegendDot("Bloque d", if (dark) Color(0xFF4DABF7) else Color(0xFF2563EB))
                StateLegendDot("Bloque f", if (dark) Color(0xFF34D399) else Color(0xFF059669))
            }
        }

        if (elements.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = accent)
            }
            return
        }

        // Vista principal: Cuadrícula IUPAC 18 columnas con zoom/arrastre o Lista ordenable
        if (!listMode) {
            Box(
                Modifier.fillMaxWidth().weight(1f)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            if (zoom != 1f && zoom.isFinite()) {
                                tableZoom = (tableZoom * zoom).coerceIn(0.68f, 1.75f)
                            }
                        }
                    }
            ) {
                val hScroll = rememberScrollState()
                val vScroll = rememberScrollState()
                val cellW = (58 * tableZoom).dp
                val cellH = (68 * tableZoom).dp
                val gap = (3.5f * tableZoom).dp

                Column(
                    Modifier.fillMaxSize()
                        .verticalScroll(vScroll)
                        .horizontalScroll(hScroll)
                        .padding(start = 10.dp, end = 24.dp, top = 6.dp, bottom = 72.dp),
                    verticalArrangement = Arrangement.spacedBy(gap)
                ) {
                    // Encabezado doble de grupos: 1–18 y Romanos IA–VIIIA / IB–VIIIB
                    Row(horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.width((24 * tableZoom).dp))
                        for (col in 1..18) {
                            Column(
                                Modifier.width(cellW),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("$col", fontSize = (10 * tableZoom).sp, fontWeight = FontWeight.ExtraBold, color = accent)
                                Text(ROMAN_HEADERS[col - 1], fontSize = (8 * tableZoom).sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    // Períodos 1 al 7
                    for (row in 1..7) {
                        Row(horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.width((24 * tableZoom).dp), contentAlignment = Alignment.Center) {
                                Text("$row", fontSize = (11 * tableZoom).sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            for (col in 1..18) {
                                val el = elementByGrid[row to col]
                                if (el != null) {
                                    PeriodicCell(
                                        el = el,
                                        color = elementCellColor(el, colorMode, tempC, dark),
                                        metric = cellMetric,
                                        tempUnit = tempUnit,
                                        tempC = tempC,
                                        showStateTag = showTempBar || colorMode == ChemColorMode.STATE,
                                        isFav = el.z in favorites,
                                        dimmed = isFiltering && el.z !in matchingSet,
                                        zoom = tableZoom,
                                        modifier = Modifier.width(cellW).height(cellH),
                                        onClick = { onSelectElement(el) }
                                    )
                                } else if ((row == 6 && col == 3) || (row == 7 && col == 3)) {
                                    val isLan = row == 6
                                    val c = (if (isLan) ChemCategory.LANTHANIDE else ChemCategory.ACTINIDE).color(dark)
                                    Box(
                                        Modifier.width(cellW).height(cellH)
                                            .clip(RoundedCornerShape((10 * tableZoom).dp))
                                            .background(c.copy(alpha = 0.12f))
                                            .border(1.dp, c.copy(alpha = 0.45f), RoundedCornerShape((10 * tableZoom).dp))
                                            .clickable {
                                                filterCategory = if (isLan) ChemCategory.LANTHANIDE else ChemCategory.ACTINIDE
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(if (isLan) "57–71" else "89–103", fontSize = (10 * tableZoom).sp, fontWeight = FontWeight.Bold, color = c)
                                            Text(if (isLan) "La–Lu" else "Ac–Lr", fontSize = (8 * tableZoom).sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                } else {
                                    Spacer(Modifier.width(cellW).height(cellH))
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height((10 * tableZoom).dp))

                    // Filas f: Lantánidos (9) y Actínidos (10)
                    for ((row, label) in listOf(9 to "La", 10 to "Ac")) {
                        Row(horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.width((24 * tableZoom).dp), contentAlignment = Alignment.Center) {
                                Text(label, fontSize = (9 * tableZoom).sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            for (col in 1..18) {
                                val el = elementByGrid[row to col]
                                if (el != null) {
                                    PeriodicCell(
                                        el = el,
                                        color = elementCellColor(el, colorMode, tempC, dark),
                                        metric = cellMetric,
                                        tempUnit = tempUnit,
                                        tempC = tempC,
                                        showStateTag = showTempBar || colorMode == ChemColorMode.STATE,
                                        isFav = el.z in favorites,
                                        dimmed = isFiltering && el.z !in matchingSet,
                                        zoom = tableZoom,
                                        modifier = Modifier.width(cellW).height(cellH),
                                        onClick = { onSelectElement(el) }
                                    )
                                } else {
                                    Spacer(Modifier.width(cellW).height(cellH))
                                }
                            }
                        }
                    }
                }

                // Controles flotantes de zoom + acceso rápido al comparador
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ZoomPillBtn("−") { tableZoom = (tableZoom - 0.16f).coerceAtLeast(0.68f) }
                    ZoomPillBtn("${(tableZoom * 100).roundToInt()}%") { tableZoom = 1.0f }
                    ZoomPillBtn("+") { tableZoom = (tableZoom + 0.16f).coerceAtMost(1.75f) }
                    Box(
                        Modifier.height(34.dp).clip(RoundedCornerShape(10.dp))
                            .background(accent)
                            .clickable { elements.firstOrNull()?.let(onOpenCompare) }
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ChemIcon(ChemIconKind.COMPARE, if (dark) Color(0xFF07111A) else Color.White, Modifier.size(14.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Comparar", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (dark) Color(0xFF07111A) else Color.White)
                        }
                    }
                }
            }
        } else {
            // Vista en Lista ordenable con todos los datos clave
            val sortedList = remember(elements, matchingSet, sortMode) {
                val base = elements.filter { it.z in matchingSet }
                when (sortMode) {
                    ChemSortMode.ATOMIC_NUM -> base.sortedBy { it.z }
                    ChemSortMode.NAME -> base.sortedBy { it.name }
                    ChemSortMode.MASS -> base.sortedByDescending { it.mass }
                    ChemSortMode.DENSITY -> base.sortedByDescending { it.density ?: -1.0 }
                    ChemSortMode.MELT -> base.sortedByDescending { it.meltK ?: -1.0 }
                    ChemSortMode.ELECTRONEG -> base.sortedByDescending { it.electronegativity ?: -1.0 }
                    ChemSortMode.YEAR -> base.sortedBy { it.discoveryYearInt() }
                }
            }
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(sortedList, key = { it.z }) { el ->
                    val col = elementCellColor(el, colorMode, tempC, dark)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(glass)
                            .border(1.dp, chemGlassBorder(col), RoundedCornerShape(16.dp))
                            .clickable { onSelectElement(el) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(13.dp))
                                .background(col.copy(alpha = 0.18f))
                                .border(1.2.dp, col.copy(alpha = 0.7f), RoundedCornerShape(13.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${el.z}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = col, fontWeight = FontWeight.Bold)
                                Text(el.symbol, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = col)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(el.name, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "${el.category.shortLabel} · ${el.massText} u · ${el.phaseAtCelsius(tempC)}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                el.hiddenObjects,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).clickable { onToggleFavorite(el.z) },
                            contentAlignment = Alignment.Center
                        ) {
                            ChemIcon(
                                if (el.z in favorites) ChemIconKind.STAR_FILLED else ChemIconKind.STAR_OUTLINE,
                                if (el.z in favorites) Color(0xFFFACC15) else MaterialTheme.colorScheme.onSurfaceVariant,
                                Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PeriodicCell(
    el: ChemElement,
    color: Color,
    metric: ChemCellMetric,
    tempUnit: TempUnit,
    tempC: Double,
    showStateTag: Boolean,
    isFav: Boolean,
    dimmed: Boolean,
    zoom: Float,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val dark = chemIsDark()
    val stateChar = when (el.phaseAtCelsius(tempC)) {
        "Sólido" -> "S"
        "Líquido" -> "L"
        "Gas" -> "G"
        else -> "X"
    }
    Column(
        modifier = modifier
            .alpha(if (dimmed) 0.18f else 1f)
            .clip(RoundedCornerShape((11 * zoom).dp))
            .background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(
                        color.copy(alpha = if (dark) 0.28f else 0.20f),
                        color.copy(alpha = if (dark) 0.11f else 0.08f)
                    )
                )
            )
            .border((1.2f * zoom).coerceAtLeast(0.9f).dp, color.copy(alpha = if (dark) 0.72f else 0.55f), RoundedCornerShape((11 * zoom).dp))
            .clickable { onClick() }
            .padding(horizontal = (4 * zoom).dp, vertical = (3 * zoom).dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${el.z}",
                fontSize = (9 * zoom).sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = color,
                maxLines = 1
            )
            Spacer(Modifier.weight(1f))
            if (isFav) {
                Box(Modifier.size((5.5f * zoom).dp).clip(CircleShape).background(Color(0xFFFACC15)))
            } else if (showStateTag) {
                Text(stateChar, fontSize = (8 * zoom).sp, fontWeight = FontWeight.ExtraBold, color = color)
            }
        }
        Text(
            el.symbol,
            fontSize = (18 * zoom).sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
            maxLines = 1
        )
        Text(
            el.name,
            fontSize = (7.5f * zoom).sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            el.metricLine(metric, tempUnit),
            fontSize = (7.5f * zoom).sp,
            fontFamily = FontFamily.Monospace,
            color = color,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun CompactLabChip(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (selected) accent.copy(alpha = 0.18f) else chemGlassSurface())
            .border(1.dp, if (selected) accent else chemGlassBorder(), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun StateLegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ZoomPillBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.height(34.dp).clip(RoundedCornerShape(10.dp))
            .background(chemGlassSurface().copy(alpha = 0.94f))
            .border(1.dp, chemGlassBorder(), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}
