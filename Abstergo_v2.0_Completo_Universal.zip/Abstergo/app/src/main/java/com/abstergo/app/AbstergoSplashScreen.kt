package com.abstergo.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Pantalla de carga Motion Graphic de ABSTERGO (5 segundos, fondo negro puro, tocar para saltar):
 * - Barra de progreso horizontal fina entre el logo y el borde inferior.
 * - Al avanzar y completar la carga, cada letra de ABSTERGO emerge del negro con la estética
 *   motion graphic de una asignatura:
 *     A: Biología (nace como 'a' minúscula celular -> evoluciona a mayúscula -> se transforma en la 'A' custom del ícono)
 *     B: Química (anillo bencénico / burbujas cian)
 *     S: Física (onda sinusoidal / osciloscopio ámbar)
 *     T: Matemática (ejes cartesianos / blueprint verde menta)
 *     E: Informática (trazos de circuito violeta)
 *     R: Historia / Literatura (trazo clásico dorado)
 *     G: Geografía (arco orbital / meridianos esmeralda)
 *     O: Óptica / Astronomía (anillo espectral prisma -> blanco luminoso)
 */
@Composable
fun AbstergoSplashScreen(onDone: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    val finish = { if (!finished) { finished = true; onDone() } }

    // Progreso maestro 0f -> 1f en exactamente 5000 ms
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 5000, easing = LinearEasing)
        )
        finish()
    }

    val t = progress.value
    // La barra fina carga suavemente en los primeros 3.4s y da paso a la revelación final completa
    val barProgress = (t / 0.72f).coerceIn(0f, 1f)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { finish() }
    ) {
        // Lienzo principal motion graphic (totalmente responsivo en vertical y horizontal)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            val w = size.width
            val h = size.height
            if (w <= 1f || h <= 1f) return@Canvas

            // Tamaño responsivo para Portrait y Landscape
            val wordMaxW = (w * 0.88f).coerceAtMost(h * 1.45f)
            val letterSlot = wordMaxW / 8.6f
            val letterW = letterSlot * 0.86f
            val letterH = letterW * 1.18f
            val totalW = letterSlot * 8f
            val startX = (w - totalW) / 2f
            val centerY = h * 0.46f
            val topY = centerY - letterH / 2f

            // Fase de cada letra (staggered motion graphic emergiendo del fondo negro):
            // A (Biología) comienza primero con evolución a -> A -> icono A
            // Las demás letras emergen en cascada conforme la barra se aproxima al 100% y culminan al completarse
            fun subT(start: Float, end: Float): Float = ((t - start) / (end - start)).coerceIn(0f, 1f)
            fun easeOutCubic(x: Float): Float = 1f - (1f - x) * (1f - x) * (1f - x)

            val tA = subT(0.06f, 0.76f)
            val tB = easeOutCubic(subT(0.32f, 0.74f))
            val tS = easeOutCubic(subT(0.40f, 0.78f))
            val tT = easeOutCubic(subT(0.48f, 0.81f))
            val tE = easeOutCubic(subT(0.54f, 0.84f))
            val tR = easeOutCubic(subT(0.60f, 0.87f))
            val tG = easeOutCubic(subT(0.66f, 0.90f))
            val tO = easeOutCubic(subT(0.71f, 0.94f))

            // Unificación luminosa final al blanco limpio de marca (0.86..0.98)
            val unify = easeOutCubic(subT(0.84f, 0.97f))

            // Destello ambiental suave detrás de la palabra
            val ambientAlpha = (t * 0.22f).coerceAtMost(0.18f) * (1f - unify * 0.35f)
            if (ambientAlpha > 0.01f) {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1F3B36).copy(alpha = ambientAlpha), Color.Transparent),
                        center = Offset(w / 2f, centerY),
                        radius = wordMaxW * 0.65f
                    )
                )
            }

            // 1) A — BIOLOGÍA: 'a' minúscula orgánica -> 'A' mayúscula -> 'A' custom exacta del ícono
            drawBioLetterA(
                left = startX + letterSlot * 0f,
                top = topY,
                w = letterW,
                h = letterH,
                p = tA,
                unify = unify
            )

            // 2) B — QUÍMICA (anillo molecular + burbujas cian)
            if (tB > 0f) {
                drawChemLetterB(startX + letterSlot * 1f, topY, letterW, letterH, tB, unify)
            }

            // 3) S — FÍSICA (onda sinusoidal + chispas vectoriales)
            if (tS > 0f) {
                drawPhysicsLetterS(startX + letterSlot * 2f, topY, letterW, letterH, tS, unify)
            }

            // 4) T — MATEMÁTICA (ejes cartesianos + ticks blueprint menta)
            if (tT > 0f) {
                drawMathLetterT(startX + letterSlot * 3f, topY, letterW, letterH, tT, unify)
            }

            // 5) E — INFORMÁTICA (trazos de circuito con nodos luminosos)
            if (tE > 0f) {
                drawTechLetterE(startX + letterSlot * 4f, topY, letterW, letterH, tE, unify)
            }

            // 6) R — HISTORIA / LITERATURA (trazo editorial dorado)
            if (tR > 0f) {
                drawHistoryLetterR(startX + letterSlot * 5f, topY, letterW, letterH, tR, unify)
            }

            // 7) G — GEOGRAFÍA (meridianos y arco orbital esmeralda-cian)
            if (tG > 0f) {
                drawGeoLetterG(startX + letterSlot * 6f, topY, letterW, letterH, tG, unify)
            }

            // 8) O — ÓPTICA / ESPECTROSCOPÍA (prisma espectral cerrándose en blanco)
            if (tO > 0f) {
                drawOpticsLetterO(startX + letterSlot * 7f, topY, letterW, letterH, tO, unify)
            }

            // Barra de progreso horizontal FINA entre el logo y el borde inferior de la pantalla
            val barW = (w * 0.56f).coerceIn(140.dp.toPx(), 340.dp.toPx())
            val barH = 2.6.dp.toPx()
            val barLeft = (w - barW) / 2f
            val barY = centerY + (h - centerY) * 0.54f

            // Pista oscura sutil
            drawRoundRect(
                color = Color(0x33FFFFFF),
                topLeft = Offset(barLeft, barY),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barH, barH)
            )
            // Progreso luminoso
            val fillW = (barW * barProgress).coerceAtLeast(barH)
            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xFF34D399), Color(0xFF38BDF8), Color.White),
                    startX = barLeft,
                    endX = barLeft + fillW
                ),
                topLeft = Offset(barLeft, barY),
                size = Size(fillW, barH),
                cornerRadius = CornerRadius(barH, barH)
            )
            // Punto de brillo en la punta de la barra mientras avanza
            if (barProgress in 0.02f..0.99f) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.75f),
                    radius = 5.dp.toPx(),
                    center = Offset(barLeft + fillW, barY + barH / 2f)
                )
            }
        }

        // Indicación ultra discreta en el borde inferior (no estorba la barra)
        Text(
            text = "Toca para saltar",
            color = Color(0x4DFFFFFF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 14.dp)
        )
    }
}

private fun blendColor(a: Color, b: Color, t: Float): Color = Color(
    red = a.red + (b.red - a.red) * t,
    green = a.green + (b.green - a.green) * t,
    blue = a.blue + (b.blue - a.blue) * t,
    alpha = a.alpha + (b.alpha - a.alpha) * t
)

/**
 * Letra A — BIOLOGÍA:
 * 0.00..0.42: Nace como una 'a' minúscula orgánica verde bioluminiscente con pulso celular.
 * 0.42..0.72: Evoluciona en motion graphic de 'a' minúscula hacia 'A' mayúscula.
 * 0.72..1.00: Cristaliza en la 'A' custom blanca exacta del ícono de Abstergo.
 */
private fun DrawScope.drawBioLetterA(
    left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float
) {
    val bioGreen = Color(0xFF34D399)
    val bioMint = Color(0xFF86FF8E)
    val stW = (w * 0.13f).coerceAtLeast(3f)

    // Fase 1: 'a' minúscula orgánica + anillo celular (desvanece al evolucionar)
    val lowerAlpha = when {
        p < 0.08f -> p / 0.08f
        p < 0.42f -> 1f
        p < 0.62f -> 1f - (p - 0.42f) / 0.20f
        else -> 0f
    }.coerceIn(0f, 1f)

    if (lowerAlpha > 0.01f) {
        val grow = (p / 0.35f).coerceIn(0.25f, 1f)
        val cx = left + w * 0.50f
        val cy = top + h * 0.64f
        val rad = w * 0.29f * grow
        // Pulso celular bioluminiscente
        drawCircle(
            color = bioGreen.copy(alpha = lowerAlpha * 0.24f),
            radius = rad * (1.25f + 0.22f * sin(p * 18f)),
            center = Offset(cx, cy),
            style = Stroke(width = stW * 0.35f)
        )
        // Trazo orgánico de la 'a' minúscula
        val aLower = Path().apply {
            moveTo(left + w * 0.24f, top + h * 0.46f)
            cubicTo(left + w * 0.38f, top + h * 0.34f, left + w * 0.74f, top + h * 0.36f, left + w * 0.76f, top + h * 0.54f)
            lineTo(left + w * 0.76f, top + h * 0.85f)
        }
        drawPath(aLower, bioMint.copy(alpha = lowerAlpha), style = Stroke(stW, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawOval(
            color = bioGreen.copy(alpha = lowerAlpha),
            topLeft = Offset(left + w * 0.20f, top + h * 0.56f),
            size = Size(w * 0.55f, h * 0.29f),
            style = Stroke(stW * 0.92f)
        )
    }

    // Fase 2 -> 3: Evolución hacia la A mayúscula y cristalización en la A custom exacta del ícono
    val upperP = ((p - 0.38f) / 0.45f).coerceIn(0f, 1f)
    if (upperP > 0f) {
        val iconMorph = ((p - 0.68f) / 0.32f).coerceIn(0f, 1f)
        val col = blendColor(bioGreen, Color.White, maxOf(iconMorph, unify))
        val scale = 0.78f + 0.22f * upperP

        // Pequeña hélice / brote biológico que se disuelve al volverse ícono
        val bioGlow = (1f - iconMorph) * upperP
        if (bioGlow > 0.02f) {
            drawCircle(
                color = bioMint.copy(alpha = bioGlow * 0.32f),
                radius = w * 0.62f * upperP,
                center = Offset(left + w * 0.5f, top + h * 0.52f),
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Exacta geometría 0..100 de la A custom del ícono de Abstergo
        fun mx(nx: Float): Float = left + w * (0.5f + ((nx / 100f) - 0.5f) * scale)
        fun my(ny: Float): Float = top + h * (0.5f + ((ny / 100f) - 0.5f) * scale)

        val mainPath = Path().apply {
            moveTo(mx(50.0f), my(15.0f))
            lineTo(mx(56.5f), my(15.0f))
            lineTo(mx(83.5f), my(85.0f))
            lineTo(mx(71.5f), my(85.0f))
            lineTo(mx(52.5f), my(33.0f))
            lineTo(mx(36.0f), my(74.5f))
            lineTo(mx(29.5f), my(85.0f))
            lineTo(mx(16.5f), my(85.0f))
            close()
        }
        val barPath = Path().apply {
            moveTo(mx(38.0f), my(64.5f))
            lineTo(mx(66.5f), my(57.0f))
            lineTo(mx(70.5f), my(67.5f))
            lineTo(mx(42.0f), my(74.0f))
            close()
        }

        drawPath(mainPath, col.copy(alpha = upperP))
        // La barra diagonal característica aparece deslizando en la fase final
        val barAlpha = ((upperP - 0.25f) / 0.75f).coerceIn(0f, 1f)
        if (barAlpha > 0f) {
            drawPath(barPath, col.copy(alpha = barAlpha))
        }
    }
}

/** Letra B — QUÍMICA: cristal cian con destello de anillo bencénico y burbujas moleculares. */
private fun DrawScope.drawChemLetterB(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val chemCyan = Color(0xFF38BDF8)
    val col = blendColor(chemCyan, Color.White, unify)
    val st = Stroke((w * 0.13f).coerceAtLeast(3f), cap = StrokeCap.Round, join = StrokeJoin.Round)
    val dy = (1f - p) * h * 0.22f

    // Burbujas / anillo molecular efímero durante la aparición
    val fx = (1f - unify) * p
    if (fx > 0.05f) {
        drawCircle(chemCyan.copy(alpha = fx * 0.45f), w * 0.12f, Offset(left + w * 0.75f, top + h * 0.25f - dy), style = Stroke(2f))
        drawCircle(chemCyan.copy(alpha = fx * 0.65f), w * 0.06f, Offset(left + w * 0.86f, top + h * 0.14f - dy))
    }

    val path = Path().apply {
        moveTo(left + w * 0.20f, top + h * 0.16f + dy)
        lineTo(left + w * 0.20f, top + h * 0.84f + dy)
        moveTo(left + w * 0.20f, top + h * 0.16f + dy)
        lineTo(left + w * 0.56f, top + h * 0.16f + dy)
        cubicTo(left + w * 0.82f, top + h * 0.16f + dy, left + w * 0.82f, top + h * 0.49f + dy, left + w * 0.56f, top + h * 0.49f + dy)
        lineTo(left + w * 0.20f, top + h * 0.49f + dy)
        lineTo(left + w * 0.60f, top + h * 0.49f + dy)
        cubicTo(left + w * 0.88f, top + h * 0.49f + dy, left + w * 0.88f, top + h * 0.84f + dy, left + w * 0.60f, top + h * 0.84f + dy)
        lineTo(left + w * 0.20f, top + h * 0.84f + dy)
    }
    drawPath(path, col.copy(alpha = p), style = st)
}

/** Letra S — FÍSICA: onda sinusoidal vibrante que se estabiliza en la letra S. */
private fun DrawScope.drawPhysicsLetterS(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val physAmber = Color(0xFFF59E0B)
    val col = blendColor(physAmber, Color.White, unify)
    val st = Stroke((w * 0.13f).coerceAtLeast(3f), cap = StrokeCap.Round, join = StrokeJoin.Round)
    val wobble = (1f - p) * w * 0.16f * sin(p * 16f)

    if ((1f - unify) > 0.05f) {
        // Vector de onda física
        drawLine(
            Color(0xFF38BDF8).copy(alpha = (1f - unify) * p * 0.45f),
            Offset(left + w * 0.1f, top + h * 0.5f),
            Offset(left + w * 0.9f, top + h * 0.5f),
            strokeWidth = 2f
        )
    }

    val path = Path().apply {
        moveTo(left + w * 0.78f + wobble, top + h * 0.24f)
        cubicTo(left + w * 0.64f, top + h * 0.11f, left + w * 0.18f, top + h * 0.14f, left + w * 0.20f, top + h * 0.34f)
        cubicTo(left + w * 0.22f, top + h * 0.50f, left + w * 0.80f, top + h * 0.48f, left + w * 0.80f - wobble, top + h * 0.68f)
        cubicTo(left + w * 0.80f, top + h * 0.88f, left + w * 0.30f, top + h * 0.89f, left + w * 0.18f, top + h * 0.76f)
    }
    drawPath(path, col.copy(alpha = p), style = st)
}

/** Letra T — MATEMÁTICA: ejes cartesianos ortogonales con marcas de escala blueprint. */
private fun DrawScope.drawMathLetterT(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val mathMint = Color(0xFF86FF8E)
    val col = blendColor(mathMint, Color.White, unify)
    val stW = (w * 0.13f).coerceAtLeast(3f)
    val cx = left + w * 0.50f

    if ((1f - unify) > 0.05f) {
        val tickCol = mathMint.copy(alpha = (1f - unify) * p * 0.55f)
        for (k in 1..3) {
            val ty = top + h * (0.25f + k * 0.16f)
            drawLine(tickCol, Offset(cx - w * 0.12f, ty), Offset(cx + w * 0.12f, ty), 2f)
        }
    }

    val halfBar = w * 0.36f * p
    drawLine(col.copy(alpha = p), Offset(cx - halfBar, top + h * 0.18f), Offset(cx + halfBar, top + h * 0.18f), stW, StrokeCap.Round)
    drawLine(col.copy(alpha = p), Offset(cx, top + h * 0.18f), Offset(cx, top + h * (0.18f + 0.66f * p)), stW, StrokeCap.Round)
}

/** Letra E — INFORMÁTICA / TECNOLOGÍA: trazos de circuito digital con nodos iluminados. */
private fun DrawScope.drawTechLetterE(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val techViolet = Color(0xFFA78BFA)
    val col = blendColor(techViolet, Color.White, unify)
    val stW = (w * 0.13f).coerceAtLeast(3f)
    val lx = left + w * 0.22f
    val rx = left + w * (0.22f + 0.58f * p)
    val midX = left + w * (0.22f + 0.46f * p)

    drawLine(col.copy(alpha = p), Offset(lx, top + h * 0.18f), Offset(lx, top + h * 0.84f), stW, StrokeCap.Round)
    drawLine(col.copy(alpha = p), Offset(lx, top + h * 0.18f), Offset(rx, top + h * 0.18f), stW, StrokeCap.Round)
    drawLine(col.copy(alpha = p), Offset(lx, top + h * 0.51f), Offset(midX, top + h * 0.51f), stW, StrokeCap.Round)
    drawLine(col.copy(alpha = p), Offset(lx, top + h * 0.84f), Offset(rx, top + h * 0.84f), stW, StrokeCap.Round)

    val nodeAlpha = (1f - unify) * p
    if (nodeAlpha > 0.05f) {
        drawCircle(techViolet.copy(alpha = nodeAlpha), stW * 0.55f, Offset(rx, top + h * 0.18f))
        drawCircle(techViolet.copy(alpha = nodeAlpha), stW * 0.55f, Offset(midX, top + h * 0.51f))
        drawCircle(techViolet.copy(alpha = nodeAlpha), stW * 0.55f, Offset(rx, top + h * 0.84f))
    }
}

/** Letra R — HISTORIA / LITERATURA: trazo editorial cálido dorado. */
private fun DrawScope.drawHistoryLetterR(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val histGold = Color(0xFFFBBF24)
    val col = blendColor(histGold, Color.White, unify)
    val st = Stroke((w * 0.13f).coerceAtLeast(3f), cap = StrokeCap.Round, join = StrokeJoin.Round)
    val dy = (1f - p) * h * 0.20f

    val path = Path().apply {
        moveTo(left + w * 0.22f, top + h * 0.84f + dy)
        lineTo(left + w * 0.22f, top + h * 0.18f + dy)
        lineTo(left + w * 0.56f, top + h * 0.18f + dy)
        cubicTo(left + w * 0.84f, top + h * 0.18f + dy, left + w * 0.84f, top + h * 0.52f + dy, left + w * 0.56f, top + h * 0.52f + dy)
        lineTo(left + w * 0.22f, top + h * 0.52f + dy)
        moveTo(left + w * 0.52f, top + h * 0.52f + dy)
        lineTo(left + w * 0.80f, top + h * 0.84f + dy)
    }
    drawPath(path, col.copy(alpha = p), style = st)
}

/** Letra G — GEOGRAFÍA / CIENCIAS DE LA TIERRA: arco orbital girando hasta encajar. */
private fun DrawScope.drawGeoLetterG(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val geoTeal = Color(0xFF2DD4BF)
    val col = blendColor(geoTeal, Color.White, unify)
    val st = Stroke((w * 0.13f).coerceAtLeast(3f), cap = StrokeCap.Round, join = StrokeJoin.Round)
    val cx = left + w * 0.52f; val cy = top + h * 0.51f

    withTransform({ rotate((1f - p) * -45f, Offset(cx, cy)) }) {
        drawArc(
            color = col.copy(alpha = p),
            startAngle = -35f,
            sweepAngle = -290f * p,
            useCenter = false,
            topLeft = Offset(left + w * 0.14f, top + h * 0.18f),
            size = Size(w * 0.72f, h * 0.66f),
            style = st
        )
    }
    if (p > 0.45f) {
        val barP = ((p - 0.45f) / 0.55f).coerceIn(0f, 1f)
        drawLine(
            col.copy(alpha = barP),
            Offset(left + w * 0.52f, cy),
            Offset(left + w * (0.52f + 0.34f * barP), cy),
            strokeWidth = (w * 0.13f).coerceAtLeast(3f),
            cap = StrokeCap.Round
        )
    }
}

/** Letra O — ÓPTICA / ASTRONOMÍA: anillo espectral arcoíris que se cierra en blanco puro. */
private fun DrawScope.drawOpticsLetterO(left: Float, top: Float, w: Float, h: Float, p: Float, unify: Float) {
    val st = Stroke((w * 0.13f).coerceAtLeast(3f), cap = StrokeCap.Round)
    val boxLeft = left + w * 0.14f
    val boxTop = top + h * 0.18f
    val boxSize = Size(w * 0.72f, h * 0.66f)

    if (unify < 0.95f) {
        val spectrumBrush = Brush.sweepGradient(
            colors = listOf(Color(0xFFC084FC), Color(0xFF38BDF8), Color(0xFF34D399), Color(0xFFFACC15), Color(0xFFF43F5E), Color(0xFFC084FC)),
            center = Offset(left + w * 0.5f, top + h * 0.51f)
        )
        drawArc(
            brush = spectrumBrush,
            startAngle = -90f,
            sweepAngle = 360f * p,
            useCenter = false,
            topLeft = Offset(boxLeft, boxTop),
            size = boxSize,
            alpha = (1f - unify) * p,
            style = st
        )
    }
    drawArc(
        color = Color.White.copy(alpha = (p * 0.35f + unify * 0.65f).coerceIn(0f, 1f)),
        startAngle = -90f,
        sweepAngle = 360f * p,
        useCenter = false,
        topLeft = Offset(boxLeft, boxTop),
        size = boxSize,
        style = st
    )
}
