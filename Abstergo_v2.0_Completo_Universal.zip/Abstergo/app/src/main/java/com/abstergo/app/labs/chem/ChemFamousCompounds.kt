package com.abstergo.app.labs.chem

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Immutable
data class FamousCompound(
    val id: String,
    val name: String,
    val iupac: String,
    val formula: String,
    val category: String,
    val molarMass: String,
    val geometry: String,
    val bondAngle: String,
    val bondType: String,
    val formationDetail: String,
    val uses: String,
    val funFact: String,
    val accentHex: Long,
    val model3D: () -> Molecule3DModel
)

val FAMOUS_COMPOUNDS: List<FamousCompound> = listOf(
    FamousCompound(
        "h2o", "Agua", "Óxido de dihidrógeno", "H₂O", "Esenciales", "18.015 g/mol",
        "Angular (VSEPR AX₂E₂)", "104.5°", "Covalente polar (2 enlaces O—H)",
        "Un átomo de oxígeno con hibridación sp³ comparte dos pares de electrones con dos hidrógenos; sus dos pares solitarios comprimen el ángulo de 109.5° a 104.5°.",
        "Base de toda vida conocida, disolvente universal, termorregulación climática e industria.",
        "Gracias a los puentes de hidrógeno, el hielo es menos denso que el agua líquida y flota, salvando la vida acuática en invierno.",
        0xFF38BDF8L
    ) {
        Molecule3DModel(
            "H₂O · Geometría Angular", "Ángulo H—O—H = 104.5°",
            listOf(atom("O", 0.0, 0.28, 0.0), atom("H", -0.95, -0.45, 0.0), atom("H", 0.95, -0.45, 0.0)),
            listOf(Bond3D(0, 1, 1), Bond3D(0, 2, 1))
        )
    },
    FamousCompound(
        "co2", "Dióxido de carbono", "Dióxido de carbono", "CO₂", "Esenciales", "44.01 g/mol",
        "Lineal (VSEPR AX₂)", "180°", "2 enlaces covalentes dobles O=C=O (apolar)",
        "El carbono central (hibridación sp) forma un doble enlace (1 σ + 1 π) con cada oxígeno. Aunque cada enlace C=O es polar, la simetría lineal cancela el momento dipolar.",
        "Fotosíntesis vegetal, bebidas carbonatadas, extintores de fuego y hielo seco (-78.5 °C).",
        "A presión atmosférica nunca se derrite en líquido: pasa directamente de sólido (hielo seco) a gas por sublimación.",
        0xFF94A3B8L
    ) {
        Molecule3DModel(
            "CO₂ · Geometría Lineal", "O=C=O · Ángulo 180°",
            listOf(atom("C", 0.0, 0.0, 0.0), atom("O", -1.25, 0.0, 0.0), atom("O", 1.25, 0.0, 0.0)),
            listOf(Bond3D(0, 1, 2), Bond3D(0, 2, 2))
        )
    },
    FamousCompound(
        "nacl", "Sal común", "Cloruro de sodio", "NaCl", "Esenciales", "58.44 g/mol",
        "Red cristalina cúbica (halita)", "90° (octaédrica)", "Enlace iónico (Na⁺ Cl⁻, ΔEN = 2.23)",
        "No forma moléculas aisladas sino un cristal iónico 3D donde cada catión Na⁺ se rodea de 6 aniones Cl⁻ y viceversa tras transferir 1 electrón del sodio al cloro.",
        "Alimentación y equilibrio nervioso humano, conservación de alimentos y fabricación de sosa y cloro.",
        "Juntar un metal explosivo en agua (Na) con un gas venenoso (Cl₂) produce el cristal indispensable en tu cocina.",
        0xFFA855F7L
    ) {
        val atoms = listOf(
            atom("Na", -0.9, -0.9, -0.9), atom("Cl", 0.9, -0.9, -0.9),
            atom("Cl", -0.9, 0.9, -0.9), atom("Na", 0.9, 0.9, -0.9),
            atom("Cl", -0.9, -0.9, 0.9), atom("Na", 0.9, -0.9, 0.9),
            atom("Na", -0.9, 0.9, 0.9), atom("Cl", 0.9, 0.9, 0.9)
        )
        val bonds = listOf(
            Bond3D(0, 1, 1), Bond3D(1, 3, 1), Bond3D(3, 2, 1), Bond3D(2, 0, 1),
            Bond3D(4, 5, 1), Bond3D(5, 7, 1), Bond3D(7, 6, 1), Bond3D(6, 4, 1),
            Bond3D(0, 4, 1), Bond3D(1, 5, 1), Bond3D(2, 6, 1), Bond3D(3, 7, 1)
        )
        Molecule3DModel("NaCl · Red Iónica Cúbica", "Cationes Na⁺ y aniones Cl⁻ alternados", atoms, bonds)
    },
    FamousCompound(
        "nh3", "Amoníaco", "Azano / Trihidruro de nitrógeno", "NH₃", "Ácidos y Bases", "17.031 g/mol",
        "Piramidal trigonal (AX₃E)", "107°", "Covalente polar (3 enlaces N—H)",
        "El nitrógeno (sp³) enlaza 3 hidrógenos en la base y conserva un par libre arriba, formando una pirámide trigonal que le permite aceptar protones (base de Brønsted).",
        "Base del 80% de los fertilizantes mundiales (proceso Haber-Bosch), limpieza y refrigeración industrial.",
        "Su síntesis industrial a partir del aire salvó a la humanidad de hambrunas globales en el siglo XX.",
        0xFF3B82F6L
    ) {
        Molecule3DModel(
            "NH₃ · Pirámide Trigonal", "Par solitario superior · Ángulo 107°",
            listOf(
                atom("N", 0.0, 0.45, 0.0),
                atom("H", 1.0, -0.35, 0.0),
                atom("H", -0.5, -0.35, 0.866),
                atom("H", -0.5, -0.35, -0.866)
            ),
            listOf(Bond3D(0, 1), Bond3D(0, 2), Bond3D(0, 3))
        )
    },
    FamousCompound(
        "ch4", "Metano", "Metano", "CH₄", "Orgánicos", "16.043 g/mol",
        "Tetraédrica perfecta (AX₄)", "109.5°", "4 enlaces covalentes simples C—H (apolar)",
        "El carbono con hibridación sp³ distribuye sus 4 enlaces simples hacia los vértices de un tetraedro regular para minimizar la repulsión electrónica.",
        "Principal componente del gas natural doméstico, calefacción, generación eléctrica y síntesis de hidrógeno.",
        "En Titán (luna de Saturno) llueve metano líquido y existen lagos y ríos enteros de hidrocarburos.",
        0xFF64748BL
    ) {
        Molecule3DModel(
            "CH₄ · Tetraedro Perfecto", "Hibridación sp³ · Ángulo 109.5°",
            listOf(
                atom("C", 0.0, 0.0, 0.0),
                atom("H", 0.82, 0.82, 0.82), atom("H", 0.82, -0.82, -0.82),
                atom("H", -0.82, 0.82, -0.82), atom("H", -0.82, -0.82, 0.82)
            ),
            listOf(Bond3D(0, 1), Bond3D(0, 2), Bond3D(0, 3), Bond3D(0, 4))
        )
    },
    FamousCompound(
        "h2so4", "Ácido sulfúrico", "Ácido tetraoxosulfúrico(VI)", "H₂SO₄", "Ácidos y Bases", "98.079 g/mol",
        "Tetraédrica centrada en S", "109.5° / 124°", "2 dobles S=O + 2 simples S—O—H",
        "El azufre en estado +6 forma un tetraedro con dos oxígenos unidos por doble enlace (S=O) y dos grupos hidroxilo (—OH) cuyos protones H⁺ se ionizan fácilmente.",
        "Químico más producido del planeta: baterías de auto, fertilizantes fosfatados, refinación y metalurgia.",
        "Es tan ávido de agua que deshidrata azúcar instantáneamente convirtiéndola en una columna humeante de carbón puro.",
        0xFFFACC15L
    ) {
        Molecule3DModel(
            "H₂SO₄ · Tetraedro de Azufre", "Dos S=O y dos grupos —OH",
            listOf(
                atom("S", 0.0, 0.0, 0.0),
                atom("O", 0.0, 1.05, 0.82), atom("O", 0.0, 1.05, -0.82),
                atom("O", -1.05, -0.82, 0.0), atom("O", 1.05, -0.82, 0.0),
                atom("H", -1.72, -0.45, 0.0), atom("H", 1.72, -0.45, 0.0)
            ),
            listOf(Bond3D(0, 1, 2), Bond3D(0, 2, 2), Bond3D(0, 3, 1), Bond3D(0, 4, 1), Bond3D(3, 5, 1), Bond3D(4, 6, 1))
        )
    },
    FamousCompound(
        "c2h5oh", "Etanol", "Etanol", "C₂H₅OH", "Orgánicos", "46.069 g/mol",
        "Cadena tetraédrica + grupo —OH", "109.5° / 104.5°", "Covalente polar (anfifílico)",
        "Dos carbonos sp³ unidos por enlace simple forman una cola hidrofóbica (—CH₂CH₃) unida a un grupo hidroxilo (—OH) capaz de formar puentes de hidrógeno con el agua.",
        "Desinfectante hospitalario (alcohol 70%), disolvente de perfumes/fármacos, biocombustible y fermentación.",
        "El alcohol al 70% desinfecta mejor que el 99% porque el agua frena su evaporación y ayuda a desnaturalizar proteínas bacterianas.",
        0xFF34D399L
    ) {
        Molecule3DModel(
            "CH₃—CH₂—OH · Etanol", "Cola etil + grupo alcohol polar",
            listOf(
                atom("C", -1.05, -0.2, 0.0), atom("C", 0.25, 0.42, 0.0), atom("O", 1.32, -0.35, 0.0),
                atom("H", 2.08, 0.12, 0.0),
                atom("H", -1.8, 0.4, 0.0), atom("H", -1.15, -0.85, 0.72), atom("H", -1.15, -0.85, -0.72),
                atom("H", 0.35, 1.08, 0.72), atom("H", 0.35, 1.08, -0.72)
            ),
            listOf(Bond3D(0, 1), Bond3D(1, 2), Bond3D(2, 3), Bond3D(0, 4), Bond3D(0, 5), Bond3D(0, 6), Bond3D(1, 7), Bond3D(1, 8))
        )
    },
    FamousCompound(
        "c6h6", "Benceno", "Benceno (Ciclohexa-1,3,5-trieno)", "C₆H₆", "Orgánicos", "78.11 g/mol",
        "Anillo hexagonal plano perfecto", "120° (sp²)", "Enlaces aromáticos deslocalizados (orden 1.5)",
        "Seis carbonos sp² forman un hexágono plano con 6 electrones π deslocalizados en una nube circular sobre y debajo del anillo, dándole una estabilidad extraordinaria.",
        "Bloque base de plásticos (poliestireno), nylon, aspirina, tintes y miles de fármacos aromáticos.",
        "August Kekulé contó que descifró su estructura en anillo tras soñar con una serpiente mordiéndose la propia cola (Uróboros).",
        0xFFF472B6L
    ) {
        val atoms = ArrayList<Atom3D>()
        val bonds = ArrayList<Bond3D>()
        for (i in 0 until 6) {
            val a = 2.0 * PI * i / 6.0
            atoms.add(atom("C", 1.32 * cos(a), 1.32 * sin(a), 0.0))
        }
        for (i in 0 until 6) {
            val a = 2.0 * PI * i / 6.0
            atoms.add(atom("H", 2.25 * cos(a), 2.25 * sin(a), 0.0))
            bonds.add(Bond3D(i, (i + 1) % 6, if (i % 2 == 0) 2 else 1))
            bonds.add(Bond3D(i, 6 + i, 1))
        }
        Molecule3DModel("C₆H₆ · Anillo Aromático", "6 carbonos sp² en resonancia · 120°", atoms, bonds)
    },
    FamousCompound(
        "o3", "Ozono", "Trioxígeno", "O₃", "Esenciales", "47.998 g/mol",
        "Angular resonante (AX₂E)", "116.8°", "Covalente polar con resonancia (orden 1.5)",
        "Tres oxígenos unidos en ángulo de 116.8° cuyos electrones π resuenan entre ambos enlaces, absorbiendo fotones ultravioleta letales (UV-B y UV-C).",
        "Capa estratosférica que protege la vida en la Tierra de la radiación UV y desinfección de agua potable.",
        "Ese olor metálico y fresco que notas justo antes o durante una tormenta eléctrica es ozono formado por los rayos.",
        0xFF06B6D4L
    ) {
        Molecule3DModel(
            "O₃ · Trioxígeno Resonante", "Ángulo O—O—O = 116.8°",
            listOf(atom("O", 0.0, 0.45, 0.0), atom("O", -1.12, -0.30, 0.0), atom("O", 1.12, -0.30, 0.0)),
            listOf(Bond3D(0, 1, 2), Bond3D(0, 2, 1))
        )
    },
    FamousCompound(
        "h2o2", "Agua oxigenada", "Peróxido de hidrógeno", "H₂O₂", "Esenciales", "34.015 g/mol",
        "Libro abierto (no plana)", "94.8° (dihedro 111.5°)", "Enlace peróxido O—O débil + dos O—H",
        "Dos oxígenos unidos por un enlace simple O—O inestable (estado de oxidación -1) con los hidrógenos apuntando en planos girados como las páginas de un libro semiabierto.",
        "Antiséptico de heridas, blanqueador ecológico de papel/cabello y propelente de cohetes.",
        "Al tocar sangre burbujea al instante porque la enzima catalasa rompe el H₂O₂ en agua y oxígeno gaseoso (O₂).",
        0xFF60A5FAL
    ) {
        Molecule3DModel(
            "H—O—O—H · Peróxido", "Geometría de libro abierto",
            listOf(atom("O", -0.68, 0.0, 0.0), atom("O", 0.68, 0.0, 0.0), atom("H", -1.12, 0.82, 0.35), atom("H", 1.12, -0.62, 0.62)),
            listOf(Bond3D(0, 1, 1), Bond3D(0, 2, 1), Bond3D(1, 3, 1))
        )
    },
    FamousCompound(
        "hcl", "Ácido clorhídrico", "Cloruro de hidrógeno", "HCl", "Ácidos y Bases", "36.46 g/mol",
        "Lineal diatómica", "180°", "Covalente polar fuerte (se ioniza 100% en agua)",
        "El cloro (EN = 3.16) atrae fuertemente el par compartido con el hidrógeno (EN = 2.20); al disolverse en agua cede su protón H⁺ completamente (ácido fuerte).",
        "Digestión estomacal humana, decapado de acero, limpieza industrial y síntesis de PVC.",
        "Tu estómago secreta HCl a pH ~1.5 capaz de disolver bacterias y activar enzimas, protegido por una mucosa renovable.",
        0xFF22C55EL
    ) {
        Molecule3DModel(
            "H—Cl · Ácido Fuerte", "Enlace polar · Ionización total en agua",
            listOf(atom("H", -0.82, 0.0, 0.0), atom("Cl", 0.68, 0.0, 0.0)),
            listOf(Bond3D(0, 1, 1))
        )
    },
    FamousCompound(
        "naoh", "Sosa cáustica", "Hidróxido de sodio", "NaOH", "Ácidos y Bases", "39.997 g/mol",
        "Iónico Na⁺ + anión lineal OH⁻", "180° (en OH⁻)", "Enlace iónico (Na⁺—OH⁻) + covalente (O—H)",
        "Combina el catión sodio (Na⁺) con el anión hidróxido (OH⁻), liberando OH⁻ de forma completa en agua (base fuerte pH 14).",
        "Fabricación de jabones (saponificación), papel, destapacañerías, aluminio y textiles.",
        "Al disolver granallas de NaOH en agua se libera tanto calor exotérmico que el vaso puede llegar a hervir.",
        0xFFC084FCL
    ) {
        Molecule3DModel(
            "Na⁺ [O—H]⁻ · Base Fuerte", "Catión Na⁺ y grupo hidróxido OH⁻",
            listOf(atom("Na", -1.25, 0.0, 0.0), atom("O", 0.35, 0.0, 0.0), atom("H", 1.32, 0.0, 0.0)),
            listOf(Bond3D(0, 1, 0), Bond3D(1, 2, 1))
        )
    },
    FamousCompound(
        "ch3cooh", "Vinagre (Ácido acético)", "Ácido etanoico", "CH₃COOH", "Orgánicos", "60.052 g/mol",
        "Tetraédrico (CH₃) + trigonal plano (COOH)", "109.5° / 120°", "Covalente polar con grupo carboxilo",
        "Un grupo metilo (—CH₃) unido a un carbono carboxílico sp² con doble enlace C=O y un grupo —OH ácido (ácido débil orgánico).",
        "Vinagre de cocina (al 5%), conservante alimentario, plásticos (acetato de vinilo) y aspirina.",
        "Puro al 100% se llama «ácido acético glacial» porque se congela formando cristales parecidos al hielo a 16.6 °C.",
        0xFFFB923CL
    ) {
        Molecule3DModel(
            "CH₃—COOH · Ácido Etanoico", "Grupo funcional carboxilo",
            listOf(
                atom("C", -1.05, 0.0, 0.0), atom("C", 0.35, 0.0, 0.0),
                atom("O", 0.98, 1.05, 0.0), atom("O", 0.98, -1.08, 0.0), atom("H", 1.92, -0.95, 0.0),
                atom("H", -1.42, 0.92, 0.45), atom("H", -1.42, -0.82, 0.55), atom("H", -1.42, -0.1, -0.95)
            ),
            listOf(Bond3D(0, 1), Bond3D(1, 2, 2), Bond3D(1, 3), Bond3D(3, 4), Bond3D(0, 5), Bond3D(0, 6), Bond3D(0, 7))
        )
    },
    FamousCompound(
        "c6h12o6", "Glucosa", "D-glucosa (hexosa)", "C₆H₁₂O₆", "Biomoléculas", "180.156 g/mol",
        "Anillo piranosa silla (6 miembros)", "109.5°", "Covalente polar (5 grupos —OH)",
        "Seis carbonos (5 formando anillo junto a 1 oxígeno) rodeados de grupos hidroxilo —OH que la hacen muy soluble en sangre y fuente inmediata de energía ATP.",
        "Combustible principal del cerebro y músculos, fotosíntesis vegetal, sueros médicos y fermentación.",
        "Tu cerebro representa solo el 2% de tu peso corporal pero consume cerca del 20% de toda tu glucosa diaria.",
        0xFF10B981L
    ) {
        val atoms = ArrayList<Atom3D>()
        val bonds = ArrayList<Bond3D>()
        // Anillo piranosa (5 C + 1 O) + C6 exocíclico + oxígenos OH clave
        for (i in 0 until 6) {
            val a = 2.0 * PI * i / 6.0
            val y = if (i % 2 == 0) 0.25 else -0.25
            atoms.add(atom(if (i == 0) "O" else "C", 1.35 * cos(a), y, 1.35 * sin(a)))
        }
        for (i in 0 until 6) bonds.add(Bond3D(i, (i + 1) % 6, 1))
        // Grupos -OH externos en C1..C4 y -CH2OH en C5
        for (i in 1..4) {
            val a = 2.0 * PI * i / 6.0
            atoms.add(atom("O", 2.38 * cos(a), if (i % 2 == 0) -0.35 else 0.35, 2.38 * sin(a)))
            bonds.add(Bond3D(i, atoms.lastIndex, 1))
        }
        val a5 = 2.0 * PI * 5 / 6.0
        atoms.add(atom("C", 2.25 * cos(a5), 0.72, 2.25 * sin(a5)))
        bonds.add(Bond3D(5, atoms.lastIndex, 1))
        atoms.add(atom("O", 2.95 * cos(a5), 1.32, 2.95 * sin(a5)))
        bonds.add(Bond3D(atoms.lastIndex - 1, atoms.lastIndex, 1))
        Molecule3DModel("C₆H₁₂O₆ · Anillo Piranosa", "Hexosa energética · Conformación silla", atoms, bonds)
    },
    FamousCompound(
        "c8h10n4o2", "Cafeína", "1,3,7-trimetilxantina", "C₈H₁₀N₄O₂", "Biomoléculas", "194.19 g/mol",
        "Bicíclica plana (anillo purina)", "120° / 109.5°", "Heterociclo aromático con 4 N y 2 C=O",
        "Fusión de un anillo pirimidina (6 miembros) y uno imidazol (5 miembros) con dos grupos carbonilo (=O) y tres grupos metilo (—CH₃) unidos a nitrógenos.",
        "Estimulante natural presente en café, té, cacao y mate; bloquea los receptores de adenosina del sueño.",
        "Las plantas evolucionaron la cafeína como pesticida natural para paralizar insectos que intentan comerse sus hojas.",
        0xFFD97706L
    ) {
        // Esqueleto purínico bicíclico + 2 carbonilos + 3 metilos
        val atoms = listOf(
            atom("N", -1.4, 0.7, 0.0), atom("C", -0.2, 1.35, 0.0), atom("N", 0.9, 0.65, 0.0),
            atom("C", 0.85, -0.65, 0.0), atom("C", -0.35, -1.3, 0.0), atom("C", -1.5, -0.6, 0.0),
            // Anillo 5 miembros
            atom("N", 2.05, -1.1, 0.0), atom("C", 2.75, 0.0, 0.0), atom("N", 2.05, 1.1, 0.0),
            // 2 oxígenos carbonilo
            atom("O", -0.2, 2.52, 0.0), atom("O", -2.58, -1.12, 0.0),
            // 3 grupos metilo C
            atom("C", -2.55, 1.4, 0.0), atom("C", -0.4, -2.6, 0.0), atom("C", 2.45, 2.35, 0.0)
        )
        val bonds = listOf(
            Bond3D(0, 1), Bond3D(1, 2), Bond3D(2, 3, 2), Bond3D(3, 4), Bond3D(4, 5), Bond3D(5, 0),
            Bond3D(3, 6), Bond3D(6, 7, 2), Bond3D(7, 8), Bond3D(8, 2),
            Bond3D(1, 9, 2), Bond3D(5, 10, 2), Bond3D(0, 11), Bond3D(4, 12), Bond3D(8, 13)
        )
        Molecule3DModel("C₈H₁₀N₄O₂ · Xantina Bicíclica", "Anillo purina + 3 metilos + 2 carbonilos", atoms, bonds)
    },
    FamousCompound(
        "c9h8o4", "Aspirina", "Ácido 2-acetoxibenzoico", "C₉H₈O₄", "Biomoléculas", "180.158 g/mol",
        "Anillo bencénico orto-disustituido", "120°", "Aromático + ácido carboxílico + éster",
        "Un anillo de benceno unido en carbonos adyacentes (posición orto) a un grupo ácido carboxílico (—COOH) y un grupo éster acetilo (—OCOCH₃).",
        "Analgésico, antipirético, antiinflamatorio y antiagregante plaquetario para prevenir infartos.",
        "Derivada de la salicina presente en la corteza del sauce blanco, usada contra el dolor desde la época de Hipócrates.",
        0xFFFB7185L
    ) {
        val atoms = ArrayList<Atom3D>()
        val bonds = ArrayList<Bond3D>()
        for (i in 0 until 6) {
            val a = 2.0 * PI * i / 6.0
            atoms.add(atom("C", 1.2 * cos(a) - 0.6, 1.2 * sin(a), 0.0))
        }
        for (i in 0 until 6) bonds.add(Bond3D(i, (i + 1) % 6, if (i % 2 == 0) 2 else 1))
        // Grupo -COOH en C0
        atoms.add(atom("C", 1.75, 0.25, 0.0)); bonds.add(Bond3D(0, 6))
        atoms.add(atom("O", 2.35, 1.25, 0.0)); bonds.add(Bond3D(6, 7, 2))
        atoms.add(atom("O", 2.45, -0.75, 0.0)); bonds.add(Bond3D(6, 8))
        // Grupo -O-CO-CH3 en C1
        atoms.add(atom("O", 0.55, 2.05, 0.2)); bonds.add(Bond3D(1, 9))
        atoms.add(atom("C", -0.45, 2.85, 0.45)); bonds.add(Bond3D(9, 10))
        atoms.add(atom("O", -1.45, 2.65, 0.95)); bonds.add(Bond3D(10, 11, 2))
        atoms.add(atom("C", -0.25, 4.05, 0.05)); bonds.add(Bond3D(10, 12))
        Molecule3DModel("C₉H₈O₄ · Ác. Acetilsalicílico", "Benceno + carboxilo + éster acetilo", atoms, bonds)
    },
    FamousCompound(
        "nahco3", "Bicarbonato de sodio", "Hidrogenocarbonato de sodio", "NaHCO₃", "Industriales", "84.007 g/mol",
        "Catión Na⁺ + anión planar HCO₃⁻", "120° (CO₃)", "Iónico + covalente polar con resonancia",
        "El catión sodio (Na⁺) equilibra al anión bicarbonato plano (HCO₃⁻), que actúa como sustancia anfótera (puede neutralizar tanto ácidos como bases).",
        "Repostería (libera CO₂ para esponjar masas), antiácido estomacal, desodorizante y extintores.",
        "Al mezclarse con vinagre reacciona instantáneamente liberando burbujas de CO₂: el clásico volcán escolar.",
        0xFF2DD4BFL
    ) {
        Molecule3DModel(
            "Na⁺ [HCO₃]⁻ · Anfótero", "Anión carbonato ácido trigonal plano",
            listOf(
                atom("C", 0.2, 0.0, 0.0), atom("O", 0.2, 1.18, 0.0),
                atom("O", 1.22, -0.62, 0.0), atom("O", -0.82, -0.62, 0.0),
                atom("H", 1.95, -0.15, 0.0), atom("Na", -2.1, 0.35, 0.0)
            ),
            listOf(Bond3D(0, 1, 2), Bond3D(0, 2), Bond3D(0, 3), Bond3D(2, 4), Bond3D(3, 5, 0))
        )
    },
    FamousCompound(
        "c2h2", "Acetileno", "Etino", "C₂H₂", "Orgánicos", "26.038 g/mol",
        "Lineal perfecta (sp)", "180°", "Enlace triple C≡C (1 σ + 2 π)",
        "Dos carbonos con hibridación sp unidos por un potentísimo enlace triple y sendos enlaces C—H en línea recta exacta.",
        "Soldadura y corte oxiacetilénico (alcanza 3300 °C) y síntesis de plásticos y acrílicos.",
        "Su llama con oxígeno puro es la tercera llama química más caliente que existe, capaz de cortar acero grueso como mantequilla.",
        0xFFEF4444L
    ) {
        Molecule3DModel(
            "H—C≡C—H · Etino", "Triple enlace carbono-carbono · 180°",
            listOf(atom("H", -1.75, 0.0, 0.0), atom("C", -0.65, 0.0, 0.0), atom("C", 0.65, 0.0, 0.0), atom("H", 1.75, 0.0, 0.0)),
            listOf(Bond3D(0, 1, 1), Bond3D(1, 2, 3), Bond3D(2, 3, 1))
        )
    },
    FamousCompound(
        "c3h6o", "Acetona", "Propanona", "CH₃COCH₃", "Orgánicos", "58.08 g/mol",
        "Carbono central trigonal plano", "120° / 109.5°", "Grupo cetona C=O flanqueado por dos metilos",
        "Es la cetona más simple: un carbono sp² con doble enlace al oxígeno (C=O) unido a dos grupos metilo simétricos.",
        "Quitaesmalte de uñas, disolvente de laboratorio y producción de plásticos acrílicos (metacrilato).",
        "Tu propio cuerpo produce pequeñas cantidades de acetona de forma natural cuando quema grasas en cetosis.",
        0xFF38BDF8L
    ) {
        Molecule3DModel(
            "CH₃—CO—CH₃ · Propanona", "Cetona más simple · C=O central",
            listOf(
                atom("C", 0.0, 0.1, 0.0), atom("O", 0.0, 1.32, 0.0),
                atom("C", -1.22, -0.65, 0.0), atom("C", 1.22, -0.65, 0.0),
                atom("H", -2.05, -0.05, 0.0), atom("H", -1.25, -1.25, 0.72), atom("H", -1.25, -1.25, -0.72),
                atom("H", 2.05, -0.05, 0.0), atom("H", 1.25, -1.25, 0.72), atom("H", 1.25, -1.25, -0.72)
            ),
            listOf(Bond3D(0, 1, 2), Bond3D(0, 2), Bond3D(0, 3), Bond3D(2, 4), Bond3D(2, 5), Bond3D(2, 6), Bond3D(3, 7), Bond3D(3, 8), Bond3D(3, 9))
        )
    },
    FamousCompound(
        "hno3", "Ácido nítrico", "Ácido trioxonítrico(V)", "HNO₃", "Ácidos y Bases", "63.01 g/mol",
        "Trigonal plano en N", "120°", "Covalente polar con resonancia N—O",
        "Un nitrógeno central (+5) plano enlazado a tres oxígenos (dos resonantes y uno unido al hidrógeno ácido H⁺).",
        "Fertilizantes (nitrato de amonio), grabado de metales, síntesis orgánica y «agua regia» (con HCl).",
        "Mezclado 1:3 con ácido clorhídrico forma el «agua regia», uno de los pocos líquidos capaces de disolver el oro puro.",
        0xFFF59E0BL
    ) {
        Molecule3DModel(
            "HNO₃ · Ácido Fuerte Oxidante", "Nitrógeno (+5) trigonal plano",
            listOf(
                atom("N", 0.0, 0.0, 0.0), atom("O", 0.0, 1.22, 0.0),
                atom("O", -1.08, -0.62, 0.0), atom("O", 1.08, -0.62, 0.0),
                atom("H", 1.85, -0.15, 0.0)
            ),
            listOf(Bond3D(0, 1, 2), Bond3D(0, 2, 1), Bond3D(0, 3, 1), Bond3D(3, 4, 1))
        )
    }
)

// ==============================================================================
// PANTALLA DE COMPUESTOS MÁS FAMOSOS (CON MOLÉCULA 3D INTERACTIVA Y FORMACIÓN)
// ==============================================================================

@Composable
fun ChemFamousCompoundsScreen(
    onOpenDrawer: () -> Unit,
    onSaveNoteToAbstergo: (title: String, body: String) -> Unit
) {
    val accent = chemPrimaryAccent()
    val glass = chemGlassSurface()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var query by remember { mutableStateOf("") }
    var catFilter by remember { mutableStateOf("Todos") }
    var selected by remember { mutableStateOf<FamousCompound?>(null) }

    selected?.let { comp ->
        BackHandler { selected = null }
        val compAccent = Color(comp.accentHex)
        val model = remember(comp.id) { comp.model3D() }

        Column(Modifier.fillMaxSize().background(chemCanvasBg())) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ChemCircleBtn(ChemIconKind.BACK, MaterialTheme.colorScheme.onSurface) { selected = null }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(comp.name, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${comp.formula} · ${comp.iupac}", fontSize = 11.sp, color = compAccent, fontWeight = FontWeight.Bold)
                }
                ChemCircleBtn(ChemIconKind.NOTE, compAccent) {
                    val body = buildString {
                        appendLine("${comp.name} (${comp.formula}) — ${comp.iupac}")
                        appendLine("Masa molar: ${comp.molarMass} · Geometría: ${comp.geometry} (${comp.bondAngle})")
                        appendLine("Tipo de enlace: ${comp.bondType}")
                        appendLine()
                        appendLine("Cómo está formada su molécula: ${comp.formationDetail}")
                        appendLine("Usos: ${comp.uses}")
                        appendLine("Dato curioso: ${comp.funFact}")
                    }
                    onSaveNoteToAbstergo("Compuesto · ${comp.name} (${comp.formula})", body)
                }
            }

            if (isLandscape) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Molecule3DCanvas(model = model, modifier = Modifier.weight(0.95f).fillMaxHeight().padding(bottom = 12.dp))
                    Column(
                        Modifier.weight(1.05f).fillMaxHeight().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CompoundDetailsCards(comp, compAccent)
                        Spacer(Modifier.height(14.dp))
                    }
                }
            } else {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Molecule3DCanvas(model = model, modifier = Modifier.fillMaxWidth().height(270.dp))
                    CompoundDetailsCards(comp, compAccent)
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
        return
    }

    val categories = listOf("Todos", "Esenciales", "Orgánicos", "Ácidos y Bases", "Biomoléculas", "Industriales")
    val filtered = remember(query, catFilter) {
        val q = query.trim().lowercase()
        FAMOUS_COMPOUNDS.filter { c ->
            val okCat = catFilter == "Todos" || c.category == catFilter
            val okQ = q.isEmpty() || c.name.lowercase().contains(q) || c.formula.lowercase().contains(q) ||
                c.iupac.lowercase().contains(q) || c.uses.lowercase().contains(q)
            okCat && okQ
        }
    }

    Column(Modifier.fillMaxSize().background(chemCanvasBg())) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChemCircleBtn(ChemIconKind.MENU, MaterialTheme.colorScheme.onSurface, onClick = onOpenDrawer)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Compuestos Famosos", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("MOLÉCULAS 3D INTERACTIVAS · GEOMETRÍA Y ENLACES", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.9.sp, color = accent)
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
            placeholder = { Text("Buscar agua, cafeína, aspirina, H2SO4, benceno…", fontSize = 12.sp) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                val sel = catFilter == cat
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp))
                        .background(if (sel) accent.copy(alpha = 0.2f) else glass)
                        .border(1.dp, if (sel) accent else chemGlassBorder(), RoundedCornerShape(10.dp))
                        .clickable { catFilter = cat }
                        .padding(horizontal = 11.dp, vertical = 5.dp)
                ) {
                    Text(cat, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, color = if (sel) accent else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(if (isLandscape) 3 else 2),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filtered, key = { it.id }) { comp ->
                val cCol = Color(comp.accentHex)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(glass)
                        .border(1.1.dp, chemGlassBorder(cCol), RoundedCornerShape(18.dp))
                        .clickable { selected = comp }
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.clip(RoundedCornerShape(10.dp))
                                .background(cCol.copy(alpha = 0.16f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(comp.formula, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, color = cCol, fontSize = 13.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text("3D", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = cCol)
                    }
                    Text(comp.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(comp.geometry, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(comp.molarMass, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = cCol)
                }
            }
        }
    }
}

@Composable
private fun CompoundDetailsCards(comp: FamousCompound, accent: Color) {
    val glass = chemGlassSurface()
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(glass).border(1.dp, chemGlassBorder(accent), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("CÓMO ESTÁ FORMADA SU MOLÉCULA", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = accent)
        Text(comp.formationDetail, fontSize = 13.sp, lineHeight = 20.sp)
        HorizontalDivider(color = chemGlassBorder())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("Geometría", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(comp.geometry, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text("Ángulo / Masa", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${comp.bondAngle} · ${comp.molarMass}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("Enlace: ${comp.bondType}", fontSize = 12.sp, color = accent, fontWeight = FontWeight.SemiBold)
    }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(glass).border(1.dp, chemGlassBorder(), RoundedCornerShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Usos en la vida real", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent)
        Text(comp.uses, fontSize = 13.sp, lineHeight = 19.sp)
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(accent.copy(alpha = 0.12f)).padding(11.dp)
        ) {
            Column {
                Text("Dato curioso", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = accent)
                Text(comp.funFact, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}
