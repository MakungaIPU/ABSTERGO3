package com.abstergo.app.labs.chem

import android.content.res.Configuration
import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

// ==============================================================================
// MOTOR DE QUÍMICA ORGÁNICA (CONSTRUCTOR TÁCTIL SIN TECLADO + IUPAC + 2D + 3D)
// ==============================================================================

enum class ChainKind(val label: String) {
    LINEAR("Lineal"),
    CYCLIC("Cíclica"),
    BENZENE("Benceno")
}

enum class MainBondKind(val label: String, val order: Int, val suffix: String) {
    SINGLE("Simple (-ano)", 1, "ano"),
    DOUBLE("Doble (-eno)", 2, "eno"),
    TRIPLE("Triple (-ino)", 3, "ino")
}

enum class OrganicFuncGroup(
    val label: String,
    val formulaTag: String,
    val suffix: String,
    val terminalOnly: Boolean,
    val requiresInternal: Boolean,
    val valenceCost: Int,
    val extraC: Int = 0,
    val extraH: Int = 0,
    val extraO: Int = 0,
    val extraN: Int = 0,
    val extraCl: Int = 0
) {
    NONE("Hidrocarburo", "C—H", "", false, false, 0),
    ALCOHOL("Alcohol", "—OH", "ol", false, false, 1, extraH = 1, extraO = 1),
    ALDEHYDE("Aldehído", "—CHO", "al", true, false, 2, extraO = 1),
    KETONE("Cetona", "—CO—", "ona", false, true, 2, extraO = 1),
    ACID("Ác. Carboxílico", "—COOH", "oico", true, false, 3, extraH = 1, extraO = 2),
    AMINE("Amina", "—NH₂", "amina", false, false, 1, extraH = 2, extraN = 1),
    AMIDE("Amida", "—CONH₂", "amida", true, false, 3, extraH = 2, extraO = 1, extraN = 1),
    ESTER("Éster (metilo)", "—COOCH₃", "oato de metilo", true, false, 3, extraC = 1, extraH = 3, extraO = 2),
    ETHER("Éter (metoxi)", "—OCH₃", "metoxi", false, false, 1, extraC = 1, extraH = 3, extraO = 1),
    NITRILE("Nitrilo", "—C≡N", "nitrilo", true, false, 3, extraN = 1),
    HALIDE("Halogenuro (-Cl)", "—Cl", "cloro", false, false, 1, extraCl = 1)
}

enum class OrgSubstituent(
    val label: String,
    val prefix: String,
    val formulaTag: String,
    val atomSym: String,
    val addC: Int = 0,
    val addH: Int = 0,
    val addO: Int = 0,
    val addCl: Int = 0,
    val addBr: Int = 0,
    val addF: Int = 0
) {
    METHYL("Metil", "metil", "—CH₃", "C", addC = 1, addH = 3),
    ETHYL("Etil", "etil", "—C₂H₅", "C", addC = 2, addH = 5),
    CHLORO("Cloro", "cloro", "—Cl", "Cl", addCl = 1),
    BROMO("Bromo", "bromo", "—Br", "Br", addBr = 1),
    FLUORO("Flúor", "fluoro", "—F", "F", addF = 1),
    HYDROXY("Hidroxi", "hidroxi", "—OH", "O", addH = 1, addO = 1)
}

@Immutable
data class BuiltOrganicMolecule(
    val iupacName: String,
    val molecularFormula: String,
    val condensedFormula: String,
    val molarMass: Double,
    val hybridization: String,
    val ihd: Int,
    val combustionEq: String,
    val chainLength: Int,
    val chainKind: ChainKind,
    val bondKind: MainBondKind,
    val bondPos: Int,
    val funcGroup: OrganicFuncGroup,
    val funcPos: Int,
    val branches: Map<Int, List<OrgSubstituent>>,
    val model3D: Molecule3DModel
)

private val ROOTS_ES = listOf("", "met", "et", "prop", "but", "pent", "hex", "hept", "oct", "non", "dec")
private val MULTI_ES = listOf("", "", "di", "tri", "tetra", "penta", "hexa")

private fun subDigits(n: Int): String {
    if (n <= 1) return ""
    val map = charArrayOf('₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉')
    return n.toString().map { map[it - '0'] }.joinToString("")
}

object OrganicBuilderEngine {
    fun build(
        chainKind: ChainKind,
        rawLength: Int,
        rawBond: MainBondKind,
        rawBondPos: Int,
        rawFunc: OrganicFuncGroup,
        rawFuncPos: Int,
        rawBranches: Map<Int, List<OrgSubstituent>>
    ): BuiltOrganicMolecule {
        val len = when (chainKind) {
            ChainKind.BENZENE -> 6
            ChainKind.CYCLIC -> rawLength.coerceIn(3, 8)
            ChainKind.LINEAR -> rawLength.coerceIn(1, 10)
        }
        val bond = when {
            chainKind == ChainKind.BENZENE -> MainBondKind.SINGLE
            len < 2 -> MainBondKind.SINGLE
            else -> rawBond
        }
        val bondPos = if (bond == MainBondKind.SINGLE) 1 else rawBondPos.coerceIn(1, (len - 1).coerceAtLeast(1))

        val func = when {
            chainKind == ChainKind.BENZENE && rawFunc in listOf(OrganicFuncGroup.KETONE, OrganicFuncGroup.NITRILE) -> OrganicFuncGroup.ALCOHOL
            chainKind == ChainKind.CYCLIC && rawFunc.terminalOnly -> OrganicFuncGroup.ALCOHOL
            rawFunc.requiresInternal && len < 3 -> OrganicFuncGroup.ALCOHOL
            else -> rawFunc
        }
        val funcPos = when {
            func == OrganicFuncGroup.NONE -> 1
            func.terminalOnly -> 1
            func.requiresInternal -> rawFuncPos.coerceIn(2, (len - 1).coerceAtLeast(2))
            else -> rawFuncPos.coerceIn(1, len)
        }

        // Calcular enlaces ocupados por cada carbono de la cadena para respetar tetravalencia (<= 4)
        val usedValence = IntArray(len + 1)
        for (c in 1..len) {
            usedValence[c] = when (chainKind) {
                ChainKind.BENZENE -> 3 // anillo aromático (1.5 + 1.5)
                ChainKind.CYCLIC -> 2
                ChainKind.LINEAR -> when {
                    len == 1 -> 0
                    c == 1 || c == len -> 1
                    else -> 2
                }
            }
        }
        if (bond != MainBondKind.SINGLE && chainKind != ChainKind.BENZENE) {
            val extra = bond.order - 1
            usedValence[bondPos] += extra
            if (bondPos + 1 <= len) usedValence[bondPos + 1] += extra
        }
        if (func != OrganicFuncGroup.NONE) {
            val cost = if (chainKind == ChainKind.BENZENE) 1 else func.valenceCost
            if (usedValence[funcPos] + cost <= 4) {
                usedValence[funcPos] += cost
            }
        }

        // Filtrar sustituyentes respetando tetravalencia
        val validBranches = LinkedHashMap<Int, MutableList<OrgSubstituent>>()
        for (c in 1..len) {
            val list = rawBranches[c].orEmpty()
            for (sub in list) {
                if (usedValence[c] + 1 <= 4) {
                    usedValence[c] += 1
                    validBranches.getOrPut(c) { ArrayList() }.add(sub)
                }
            }
        }

        // Hidrógenos restantes en cada carbono de la cadena principal
        val hOnCarbon = IntArray(len + 1) { c -> if (c == 0) 0 else (4 - usedValence[c]).coerceAtLeast(0) }

        // Conteo total exacto de átomos
        var cTot = len + func.extraC + (if (chainKind == ChainKind.BENZENE && func in listOf(OrganicFuncGroup.ALDEHYDE, OrganicFuncGroup.ACID, OrganicFuncGroup.AMIDE, OrganicFuncGroup.ESTER)) 1 else 0)
        var hTot = (1..len).sumOf { hOnCarbon[it] } + func.extraH
        var oTot = func.extraO
        var nTot = func.extraN
        var clTot = func.extraCl
        var brTot = 0
        var fTot = 0

        validBranches.values.flatten().forEach { sub ->
            cTot += sub.addC; hTot += sub.addH; oTot += sub.addO
            clTot += sub.addCl; brTot += sub.addBr; fTot += sub.addF
        }

        val formula = buildString {
            append("C").append(subDigits(cTot))
            if (hTot > 0) append("H").append(subDigits(hTot))
            if (brTot > 0) append("Br").append(subDigits(brTot))
            if (clTot > 0) append("Cl").append(subDigits(clTot))
            if (fTot > 0) append("F").append(subDigits(fTot))
            if (nTot > 0) append("N").append(subDigits(nTot))
            if (oTot > 0) append("O").append(subDigits(oTot))
        }

        val molarMass = cTot * 12.011 + hTot * 1.008 + oTot * 15.999 + nTot * 14.007 + clTot * 35.45 + brTot * 79.904 + fTot * 18.998
        val ihd = ((2 * cTot + 2 + nTot - hTot - clTot - brTot - fTot) / 2).coerceAtLeast(0)

        val iupac = buildIupacName(chainKind, len, bond, bondPos, func, funcPos, validBranches)
        val condensed = buildCondensedFormula(chainKind, len, bond, bondPos, func, funcPos, hOnCarbon, validBranches)
        val hybrid = when {
            chainKind == ChainKind.BENZENE -> "sp² aromática (deslocalizada)"
            bond == MainBondKind.TRIPLE || func == OrganicFuncGroup.NITRILE -> "sp (triple) + sp³"
            bond == MainBondKind.DOUBLE || func in listOf(OrganicFuncGroup.ALDEHYDE, OrganicFuncGroup.KETONE, OrganicFuncGroup.ACID, OrganicFuncGroup.AMIDE, OrganicFuncGroup.ESTER) -> "sp² (doble) + sp³"
            else -> "sp³ (tetraédrica, 109.5°)"
        }

        // Ecuación de combustión completa balanceada (para compuestos C-H-O)
        val combEq = if (nTot == 0 && clTot == 0 && brTot == 0 && fTot == 0) {
            val oNeedNum = 2 * cTot + hTot / 2 - oTot
            if (oNeedNum > 0) {
                if (oNeedNum % 2 == 0) {
                    "$formula + ${oNeedNum / 2} O₂ → ${cTot} CO₂ + ${hTot / 2} H₂O"
                } else {
                    "2 $formula + $oNeedNum O₂ → ${2 * cTot} CO₂ + $hTot H₂O"
                }
            } else "Compuesto completamente oxidado"
        } else {
            "Combustión genera CO₂, H₂O y óxidos/haluros de los heteroátomos presentes."
        }

        val m3d = buildOrganic3D(iupac, formula, chainKind, len, bond, bondPos, func, funcPos, validBranches)

        return BuiltOrganicMolecule(
            iupacName = iupac,
            molecularFormula = formula,
            condensedFormula = condensed,
            molarMass = molarMass,
            hybridization = hybrid,
            ihd = ihd,
            combustionEq = combEq,
            chainLength = len,
            chainKind = chainKind,
            bondKind = bond,
            bondPos = bondPos,
            funcGroup = func,
            funcPos = funcPos,
            branches = validBranches,
            model3D = m3d
        )
    }

    private fun buildIupacName(
        kind: ChainKind, len: Int, bond: MainBondKind, bondPos: Int,
        func: OrganicFuncGroup, funcPos: Int, branches: Map<Int, List<OrgSubstituent>>
    ): String {
        // Agrupar sustituyentes alfabéticamente con localizadores
        val grouped = LinkedHashMap<String, MutableList<Int>>()
        branches.forEach { (pos, list) ->
            list.forEach { sub -> grouped.getOrPut(sub.prefix) { ArrayList() }.add(pos) }
        }
        if (func == OrganicFuncGroup.ETHER) grouped.getOrPut("metoxi") { ArrayList() }.add(funcPos)
        if (func == OrganicFuncGroup.HALIDE) grouped.getOrPut("cloro") { ArrayList() }.add(funcPos)

        val prefixPart = grouped.entries.sortedBy { it.key }.joinToString("-") { (pref, locs) ->
            val sortedLocs = locs.sorted()
            val mult = MULTI_ES.getOrElse(sortedLocs.size) { "${sortedLocs.size}-" }
            if (len == 1 && sortedLocs.size == 1) pref
            else "${sortedLocs.joinToString(",")}-$mult$pref"
        }

        if (kind == ChainKind.BENZENE) {
            val base = when (func) {
                OrganicFuncGroup.ALCOHOL -> "fenol"
                OrganicFuncGroup.ALDEHYDE -> "benzaldehído"
                OrganicFuncGroup.ACID -> "ácido benzoico"
                OrganicFuncGroup.AMINE -> "anilina (fenilamina)"
                OrganicFuncGroup.AMIDE -> "benzamida"
                OrganicFuncGroup.ESTER -> "benzoato de metilo"
                else -> "benceno"
            }
            return if (prefixPart.isBlank()) base else "$prefixPart$base"
        }

        val root = (if (kind == ChainKind.CYCLIC) "ciclo" else "") + ROOTS_ES[len]
        val stem = when (bond) {
            MainBondKind.SINGLE -> "${root}an"
            MainBondKind.DOUBLE -> if (len <= 3 || kind == ChainKind.CYCLIC) "${root}en" else "$root-$bondPos-en"
            MainBondKind.TRIPLE -> if (len <= 3 || kind == ChainKind.CYCLIC) "${root}in" else "$root-$bondPos-in"
        }

        val fullBase = when (func) {
            OrganicFuncGroup.NONE, OrganicFuncGroup.ETHER, OrganicFuncGroup.HALIDE -> "${stem}o"
            OrganicFuncGroup.ALCOHOL -> if (len <= 2 || kind == ChainKind.CYCLIC) "${stem}ol" else "$stem-$funcPos-ol"
            OrganicFuncGroup.ALDEHYDE -> "${stem}al"
            OrganicFuncGroup.KETONE -> if (len <= 4 && kind == ChainKind.LINEAR) "${stem}ona" else "$stem-$funcPos-ona"
            OrganicFuncGroup.ACID -> "ácido ${stem}oico"
            OrganicFuncGroup.AMINE -> if (len <= 2 || kind == ChainKind.CYCLIC) "${stem}amina" else "$stem-$funcPos-amina"
            OrganicFuncGroup.AMIDE -> "${stem}amida"
            OrganicFuncGroup.ESTER -> "${stem}oato de metilo"
            OrganicFuncGroup.NITRILE -> "${stem}onitrilo"
        }

        return when {
            prefixPart.isBlank() -> fullBase
            fullBase.startsWith("ácido ") -> "ácido $prefixPart${fullBase.removePrefix("ácido ")}"
            else -> "$prefixPart$fullBase"
        }
    }

    private fun buildCondensedFormula(
        kind: ChainKind, len: Int, bond: MainBondKind, bondPos: Int,
        func: OrganicFuncGroup, funcPos: Int, hCount: IntArray, branches: Map<Int, List<OrgSubstituent>>
    ): String {
        if (kind == ChainKind.BENZENE) {
            val subs = branches.values.flatten().joinToString("") { "(${it.formulaTag.removePrefix("—")})" }
            val fg = if (func != OrganicFuncGroup.NONE) func.formulaTag else ""
            return "C₆H${subDigits((6 - branches.values.sumOf { it.size } - (if (func != OrganicFuncGroup.NONE) 1 else 0)).coerceAtLeast(0))}$subs$fg"
        }
        val sb = StringBuilder()
        if (kind == ChainKind.CYCLIC) sb.append("Ciclo[ ")
        for (i in 1..len) {
            if (i > 1) {
                val sep = if (bond != MainBondKind.SINGLE && bondPos == i - 1) {
                    if (bond == MainBondKind.DOUBLE) "=" else "≡"
                } else "—"
                sb.append(sep)
            }
            val fgStr = if (func != OrganicFuncGroup.NONE && funcPos == i) {
                when (func) {
                    OrganicFuncGroup.ALCOHOL -> "(OH)"
                    OrganicFuncGroup.ALDEHYDE -> "HO"
                    OrganicFuncGroup.KETONE -> "O"
                    OrganicFuncGroup.ACID -> "OOH"
                    OrganicFuncGroup.AMINE -> "(NH₂)"
                    OrganicFuncGroup.AMIDE -> "ONH₂"
                    OrganicFuncGroup.ESTER -> "OOCH₃"
                    OrganicFuncGroup.ETHER -> "(OCH₃)"
                    OrganicFuncGroup.NITRILE -> "N"
                    OrganicFuncGroup.HALIDE -> "(Cl)"
                    OrganicFuncGroup.NONE -> ""
                }
            } else ""
            val brStr = branches[i].orEmpty().joinToString("") { "(${it.formulaTag.removePrefix("—")})" }
            if (func in listOf(OrganicFuncGroup.ALDEHYDE, OrganicFuncGroup.KETONE, OrganicFuncGroup.ACID, OrganicFuncGroup.AMIDE, OrganicFuncGroup.ESTER, OrganicFuncGroup.NITRILE) && funcPos == i) {
                sb.append("C").append(fgStr).append(brStr)
            } else {
                sb.append("C")
                if (hCount[i] > 0) sb.append("H").append(subDigits(hCount[i]))
                sb.append(fgStr).append(brStr)
            }
        }
        if (kind == ChainKind.CYCLIC) sb.append(" ]")
        return sb.toString()
    }

    private fun buildOrganic3D(
        iupac: String, formula: String, kind: ChainKind, len: Int,
        bond: MainBondKind, bondPos: Int, func: OrganicFuncGroup, funcPos: Int,
        branches: Map<Int, List<OrgSubstituent>>
    ): Molecule3DModel {
        val atoms = ArrayList<Atom3D>()
        val bonds = ArrayList<Bond3D>()

        // 1. Esqueleto de carbonos en zigzag 3D real o anillo
        if (kind == ChainKind.LINEAR) {
            val stepX = 1.25
            for (i in 0 until len) {
                val x = (i - (len - 1) / 2.0) * stepX
                val y = if (i % 2 == 0) 0.36 else -0.36
                val z = if (i % 2 == 0) 0.14 else -0.14
                atoms.add(atom("C", x, y, z))
                if (i > 0) {
                    val ord = if (bond != MainBondKind.SINGLE && bondPos == i) bond.order else 1
                    bonds.add(Bond3D(i - 1, i, ord))
                }
            }
        } else {
            val r = (0.75 + len * 0.14).coerceAtLeast(1.15)
            for (i in 0 until len) {
                val ang = 2.0 * PI * i / len
                val z = if (kind == ChainKind.BENZENE) 0.0 else if (i % 2 == 0) 0.22 else -0.22
                atoms.add(atom("C", r * cos(ang), r * sin(ang), z))
            }
            for (i in 0 until len) {
                val ord = when {
                    kind == ChainKind.BENZENE -> if (i % 2 == 0) 2 else 1
                    bond != MainBondKind.SINGLE && bondPos == i + 1 -> bond.order
                    else -> 1
                }
                bonds.add(Bond3D(i, (i + 1) % len, ord))
            }
        }

        // 2. Grupo funcional principal en funcPos
        if (func != OrganicFuncGroup.NONE && funcPos in 1..len) {
            val cIdx = funcPos - 1
            val cA = atoms[cIdx]
            val dirY = if (cA.y >= 0) 1.0 else -1.0
            when (func) {
                OrganicFuncGroup.ALCOHOL -> {
                    val oI = atoms.size; atoms.add(atom("O", cA.x, cA.y + 1.05 * dirY, cA.z + 0.35))
                    bonds.add(Bond3D(cIdx, oI, 1))
                    val hI = atoms.size; atoms.add(atom("H", cA.x + 0.65, cA.y + 1.48 * dirY, cA.z + 0.55))
                    bonds.add(Bond3D(oI, hI, 1))
                }
                OrganicFuncGroup.ALDEHYDE, OrganicFuncGroup.KETONE -> {
                    val oI = atoms.size; atoms.add(atom("O", cA.x, cA.y + 1.15 * dirY, cA.z))
                    bonds.add(Bond3D(cIdx, oI, 2))
                }
                OrganicFuncGroup.ACID -> {
                    val o1 = atoms.size; atoms.add(atom("O", cA.x - 0.55, cA.y + 1.08 * dirY, cA.z))
                    val o2 = atoms.size; atoms.add(atom("O", cA.x + 0.65, cA.y + 0.92 * dirY, cA.z + 0.25))
                    val hI = atoms.size; atoms.add(atom("H", cA.x + 1.25, cA.y + 1.35 * dirY, cA.z + 0.35))
                    bonds.add(Bond3D(cIdx, o1, 2)); bonds.add(Bond3D(cIdx, o2, 1)); bonds.add(Bond3D(o2, hI, 1))
                }
                OrganicFuncGroup.AMINE -> {
                    val nI = atoms.size; atoms.add(atom("N", cA.x, cA.y + 1.08 * dirY, cA.z + 0.3))
                    bonds.add(Bond3D(cIdx, nI, 1))
                }
                OrganicFuncGroup.AMIDE -> {
                    val oI = atoms.size; atoms.add(atom("O", cA.x - 0.5, cA.y + 1.05 * dirY, cA.z))
                    val nI = atoms.size; atoms.add(atom("N", cA.x + 0.65, cA.y + 0.95 * dirY, cA.z + 0.2))
                    bonds.add(Bond3D(cIdx, oI, 2)); bonds.add(Bond3D(cIdx, nI, 1))
                }
                OrganicFuncGroup.ESTER -> {
                    val o1 = atoms.size; atoms.add(atom("O", cA.x - 0.5, cA.y + 1.05 * dirY, cA.z))
                    val o2 = atoms.size; atoms.add(atom("O", cA.x + 0.6, cA.y + 0.95 * dirY, cA.z))
                    val cm = atoms.size; atoms.add(atom("C", cA.x + 1.4, cA.y + 1.45 * dirY, cA.z + 0.2))
                    bonds.add(Bond3D(cIdx, o1, 2)); bonds.add(Bond3D(cIdx, o2, 1)); bonds.add(Bond3D(o2, cm, 1))
                }
                OrganicFuncGroup.ETHER -> {
                    val oI = atoms.size; atoms.add(atom("O", cA.x, cA.y + 1.05 * dirY, cA.z))
                    val cm = atoms.size; atoms.add(atom("C", cA.x + 0.95, cA.y + 1.45 * dirY, cA.z + 0.2))
                    bonds.add(Bond3D(cIdx, oI, 1)); bonds.add(Bond3D(oI, cm, 1))
                }
                OrganicFuncGroup.NITRILE -> {
                    val nI = atoms.size; atoms.add(atom("N", cA.x - 1.15, cA.y + 0.35 * dirY, cA.z))
                    bonds.add(Bond3D(cIdx, nI, 3))
                }
                OrganicFuncGroup.HALIDE -> {
                    val clI = atoms.size; atoms.add(atom("Cl", cA.x, cA.y + 1.15 * dirY, cA.z + 0.2))
                    bonds.add(Bond3D(cIdx, clI, 1))
                }
                OrganicFuncGroup.NONE -> Unit
            }
        }

        // 3. Sustituyentes / ramificaciones
        branches.forEach { (pos, list) ->
            if (pos in 1..len) {
                val cIdx = pos - 1
                val cA = atoms[cIdx]
                list.forEachIndexed { bIdx, sub ->
                    val signY = if ((cIdx + bIdx) % 2 == 0) -1.0 else 1.0
                    val signZ = if (bIdx % 2 == 0) 0.55 else -0.55
                    val sIdx = atoms.size
                    atoms.add(atom(sub.atomSym, cA.x + 0.25 * bIdx, cA.y + 1.12 * signY, cA.z + signZ))
                    bonds.add(Bond3D(cIdx, sIdx, 1))
                    if (sub == OrgSubstituent.ETHYL) {
                        val s2 = atoms.size
                        atoms.add(atom("C", cA.x + 0.95, cA.y + 1.85 * signY, cA.z + signZ * 1.4))
                        bonds.add(Bond3D(sIdx, s2, 1))
                    }
                }
            }
        }

        return Molecule3DModel(iupac.replaceFirstChar { it.uppercase() }, formula, atoms, bonds)
    }
}

// ==============================================================================
// PANTALLA DE QUÍMICA ORGÁNICA (CONSTRUCTOR SIN TECLADO + ATLAS + REACCIONES)
// ==============================================================================

@Composable
fun ChemOrganicLabScreen(
    onOpenDrawer: () -> Unit,
    onSaveNoteToAbstergo: (title: String, body: String) -> Unit
) {
    val accent = Color(0xFF34D399)
    val glass = chemGlassSurface()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var subTab by remember { mutableStateOf(0) } // 0=Constructor, 1=Grupos Funcionales, 2=Isomería y Reacciones

    // Estado 100% táctil del Constructor de Cadenas y Enlaces
    var chainKind by remember { mutableStateOf(ChainKind.LINEAR) }
    var length by remember { mutableStateOf(4) }
    var bondKind by remember { mutableStateOf(MainBondKind.SINGLE) }
    var bondPos by remember { mutableStateOf(1) }
    var funcGroup by remember { mutableStateOf(OrganicFuncGroup.ALCOHOL) }
    var funcPos by remember { mutableStateOf(1) }
    var activeBranchCarbon by remember { mutableStateOf(2) }
    var branches by remember { mutableStateOf<Map<Int, List<OrgSubstituent>>>(mapOf(2 to listOf(OrgSubstituent.METHYL))) }
    var show3D by remember { mutableStateOf(false) }

    val built = remember(chainKind, length, bondKind, bondPos, funcGroup, funcPos, branches) {
        OrganicBuilderEngine.build(chainKind, length, bondKind, bondPos, funcGroup, funcPos, branches)
    }

    fun addSubstituent(sub: OrgSubstituent) {
        val c = activeBranchCarbon.coerceIn(1, built.chainLength)
        val cur = branches.toMutableMap()
        val list = cur[c].orEmpty().toMutableList()
        if (list.size < 2) {
            list.add(sub)
            cur[c] = list
            branches = cur
        }
    }

    fun clearBranches() { branches = emptyMap() }

    Column(Modifier.fillMaxSize().background(chemCanvasBg())) {
        // Barra superior
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChemCircleBtn(ChemIconKind.MENU, MaterialTheme.colorScheme.onSurface, onClick = onOpenDrawer)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Química Orgánica", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("CONSTRUCTOR DE ENLACES · IUPAC · GRUPOS Y REACCIONES", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, color = accent)
            }
            if (subTab == 0) {
                ChemCircleBtn(ChemIconKind.NOTE, accent) {
                    val body = buildString {
                        appendLine("Nombre IUPAC: ${built.iupacName}")
                        appendLine("Fórmula molecular: ${built.molecularFormula}")
                        appendLine("Fórmula semidesarrollada: ${built.condensedFormula}")
                        appendLine("Masa molar: ${formatChemNum(built.molarMass, 2)} g/mol · Hibridación: ${built.hybridization}")
                        appendLine("Combustión: ${built.combustionEq}")
                    }
                    onSaveNoteToAbstergo("Orgánica · ${built.iupacName}", body)
                }
            }
        }

        // Pestañas internas de Química Orgánica
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Constructor Táctil", "Grupos Funcionales", "Isomería y Reacciones").forEachIndexed { idx, lbl ->
                val sel = subTab == idx
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(if (sel) accent.copy(alpha = 0.18f) else glass)
                        .border(1.dp, if (sel) accent else chemGlassBorder(), RoundedCornerShape(12.dp))
                        .clickable { subTab = idx }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(lbl, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, color = if (sel) accent else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            }
        }

        when (subTab) {
            0 -> {
                val previewBlock: @Composable (Modifier) -> Unit = { mod ->
                    Column(mod, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Tarjeta Hero con Nombre IUPAC + Fórmula + Toggle 2D/3D
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                                .background(glass).border(1.3.dp, chemGlassBorder(accent), RoundedCornerShape(20.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("NOMBRE IUPAC GENERADO", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = accent)
                                    Text(
                                        built.iupacName.replaceFirstChar { it.uppercase() },
                                        fontSize = 20.sp, fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        "${built.molecularFormula}  ·  ${formatChemNum(built.molarMass, 2)} g/mol  ·  IHD = ${built.ihd}",
                                        fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = accent
                                    )
                                }
                                Row(
                                    Modifier.clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.surfaceVariant).padding(2.dp)
                                ) {
                                    listOf(false to "2D", true to "3D").forEach { (is3, tag) ->
                                        Box(
                                            Modifier.clip(RoundedCornerShape(50))
                                                .background(if (show3D == is3) accent else Color.Transparent)
                                                .clickable { show3D = is3 }
                                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(tag, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (show3D == is3) Color(0xFF07111A) else MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }

                            if (show3D) {
                                Molecule3DCanvas(model = built.model3D, modifier = Modifier.fillMaxWidth().height(205.dp))
                            } else {
                                Organic2DStructureCanvas(built = built, accent = accent, modifier = Modifier.fillMaxWidth().height(175.dp))
                            }

                            Text(built.condensedFormula, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                            Text("Hibridación: ${built.hybridization}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Combustión: ${built.combustionEq}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                val controlsBlock: @Composable (Modifier) -> Unit = { mod ->
                    Column(mod, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Paso 1: Tipo de Cadena
                        BuilderSectionCard("1. Tipo de cadena", accent) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                ChainKind.entries.forEach { ck ->
                                    OrgPickChip(ck.label, chainKind == ck, accent, Modifier.weight(1f)) {
                                        chainKind = ck
                                        if (ck == ChainKind.BENZENE) length = 6
                                        if (ck == ChainKind.CYCLIC && length < 3) length = 6
                                    }
                                }
                            }
                        }

                        // Paso 2: Longitud de Carbonos (Met -> Dec)
                        if (chainKind != ChainKind.BENZENE) {
                            BuilderSectionCard("2. Carbonos en la cadena principal (${ROOTS_ES[built.chainLength]}-)", accent) {
                                val range = if (chainKind == ChainKind.CYCLIC) 3..8 else 1..10
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    for (n in range) {
                                        OrgPickChip("C$n ${ROOTS_ES[n]}", length == n, accent) {
                                            length = n
                                            if (activeBranchCarbon > n) activeBranchCarbon = n
                                        }
                                    }
                                }
                            }
                        }

                        // Paso 3: Enlaces C—C (Simple, Doble, Triple + Posición)
                        if (chainKind != ChainKind.BENZENE && built.chainLength >= 2) {
                            BuilderSectionCard("3. Tipo de enlace carbono–carbono", accent) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    MainBondKind.entries.forEach { bk ->
                                        OrgPickChip(bk.label, bondKind == bk, accent, Modifier.weight(1f)) { bondKind = bk }
                                    }
                                }
                                if (bondKind != MainBondKind.SINGLE && built.chainLength >= 4) {
                                    Spacer(Modifier.height(6.dp))
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("Posición:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        for (pos in 1 until built.chainLength) {
                                            OrgPickChip("C$pos=C${pos + 1}", bondPos == pos, accent) { bondPos = pos }
                                        }
                                    }
                                }
                            }
                        }

                        // Paso 4: Grupo Funcional principal
                        BuilderSectionCard("4. Grupo funcional principal", accent) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OrganicFuncGroup.entries.forEach { fg ->
                                    OrgPickChip("${fg.label} (${fg.formulaTag})", funcGroup == fg, accent) { funcGroup = fg }
                                }
                            }
                            if (funcGroup != OrganicFuncGroup.NONE && !funcGroup.terminalOnly && built.chainLength >= 3) {
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("En carbono:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    val r = if (funcGroup.requiresInternal) 2 until built.chainLength else 1..built.chainLength
                                    for (pos in r) {
                                        OrgPickChip("C$pos", funcPos == pos, accent) { funcPos = pos }
                                    }
                                }
                            }
                        }

                        // Paso 5: Añadir Ramificaciones / Sustituyentes por botones
                        BuilderSectionCard("5. Ramificaciones y sustituyentes (sin escribir)", accent) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("Enlazar en:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                for (c in 1..built.chainLength) {
                                    OrgPickChip("C$c", activeBranchCarbon == c, Color(0xFF38BDF8)) { activeBranchCarbon = c }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OrgSubstituent.entries.forEach { sub ->
                                    OrgPickChip("+ ${sub.label} (${sub.formulaTag})", false, accent) { addSubstituent(sub) }
                                }
                            }
                            if (built.branches.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Activos: " + built.branches.entries.joinToString(", ") { (k, v) -> "C$k:${v.joinToString("+") { it.prefix }}" },
                                        fontSize = 11.sp, color = accent, modifier = Modifier.weight(1f)
                                    )
                                    TextButton(onClick = ::clearBranches) { Text("Limpiar", fontSize = 11.sp) }
                                }
                            }
                        }
                    }
                }

                if (isLandscape) {
                    Row(
                        Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                            previewBlock(Modifier.fillMaxWidth())
                            Spacer(Modifier.height(12.dp))
                        }
                        Column(Modifier.weight(1.05f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                            controlsBlock(Modifier.fillMaxWidth())
                            Spacer(Modifier.height(14.dp))
                        }
                    }
                } else {
                    Column(
                        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        previewBlock(Modifier.fillMaxWidth())
                        controlsBlock(Modifier.fillMaxWidth())
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }

            1 -> OrganicFunctionalGroupsAtlas(accent)
            else -> OrganicIsomerismAndReactionsPane(accent)
        }
    }
}

@Composable
private fun Organic2DStructureCanvas(built: BuiltOrganicMolecule, accent: Color, modifier: Modifier) {
    val dark = chemIsDark()
    val bg = if (dark) Color(0xFF0A0F18) else Color(0xFFEEF3FA)
    val bondCol = if (dark) Color(0xFFE2E8F0) else Color(0xFF1E293B)
    val textArgb = (if (dark) Color(0xFFF8FAFC) else Color(0xFF0F172A)).toArgb()
    val accentArgb = accent.toArgb()

    val atomPaint = remember(textArgb) {
        Paint().apply { isAntiAlias = true; color = textArgb; textSize = 28f; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
    }
    val subPaint = remember(accentArgb) {
        Paint().apply { isAntiAlias = true; color = accentArgb; textSize = 23f; textAlign = Paint.Align.CENTER; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
    }

    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(1.dp, chemGlassBorder(), RoundedCornerShape(14.dp))
    ) {
        val w = size.width; val h = size.height
        val n = built.chainLength
        val pts = ArrayList<Offset>(n)

        if (built.chainKind == ChainKind.LINEAR) {
            val padX = 56f
            val stepX = if (n == 1) 0f else ((w - 2 * padX) / (n - 1)).coerceAtMost(96f)
            val totalW = stepX * (n - 1)
            val startX = (w - totalW) / 2f
            for (i in 0 until n) {
                val x = startX + i * stepX
                val y = h * 0.52f + if (i % 2 == 0) -18f else 18f
                pts.add(Offset(x, y))
            }
        } else {
            val r = minOf(w, h) * 0.28f
            val cx = w / 2f; val cy = h / 2f
            for (i in 0 until n) {
                val ang = -PI / 2.0 + 2.0 * PI * i / n
                pts.add(Offset(cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat()))
            }
        }

        fun drawMultiBond(a: Offset, b: Offset, order: Int, col: Color) {
            val dx = b.x - a.x; val dy = b.y - a.y
            val d = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
            val nx = -dy / d; val ny = dx / d
            when (order) {
                1 -> drawLine(col, a, b, 5.5f, StrokeCap.Round)
                2 -> {
                    drawLine(col, Offset(a.x + nx * 4.5f, a.y + ny * 4.5f), Offset(b.x + nx * 4.5f, b.y + ny * 4.5f), 4.5f, StrokeCap.Round)
                    drawLine(col, Offset(a.x - nx * 4.5f, a.y - ny * 4.5f), Offset(b.x - nx * 4.5f, b.y - ny * 4.5f), 4.5f, StrokeCap.Round)
                }
                else -> {
                    drawLine(col, a, b, 4f, StrokeCap.Round)
                    drawLine(col, Offset(a.x + nx * 7f, a.y + ny * 7f), Offset(b.x + nx * 7f, b.y + ny * 7f), 4f, StrokeCap.Round)
                    drawLine(col, Offset(a.x - nx * 7f, a.y - ny * 7f), Offset(b.x - nx * 7f, b.y - ny * 7f), 4f, StrokeCap.Round)
                }
            }
        }

        // Dibujar enlaces de la cadena
        if (built.chainKind == ChainKind.LINEAR) {
            for (i in 0 until n - 1) {
                val ord = if (built.bondKind != MainBondKind.SINGLE && built.bondPos == i + 1) built.bondKind.order else 1
                drawMultiBond(pts[i], pts[i + 1], ord, if (ord > 1) accent else bondCol)
            }
        } else {
            for (i in 0 until n) {
                val ord = when {
                    built.chainKind == ChainKind.BENZENE -> if (i % 2 == 0) 2 else 1
                    built.bondKind != MainBondKind.SINGLE && built.bondPos == i + 1 -> built.bondKind.order
                    else -> 1
                }
                drawMultiBond(pts[i], pts[(i + 1) % n], ord, if (ord > 1) accent else bondCol)
            }
        }

        // Dibujar grupo funcional + sustituyentes
        if (built.funcGroup != OrganicFuncGroup.NONE && built.funcPos in 1..n) {
            val p = pts[built.funcPos - 1]
            val target = Offset(p.x, p.y - 48f)
            val ord = if (built.funcGroup in listOf(OrganicFuncGroup.KETONE, OrganicFuncGroup.ALDEHYDE)) 2 else 1
            drawMultiBond(p, target, ord, accent)
            drawContext.canvas.nativeCanvas.drawText(built.funcGroup.formulaTag.removePrefix("—"), target.x, target.y - 10f, subPaint)
        }
        built.branches.forEach { (cNum, subs) ->
            if (cNum in 1..n) {
                val p = pts[cNum - 1]
                subs.forEachIndexed { idx, sub ->
                    val dirY = if (idx == 0) 48f else -48f
                    val target = Offset(p.x + idx * 14f, p.y + dirY)
                    drawLine(Color(0xFF38BDF8), p, target, 4.5f, StrokeCap.Round)
                    drawContext.canvas.nativeCanvas.drawText(sub.formulaTag.removePrefix("—"), target.x, target.y + (if (dirY > 0) 24f else -8f), subPaint)
                }
            }
        }

        // Nodos de carbono numerados
        pts.forEachIndexed { i, p ->
            drawCircle(bg, 16f, p)
            drawCircle(bondCol.copy(alpha = 0.22f), 16f, p)
            drawContext.canvas.nativeCanvas.drawText("C${i + 1}", p.x, p.y + 9f, atomPaint)
        }
    }
}

@Composable
private fun OrganicFunctionalGroupsAtlas(accent: Color) {
    val glass = chemGlassSurface()
    val groups = listOf(
        Triple("1. Ácido Carboxílico", "R—COOH", "Sufijo: -oico · Prefijo: carboxi- · Máxima prioridad IUPAC · Ej: ácido etanoico (vinagre)"),
        Triple("2. Éster", "R—COO—R'", "Sufijo: -oato de ...ilo · Aromas de frutas · Ej: etanoato de etilo"),
        Triple("3. Amida", "R—CONH₂", "Sufijo: -amida · Enlace peptídico en proteínas · Ej: etanamida"),
        Triple("4. Nitrilo", "R—C≡N", "Sufijo: -nitrilo · Prefijo: ciano- · Hibridación sp · Ej: etanonitrilo"),
        Triple("5. Aldehído", "R—CHO", "Sufijo: -al · Prefijo: formil-/oxo- · Carbonilo terminal · Ej: metanal (formol)"),
        Triple("6. Cetona", "R—CO—R'", "Sufijo: -ona · Prefijo: oxo- · Carbonilo interno · Ej: propanona (acetona)"),
        Triple("7. Alcohol", "R—OH", "Sufijo: -ol · Prefijo: hidroxi- · Puentes de hidrógeno · Ej: etanol"),
        Triple("8. Amina", "R—NH₂", "Sufijo: -amina · Prefijo: amino- · Carácter básico · Ej: metilamina"),
        Triple("9. Éter", "R—O—R'", "Prefijo: alcoxi- / ...il éter · Baja reactividad · Ej: dietil éter"),
        Triple("10. Alqueno / Alquino", "C=C  /  C≡C", "Sufijos: -eno (sp²) / -ino (sp) · Reacciones de adición electrofílica"),
        Triple("11. Halogenuro", "R—X (F,Cl,Br,I)", "Prefijo: fluoro-, cloro-, bromo-, yodo- · Sustitución nucleofílica")
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Orden oficial de prioridad IUPAC (de mayor a menor)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent)
        groups.forEach { (title, form, desc) ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(glass).border(1.dp, chemGlassBorder(), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(accent.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text(form, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = accent)
                    }
                }
                Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun OrganicIsomerismAndReactionsPane(accent: Color) {
    val glass = chemGlassSurface()
    val topics = listOf(
        "Isomería de Cadena" to "Misma fórmula molecular pero distinto esqueleto carbonado.\nEj. C₄H₁₀: butano (lineal) vs. 2-metilpropano (ramificado).",
        "Isomería de Posición" to "Cambia la ubicación del grupo funcional o del enlace múltiple.\nEj. C₃H₈O: propan-1-ol vs. propan-2-ol.",
        "Isomería de Función" to "Misma fórmula pero diferente grupo funcional.\nEj. C₂H₆O: etanol (alcohol) vs. dimetiléter (éter). También aldehídos ↔ cetonas.",
        "Estereoisomería Geométrica (cis / trans)" to "Ocurre en alquenos (C=C sin giro libre) cuando cada carbono tiene dos grupos distintos.\ncis = grupos iguales del mismo lado · trans = lados opuestos.",
        "Estereoisomería Óptica (Quiralidad)" to "Un carbono asimétrico (unido a 4 grupos diferentes) genera dos imágenes especulares no superponibles (enantiómeros) que desvían la luz polarizada.",
        "Reacciones de Adición (Regla de Markovnikov)" to "Alquenos/alquinos rompen su enlace π para sumar H₂, X₂, HX o H₂O.\nEn HX sobre alquenos asimétricos, el H va al carbono con MÁS hidrógenos.",
        "Reacciones de Eliminación (Regla de Zaitsev)" to "Un alcohol o halogenuro pierde H₂O o HX formando un alqueno (predomina el doble enlace más sustituido).",
        "Oxidación de Alcoholes" to "Alcohol 1° → Aldehído → Ácido carboxílico.\nAlcohol 2° → Cetona.\nAlcohol 3° → No se oxida fácilmente.",
        "Esterificación de Fischer y Saponificación" to "Ácido carboxílico + Alcohol ⇌ Éster + H₂O (con H₂SO₄).\nÉster (grasa) + NaOH → Jabón (sal orgánica) + Glicerol."
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        topics.forEach { (title, body) ->
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(glass).border(1.dp, chemGlassBorder(), RoundedCornerShape(16.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = accent)
                Text(body, fontSize = 12.sp, lineHeight = 19.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun BuilderSectionCard(title: String, accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(chemGlassSurface()).border(1.dp, chemGlassBorder(), RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent)
        content()
    }
}

@Composable
private fun OrgPickChip(label: String, selected: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier.clip(RoundedCornerShape(10.dp))
            .background(if (selected) accent.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, if (selected) accent else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) accent else MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )
    }
}
