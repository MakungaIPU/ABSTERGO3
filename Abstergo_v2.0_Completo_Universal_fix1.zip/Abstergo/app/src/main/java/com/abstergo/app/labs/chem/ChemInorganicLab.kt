package com.abstergo.app.labs.chem

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

// ==============================================================================
// MOTOR DE QUÍMICA INORGÁNICA (CONSTRUCTOR DE ENLACES SIN TECLADO + 3 NOMENCLATURAS)
// ==============================================================================

enum class InorgFamily(val label: String, val tag: String) {
    BASIC_OXIDE("Óxidos Básicos", "Metal + O²⁻"),
    ACID_OXIDE("Óxidos Ácidos", "No Metal + O²⁻"),
    HYDROXIDE("Hidróxidos", "Metal + OH⁻"),
    HYDRACID("Hidrácidos", "H⁺ + No Metal"),
    OXOACID("Oxoácidos", "H⁺ + Oxoanión"),
    BINARY_SALT("Sales Binarias", "Metal + No Metal"),
    OXOSALT("Oxosales", "Metal + Oxoanión"),
    HYDRIDE("Hidruros", "Metal + H⁻"),
    PEROXIDE("Peróxidos", "Metal + O₂²⁻")
}

private data class InorgElemSpec(
    val sym: String,
    val name: String,
    val root: String,
    val mass: Double,
    val en: Double,
    val valences: List<Int>
)

private data class PolyAnionSpec(
    val formula: String,
    val atomSym: String,
    val charge: Int, // magnitud positiva (1, 2 o 3)
    val saltName: String,
    val acidName: String,
    val iupacOxo: String,
    val mass: Double
)

private val INORG_METALS = listOf(
    InorgElemSpec("Na", "sodio", "sód", 22.99, 0.93, listOf(1)),
    InorgElemSpec("K", "potasio", "potás", 39.098, 0.82, listOf(1)),
    InorgElemSpec("Li", "litio", "lít", 6.94, 0.98, listOf(1)),
    InorgElemSpec("Ca", "calcio", "cálc", 40.078, 1.00, listOf(2)),
    InorgElemSpec("Mg", "magnesio", "magnés", 24.305, 1.31, listOf(2)),
    InorgElemSpec("Ba", "bario", "bár", 137.33, 0.89, listOf(2)),
    InorgElemSpec("Al", "aluminio", "alumín", 26.982, 1.61, listOf(3)),
    InorgElemSpec("Zn", "zinc", "cínc", 65.38, 1.65, listOf(2)),
    InorgElemSpec("Ag", "plata", "argént", 107.87, 1.93, listOf(1)),
    InorgElemSpec("Fe", "hierro", "ferr", 55.845, 1.83, listOf(2, 3)),
    InorgElemSpec("Cu", "cobre", "cupr", 63.546, 1.90, listOf(1, 2)),
    InorgElemSpec("Pb", "plomo", "plumb", 207.2, 2.33, listOf(2, 4)),
    InorgElemSpec("Au", "oro", "áur", 196.97, 2.54, listOf(1, 3)),
    InorgElemSpec("Sn", "estaño", "estann", 118.71, 1.96, listOf(2, 4))
)

private val INORG_NONMETALS_OX = listOf(
    InorgElemSpec("C", "carbono", "carbón", 12.011, 2.55, listOf(2, 4)),
    InorgElemSpec("S", "azufre", "sulfur", 32.06, 2.58, listOf(2, 4, 6)),
    InorgElemSpec("N", "nitrógeno", "nitr", 14.007, 3.04, listOf(3, 5)),
    InorgElemSpec("P", "fósforo", "fosfor", 30.974, 2.19, listOf(3, 5)),
    InorgElemSpec("Cl", "cloro", "clor", 35.45, 3.16, listOf(1, 3, 5, 7)),
    InorgElemSpec("Br", "bromo", "brom", 79.904, 2.96, listOf(1, 3, 5, 7)),
    InorgElemSpec("I", "yodo", "yod", 126.90, 2.66, listOf(1, 3, 5, 7))
)

private val BINARY_ANIONS = listOf(
    InorgElemSpec("F", "fluoruro", "fluorhídrico", 18.998, 3.98, listOf(1)),
    InorgElemSpec("Cl", "cloruro", "clorhídrico", 35.45, 3.16, listOf(1)),
    InorgElemSpec("Br", "bromuro", "bromhídrico", 79.904, 2.96, listOf(1)),
    InorgElemSpec("I", "yoduro", "yodhídrico", 126.90, 2.66, listOf(1)),
    InorgElemSpec("S", "sulfuro", "sulfhídrico", 32.06, 2.58, listOf(2)),
    InorgElemSpec("Se", "seleniuro", "selenhídrico", 78.971, 2.55, listOf(2))
)

private val OXOANIONS = listOf(
    PolyAnionSpec("NO₃", "N", 1, "nitrato", "ácido nítrico", "trioxonitrato(V)", 62.004),
    PolyAnionSpec("NO₂", "N", 1, "nitrito", "ácido nitroso", "dioxonitrato(III)", 46.005),
    PolyAnionSpec("SO₄", "S", 2, "sulfato", "ácido sulfúrico", "tetraoxosulfato(VI)", 96.06),
    PolyAnionSpec("SO₃", "S", 2, "sulfito", "ácido sulfuroso", "trioxosulfato(IV)", 80.06),
    PolyAnionSpec("CO₃", "C", 2, "carbonato", "ácido carbónico", "trioxocarbonato(IV)", 60.008),
    PolyAnionSpec("PO₄", "P", 3, "fosfato", "ácido fosfórico", "tetraoxofosfato(V)", 94.971),
    PolyAnionSpec("ClO", "Cl", 1, "hipoclorito", "ácido hipocloroso", "oxoclorato(I)", 51.45),
    PolyAnionSpec("ClO₃", "Cl", 1, "clorato", "ácido clórico", "trioxoclorato(V)", 83.45),
    PolyAnionSpec("ClO₄", "Cl", 1, "perclorato", "ácido perclórico", "tetraoxoclorato(VII)", 99.45),
    PolyAnionSpec("MnO₄", "Mn", 1, "permanganato", "ácido permangánico", "tetraoxomanganato(VII)", 118.934),
    PolyAnionSpec("Cr₂O₇", "Cr", 2, "dicromato", "ácido dicrómico", "heptaoxodicromato(VI)", 215.988)
)

@Immutable
data class BuiltInorganicCompound(
    val formula: String,
    val crossStep: String,
    val iupacName: String,
    val stockName: String,
    val tradName: String,
    val bondType: String,
    val deltaEnText: String,
    val bondExplanation: String,
    val molarMass: Double,
    val formationEq: String,
    val model3D: Molecule3DModel
)

private fun gcdInt(a: Int, b: Int): Int = if (b == 0) a else gcdInt(b, a % b)
private fun roman(v: Int): String = when (v) {
    1 -> "I"; 2 -> "II"; 3 -> "III"; 4 -> "IV"; 5 -> "V"; 6 -> "VI"; 7 -> "VII"; else -> "$v"
}
private fun greekPref(n: Int, allowMono: Boolean = false): String = when (n) {
    1 -> if (allowMono) "mon" else ""
    2 -> "di"
    3 -> "tri"
    4 -> "tetra"
    5 -> "penta"
    6 -> "hexa"
    7 -> "hepta"
    else -> "$n-"
}
private fun subNum(n: Int): String {
    if (n <= 1) return ""
    val m = charArrayOf('₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉')
    return n.toString().map { m[it - '0'] }.joinToString("")
}

private fun traditionalAdj(el: InorgElemSpec, v: Int): String {
    val vs = el.valences.sorted()
    return when (vs.size) {
        1 -> "de ${el.name}"
        2 -> if (v == vs[0]) "${el.root}oso" else "${el.root}ico"
        3 -> when (v) {
            vs[0] -> "hipo${el.root}oso"
            vs[1] -> "${el.root}oso"
            else -> "${el.root}ico"
        }
        else -> when (v) {
            vs[0] -> "hipo${el.root}oso"
            vs[1] -> "${el.root}oso"
            vs[2] -> "${el.root}ico"
            else -> "per${el.root}ico"
        }
    }
}

private fun classifyDeltaEn(en1: Double, en2: Double): Triple<String, String, String> {
    val d = abs(en1 - en2)
    val dStr = "ΔEN = ${"%.2f".format(Locale.US, d)}"
    return when {
        d >= 1.7 -> Triple("Enlace Iónico", dStr, "Transferencia completa de electrones del elemento menos electronegativo al más electronegativo formando iones unidos por atracción electrostática.")
        d >= 0.4 -> Triple("Enlace Covalente Polar", dStr, "Compartición desigual de electrones: genera polos parciales δ⁺ y δ⁻ en la molécula.")
        else -> Triple("Enlace Covalente Apolar", dStr, "Compartición equilibrada de pares electrónicos entre átomos de electronegatividad muy similar.")
    }
}

private fun buildBinaryModel3D(symA: String, cntA: Int, symB: String, cntB: Int, ionic: Boolean, title: String, sub: String): Molecule3DModel {
    val atoms = ArrayList<Atom3D>()
    val bonds = ArrayList<Bond3D>()
    val bOrder = if (ionic) 0 else 1
    if (cntA == 1) {
        atoms.add(Atom3D(symA, 0.0, 0.0, 0.0, cpkColor(symA), cpkRadius(symA)))
        for (i in 0 until cntB) {
            val ang = 2.0 * PI * i / cntB.coerceAtLeast(1)
            val y = if (cntB == 4) (if (i % 2 == 0) 0.55 else -0.55) else 0.0
            atoms.add(Atom3D(symB, 1.35 * cos(ang), y, 1.35 * sin(ang), cpkColor(symB), cpkRadius(symB)))
            bonds.add(Bond3D(0, i + 1, if (!ionic && symB == "O" && cntB <= 3) 2 else bOrder))
        }
    } else {
        // Dos átomos centrales (ej. Fe2O3, N2O5)
        atoms.add(Atom3D(symA, -1.1, 0.0, 0.0, cpkColor(symA), cpkRadius(symA)))
        atoms.add(Atom3D(symA, 1.1, 0.0, 0.0, cpkColor(symA), cpkRadius(symA)))
        val midIdx = atoms.size
        atoms.add(Atom3D(symB, 0.0, 0.55, 0.0, cpkColor(symB), cpkRadius(symB)))
        bonds.add(Bond3D(0, midIdx, bOrder)); bonds.add(Bond3D(1, midIdx, bOrder))
        val rem = (cntB - 1).coerceAtLeast(0)
        for (i in 0 until rem) {
            val side = if (i % 2 == 0) 0 else 1
            val sx = if (side == 0) -2.05 else 2.05
            val ang = (i / 2) * 1.4 - 0.7
            val idx = atoms.size
            atoms.add(Atom3D(symB, sx, 0.95 * sin(ang), 0.95 * cos(ang), cpkColor(symB), cpkRadius(symB)))
            bonds.add(Bond3D(side, idx, if (!ionic && symB == "O") 2 else bOrder))
        }
    }
    return Molecule3DModel(title, sub, atoms, bonds)
}

private object InorganicBuilderEngine {
    fun build(
        family: InorgFamily,
        metal: InorgElemSpec,
        metalValence: Int,
        nonMetalOx: InorgElemSpec,
        nonMetalValence: Int,
        binaryAnion: InorgElemSpec,
        oxoAnion: PolyAnionSpec
    ): BuiltInorganicCompound {
        return when (family) {
            InorgFamily.BASIC_OXIDE -> {
                val g = gcdInt(metalValence, 2)
                val nM = 2 / g; val nO = metalValence / g
                val f = "${metal.sym}${subNum(nM)}O${subNum(nO)}"
                val cross = "${metal.sym}⁺${metalValence} + O²⁻ → ${metal.sym}${subNum(2)}O${subNum(metalValence)}" + if (g > 1) " → $f (simplificado)" else ""
                val oxPref = if (nO == 1) "monóxido" else "${greekPref(nO)}óxido"
                val mPref = greekPref(nM)
                val iupac = "$oxPref de ${mPref}${metal.name}"
                val stock = if (metal.valences.size == 1) "óxido de ${metal.name}" else "óxido de ${metal.name}(${roman(metalValence)})"
                val trad = "óxido ${traditionalAdj(metal, metalValence)}"
                val (bt, dEn, exp) = classifyDeltaEn(metal.en, 3.44)
                val mm = nM * metal.mass + nO * 15.999
                val eq = if (nO % 2 == 0) "${nM} ${metal.sym} + ${nO / 2} O₂ → $f" else "${nM * 2} ${metal.sym} + $nO O₂ → 2 $f"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, bt, dEn, exp, mm, eq, buildBinaryModel3D(metal.sym, nM, "O", nO, true, f, "Óxido básico"))
            }
            InorgFamily.ACID_OXIDE -> {
                val g = gcdInt(nonMetalValence, 2)
                val nX = 2 / g; val nO = nonMetalValence / g
                val f = "${nonMetalOx.sym}${subNum(nX)}O${subNum(nO)}"
                val cross = "${nonMetalOx.sym}⁺${nonMetalValence} + O²⁻ → ${nonMetalOx.sym}${subNum(2)}O${subNum(nonMetalValence)}" + if (g > 1) " → $f" else ""
                val oxPref = if (nO == 1) "monóxido" else "${greekPref(nO)}óxido"
                val iupac = "$oxPref de ${greekPref(nX)}${nonMetalOx.name}"
                val stock = "óxido de ${nonMetalOx.name}(${roman(nonMetalValence)})"
                val trad = "anhídrido ${traditionalAdj(nonMetalOx, nonMetalValence)}"
                val (bt, dEn, exp) = classifyDeltaEn(nonMetalOx.en, 3.44)
                val mm = nX * nonMetalOx.mass + nO * 15.999
                val eq = if (nO % 2 == 0) "${nX} ${nonMetalOx.sym} + ${nO / 2} O₂ → $f" else "${nX * 2} ${nonMetalOx.sym} + $nO O₂ → 2 $f"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, bt, dEn, exp, mm, eq, buildBinaryModel3D(nonMetalOx.sym, nX, "O", nO, false, f, "Óxido ácido / anhídrido"))
            }
            InorgFamily.HYDROXIDE -> {
                val f = if (metalValence == 1) "${metal.sym}OH" else "${metal.sym}(OH)${subNum(metalValence)}"
                val cross = "${metal.sym}⁺${metalValence} + (OH)¹⁻ → $f"
                val iupac = "${greekPref(metalValence)}hidróxido de ${metal.name}"
                val stock = if (metal.valences.size == 1) "hidróxido de ${metal.name}" else "hidróxido de ${metal.name}(${roman(metalValence)})"
                val trad = "hidróxido ${traditionalAdj(metal, metalValence)}"
                val (bt, dEn, exp) = classifyDeltaEn(metal.en, 3.44)
                val mm = metal.mass + metalValence * 17.007
                val eq = "Óxido de ${metal.name} + H₂O → $f (base)"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, "Iónico (${metal.sym}⁺—OH⁻) + Covalente (O—H)", dEn, exp, mm, eq, buildBinaryModel3D(metal.sym, 1, "O", metalValence, true, f, "Hidróxido / Base"))
            }
            InorgFamily.HYDRACID -> {
                val v = binaryAnion.valences[0]
                val f = "H${subNum(v)}${binaryAnion.sym}"
                val cross = "H⁺ + ${binaryAnion.sym}${v}⁻ → $f"
                val iupac = "${binaryAnion.name} de ${greekPref(v)}hidrógeno"
                val stock = "${binaryAnion.name} de hidrógeno"
                val trad = "ácido ${binaryAnion.root} (en agua)"
                val (bt, dEn, exp) = classifyDeltaEn(2.20, binaryAnion.en)
                val mm = v * 1.008 + binaryAnion.mass
                val eq = "H₂ + ${binaryAnion.sym}₂ → 2 $f"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, bt, dEn, exp, mm, eq, buildBinaryModel3D(binaryAnion.sym, 1, "H", v, false, f, "Ácido hidrácido"))
            }
            InorgFamily.OXOACID -> {
                val h = oxoAnion.charge
                val f = "H${subNum(h)}${oxoAnion.formula}"
                val cross = "$h H⁺ + (${oxoAnion.formula})${h}⁻ → $f"
                val iupac = "${oxoAnion.iupacOxo} de ${greekPref(h)}hidrógeno"
                val stock = "ácido ${oxoAnion.iupacOxo.replace("ato", "ico")}"
                val trad = oxoAnion.acidName
                val mm = h * 1.008 + oxoAnion.mass
                val eq = "Anhídrido + H₂O → $f"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, "Covalente polar (ioniza H⁺ en agua)", "Ácido oxácido", "Los protones H⁺ están unidos a átomos de oxígeno terminales y se liberan en disolución acuosa.", mm, eq, buildBinaryModel3D(oxoAnion.atomSym, 1, "O", 3, false, f, "Oxoácido"))
            }
            InorgFamily.BINARY_SALT -> {
                val av = binaryAnion.valences[0]
                val g = gcdInt(metalValence, av)
                val nM = av / g; val nA = metalValence / g
                val f = "${metal.sym}${subNum(nM)}${binaryAnion.sym}${subNum(nA)}"
                val cross = "${metal.sym}⁺${metalValence} + ${binaryAnion.sym}${av}⁻ → $f"
                val iupac = "${greekPref(nA)}${binaryAnion.name} de ${greekPref(nM)}${metal.name}"
                val stock = if (metal.valences.size == 1) "${binaryAnion.name} de ${metal.name}" else "${binaryAnion.name} de ${metal.name}(${roman(metalValence)})"
                val trad = "${binaryAnion.name} ${traditionalAdj(metal, metalValence)}"
                val (bt, dEn, exp) = classifyDeltaEn(metal.en, binaryAnion.en)
                val mm = nM * metal.mass + nA * binaryAnion.mass
                val eq = "Hidróxido + Ácido ${binaryAnion.root} → $f + H₂O"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, bt, dEn, exp, mm, eq, buildBinaryModel3D(metal.sym, nM, binaryAnion.sym, nA, true, f, "Sal binaria"))
            }
            InorgFamily.OXOSALT -> {
                val av = oxoAnion.charge
                val g = gcdInt(metalValence, av)
                val nM = av / g; val nA = metalValence / g
                val anionPart = if (nA == 1) oxoAnion.formula else "(${oxoAnion.formula})${subNum(nA)}"
                val f = "${metal.sym}${subNum(nM)}$anionPart"
                val cross = "${metal.sym}⁺${metalValence} + (${oxoAnion.formula})${av}⁻ → $f"
                val iupac = "${if (nA > 1) "${greekPref(nA)}[" else ""}${oxoAnion.iupacOxo}${if (nA > 1) "]" else ""} de ${greekPref(nM)}${metal.name}"
                val stock = if (metal.valences.size == 1) "${oxoAnion.saltName} de ${metal.name}" else "${oxoAnion.saltName} de ${metal.name}(${roman(metalValence)})"
                val trad = "${oxoAnion.saltName} ${traditionalAdj(metal, metalValence)}"
                val mm = nM * metal.mass + nA * oxoAnion.mass
                val eq = "Base(${metal.sym}) + ${oxoAnion.acidName} → $f + H₂O"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, "Iónico (catión + oxoanión covalente)", "Enlace mixto", "El catión metálico se une iónicamente al oxoanión poliatómico cuyos átomos internos mantienen enlaces covalentes fuertes.", mm, eq, buildBinaryModel3D(metal.sym, nM, oxoAnion.atomSym, nA, true, f, "Oxosal neutra"))
            }
            InorgFamily.HYDRIDE -> {
                val f = "${metal.sym}H${subNum(metalValence)}"
                val cross = "${metal.sym}⁺${metalValence} + H¹⁻ → $f"
                val iupac = "${greekPref(metalValence)}hidruro de ${metal.name}"
                val stock = if (metal.valences.size == 1) "hidruro de ${metal.name}" else "hidruro de ${metal.name}(${roman(metalValence)})"
                val trad = "hidruro ${traditionalAdj(metal, metalValence)}"
                val (bt, dEn, exp) = classifyDeltaEn(metal.en, 2.20)
                val mm = metal.mass + metalValence * 1.008
                val eq = "2 ${metal.sym} + $metalValence H₂ → 2 $f"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, bt, dEn, exp, mm, eq, buildBinaryModel3D(metal.sym, 1, "H", metalValence, true, f, "Hidruro metálico"))
            }
            InorgFamily.PEROXIDE -> {
                // Grupo peróxido O2^(2-) NO se simplifica el subíndice 2 del oxígeno
                val nM = if (metalValence == 1) 2 else 1
                val oSub = if (metalValence == 1) 2 else metalValence
                val f = "${metal.sym}${subNum(nM)}O${subNum(oSub)}"
                val cross = "${metal.sym}⁺${metalValence} + (O₂)²⁻ → $f (sin simplificar el enlace peróxido O—O)"
                val iupac = "${greekPref(oSub)}óxido de ${greekPref(nM)}${metal.name}"
                val stock = "peróxido de ${metal.name}"
                val trad = "peróxido ${traditionalAdj(metal, metalValence)}"
                val (bt, dEn, exp) = classifyDeltaEn(metal.en, 3.44)
                val mm = nM * metal.mass + oSub * 15.999
                val eq = "${nM} ${metal.sym} + O₂ → $f"
                BuiltInorganicCompound(f, cross, iupac, stock, trad, "Iónico + enlace peróxido O—O (ox. -1)", dEn, exp, mm, eq, buildBinaryModel3D(metal.sym, nM, "O", oSub, true, f, "Peróxido metálico"))
            }
        }
    }
}

// ==============================================================================
// PANTALLA DE QUÍMICA INORGÁNICA (CONSTRUCTOR + SOLUBILIDAD & pH + REDOX)
// ==============================================================================

@Composable
fun ChemInorganicLabScreen(
    onOpenDrawer: () -> Unit,
    onSaveNoteToAbstergo: (title: String, body: String) -> Unit
) {
    val accent = Color(0xFF38BDF8)
    val glass = chemGlassSurface()
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    var subTab by remember { mutableStateOf(0) } // 0=Constructor, 1=Solubilidad y pH, 2=Iones y Redox

    // Estado 100% táctil del constructor inorgánico
    var family by remember { mutableStateOf(InorgFamily.BASIC_OXIDE) }
    var metalIdx by remember { mutableStateOf(9) } // Fe
    var metalVal by remember { mutableStateOf(3) } // Fe3+
    var nmOxIdx by remember { mutableStateOf(1) }  // S
    var nmVal by remember { mutableStateOf(6) }    // S6+
    var binAnionIdx by remember { mutableStateOf(1) } // Cl-
    var oxoIdx by remember { mutableStateOf(2) }   // SO4 2-

    val metal = INORG_METALS[metalIdx]
    val effMetalVal = if (metalVal in metal.valences) metalVal else metal.valences.first()
    val nmOx = INORG_NONMETALS_OX[nmOxIdx]
    val effNmVal = if (nmVal in nmOx.valences) nmVal else nmOx.valences.last()
    val binAnion = BINARY_ANIONS[binAnionIdx]
    val oxoAnion = OXOANIONS[oxoIdx]

    val built = remember(family, metalIdx, effMetalVal, nmOxIdx, effNmVal, binAnionIdx, oxoIdx) {
        InorganicBuilderEngine.build(family, metal, effMetalVal, nmOx, effNmVal, binAnion, oxoAnion)
    }

    Column(Modifier.fillMaxSize().background(chemCanvasBg())) {
        // Barra superior
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChemCircleBtn(ChemIconKind.MENU, MaterialTheme.colorScheme.onSurface, onClick = onOpenDrawer)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Química Inorgánica", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("ENLACES · NOMENCLATURA · SOLUBILIDAD · pH · REDOX", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, color = accent)
            }
            if (subTab == 0) {
                ChemCircleBtn(ChemIconKind.NOTE, accent) {
                    val body = buildString {
                        appendLine("Fórmula: ${built.formula} (${formatChemNum(built.molarMass, 2)} g/mol)")
                        appendLine("Cruce de valencias: ${built.crossStep}")
                        appendLine("IUPAC: ${built.iupacName}")
                        appendLine("Stock: ${built.stockName}")
                        appendLine("Tradicional: ${built.tradName}")
                        appendLine("Enlace: ${built.bondType} (${built.deltaEnText})")
                        appendLine("Formación: ${built.formationEq}")
                    }
                    onSaveNoteToAbstergo("Inorgánica · ${built.formula}", body)
                }
            }
        }

        // Pestañas internas
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Constructor Táctil", "Solubilidad y pH", "Iones y Redox").forEachIndexed { idx, lbl ->
                val sel = subTab == idx
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(if (sel) accent.copy(alpha = 0.18f) else glass)
                        .border(1.dp, if (sel) accent else chemGlassBorder(), RoundedCornerShape(12.dp))
                        .clickable { subTab = idx }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(lbl, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, color = if (sel) accent else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            }
        }

        when (subTab) {
            0 -> {
                val resultPane: @Composable (Modifier) -> Unit = { mod ->
                    Column(mod, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                                .background(glass).border(1.3.dp, chemGlassBorder(accent), RoundedCornerShape(20.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(family.label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = accent)
                                    Text(built.formula, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                                    Text("${formatChemNum(built.molarMass, 2)} g/mol  ·  ${built.deltaEnText}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(accent.copy(alpha = 0.11f)).padding(10.dp)
                            ) {
                                Text("Cruce de valencias: ${built.crossStep}", fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                            }

                            Molecule3DCanvas(model = built.model3D, modifier = Modifier.fillMaxWidth().height(185.dp))

                            // Las 3 Nomenclaturas oficiales
                            InorgNameRow("IUPAC (Sistemática)", built.iupacName, accent)
                            InorgNameRow("Stock", built.stockName, Color(0xFF34D399))
                            InorgNameRow("Tradicional", built.tradName, Color(0xFFF59E0B))
                            HorizontalDivider(color = chemGlassBorder())
                            Text(built.bondType, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = accent)
                            Text(built.bondExplanation, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
                            Text("Formación: ${built.formationEq}", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = accent)
                        }
                    }
                }

                val controlsPane: @Composable (Modifier) -> Unit = { mod ->
                    Column(mod, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // 1. Función inorgánica
                        InorgCard("1. Elige la función inorgánica", accent) {
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                InorgFamily.entries.forEach { fam ->
                                    InorgChip("${fam.label} (${fam.tag})", family == fam, accent) { family = fam }
                                }
                            }
                        }

                        // 2. Catión / Elemento 1 + Estado de Oxidación
                        if (family in listOf(InorgFamily.BASIC_OXIDE, InorgFamily.HYDROXIDE, InorgFamily.BINARY_SALT, InorgFamily.OXOSALT, InorgFamily.HYDRIDE, InorgFamily.PEROXIDE)) {
                            InorgCard("2. Selecciona el Metal (Catión)", accent) {
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    INORG_METALS.forEachIndexed { idx, m ->
                                        InorgChip("${m.sym} (${m.name})", metalIdx == idx, accent) {
                                            metalIdx = idx
                                            metalVal = m.valences.first()
                                        }
                                    }
                                }
                                if (metal.valences.size > 1) {
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("Estado de oxidación:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        metal.valences.forEach { v ->
                                            InorgChip("${metal.sym}⁺$v (${roman(v)})", effMetalVal == v, Color(0xFFF59E0B)) { metalVal = v }
                                        }
                                    }
                                }
                            }
                        } else if (family == InorgFamily.ACID_OXIDE) {
                            InorgCard("2. Selecciona el No Metal y su estado de oxidación", accent) {
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    INORG_NONMETALS_OX.forEachIndexed { idx, nm ->
                                        InorgChip("${nm.sym} (${nm.name})", nmOxIdx == idx, accent) {
                                            nmOxIdx = idx
                                            nmVal = nm.valences.last()
                                        }
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("Valencia (+):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    nmOx.valences.forEach { v ->
                                        InorgChip("+${v} (${roman(v)})", effNmVal == v, Color(0xFFF59E0B)) { nmVal = v }
                                    }
                                }
                            }
                        }

                        // 3. Anión / Elemento 2
                        if (family in listOf(InorgFamily.HYDRACID, InorgFamily.BINARY_SALT)) {
                            InorgCard("3. Selecciona el Anión no metálico", accent) {
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    BINARY_ANIONS.forEachIndexed { idx, an ->
                                        InorgChip("${an.sym}${an.valences[0]}⁻ (${an.name})", binAnionIdx == idx, Color(0xFF34D399)) { binAnionIdx = idx }
                                    }
                                }
                            }
                        } else if (family in listOf(InorgFamily.OXOACID, InorgFamily.OXOSALT)) {
                            InorgCard("3. Selecciona el Oxoanión poliatómico", accent) {
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OXOANIONS.forEachIndexed { idx, ox ->
                                        InorgChip("${ox.formula}${ox.charge}⁻ (${ox.saltName})", oxoIdx == idx, Color(0xFF34D399)) { oxoIdx = idx }
                                    }
                                }
                            }
                        }
                    }
                }

                if (isLandscape) {
                    Row(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) { resultPane(Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)) }
                        Column(Modifier.weight(1.05f).fillMaxHeight().verticalScroll(rememberScrollState())) { controlsPane(Modifier.fillMaxWidth()); Spacer(Modifier.height(14.dp)) }
                    }
                } else {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        resultPane(Modifier.fillMaxWidth())
                        controlsPane(Modifier.fillMaxWidth())
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }

            1 -> SolubilityAndPhPane(accent)
            else -> IonsAndRedoxPane(accent)
        }
    }
}

@Composable
private fun SolubilityAndPhPane(accent: Color) {
    val glass = chemGlassSurface()
    var ph by remember { mutableStateOf(7.0f) }

    val phColor = when {
        ph < 3f -> Color(0xFFEF4444)
        ph < 6f -> Color(0xFFF97316)
        ph < 6.7f -> Color(0xFFFACC15)
        ph <= 7.3f -> Color(0xFF22C55E)
        ph < 10f -> Color(0xFF06B6D4)
        ph < 12f -> Color(0xFF3B82F6)
        else -> Color(0xFF8B5CF6)
    }
    val medium = when {
        ph < 3f -> "Ácido fuerte (ej. HCl, jugo gástrico)"
        ph < 6.7f -> "Ácido débil (ej. vinagre, café, limón)"
        ph <= 7.3f -> "Neutro (agua pura a 25 °C)"
        ph < 11f -> "Base débil (ej. bicarbonato, amoníaco)"
        else -> "Base fuerte (ej. NaOH, lejía)"
    }
    val poh = 14.0 - ph
    val hConc = 10.0.pow(-ph.toDouble())
    val ohConc = 10.0.pow(-poh)

    val anions = listOf("NO₃⁻", "Cl⁻", "SO₄²⁻", "OH⁻", "CO₃²⁻", "S²⁻")
    val cations = listOf(
        "Na⁺ / K⁺" to listOf("S", "S", "S", "S", "S", "S"),
        "NH₄⁺" to listOf("S", "S", "S", "S", "S", "S"),
        "Ca²⁺" to listOf("S", "S", "P", "P", "I", "P"),
        "Ba²⁺" to listOf("S", "S", "I", "S", "I", "D"),
        "Mg²⁺" to listOf("S", "S", "S", "I", "I", "D"),
        "Fe²⁺/³⁺" to listOf("S", "S", "S", "I", "I", "I"),
        "Cu²⁺" to listOf("S", "S", "S", "I", "I", "I"),
        "Ag⁺" to listOf("S", "I", "P", "D", "I", "I"),
        "Pb²⁺" to listOf("S", "P", "I", "I", "I", "I")
    )

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Laboratorio interactivo de pH e Indicadores
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(glass).border(1.2.dp, chemGlassBorder(phColor), RoundedCornerShape(20.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Escala Interactiva de pH", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Box(Modifier.clip(RoundedCornerShape(10.dp)).background(phColor.copy(alpha = 0.22f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Text("pH = ${"%.1f".format(Locale.US, ph)}", fontWeight = FontWeight.ExtraBold, color = phColor, fontFamily = FontFamily.Monospace)
                }
            }
            Box(
                Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)).background(
                    Brush.horizontalGradient(listOf(Color(0xFFEF4444), Color(0xFFF97316), Color(0xFFFACC15), Color(0xFF22C55E), Color(0xFF06B6D4), Color(0xFF3B82F6), Color(0xFF8B5CF6)))
                )
            )
            Slider(value = ph, onValueChange = { ph = it }, valueRange = 0f..14f)
            Text(medium, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = phColor)
            Text(
                "pOH = ${"%.1f".format(Locale.US, poh)}  ·  [H⁺] = ${"%.2e".format(Locale.US, hConc)} M  ·  [OH⁻] = ${"%.2e".format(Locale.US, ohConc)} M",
                fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            HorizontalDivider(color = chemGlassBorder())
            Text("Color de indicadores ácido–base a pH ${"%.1f".format(Locale.US, ph)}:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IndicatorPill("Tornasol", if (ph < 6.8f) "Rojo" else "Azul", if (ph < 6.8f) Color(0xFFEF4444) else Color(0xFF3B82F6), Modifier.weight(1f))
                IndicatorPill("Fenolftaleína", if (ph < 8.3f) "Incoloro" else "Fucsia", if (ph < 8.3f) Color(0xFF94A3B8) else Color(0xFFEC4899), Modifier.weight(1f))
                IndicatorPill("Azul bromot.", if (ph < 6.0f) "Amarillo" else if (ph < 7.6f) "Verde" else "Azul", if (ph < 6.0f) Color(0xFFFACC15) else if (ph < 7.6f) Color(0xFF22C55E) else Color(0xFF2563EB), Modifier.weight(1f))
            }
        }

        // Tabla de solubilidad en agua (25 °C)
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(glass).border(1.dp, chemGlassBorder(), RoundedCornerShape(20.dp))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Tabla de Solubilidad en Agua (25 °C)", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = accent)
            Text("S = Soluble · P = Poco soluble · I = Insoluble (precipita) · D = Descompone", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Text("Catión", Modifier.width(68.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                anions.forEach { a -> Text(a, Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace) }
            }
            HorizontalDivider(color = chemGlassBorder())
            cations.forEach { (cat, states) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(cat, Modifier.width(68.dp), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
                    states.forEach { st ->
                        val c = when (st) {
                            "S" -> Color(0xFF22C55E)
                            "P" -> Color(0xFFF59E0B)
                            "I" -> Color(0xFFEF4444)
                            else -> Color(0xFF94A3B8)
                        }
                        Box(
                            Modifier.weight(1f).padding(horizontal = 2.dp).clip(RoundedCornerShape(6.dp))
                                .background(c.copy(alpha = 0.2f)).padding(vertical = 3.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(st, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = c) }
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun IndicatorPill(name: String, state: String, color: Color, modifier: Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.14f)).border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(10.dp))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(name, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(state, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = color)
    }
}

@Composable
private fun IonsAndRedoxPane(accent: Color) {
    val glass = chemGlassSurface()
    // Serie de actividad de metales (de más reactivo a más noble)
    val series = listOf("Li", "K", "Ca", "Na", "Mg", "Al", "Zn", "Fe", "Pb", "H", "Cu", "Ag", "Pt", "Au")
    var metalA by remember { mutableStateOf(6) } // Zn
    var ionB by remember { mutableStateOf(10) }  // Cu2+
    val reacts = metalA < ionB

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Predictor interactivo de desplazamiento Redox
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(glass).border(1.2.dp, chemGlassBorder(accent), RoundedCornerShape(20.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Predictor Redox · Serie de Actividad de Metales", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = accent)
            Text("Un metal desplaza a otro de su sal o ácido si está MÁS A LA IZQUIERDA (es más reductor).", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Metal sólido A:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                series.forEachIndexed { idx, s ->
                    if (s != "H") InorgChip(s, metalA == idx, accent) { metalA = idx }
                }
            }
            Text("En solución con ion de B (sal o ácido):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                series.forEachIndexed { idx, s ->
                    InorgChip(if (s == "H") "H⁺ (ácido)" else "${s}ⁿ⁺", ionB == idx, Color(0xFFF59E0B)) { ionB = idx }
                }
            }
            val resColor = if (reacts) Color(0xFF22C55E) else Color(0xFFEF4444)
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(resColor.copy(alpha = 0.14f)).border(1.dp, resColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        if (reacts) "✓ SÍ REACCIONA (Desplazamiento espontáneo)" else "✗ NO REACCIONA",
                        fontWeight = FontWeight.ExtraBold, color = resColor, fontSize = 13.sp
                    )
                    Text(
                        if (reacts) "${series[metalA]} es más reactivo que ${series[ionB]}: ${series[metalA]} se oxida (cede electrones) y ${series[ionB]} se reduce."
                        else "${series[metalA]} es menos reactivo que ${series[ionB]} y no puede desplazarlo de la disolución.",
                        fontSize = 12.sp, lineHeight = 18.sp
                    )
                }
            }
        }

        // Tabla rápida de oxoaniones y cationes más usados en 10mo–12mo
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(glass).border(1.dp, chemGlassBorder(), RoundedCornerShape(20.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Oxoaniones fundamentales (Preuniversitario)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = accent)
            OXOANIONS.forEach { ox ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${ox.formula}${ox.charge}⁻", Modifier.width(64.dp), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.ExtraBold, color = accent, fontSize = 13.sp)
                    Column(Modifier.weight(1f)) {
                        Text(ox.saltName.replaceFirstChar { it.uppercase() }, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("${ox.acidName} · ${ox.iupacOxo}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

@Composable
private fun InorgNameRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value.replaceFirstChar { it.uppercase() }, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InorgCard(title: String, accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(chemGlassSurface()).border(1.dp, chemGlassBorder(), RoundedCornerShape(16.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent)
        content()
    }
}

@Composable
private fun InorgChip(label: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (selected) accent.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, if (selected) accent else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, color = if (selected) accent else MaterialTheme.colorScheme.onSurface, maxLines = 1)
    }
}
