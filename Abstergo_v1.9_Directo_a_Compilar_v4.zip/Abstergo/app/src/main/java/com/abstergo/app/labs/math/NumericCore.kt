package com.abstergo.app.labs.math

import org.apache.commons.math3.analysis.UnivariateFunction
import org.apache.commons.math3.analysis.integration.SimpsonIntegrator
import org.apache.commons.math3.analysis.solvers.BrentSolver
import org.apache.commons.math3.complex.Complex
import org.apache.commons.math3.fraction.Fraction
import org.apache.commons.math3.linear.Array2DRowRealMatrix
import org.apache.commons.math3.linear.ArrayRealVector
import org.apache.commons.math3.linear.LUDecomposition
import org.apache.commons.math3.linear.SingularValueDecomposition
import org.apache.commons.math3.util.FastMath
import kotlin.math.abs

/**
 * Núcleo numérico científico basado en microMathematics + Apache Commons Math3.
 * 100% JVM puro (universal 32/64 bits): complejos, derivación/integración numérica,
 * búsqueda de raíces con Brent, fracciones exactas, álgebra lineal y FFT.
 */
object NumericCore {

    /** Evalúa una expresión en aritmética compleja completa (soporta i, sqrt(-1), etc.). */
    fun evalComplex(expr: Expr, vars: Map<String, Complex> = emptyMap()): Complex = when (expr) {
        is Expr.Num -> Complex(expr.text.toDoubleOrNull() ?: Double.NaN, 0.0)
        is Expr.Var -> vars[expr.name] ?: Complex.NaN
        is Expr.Const -> when (expr.name) {
            "pi" -> Complex(Math.PI, 0.0)
            "e" -> Complex(Math.E, 0.0)
            "i" -> Complex.I
            else -> Complex.NaN
        }
        is Expr.Unary -> when (expr.op) {
            "-" -> evalComplex(expr.operand, vars).negate()
            "+" -> evalComplex(expr.operand, vars)
            else -> Complex.NaN
        }
        is Expr.Binary -> {
            val l = evalComplex(expr.left, vars)
            val r = evalComplex(expr.right, vars)
            when (expr.op) {
                "+" -> l.add(r)
                "-" -> l.subtract(r)
                "*" -> l.multiply(r)
                "/" -> l.divide(r)
                "^" -> l.pow(r)
                "=" -> l.subtract(r)
                else -> Complex.NaN
            }
        }
        is Expr.Call -> {
            if (expr.args.size == 1) {
                val z = evalComplex(expr.args[0], vars)
                when (expr.name) {
                    "sqrt" -> z.sqrt()
                    "sin" -> z.sin()
                    "cos" -> z.cos()
                    "tan" -> z.tan()
                    "sinh" -> z.sinh()
                    "cosh" -> z.cosh()
                    "tanh" -> z.tanh()
                    "asin" -> z.asin()
                    "acos" -> z.acos()
                    "atan" -> z.atan()
                    "exp" -> z.exp()
                    "ln", "log" -> z.log()
                    "abs" -> Complex(z.abs(), 0.0)
                    else -> Complex.NaN
                }
            } else Complex.NaN
        }
    }

    fun formatComplex(z: Complex): String {
        if (z.isNaN) return "Indefinido"
        val re = if (abs(z.real) < 1e-10) 0.0 else z.real
        val im = if (abs(z.imaginary) < 1e-10) 0.0 else z.imaginary
        if (im == 0.0) return ExprFormatter.formatNumber(re)
        val imAbs = ExprFormatter.formatNumber(abs(im))
        val imPart = if (imAbs == "1") "i" else "${imAbs}i"
        if (re == 0.0) return if (im < 0) "-$imPart" else imPart
        val sign = if (im < 0) " - " else " + "
        return "${ExprFormatter.formatNumber(re)}$sign$imPart"
    }

    /** Convierte un número real a fracción reducida si tiene una aproximación exacta razonable. */
    fun toExactFraction(value: Double, maxDenom: Int = 1000): Pair<Int, Int>? {
        if (!value.isFinite()) return null
        return try {
            val frac = Fraction(value, 1e-9, 25)
            if (frac.denominator in 2..maxDenom && abs(frac.toDouble() - value) < 1e-8) {
                frac.numerator to frac.denominator
            } else null
        } catch (_: Exception) { null }
    }

    /** Derivada numérica centrada de 4º orden (extrapolación de Richardson). */
    fun numericalDerivative(compiled: CompiledExpr, x: Double, h: Double = 1e-4): Double {
        val slots = compiled.newSlots()
        fun f(t: Double): Double {
            slots[0] = t
            return compiled.eval(slots)
        }
        val d1 = (f(x + h) - f(x - h)) / (2.0 * h)
        val d2 = (f(x + 2.0 * h) - f(x - 2.0 * h)) / (4.0 * h)
        return (4.0 * d1 - d2) / 3.0
    }

    /** Integración numérica definida (Simpson adaptativo de commons-math3 con respaldo compuesto). */
    fun definiteIntegral(compiled: CompiledExpr, lower: Double, upper: Double): Double {
        if (!lower.isFinite() || !upper.isFinite()) return Double.NaN
        if (abs(upper - lower) < 1e-12) return 0.0
        val sign = if (upper < lower) -1.0 else 1.0
        val a = minOf(lower, upper)
        val b = maxOf(lower, upper)
        val slots = compiled.newSlots()
        val fn = UnivariateFunction { t ->
            slots[0] = t
            compiled.eval(slots)
        }
        return try {
            sign * SimpsonIntegrator().integrate(2000, fn, a, b)
        } catch (_: Exception) {
            // Respaldo: Simpson compuesto de 400 subintervalos
            val n = 400
            val h = (b - a) / n
            var sum = fn.value(a) + fn.value(b)
            for (i in 1 until n) {
                val v = fn.value(a + i * h)
                if (!v.isFinite()) return Double.NaN
                sum += if (i % 2 == 0) 2.0 * v else 4.0 * v
            }
            sign * sum * h / 3.0
        }
    }

    /**
     * Busca raíces reales de f(x) = 0 en [minX, maxX] barriendo subintervalos
     * y refinando cada cambio de signo con BrentSolver (estrategia de microMathematics SeriesIntegrals).
     */
    fun findRealRoots(
        compiled: CompiledExpr,
        minX: Double = -50.0,
        maxX: Double = 50.0,
        steps: Int = 500
    ): List<Double> {
        val slots = compiled.newSlots()
        val fn = UnivariateFunction { t ->
            slots[0] = t
            compiled.eval(slots)
        }
        val solver = BrentSolver(1e-10, 1e-12)
        val roots = ArrayList<Double>()
        val dx = (maxX - minX) / steps
        var prevX = minX
        var prevY = fn.value(prevX)

        fun addUnique(r: Double) {
            if (!r.isFinite()) return
            val clean = if (abs(r) < 1e-9) 0.0 else r
            if (roots.none { abs(it - clean) < 1e-5 }) roots.add(clean)
        }

        if (prevY.isFinite() && abs(prevY) < 1e-9) addUnique(prevX)
        for (i in 1..steps) {
            val curX = minX + i * dx
            val curY = fn.value(curX)
            if (prevY.isFinite() && curY.isFinite()) {
                if (abs(curY) < 1e-9) {
                    addUnique(curX)
                } else if (prevY * curY < 0.0) {
                    try {
                        val root = solver.solve(100, fn, prevX, curX)
                        if (abs(fn.value(root)) < 1e-5) addUnique(root)
                    } catch (_: Exception) { }
                }
            }
            prevX = curX
            prevY = curY
        }
        return roots.sorted()
    }

    /** Álgebra lineal: determinante, rango, traza, inversa y resolución Ax = b. */
    data class LinearSystemResult(
        val solved: Boolean,
        val solution: DoubleArray? = null,
        val determinant: Double = Double.NaN,
        val message: String = ""
    )

    fun solveLinearSystem(a: Array<DoubleArray>, b: DoubleArray): LinearSystemResult {
        if (a.isEmpty() || a.size != b.size || a.any { it.size != a.size }) {
            return LinearSystemResult(false, message = "La matriz de coeficientes debe ser cuadrada.")
        }
        return try {
            val mat = Array2DRowRealMatrix(a, false)
            val lu = LUDecomposition(mat)
            val det = lu.determinant
            if (!lu.solver.isNonSingular || abs(det) < 1e-12) {
                LinearSystemResult(
                    solved = false,
                    determinant = det,
                    message = "El determinante es 0: el sistema no tiene solución única (es compatible indeterminado o incompatible)."
                )
            } else {
                val sol = lu.solver.solve(ArrayRealVector(b, false)).toArray()
                LinearSystemResult(solved = true, solution = sol, determinant = det, message = "Solución única encontrada.")
            }
        } catch (e: Exception) {
            LinearSystemResult(false, message = e.message ?: "No se pudo resolver el sistema.")
        }
    }

    fun matrixDeterminant(a: Array<DoubleArray>): Double =
        try { LUDecomposition(Array2DRowRealMatrix(a, false)).determinant } catch (_: Exception) { Double.NaN }

    fun matrixRank(a: Array<DoubleArray>): Int =
        try { SingularValueDecomposition(Array2DRowRealMatrix(a, false)).rank } catch (_: Exception) { 0 }

    fun matrixInverse(a: Array<DoubleArray>): Array<DoubleArray>? =
        try {
            val lu = LUDecomposition(Array2DRowRealMatrix(a, false))
            if (lu.solver.isNonSingular) lu.solver.inverse.data else null
        } catch (_: Exception) { null }

    /** Transformada rápida de Fourier (portada de microMathematics Fft.java: radix-2 + DFT genérica). */
    fun fft(input: Array<Complex>, inverse: Boolean = false): Array<Complex> {
        val n = input.size
        if (n == 0) return emptyArray()
        val sign = if (inverse) 1.0 else -1.0
        val isPow2 = (n and (n - 1)) == 0
        if (!isPow2) {
            val factor = sign * 2.0 * FastMath.PI / n
            val norm = if (inverse) 1.0 / n else 1.0
            return Array(n) { k ->
                var re = 0.0
                var im = 0.0
                for (t in 0 until n) {
                    val angle = factor * t * k
                    val c = FastMath.cos(angle)
                    val s = FastMath.sin(angle)
                    val xr = input[t].real
                    val xi = input[t].imaginary
                    re += xr * c - xi * s
                    im += xr * s + xi * c
                }
                Complex(re * norm, im * norm)
            }
        }
        val data = DoubleArray(2 * n + 1)
        for (k in 0 until n) {
            data[2 * k + 1] = input[k].real
            data[2 * k + 2] = input[k].imaginary
        }
        val nn = n shl 1
        var j = 1
        var i = 1
        while (i < nn) {
            if (j > i) {
                var tmp = data[j]; data[j] = data[i]; data[i] = tmp
                tmp = data[j + 1]; data[j + 1] = data[i + 1]; data[i + 1] = tmp
            }
            var m = n
            while (m >= 2 && j > m) { j -= m; m = m shr 1 }
            j += m
            i += 2
        }
        var mmax = 2
        while (nn > mmax) {
            val istep = mmax shl 1
            val theta = sign * (2.0 * FastMath.PI / mmax)
            val wtemp = FastMath.sin(0.5 * theta)
            val wpr = -2.0 * wtemp * wtemp
            val wpi = FastMath.sin(theta)
            var wr = 1.0
            var wi = 0.0
            var m = 1
            while (m < mmax) {
                var idx = m
                while (idx <= nn) {
                    val jIdx = idx + mmax
                    val tempr = wr * data[jIdx] - wi * data[jIdx + 1]
                    val tempi = wr * data[jIdx + 1] + wi * data[jIdx]
                    data[jIdx] = data[idx] - tempr
                    data[jIdx + 1] = data[idx + 1] - tempi
                    data[idx] += tempr
                    data[idx + 1] += tempi
                    idx += istep
                }
                val nextWr = wr * wpr - wi * wpi + wr
                wi = wi * wpr + wr * wpi + wi
                wr = nextWr
                m += 2
            }
            mmax = istep
        }
        val norm = if (inverse) n.toDouble() else 1.0
        return Array(n) { k -> Complex(data[2 * k + 1] / norm, data[2 * k + 2] / norm) }
    }
}
