package com.abstergo.app.labs.math

import androidx.compose.runtime.Immutable
import kotlin.math.abs
import kotlin.math.sqrt

enum class MathSolveMode(val label: String) {
    AUTO("Automático"),
    SOLVE("Resolver"),
    SIMPLIFY("Simplificar"),
    DERIVE("Derivar"),
    FACTOR("Factorizar"),
    PLOT("Graficar")
}

enum class ProblemType(val label: String) {
    EXPRESSION("Expresión numérica / algebraica"),
    LINEAR_EQUATION("Ecuación lineal"),
    QUADRATIC_EQUATION("Ecuación cuadrática"),
    GENERAL_EQUATION("Ecuación general"),
    LINEAR_SYSTEM("Sistema de ecuaciones"),
    DERIVATIVE("Derivada simbólica"),
    FUNCTION_PLOT("Gráfica de función")
}

@Immutable
data class MathStep(
    val index: Int,
    val title: String,
    val explanation: String,
    val expression: String,
    val latex: String,
    val ruleTag: String,
    val elements: List<InteractiveElement>
)

@Immutable
data class PlotPointSpec(
    val x: Double,
    val y: Double,
    val label: String,
    val color: String = "#E53935"
)

@Immutable
data class PlotFunctionSpec(
    val jsExpression: String,
    val label: String,
    val color: String = "#0072B2"
)

@Immutable
data class PlotSceneSpec(
    val functions: List<PlotFunctionSpec> = emptyList(),
    val points: List<PlotPointSpec> = emptyList(),
    val xMin: Double = -8.0,
    val xMax: Double = 8.0,
    val yMin: Double = -8.0,
    val yMax: Double = 8.0
)

@Immutable
data class MathSolution(
    val ok: Boolean,
    val originalInput: String,
    val normalizedInput: String,
    val problemType: ProblemType,
    val steps: List<MathStep>,
    val finalAnswer: String,
    val finalLatex: String,
    val plotScene: PlotSceneSpec? = null,
    val error: String? = null
)

/**
 * Fachada principal del Motor Matemático Fusionado de Abstergo Labs.
 * Une el parser y compilador de MaxMath, el núcleo numérico de microMathematics/commons-math3,
 * el motor simbólico paso a paso y las especificaciones de escena 2D para JSXGraph 1.14.3.
 */
object MathLabEngine {

    private val PLOT_PALETTE = listOf("#1E88E5", "#43A047", "#E53935", "#8E24AA", "#FB8C00")

    fun solve(rawInput: String, mode: MathSolveMode = MathSolveMode.AUTO): MathSolution {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return errorSolution(rawInput, "Escribe o escanea un ejercicio matemático para comenzar.")
        }
        val normalized = LatexToMath.normalize(trimmed)
        return try {
            val system = MathInputParser.parseSystem(normalized)
            when {
                system.equations.size > 1 -> solveSystem(trimmed, normalized, system)
                mode == MathSolveMode.DERIVE -> solveDerivative(trimmed, normalized, system.equations[0], system.variables)
                mode == MathSolveMode.FACTOR -> solveFactor(trimmed, normalized, system.equations[0], system.variables)
                mode == MathSolveMode.SIMPLIFY -> solveSimplify(trimmed, normalized, system.equations[0], system.variables)
                mode == MathSolveMode.PLOT -> solvePlotOnly(trimmed, normalized, system.equations[0], system.variables)
                else -> {
                    val eq = system.equations[0]
                    val isEquation = eq is Expr.Binary && eq.op == "="
                    if (isEquation) {
                        val b = eq as Expr.Binary
                        // Caso "y = f(x)" -> graficar y analizar
                        if (mode == MathSolveMode.AUTO && b.left is Expr.Var && b.left.name.equals("y", true) &&
                            system.variables.any { !it.equals("y", true) }
                        ) {
                            solvePlotOnly(trimmed, normalized, b.right, system.variables.filterNot { it.equals("y", true) })
                        } else {
                            solveSingleEquation(trimmed, normalized, b.left, b.right, system.variables)
                        }
                    } else if (mode == MathSolveMode.SOLVE && system.variables.size == 1) {
                        solveSingleEquation(trimmed, normalized, eq, Expr.Num("0"), system.variables)
                    } else {
                        solveExpression(trimmed, normalized, eq, system.variables)
                    }
                }
            }
        } catch (e: MathParseException) {
            errorSolution(rawInput, e.userMessage)
        } catch (e: Exception) {
            errorSolution(rawInput, e.message ?: "No se pudo interpretar la expresión.")
        }
    }

    // ---------- 1. Expresiones numéricas o algebraicas ----------
    private fun solveExpression(raw: String, norm: String, expr: Expr, vars: List<String>): MathSolution {
        val steps = ArrayList<MathStep>()
        steps.add(makeStep(1, "Expresión original", "Identificamos los términos, operadores y prioridades de la expresión.", expr, "Lectura"))

        if (vars.isEmpty()) {
            val hasImaginary = containsImaginary(expr)
            val simplified = SymbolicEngine.simplify(expr)
            if (simplified != expr) {
                steps.add(makeStep(steps.size + 1, "Simplificación paso a paso", "Aplicamos orden de operaciones: paréntesis, potencias, multiplicaciones/divisiones y sumas/restas.", simplified, "Jerarquía"))
            }
            if (hasImaginary) {
                val z = NumericCore.evalComplex(expr)
                val formatted = NumericCore.formatComplex(z)
                steps.add(makeStepText(steps.size + 1, "Resultado en números complejos", "Evaluamos parte real y parte imaginaria usando aritmética compleja.", formatted, formatted, "Complejos"))
                return MathSolution(true, raw, norm, ProblemType.EXPRESSION, steps, formatted, formatted)
            }
            val compiled = CompiledExpr.compile(expr, emptyList())
            val result = compiled.eval(DoubleArray(0))
            if (!result.isFinite()) {
                return errorSolution(raw, "El resultado no está definido en los números reales (posible división entre cero o raíz negativa).")
            }
            val answer = SymbolicEngine.formatValueWithFraction(result)
            val dec = ExprFormatter.formatNumber(result)
            steps.add(makeStepText(steps.size + 1, "Resultado final", "Evaluamos numéricamente la expresión completa.", dec, dec, "Resultado"))
            return MathSolution(true, raw, norm, ProblemType.EXPRESSION, steps, answer, dec)
        }

        // Expresión con variables: simplificar + mostrar forma polinómica y gráfica si es 1D
        val v = vars[0]
        val poly = if (vars.size == 1) SymbolicEngine.toPolynomial(expr, v) else null
        val simplified = poly?.toExpr() ?: SymbolicEngine.simplify(expr)
        if (simplified != expr) {
            steps.add(makeStep(steps.size + 1, "Reducción de términos semejantes", "Agrupamos coeficientes y aplicamos identidades algebraicas.", simplified, "Simplificación"))
        }
        val factored = poly?.let { SymbolicEngine.factorQuadratic(it) }
        if (factored != null) {
            steps.add(makeStepText(steps.size + 1, "Forma factorizada", "Reescribimos el polinomio cuadrático como producto de factores.", factored, factored, "Factorización"))
        }
        val plot = if (vars.size == 1) buildPlotForFunction(simplified, v) else null
        val ansPlain = ExprFormatter.toPlain(simplified)
        val ansLatex = ExprFormatter.toLatex(simplified)
        return MathSolution(true, raw, norm, ProblemType.EXPRESSION, steps, ansPlain, ansLatex, plot)
    }

    // ---------- 2. Ecuación en una variable ----------
    private fun solveSingleEquation(raw: String, norm: String, left: Expr, right: Expr, vars: List<String>): MathSolution {
        val steps = ArrayList<MathStep>()
        val eqExpr = Expr.Binary("=", left, right)
        steps.add(makeStep(1, "Ecuación planteada", "Observamos ambos miembros separados por el signo igual (=).", eqExpr, "Planteamiento"))

        if (vars.isEmpty()) {
            val lv = Evaluator.eval(left)
            val rv = Evaluator.eval(right)
            val holds = lv.isFinite() && rv.isFinite() && abs(lv - rv) < 1e-9
            val text = "${ExprFormatter.formatNumber(lv)} = ${ExprFormatter.formatNumber(rv)}"
            steps.add(makeStepText(2, "Comprobación numérica", if (holds) "Ambos miembros tienen el mismo valor: la igualdad es verdadera." else "Los miembros difieren: la igualdad es falsa.", text, text, "Verificación"))
            val ans = if (holds) "Verdadero ($text)" else "Falso ($text)"
            return MathSolution(true, raw, norm, ProblemType.EXPRESSION, steps, ans, text)
        }

        val v = vars[0]
        val diffExpr = SymbolicEngine.simplify(Expr.Binary("-", left, right))
        val poly = if (vars.size == 1) SymbolicEngine.toPolynomial(diffExpr, v) else null

        if (poly != null) {
            val stdExpr = poly.toExpr()
            val stdEq = Expr.Binary("=", stdExpr, Expr.Num("0"))
            if (stdEq != eqExpr) {
                steps.add(makeStep(steps.size + 1, "Pasar todo al primer miembro", "Restamos el segundo miembro a ambos lados y agrupamos términos semejantes en $v.", stdEq, "Transposición"))
            }

            return when (poly.degree) {
                0 -> {
                    val c = poly.coeff(0)
                    val ans = if (abs(c) < 1e-10) "Infinitas soluciones (identidad)" else "Sin solución (contradicción)"
                    steps.add(makeStepText(steps.size + 1, "Análisis del término constante", ans, "${ExprFormatter.formatNumber(c)} = 0", "${ExprFormatter.formatNumber(c)} = 0", "Conclusión"))
                    MathSolution(true, raw, norm, ProblemType.LINEAR_EQUATION, steps, ans, ans)
                }

                1 -> solveLinearPoly(raw, norm, poly, steps)
                2 -> solveQuadraticPoly(raw, norm, poly, steps)
                else -> solveGeneralEquation(raw, norm, diffExpr, v, steps)
            }
        }

        return solveGeneralEquation(raw, norm, diffExpr, v, steps)
    }

    private fun solveLinearPoly(raw: String, norm: String, poly: Polynomial, steps: MutableList<MathStep>): MathSolution {
        val v = poly.variable
        val a = poly.coeff(1)
        val b = poly.coeff(0)
        val negB = -b
        val stepMove = "${ExprFormatter.formatNumber(a)}$v = ${ExprFormatter.formatNumber(negB)}"
        steps.add(makeStepText(steps.size + 1, "Aislar el término con $v", "Pasamos el término independiente al otro lado cambiando su signo.", stepMove, stepMove, "Despeje"))

        val root = negB / a
        if (abs(a - 1.0) > 1e-10) {
            val divExpr = "$v = ${ExprFormatter.formatNumber(negB)} / ${ExprFormatter.formatNumber(a)}"
            steps.add(makeStepText(steps.size + 1, "Dividir entre el coeficiente", "Dividimos ambos lados entre ${ExprFormatter.formatNumber(a)} para despejar $v.", divExpr, "$v = \\frac{${ExprFormatter.formatNumber(negB)}}{${ExprFormatter.formatNumber(a)}}", "División"))
        }

        val ansValue = SymbolicEngine.formatValueWithFraction(root)
        val cleanRoot = ExprFormatter.formatNumber(root)
        steps.add(makeStepText(steps.size + 1, "Solución encontrada", "Al sustituir $v = $cleanRoot en la ecuación original ambos miembros coinciden.", "$v = $cleanRoot", "$v = $cleanRoot", "Solución"))

        val scene = buildPlotForFunction(poly.toExpr(), v, listOf(PlotPointSpec(root, 0.0, "Raíz ($cleanRoot, 0)")))
        return MathSolution(true, raw, norm, ProblemType.LINEAR_EQUATION, steps, "$v = $ansValue", "$v = $cleanRoot", scene)
    }

    private fun solveQuadraticPoly(raw: String, norm: String, poly: Polynomial, steps: MutableList<MathStep>): MathSolution {
        val v = poly.variable
        val a = poly.coeff(2)
        val b = poly.coeff(1)
        val c = poly.coeff(0)
        val aS = ExprFormatter.formatNumber(a)
        val bS = ExprFormatter.formatNumber(b)
        val cS = ExprFormatter.formatNumber(c)

        steps.add(
            makeStepText(
                steps.size + 1,
                "Identificar coeficientes a, b y c",
                "Comparamos con la forma estándar a${v}² + b$v + c = 0.",
                "a = $aS, b = $bS, c = $cS",
                "a = $aS,\\; b = $bS,\\; c = $cS",
                "Cuadrática"
            )
        )

        val disc = b * b - 4.0 * a * c
        val discS = ExprFormatter.formatNumber(disc)
        val discExplain = when {
            disc > 1e-10 -> "Como Δ > 0, la ecuación tiene dos soluciones reales distintas."
            abs(disc) <= 1e-10 -> "Como Δ = 0, la ecuación tiene una única solución real (raíz doble)."
            else -> "Como Δ < 0, la ecuación no tiene raíces reales; sus soluciones son complejas conjugadas."
        }
        steps.add(
            makeStepText(
                steps.size + 1,
                "Calcular el discriminante Δ = b² - 4ac",
                discExplain,
                "Δ = ($bS)^2 - 4($aS)($cS) = $discS",
                "\\Delta = ($bS)^2 - 4($aS)($cS) = $discS",
                "Discriminante"
            )
        )

        val factored = SymbolicEngine.factorQuadratic(poly)
        if (factored != null) {
            steps.add(
                makeStepText(
                    steps.size + 1,
                    "Factorización equivalente",
                    "La expresión también puede factorizarse directamente igualando cada factor a cero.",
                    "$factored = 0",
                    "$factored = 0",
                    "Factorización"
                )
            )
        }

        val (r1, r2) = SymbolicEngine.solveQuadraticRoots(a, b, c)
        val vertexX = -b / (2.0 * a)
        val vertexY = a * vertexX * vertexX + b * vertexX + c
        val pts = ArrayList<PlotPointSpec>()
        pts.add(PlotPointSpec(vertexX, vertexY, "Vértice (${ExprFormatter.formatNumber(vertexX)}, ${ExprFormatter.formatNumber(vertexY)})", "#1E88E5"))

        val finalAns: String
        val finalLatex: String
        if (disc >= -1e-10) {
            val x1 = r1.real
            val x2 = r2.real
            val x1S = ExprFormatter.formatNumber(x1)
            val x2S = ExprFormatter.formatNumber(x2)
            if (abs(x1 - x2) < 1e-9) {
                finalAns = "$v = ${SymbolicEngine.formatValueWithFraction(x1)} (raíz doble)"
                finalLatex = "$v = $x1S"
                pts.add(PlotPointSpec(x1, 0.0, "Raíz ($x1S, 0)"))
            } else {
                finalAns = "${v}₁ = ${SymbolicEngine.formatValueWithFraction(x1)} ; ${v}₂ = ${SymbolicEngine.formatValueWithFraction(x2)}"
                finalLatex = "${v}_1 = $x1S,\\; ${v}_2 = $x2S"
                pts.add(PlotPointSpec(x1, 0.0, "${v}₁ ($x1S, 0)"))
                pts.add(PlotPointSpec(x2, 0.0, "${v}₂ ($x2S, 0)"))
            }
            steps.add(
                makeStepText(
                    steps.size + 1,
                    "Aplicar la fórmula general",
                    "Sustituimos a, b y √Δ en $v = (-b ± √Δ) / (2a).",
                    finalAns,
                    finalLatex,
                    "Fórmula general"
                )
            )
        } else {
            val z1 = NumericCore.formatComplex(r1)
            val z2 = NumericCore.formatComplex(r2)
            finalAns = "${v}₁ = $z1 ; ${v}₂ = $z2"
            finalLatex = "${v}_1 = $z1,\\; ${v}_2 = $z2"
            steps.add(
                makeStepText(
                    steps.size + 1,
                    "Raíces complejas conjugadas",
                    "Extraemos √(${ExprFormatter.formatNumber(-disc)})·i para obtener las dos raíces complejas.",
                    finalAns,
                    finalLatex,
                    "Complejos"
                )
            )
        }

        val scene = buildPlotForFunction(poly.toExpr(), v, pts)
        return MathSolution(true, raw, norm, ProblemType.QUADRATIC_EQUATION, steps, finalAns, finalLatex, scene)
    }

    private fun solveGeneralEquation(raw: String, norm: String, diffExpr: Expr, v: String, steps: MutableList<MathStep>): MathSolution {
        val diffEq = Expr.Binary("=", diffExpr, Expr.Num("0"))
        steps.add(makeStep(steps.size + 1, "Forma equivalente f($v) = 0", "Igualamos la expresión a cero para localizar sus raíces reales.", diffEq, "Ecuación"))

        val compiled = CompiledExpr.compile(diffExpr, listOf(v))
        val roots = NumericCore.findRealRoots(compiled, -50.0, 50.0, 600)
        if (roots.isEmpty()) {
            val scene = buildPlotForFunction(diffExpr, v)
            val msg = "No se hallaron raíces reales en [-50, 50]"
            steps.add(makeStepText(steps.size + 1, "Búsqueda numérica (Brent)", "No se detectaron cambios de signo en el intervalo analizado.", msg, msg, "Numérico"))
            return MathSolution(true, raw, norm, ProblemType.GENERAL_EQUATION, steps, msg, msg, scene)
        }

        val pts = roots.mapIndexed { idx, r ->
            val rs = ExprFormatter.formatNumber(r)
            PlotPointSpec(r, 0.0, "${v}${idx + 1} ($rs, 0)")
        }
        val ans = roots.mapIndexed { i, r -> "${v}${i + 1} = ${ExprFormatter.formatNumber(r)}" }.joinToString(" ; ")
        steps.add(
            makeStepText(
                steps.size + 1,
                "Raíces encontradas (método de Brent)",
                "Localizamos cada cambio de signo de f($v) y refinamos con precisión de 10⁻¹⁰.",
                ans,
                ans,
                "Raíces reales"
            )
        )
        val scene = buildPlotForFunction(diffExpr, v, pts)
        return MathSolution(true, raw, norm, ProblemType.GENERAL_EQUATION, steps, ans, ans, scene)
    }

    // ---------- 3. Sistemas de ecuaciones lineales ----------
    private fun solveSystem(raw: String, norm: String, sys: ParsedSystem): MathSolution {
        val steps = ArrayList<MathStep>()
        val vars = sys.variables
        val eqsText = sys.equations.joinToString(" ; ") { ExprFormatter.toPlain(it) }
        steps.add(
            makeStepText(
                1,
                "Sistema planteado (${sys.equations.size} ecuaciones, ${vars.size} incógnitas)",
                "Variables detectadas: ${vars.joinToString(", ")}.",
                eqsText,
                eqsText,
                "Sistema"
            )
        )

        if (vars.size != sys.equations.size) {
            return errorSolution(raw, "El sistema tiene ${sys.equations.size} ecuaciones y ${vars.size} variables (${vars.joinToString(", ")}). Necesita el mismo número de ecuaciones que de incógnitas.")
        }

        val n = vars.size
        val matrix = Array(n) { DoubleArray(n) }
        val rhs = DoubleArray(n)
        for (i in 0 until n) {
            val eq = sys.equations[i]
            val diff = if (eq is Expr.Binary && eq.op == "=") Expr.Binary("-", eq.left, eq.right) else eq
            val lf = SymbolicEngine.toLinearForm(diff, vars)
                ?: return errorSolution(raw, "La ecuación ${i + 1} no es lineal. Por ahora los sistemas paso a paso admiten ecuaciones lineales.")
            for (j in 0 until n) matrix[i][j] = lf.coeffs[j]
            rhs[i] = -lf.constant
        }

        val matDesc = (0 until n).joinToString(" ; ") { i ->
            val lhs = (0 until n).joinToString(" + ") { j -> "${ExprFormatter.formatNumber(matrix[i][j])}${vars[j]}" }
            "$lhs = ${ExprFormatter.formatNumber(rhs[i])}"
        }
        steps.add(makeStepText(2, "Forma canónica Ax = b", "Ordenamos las incógnitas en columnas y los términos independientes a la derecha.", matDesc, matDesc, "Matriz"))

        val res = NumericCore.solveLinearSystem(matrix, rhs)
        val detS = ExprFormatter.formatNumber(res.determinant)
        steps.add(
            makeStepText(
                3,
                "Determinante del sistema",
                if (res.solved) "det(A) = $detS ≠ 0, por lo tanto el sistema tiene solución única."
                else res.message,
                "det(A) = $detS",
                "\\det(A) = $detS",
                "Determinante"
            )
        )

        if (!res.solved || res.solution == null) {
            return MathSolution(true, raw, norm, ProblemType.LINEAR_SYSTEM, steps, res.message, res.message)
        }

        val sol = res.solution
        val ansText = (0 until n).joinToString(" ; ") { i -> "${vars[i]} = ${SymbolicEngine.formatValueWithFraction(sol[i])}" }
        val ansShort = (0 until n).joinToString(", ") { i -> "${vars[i]} = ${ExprFormatter.formatNumber(sol[i])}" }
        steps.add(makeStepText(4, "Solución del sistema", "Resolvemos por descomposición LU / eliminación gaussiana y verificamos cada ecuación.", ansShort, ansShort, "Solución"))

        // Si es 2x2 en (x, y), generar escena 2D de ambas rectas y su punto de intersección
        val scene = if (n == 2) buildLinearSystem2DScene(matrix, rhs, sol, vars) else null
        return MathSolution(true, raw, norm, ProblemType.LINEAR_SYSTEM, steps, ansText, ansShort, scene)
    }

    private fun buildLinearSystem2DScene(
        a: Array<DoubleArray>,
        b: DoubleArray,
        sol: DoubleArray,
        vars: List<String>
    ): PlotSceneSpec {
        val funcs = ArrayList<PlotFunctionSpec>()
        for (i in 0..1) {
            val cx = a[i][0]
            val cy = a[i][1]
            val c = b[i]
            if (abs(cy) > 1e-10) {
                val js = "(${c} - (${cx}) * x) / (${cy})"
                funcs.add(PlotFunctionSpec(js, "Ec. ${i + 1}", PLOT_PALETTE[i]))
            }
        }
        val ix = sol[0]
        val iy = sol[1]
        val pad = maxOf(5.0, maxOf(abs(ix), abs(iy)) * 0.6 + 3.0)
        return PlotSceneSpec(
            functions = funcs,
            points = listOf(
                PlotPointSpec(
                    ix, iy,
                    "Intersección (${ExprFormatter.formatNumber(ix)}, ${ExprFormatter.formatNumber(iy)})",
                    "#E53935"
                )
            ),
            xMin = ix - pad, xMax = ix + pad,
            yMin = iy - pad, yMax = iy + pad
        )
    }

    // ---------- 4. Derivada simbólica ----------
    private fun solveDerivative(raw: String, norm: String, expr: Expr, vars: List<String>): MathSolution {
        val target = if (expr is Expr.Binary && expr.op == "=") expr.right else expr
        val v = vars.firstOrNull { !it.equals("y", true) } ?: "x"
        val steps = ArrayList<MathStep>()
        steps.add(makeStep(1, "Función a derivar respecto a $v", "Identificamos la estructura de f($v) para aplicar las reglas de derivación.", target, "f($v)"))

        val (deriv, rules) = SymbolicEngine.differentiate(target, v)
        if (rules.isNotEmpty()) {
            steps.add(
                makeStepText(
                    2,
                    "Reglas aplicadas",
                    rules.joinToString("\n• ", prefix = "• "),
                    "d/d$v (${ExprFormatter.toPlain(target)})",
                    "\\frac{d}{d$v}\\left(${ExprFormatter.toLatex(target)}\\right)",
                    "Reglas"
                )
            )
        }
        steps.add(makeStep(steps.size + 1, "Derivada simplificada f'($v)", "Simplificamos el resultado agrupando coeficientes y potencias.", deriv, "Derivada"))

        val fJs = toJsExpression(target, v)
        val dfJs = toJsExpression(deriv, v)
        val scene = PlotSceneSpec(
            functions = listOf(
                PlotFunctionSpec(fJs, "f($v)", PLOT_PALETTE[0]),
                PlotFunctionSpec(dfJs, "f'($v)", PLOT_PALETTE[2])
            )
        )
        return MathSolution(true, raw, norm, ProblemType.DERIVATIVE, steps, "f'($v) = ${ExprFormatter.toPlain(deriv)}", "f'($v) = ${ExprFormatter.toLatex(deriv)}", scene)
    }

    // ---------- 5. Factorización ----------
    private fun solveFactor(raw: String, norm: String, expr: Expr, vars: List<String>): MathSolution {
        val target = if (expr is Expr.Binary && expr.op == "=") Expr.Binary("-", expr.left, expr.right) else expr
        val v = vars.firstOrNull() ?: return solveExpression(raw, norm, target, vars)
        val poly = SymbolicEngine.toPolynomial(target, v)
            ?: return solveExpression(raw, norm, target, vars)
        val steps = ArrayList<MathStep>()
        steps.add(makeStep(1, "Polinomio original", "Ordenamos el polinomio según potencias decrecientes de $v.", poly.toExpr(), "Polinomio"))
        val factored = SymbolicEngine.factorQuadratic(poly)
            ?: return solveExpression(raw, norm, target, vars)
        steps.add(makeStepText(2, "Forma factorizada", "Expresamos el polinomio como producto de factores lineales.", factored, factored, "Factorización"))
        val scene = buildPlotForFunction(poly.toExpr(), v)
        return MathSolution(true, raw, norm, ProblemType.EXPRESSION, steps, factored, factored, scene)
    }

    // ---------- 6. Simplificación directa ----------
    private fun solveSimplify(raw: String, norm: String, expr: Expr, vars: List<String>): MathSolution =
        solveExpression(raw, norm, expr, vars)

    // ---------- 7. Modo gráfica 2D ----------
    private fun solvePlotOnly(raw: String, norm: String, expr: Expr, vars: List<String>): MathSolution {
        val v = vars.firstOrNull() ?: "x"
        val compiled = CompiledExpr.compile(expr, listOf(v))
        val roots = NumericCore.findRealRoots(compiled, -20.0, 20.0, 400)
        val y0 = compiled.evalSingle(0.0)
        val pts = ArrayList<PlotPointSpec>()
        if (y0.isFinite()) pts.add(PlotPointSpec(0.0, y0, "Corte Y (0, ${ExprFormatter.formatNumber(y0)})", "#43A047"))
        roots.take(6).forEach { r -> pts.add(PlotPointSpec(r, 0.0, "Cero (${ExprFormatter.formatNumber(r)}, 0)", "#E53935")) }

        val steps = listOf(
            makeStep(1, "Función f($v)", "La gráfica se renderiza offline en JSXGraph 1.14.3; puedes hacer zoom, arrastrar y tocar puntos clave.", expr, "Gráfica"),
            makeStepText(
                2,
                "Puntos notables detectados",
                buildString {
                    if (y0.isFinite()) append("Corte con eje Y: (0, ${ExprFormatter.formatNumber(y0)}). ")
                    if (roots.isNotEmpty()) append("Raíces reales: ${roots.take(6).joinToString(", ") { ExprFormatter.formatNumber(it) }}.")
                    else append("Sin raíces reales en [-20, 20].")
                },
                "f($v) = ${ExprFormatter.toPlain(expr)}",
                "f($v) = ${ExprFormatter.toLatex(expr)}",
                "Análisis"
            )
        )
        val scene = buildPlotForFunction(expr, v, pts)
        return MathSolution(true, raw, norm, ProblemType.FUNCTION_PLOT, steps, "f($v) = ${ExprFormatter.toPlain(expr)}", ExprFormatter.toLatex(expr), scene)
    }

    // ---------- Helpers ----------
    private fun buildPlotForFunction(expr: Expr, variable: String, points: List<PlotPointSpec> = emptyList()): PlotSceneSpec {
        val js = toJsExpression(expr, variable)
        var xMin = -8.0; var xMax = 8.0; var yMin = -8.0; var yMax = 8.0
        if (points.isNotEmpty()) {
            val xs = points.map { it.x }
            val ys = points.map { it.y }
            val cx = (xs.min() + xs.max()) / 2.0
            val cy = (ys.min() + ys.max()) / 2.0
            val spanX = maxOf(10.0, (xs.max() - xs.min()) * 1.8 + 4.0)
            val spanY = maxOf(10.0, (ys.max() - ys.min()) * 1.8 + 4.0)
            xMin = cx - spanX / 2.0; xMax = cx + spanX / 2.0
            yMin = cy - spanY / 2.0; yMax = cy + spanY / 2.0
        }
        return PlotSceneSpec(
            functions = listOf(PlotFunctionSpec(js, "f($variable) = ${ExprFormatter.toPlain(expr)}", PLOT_PALETTE[0])),
            points = points,
            xMin = xMin, xMax = xMax, yMin = yMin, yMax = yMax
        )
    }

    /** Traduce un AST a una expresión segura de JavaScript (Math.*) para JSXGraph 1.14.3. */
    fun toJsExpression(expr: Expr, variable: String = "x"): String = when (expr) {
        is Expr.Num -> expr.text
        is Expr.Var -> if (expr.name == variable) "x" else "0"
        is Expr.Const -> when (expr.name) {
            "pi" -> "Math.PI"
            "e" -> "Math.E"
            else -> "NaN"
        }
        is Expr.Unary -> "(${expr.op}(${toJsExpression(expr.operand, variable)}))"
        is Expr.Binary -> {
            val l = toJsExpression(expr.left, variable)
            val r = toJsExpression(expr.right, variable)
            when (expr.op) {
                "^" -> "Math.pow($l, $r)"
                "=" -> "(($l) - ($r))"
                else -> "($l ${expr.op} $r)"
            }
        }
        is Expr.Call -> {
            val args = expr.args.joinToString(", ") { toJsExpression(it, variable) }
            when (expr.name) {
                "ln", "log" -> if (expr.args.size == 1) "Math.log($args)" else "(Math.log(${toJsExpression(expr.args[1], variable)})/Math.log(${toJsExpression(expr.args[0], variable)}))"
                "log10" -> "Math.log10($args)"
                "sqrt" -> "Math.sqrt($args)"
                "abs" -> "Math.abs($args)"
                "sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh", "exp", "floor", "round", "min", "max" -> "Math.${expr.name}($args)"
                "ceiling" -> "Math.ceil($args)"
                "cot" -> "(1/Math.tan($args))"
                "sec" -> "(1/Math.cos($args))"
                "csc" -> "(1/Math.sin($args))"
                else -> "NaN"
            }
        }
    }

    private fun containsImaginary(expr: Expr): Boolean = when (expr) {
        is Expr.Const -> expr.name == "i"
        is Expr.Unary -> containsImaginary(expr.operand)
        is Expr.Binary -> containsImaginary(expr.left) || containsImaginary(expr.right)
        is Expr.Call -> expr.args.any(::containsImaginary)
        else -> false
    }

    private fun makeStep(index: Int, title: String, explanation: String, expr: Expr, tag: String): MathStep {
        val plain = ExprFormatter.toPlain(expr)
        val latex = ExprFormatter.toLatex(expr)
        return MathStep(
            index = index,
            title = title,
            explanation = explanation,
            expression = plain,
            latex = latex,
            ruleTag = tag,
            elements = InteractiveInspector.inspectLine(plain, index, explanation)
        )
    }

    private fun makeStepText(index: Int, title: String, explanation: String, plain: String, latex: String, tag: String): MathStep =
        MathStep(
            index = index,
            title = title,
            explanation = explanation,
            expression = plain,
            latex = latex,
            ruleTag = tag,
            elements = InteractiveInspector.inspectLine(plain, index, explanation)
        )

    private fun errorSolution(raw: String, msg: String): MathSolution = MathSolution(
        ok = false,
        originalInput = raw,
        normalizedInput = raw,
        problemType = ProblemType.EXPRESSION,
        steps = emptyList(),
        finalAnswer = "",
        finalLatex = "",
        error = msg
    )
}
