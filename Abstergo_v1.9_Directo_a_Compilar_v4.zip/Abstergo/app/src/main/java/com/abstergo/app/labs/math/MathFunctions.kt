package com.abstergo.app.labs.math

import org.apache.commons.math3.util.CombinatoricsUtils
import org.apache.commons.math3.util.FastMath
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sign

/**
 * Tabla única de funciones matemáticas compartida por Evaluator y CompiledExpr
 * (fusión de MaxMath MathFunctions + microMathematics Common/Trig/Log/NumberFunctions).
 */
internal object MathFunctions {

    fun unary(name: String): ((Double) -> Double)? = UNARY[name]
    fun binary(name: String): ((Double, Double) -> Double)? = BINARY[name]
    fun reducer(name: String): ((Double, Double) -> Double)? = REDUCERS[name]

    private val UNARY: Map<String, (Double) -> Double> = mapOf(
        "ln" to { x -> FastMath.log(x) },
        "log" to { x -> FastMath.log(x) },
        "log10" to { x -> FastMath.log10(x) },
        "exp" to { x -> FastMath.exp(x) },
        "sqrt" to { x -> FastMath.sqrt(x) },
        "abs" to { x -> abs(x) },
        "floor" to { x -> floor(x) },
        "ceiling" to { x -> ceil(x) },
        "round" to { x -> round(x) },
        "sign" to { x -> sign(x) },
        "factorial" to { x ->
            val n = x.toInt()
            if (x.isNaN() || x < 0.0 || x > 170.0 || x != n.toDouble()) Double.NaN
            else CombinatoricsUtils.factorialDouble(n)
        },
        "sin" to { x -> FastMath.sin(x) },
        "cos" to { x -> FastMath.cos(x) },
        "tan" to { x -> FastMath.tan(x) },
        "sinh" to { x -> FastMath.sinh(x) },
        "cosh" to { x -> FastMath.cosh(x) },
        "tanh" to { x -> FastMath.tanh(x) },
        "asin" to { x -> FastMath.asin(x) },
        "acos" to { x -> FastMath.acos(x) },
        "atan" to { x -> FastMath.atan(x) },
        "asinh" to { x -> FastMath.asinh(x) },
        "acosh" to { x -> FastMath.acosh(x) },
        "atanh" to { x -> FastMath.atanh(x) },
        "cot" to { x -> 1.0 / FastMath.tan(x) },
        "sec" to { x -> 1.0 / FastMath.cos(x) },
        "csc" to { x -> 1.0 / FastMath.sin(x) },
        "acot" to { x -> FastMath.atan(1.0 / x) },
        "asec" to { x -> FastMath.acos(1.0 / x) },
        "acsc" to { x -> FastMath.asin(1.0 / x) },
        "coth" to { x -> 1.0 / FastMath.tanh(x) },
        "sech" to { x -> 1.0 / FastMath.cosh(x) },
        "csch" to { x -> 1.0 / FastMath.sinh(x) },
        "acoth" to { x -> 0.5 * FastMath.log((x + 1.0) / (x - 1.0)) },
        "asech" to { x -> FastMath.log(1.0 / x + FastMath.sqrt(1.0 / (x * x) - 1.0)) },
        "acsch" to { x -> FastMath.log(1.0 / x + FastMath.sqrt(1.0 / (x * x) + 1.0)) }
    )

    private val BINARY: Map<String, (Double, Double) -> Double> = mapOf(
        "log" to { base, x -> FastMath.log(x) / FastMath.log(base) },
        "mod" to { a, b -> if (b == 0.0) Double.NaN else a % b },
        "nthrt" to { n, x ->
            if (n == 0.0) Double.NaN
            else if (x < 0.0 && n == floor(n) && n.toInt() % 2 != 0) -(-x).pow(1.0 / n)
            else x.pow(1.0 / n)
        }
    )

    private val REDUCERS: Map<String, (Double, Double) -> Double> = mapOf(
        "min" to { a, b -> if (a.isNaN() || b.isNaN()) Double.NaN else minOf(a, b) },
        "max" to { a, b -> if (a.isNaN() || b.isNaN()) Double.NaN else maxOf(a, b) }
    )
}

/** Evaluador directo de AST en precisión Double (incluye comparadores de microMathematics). */
object Evaluator {

    fun eval(expr: Expr, vars: Map<String, Double> = emptyMap()): Double = when (expr) {
        is Expr.Num -> expr.text.toDoubleOrNull() ?: Double.NaN
        is Expr.Var -> vars[expr.name] ?: Double.NaN
        is Expr.Const -> when (expr.name) {
            "pi" -> Math.PI
            "e" -> Math.E
            else -> Double.NaN
        }
        is Expr.Unary -> when (expr.op) {
            "-" -> -eval(expr.operand, vars)
            "+" -> eval(expr.operand, vars)
            else -> Double.NaN
        }
        is Expr.Binary -> {
            val l = eval(expr.left, vars)
            val r = eval(expr.right, vars)
            when (expr.op) {
                "+" -> l + r
                "-" -> l - r
                "*" -> l * r
                "/" -> l / r
                "%" -> if (r == 0.0) Double.NaN else l % r
                "^" -> l.pow(r)
                "<" -> if (l < r) 1.0 else 0.0
                "<=" -> if (l <= r) 1.0 else 0.0
                ">" -> if (l > r) 1.0 else 0.0
                ">=" -> if (l >= r) 1.0 else 0.0
                "==" -> if (abs(l - r) < 1e-10) 1.0 else 0.0
                "!=" -> if (abs(l - r) >= 1e-10) 1.0 else 0.0
                "=" -> l - r
                else -> Double.NaN
            }
        }
        is Expr.Call -> evalCall(expr, vars)
    }

    private fun evalCall(call: Expr.Call, vars: Map<String, Double>): Double {
        val reducer = MathFunctions.reducer(call.name)
        if (reducer != null) {
            if (call.args.isEmpty()) return Double.NaN
            var acc = eval(call.args[0], vars)
            for (i in 1 until call.args.size) acc = reducer(acc, eval(call.args[i], vars))
            return acc
        }
        if (call.args.size == 2) {
            MathFunctions.binary(call.name)?.let { fn ->
                return fn(eval(call.args[0], vars), eval(call.args[1], vars))
            }
        }
        if (call.args.size == 1) {
            MathFunctions.unary(call.name)?.let { fn ->
                return fn(eval(call.args[0], vars))
            }
        }
        return Double.NaN
    }
}

/**
 * Expresión precompilada sin asignaciones en memoria (de MaxMath CompiledExpr):
 * ideal para muestrear curvas, evaluar derivadas/integrales numéricas y correr fluido en equipos de 32 bits.
 * Sin estado mutable: segura para múltiples hilos con slots independientes.
 */
class CompiledExpr internal constructor(
    private val root: Node,
    val variables: List<String>
) {
    fun eval(slots: DoubleArray): Double = root.eval(slots)
    fun newSlots(): DoubleArray = DoubleArray(variables.size)

    fun evalSingle(x: Double): Double {
        val slots = DoubleArray(maxOf(1, variables.size))
        slots[0] = x
        return root.eval(slots)
    }

    companion object {
        private val NAN = ConstNode(Double.NaN)

        fun compile(expr: Expr, variables: List<String> = listOf("x")): CompiledExpr =
            CompiledExpr(buildNode(expr, variables), variables)

        private fun buildNode(expr: Expr, variables: List<String>): Node = when (expr) {
            is Expr.Num -> ConstNode(expr.text.toDoubleOrNull() ?: Double.NaN)
            is Expr.Var -> {
                val idx = variables.indexOf(expr.name)
                if (idx >= 0) SlotNode(idx) else NAN
            }
            is Expr.Const -> ConstNode(
                when (expr.name) {
                    "pi" -> Math.PI
                    "e" -> Math.E
                    else -> Double.NaN
                }
            )
            is Expr.Unary -> when (expr.op) {
                "-" -> {
                    val inner = buildNode(expr.operand, variables)
                    if (inner is ConstNode) ConstNode(-inner.value) else NegNode(inner)
                }
                "+" -> buildNode(expr.operand, variables)
                else -> NAN
            }
            is Expr.Binary -> buildBinary(expr.op, buildNode(expr.left, variables), buildNode(expr.right, variables))
            is Expr.Call -> buildCall(expr, variables)
        }

        private fun buildBinary(op: String, left: Node, right: Node): Node {
            if (left is ConstNode && right is ConstNode) {
                return ConstNode(applyBinary(op, left.value, right.value))
            }
            return when (op) {
                "+" -> AddNode(left, right)
                "-" -> SubNode(left, right)
                "*" -> MulNode(left, right)
                "/" -> DivNode(left, right)
                "%" -> ModNode(left, right)
                "^" -> buildPower(left, right)
                "=" -> SubNode(left, right)
                else -> CmpNode(op, left, right)
            }
        }

        private fun applyBinary(op: String, a: Double, b: Double): Double = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> a / b
            "%" -> if (b == 0.0) Double.NaN else a % b
            "^" -> a.pow(b)
            "=" -> a - b
            "<" -> if (a < b) 1.0 else 0.0
            "<=" -> if (a <= b) 1.0 else 0.0
            ">" -> if (a > b) 1.0 else 0.0
            ">=" -> if (a >= b) 1.0 else 0.0
            "==" -> if (abs(a - b) < 1e-10) 1.0 else 0.0
            "!=" -> if (abs(a - b) >= 1e-10) 1.0 else 0.0
            else -> Double.NaN
        }

        private fun buildPower(base: Node, exp: Node): Node {
            if (exp is ConstNode) {
                val e = exp.value
                if (e >= 0.0 && e <= 4.0 && e == floor(e)) {
                    return when (e.toInt()) {
                        0 -> ConstNode(1.0)
                        1 -> base
                        else -> IntPowNode(base, e.toInt())
                    }
                }
            }
            return PowNode(base, exp)
        }

        private fun buildCall(call: Expr.Call, variables: List<String>): Node {
            val reducer = MathFunctions.reducer(call.name)
            if (reducer != null) {
                if (call.args.isEmpty()) return NAN
                val args = Array(call.args.size) { buildNode(call.args[it], variables) }
                if (args.all { it is ConstNode }) {
                    var acc = (args[0] as ConstNode).value
                    for (i in 1 until args.size) acc = reducer(acc, (args[i] as ConstNode).value)
                    return ConstNode(acc)
                }
                return ReduceNode(reducer, args)
            }
            if (call.args.size == 2) {
                val fn2 = MathFunctions.binary(call.name) ?: return NAN
                val a = buildNode(call.args[0], variables)
                val b = buildNode(call.args[1], variables)
                return if (a is ConstNode && b is ConstNode) ConstNode(fn2(a.value, b.value))
                else Call2Node(fn2, a, b)
            }
            if (call.args.size == 1) {
                val fn1 = MathFunctions.unary(call.name) ?: return NAN
                val a = buildNode(call.args[0], variables)
                return if (a is ConstNode) ConstNode(fn1(a.value)) else Call1Node(fn1, a)
            }
            return NAN
        }
    }
}

internal abstract class Node {
    abstract fun eval(slots: DoubleArray): Double
}

private class ConstNode(val value: Double) : Node() {
    override fun eval(slots: DoubleArray): Double = value
}

private class SlotNode(private val index: Int) : Node() {
    override fun eval(slots: DoubleArray): Double = slots[index]
}

private class NegNode(private val operand: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = -operand.eval(slots)
}

private class AddNode(private val l: Node, private val r: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = l.eval(slots) + r.eval(slots)
}

private class SubNode(private val l: Node, private val r: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = l.eval(slots) - r.eval(slots)
}

private class MulNode(private val l: Node, private val r: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = l.eval(slots) * r.eval(slots)
}

private class DivNode(private val l: Node, private val r: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = l.eval(slots) / r.eval(slots)
}

private class ModNode(private val l: Node, private val r: Node) : Node() {
    override fun eval(slots: DoubleArray): Double {
        val b = r.eval(slots)
        return if (b == 0.0) Double.NaN else l.eval(slots) % b
    }
}

private class PowNode(private val base: Node, private val exp: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = base.eval(slots).pow(exp.eval(slots))
}

private class IntPowNode(private val base: Node, private val n: Int) : Node() {
    override fun eval(slots: DoubleArray): Double {
        val x = base.eval(slots)
        return when (n) {
            2 -> x * x
            3 -> x * x * x
            4 -> { val sq = x * x; sq * sq }
            else -> x.pow(n)
        }
    }
}

private class CmpNode(private val op: String, private val l: Node, private val r: Node) : Node() {
    override fun eval(slots: DoubleArray): Double {
        val a = l.eval(slots)
        val b = r.eval(slots)
        return when (op) {
            "<" -> if (a < b) 1.0 else 0.0
            "<=" -> if (a <= b) 1.0 else 0.0
            ">" -> if (a > b) 1.0 else 0.0
            ">=" -> if (a >= b) 1.0 else 0.0
            "==" -> if (abs(a - b) < 1e-10) 1.0 else 0.0
            "!=" -> if (abs(a - b) >= 1e-10) 1.0 else 0.0
            else -> Double.NaN
        }
    }
}

private class Call1Node(private val fn: (Double) -> Double, private val arg: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = fn(arg.eval(slots))
}

private class Call2Node(private val fn: (Double, Double) -> Double, private val a: Node, private val b: Node) : Node() {
    override fun eval(slots: DoubleArray): Double = fn(a.eval(slots), b.eval(slots))
}

private class ReduceNode(private val reducer: (Double, Double) -> Double, private val args: Array<Node>) : Node() {
    override fun eval(slots: DoubleArray): Double {
        var acc = args[0].eval(slots)
        for (i in 1 until args.size) acc = reducer(acc, args[i].eval(slots))
        return acc
    }
}
