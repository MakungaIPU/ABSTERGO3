package com.abstergo.app.labs.math

import org.apache.commons.math3.complex.Complex
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sqrt

/** Representación polinómica de grado arbitrario en una variable: coeffs[k] = coeficiente de x^k. */
data class Polynomial(val variable: String, val coeffs: DoubleArray) {
    val degree: Int
        get() {
            var d = coeffs.lastIndex
            while (d > 0 && abs(coeffs[d]) < 1e-10) d--
            return d
        }

    fun coeff(k: Int): Double = if (k in coeffs.indices) coeffs[k] else 0.0

    fun toExpr(): Expr {
        val deg = degree
        var acc: Expr? = null
        for (k in deg downTo 0) {
            val c = coeff(k)
            if (abs(c) < 1e-10) continue
            val term = buildTerm(abs(c), variable, k)
            acc = if (acc == null) {
                if (c < 0) Expr.Unary("-", term) else term
            } else {
                if (c < 0) Expr.Binary("-", acc, term) else Expr.Binary("+", acc, term)
            }
        }
        return acc ?: Expr.Num("0")
    }

    private fun buildTerm(absCoeff: Double, v: String, power: Int): Expr {
        val numStr = ExprFormatter.formatNumber(absCoeff)
        if (power == 0) return Expr.Num(numStr)
        val varPart: Expr = if (power == 1) Expr.Var(v) else Expr.Binary("^", Expr.Var(v), Expr.Num(power.toString()))
        return if (abs(absCoeff - 1.0) < 1e-10) varPart else Expr.Binary("*", Expr.Num(numStr), varPart)
    }

    operator fun plus(other: Polynomial): Polynomial {
        val size = maxOf(coeffs.size, other.coeffs.size)
        return Polynomial(variable, DoubleArray(size) { i -> coeff(i) + other.coeff(i) })
    }

    operator fun minus(other: Polynomial): Polynomial {
        val size = maxOf(coeffs.size, other.coeffs.size)
        return Polynomial(variable, DoubleArray(size) { i -> coeff(i) - other.coeff(i) })
    }

    operator fun times(other: Polynomial): Polynomial {
        val out = DoubleArray(degree + other.degree + 1)
        for (i in 0..degree) {
            for (j in 0..other.degree) {
                out[i + j] += coeff(i) * other.coeff(j)
            }
        }
        return Polynomial(variable, out)
    }

    fun scale(factor: Double): Polynomial =
        Polynomial(variable, DoubleArray(coeffs.size) { coeffs[it] * factor })

    override fun equals(other: Any?): Boolean =
        other is Polynomial && variable == other.variable && coeffs.contentEquals(other.coeffs)

    override fun hashCode(): Int = 31 * variable.hashCode() + coeffs.contentHashCode()
}

/**
 * Motor simbólico en Kotlin puro (100% offline y universal 32/64 bits):
 * simplificación algebraica, polinomios, ecuaciones lineales/cuadráticas,
 * sistemas de ecuaciones, factorización y derivación simbólica paso a paso.
 */
object SymbolicEngine {

    /** Simplifica un AST aplicando identidades algebraicas y plegado de constantes. */
    fun simplify(expr: Expr): Expr {
        var cur = expr
        repeat(6) {
            val next = simplifyOnce(cur)
            if (next == cur) return next
            cur = next
        }
        return cur
    }

    private fun simplifyOnce(expr: Expr): Expr {
        return when (expr) {
            is Expr.Num, is Expr.Var, is Expr.Const -> expr
            is Expr.Unary -> {
                val inner = simplifyOnce(expr.operand)
                when (expr.op) {
                    "+" -> inner
                    "-" -> when (inner) {
                        is Expr.Num -> {
                            val v = inner.text.toDoubleOrNull()
                            if (v != null) numExpr(-v) else Expr.Unary("-", inner)
                        }
                        is Expr.Unary -> if (inner.op == "-") inner.operand else Expr.Unary("-", inner)
                        else -> Expr.Unary("-", inner)
                    }
                    else -> Expr.Unary(expr.op, inner)
                }
            }
            is Expr.Binary -> simplifyBinary(expr.op, simplifyOnce(expr.left), simplifyOnce(expr.right))
            is Expr.Call -> {
                val args = expr.args.map(::simplifyOnce)
                val allNums = args.isNotEmpty() && args.all { it is Expr.Num }
                if (allNums && expr.name != "sqrt") {
                    val evaluated = Evaluator.eval(Expr.Call(expr.name, args))
                    if (evaluated.isFinite() && abs(evaluated - round(evaluated)) < 1e-10) {
                        return numExpr(evaluated)
                    }
                }
                if (expr.name == "sqrt" && args.size == 1 && args[0] is Expr.Num) {
                    val v = (args[0] as Expr.Num).text.toDoubleOrNull()
                    if (v != null && v >= 0.0) {
                        val r = sqrt(v)
                        if (abs(r - round(r)) < 1e-10) return numExpr(r)
                    }
                }
                Expr.Call(expr.name, args)
            }
        }
    }

    private fun simplifyBinary(op: String, l: Expr, r: Expr): Expr {
        val ln = asNumber(l)
        val rn = asNumber(r)

        if (ln != null && rn != null && op != "=") {
            val res = when (op) {
                "+" -> ln + rn
                "-" -> ln - rn
                "*" -> ln * rn
                "/" -> if (abs(rn) > 1e-12 && abs((ln / rn) - round(ln / rn)) < 1e-10) ln / rn else Double.NaN
                "^" -> if (rn >= 0 && rn <= 10 && rn == floor(rn)) ln.pow(rn) else Double.NaN
                else -> Double.NaN
            }
            if (res.isFinite()) return numExpr(res)
        }

        return when (op) {
            "+" -> when {
                ln != null && abs(ln) < 1e-12 -> r
                rn != null && abs(rn) < 1e-12 -> l
                l == r -> Expr.Binary("*", Expr.Num("2"), l)
                else -> Expr.Binary("+", l, r)
            }
            "-" -> when {
                rn != null && abs(rn) < 1e-12 -> l
                ln != null && abs(ln) < 1e-12 -> simplifyOnce(Expr.Unary("-", r))
                l == r -> Expr.Num("0")
                else -> Expr.Binary("-", l, r)
            }
            "*" -> when {
                (ln != null && abs(ln) < 1e-12) || (rn != null && abs(rn) < 1e-12) -> Expr.Num("0")
                ln != null && abs(ln - 1.0) < 1e-12 -> r
                rn != null && abs(rn - 1.0) < 1e-12 -> l
                ln != null && abs(ln + 1.0) < 1e-12 -> simplifyOnce(Expr.Unary("-", r))
                rn != null && abs(rn + 1.0) < 1e-12 -> simplifyOnce(Expr.Unary("-", l))
                // Reagrupar c1 * (c2 * x) -> (c1*c2) * x
                ln != null && r is Expr.Binary && r.op == "*" && asNumber(r.left) != null ->
                    simplifyBinary("*", numExpr(ln * asNumber(r.left)!!), r.right)
                // Mover constante a la izquierda: x * 3 -> 3 * x
                rn != null && ln == null -> Expr.Binary("*", numExpr(rn), l)
                else -> Expr.Binary("*", l, r)
            }
            "/" -> when {
                ln != null && abs(ln) < 1e-12 -> Expr.Num("0")
                rn != null && abs(rn - 1.0) < 1e-12 -> l
                l == r -> Expr.Num("1")
                else -> Expr.Binary("/", l, r)
            }
            "^" -> when {
                rn != null && abs(rn) < 1e-12 -> Expr.Num("1")
                rn != null && abs(rn - 1.0) < 1e-12 -> l
                ln != null && abs(ln) < 1e-12 -> Expr.Num("0")
                ln != null && abs(ln - 1.0) < 1e-12 -> Expr.Num("1")
                else -> Expr.Binary("^", l, r)
            }
            else -> Expr.Binary(op, l, r)
        }
    }

    /** Intenta convertir una expresión en polinomio exacto en la variable indicada. */
    fun toPolynomial(expr: Expr, variable: String): Polynomial? {
        return when (expr) {
            is Expr.Num -> {
                val v = expr.text.toDoubleOrNull() ?: return null
                Polynomial(variable, doubleArrayOf(v))
            }
            is Expr.Const -> {
                val v = when (expr.name) {
                    "pi" -> Math.PI
                    "e" -> Math.E
                    else -> return null
                }
                Polynomial(variable, doubleArrayOf(v))
            }
            is Expr.Var -> if (expr.name == variable) Polynomial(variable, doubleArrayOf(0.0, 1.0)) else null
            is Expr.Unary -> {
                val inner = toPolynomial(expr.operand, variable) ?: return null
                when (expr.op) {
                    "-" -> inner.scale(-1.0)
                    "+" -> inner
                    else -> null
                }
            }
            is Expr.Binary -> {
                val lp = toPolynomial(expr.left, variable) ?: return null
                val rp = toPolynomial(expr.right, variable) ?: return null
                when (expr.op) {
                    "+" -> lp + rp
                    "-" -> lp - rp
                    "*" -> lp * rp
                    "/" -> {
                        if (rp.degree != 0 || abs(rp.coeff(0)) < 1e-12) null
                        else lp.scale(1.0 / rp.coeff(0))
                    }
                    "^" -> {
                        if (rp.degree != 0) return null
                        val expVal = rp.coeff(0)
                        val n = expVal.toInt()
                        if (n < 0 || n > 6 || abs(expVal - n) > 1e-10) return null
                        var acc = Polynomial(variable, doubleArrayOf(1.0))
                        repeat(n) { acc *= lp }
                        acc
                    }
                    else -> null
                }
            }
            is Expr.Call -> null
        }
    }

    /** Extrae coeficientes lineales [c_0, c_1, ..., c_{n-1}] y término independiente de una expresión lineal multivariable. */
    data class LinearForm(val coeffs: DoubleArray, val constant: Double)

    fun toLinearForm(expr: Expr, variables: List<String>): LinearForm? {
        val n = variables.size
        fun combine(a: LinearForm, b: LinearForm, sign: Double): LinearForm =
            LinearForm(DoubleArray(n) { a.coeffs[it] + sign * b.coeffs[it] }, a.constant + sign * b.constant)

        return when (expr) {
            is Expr.Num -> {
                val v = expr.text.toDoubleOrNull() ?: return null
                LinearForm(DoubleArray(n), v)
            }
            is Expr.Const -> {
                val v = when (expr.name) { "pi" -> Math.PI; "e" -> Math.E; else -> return null }
                LinearForm(DoubleArray(n), v)
            }
            is Expr.Var -> {
                val idx = variables.indexOf(expr.name)
                if (idx < 0) return null
                val arr = DoubleArray(n); arr[idx] = 1.0
                LinearForm(arr, 0.0)
            }
            is Expr.Unary -> {
                val inner = toLinearForm(expr.operand, variables) ?: return null
                if (expr.op == "-") LinearForm(DoubleArray(n) { -inner.coeffs[it] }, -inner.constant) else inner
            }
            is Expr.Binary -> {
                val l = toLinearForm(expr.left, variables) ?: return null
                val r = toLinearForm(expr.right, variables) ?: return null
                when (expr.op) {
                    "+" -> combine(l, r, 1.0)
                    "-" -> combine(l, r, -1.0)
                    "*" -> {
                        val lIsConst = l.coeffs.all { abs(it) < 1e-12 }
                        val rIsConst = r.coeffs.all { abs(it) < 1e-12 }
                        when {
                            lIsConst -> LinearForm(DoubleArray(n) { r.coeffs[it] * l.constant }, r.constant * l.constant)
                            rIsConst -> LinearForm(DoubleArray(n) { l.coeffs[it] * r.constant }, l.constant * r.constant)
                            else -> null
                        }
                    }
                    "/" -> {
                        val rIsConst = r.coeffs.all { abs(it) < 1e-12 } && abs(r.constant) > 1e-12
                        if (rIsConst) LinearForm(DoubleArray(n) { l.coeffs[it] / r.constant }, l.constant / r.constant) else null
                    }
                    else -> null
                }
            }
            is Expr.Call -> null
        }
    }

    /** Derivación simbólica completa (reglas de potencia, suma, producto, cociente y cadena). */
    fun differentiate(expr: Expr, variable: String): Pair<Expr, List<String>> {
        val rulesUsed = LinkedHashSet<String>()

        fun diff(e: Expr): Expr = when (e) {
            is Expr.Num, is Expr.Const -> {
                rulesUsed.add("Derivada de una constante: d/d$variable(c) = 0")
                Expr.Num("0")
            }
            is Expr.Var -> {
                if (e.name == variable) {
                    rulesUsed.add("Derivada de la variable: d/d$variable($variable) = 1")
                    Expr.Num("1")
                } else {
                    Expr.Num("0")
                }
            }
            is Expr.Unary -> when (e.op) {
                "-" -> Expr.Unary("-", diff(e.operand))
                "+" -> diff(e.operand)
                else -> Expr.Num("0")
            }
            is Expr.Binary -> when (e.op) {
                "+", "-" -> {
                    rulesUsed.add("Regla de la suma/resta: (u ± v)' = u' ± v'")
                    Expr.Binary(e.op, diff(e.left), diff(e.right))
                }
                "*" -> {
                    val lConst = !dependsOn(e.left, variable)
                    val rConst = !dependsOn(e.right, variable)
                    when {
                        lConst -> {
                            rulesUsed.add("Factor constante: (c·u)' = c·u'")
                            Expr.Binary("*", e.left, diff(e.right))
                        }
                        rConst -> {
                            rulesUsed.add("Factor constante: (u·c)' = c·u'")
                            Expr.Binary("*", e.right, diff(e.left))
                        }
                        else -> {
                            rulesUsed.add("Regla del producto: (u·v)' = u'·v + u·v'")
                            Expr.Binary(
                                "+",
                                Expr.Binary("*", diff(e.left), e.right),
                                Expr.Binary("*", e.left, diff(e.right))
                            )
                        }
                    }
                }
                "/" -> {
                    if (!dependsOn(e.right, variable)) {
                        rulesUsed.add("División entre constante: (u/c)' = u'/c")
                        Expr.Binary("/", diff(e.left), e.right)
                    } else {
                        rulesUsed.add("Regla del cociente: (u/v)' = (u'·v - u·v') / v²")
                        val num = Expr.Binary(
                            "-",
                            Expr.Binary("*", diff(e.left), e.right),
                            Expr.Binary("*", e.left, diff(e.right))
                        )
                        val den = Expr.Binary("^", e.right, Expr.Num("2"))
                        Expr.Binary("/", num, den)
                    }
                }
                "^" -> {
                    val baseDep = dependsOn(e.left, variable)
                    val expDep = dependsOn(e.right, variable)
                    when {
                        baseDep && !expDep -> {
                            rulesUsed.add("Regla de la potencia y cadena: (uⁿ)' = n·uⁿ⁻¹·u'")
                            val newExp = simplify(Expr.Binary("-", e.right, Expr.Num("1")))
                            val powPart = Expr.Binary("*", e.right, Expr.Binary("^", e.left, newExp))
                            Expr.Binary("*", powPart, diff(e.left))
                        }
                        !baseDep && expDep -> {
                            rulesUsed.add("Derivada exponencial: (aᵘ)' = aᵘ·ln(a)·u'")
                            val lnBase = if (e.left is Expr.Const && e.left.name == "e") Expr.Num("1") else Expr.Call("ln", listOf(e.left))
                            Expr.Binary("*", Expr.Binary("*", e, lnBase), diff(e.right))
                        }
                        else -> Expr.Num("0")
                    }
                }
                else -> Expr.Num("0")
            }
            is Expr.Call -> {
                if (e.args.size != 1) Expr.Num("0")
                else {
                    val u = e.args[0]
                    val du = diff(u)
                    val outer: Expr = when (e.name) {
                        "sin" -> { rulesUsed.add("Derivada del seno: (sin u)' = cos(u)·u'"); Expr.Call("cos", listOf(u)) }
                        "cos" -> { rulesUsed.add("Derivada del coseno: (cos u)' = -sin(u)·u'"); Expr.Unary("-", Expr.Call("sin", listOf(u))) }
                        "tan" -> { rulesUsed.add("Derivada de la tangente: (tan u)' = sec²(u)·u'"); Expr.Binary("/", Expr.Num("1"), Expr.Binary("^", Expr.Call("cos", listOf(u)), Expr.Num("2"))) }
                        "ln", "log" -> { rulesUsed.add("Derivada del logaritmo natural: (ln u)' = u'/u"); Expr.Binary("/", Expr.Num("1"), u) }
                        "exp" -> { rulesUsed.add("Derivada exponencial: (eᵘ)' = eᵘ·u'"); Expr.Call("exp", listOf(u)) }
                        "sqrt" -> { rulesUsed.add("Derivada de raíz cuadrada: (√u)' = u' / (2√u)"); Expr.Binary("/", Expr.Num("1"), Expr.Binary("*", Expr.Num("2"), Expr.Call("sqrt", listOf(u)))) }
                        else -> Expr.Num("0")
                    }
                    Expr.Binary("*", outer, du)
                }
            }
        }

        val raw = diff(expr)
        val simplified = simplify(raw)
        // Si sigue siendo polinomio, colapsar términos semejantes limpiamente
        val poly = toPolynomial(simplified, variable)
        val finalExpr = poly?.toExpr() ?: simplified
        return finalExpr to rulesUsed.toList()
    }

    /** Intenta factorizar un polinomio cuadrático ax² + bx + c sobre los reales. */
    fun factorQuadratic(poly: Polynomial): String? {
        if (poly.degree != 2) return null
        val a = poly.coeff(2)
        val b = poly.coeff(1)
        val c = poly.coeff(0)
        val disc = b * b - 4.0 * a * c
        if (disc < -1e-9) return null
        val sqrtD = sqrt(maxOf(0.0, disc))
        val r1 = (-b + sqrtD) / (2.0 * a)
        val r2 = (-b - sqrtD) / (2.0 * a)
        val v = poly.variable
        fun factorTerm(root: Double): String {
            val clean = if (abs(root) < 1e-10) 0.0 else root
            return when {
                clean == 0.0 -> v
                clean > 0 -> "($v - ${ExprFormatter.formatNumber(clean)})"
                else -> "($v + ${ExprFormatter.formatNumber(-clean)})"
            }
        }
        val lead = when {
            abs(a - 1.0) < 1e-10 -> ""
            abs(a + 1.0) < 1e-10 -> "-"
            else -> ExprFormatter.formatNumber(a)
        }
        return if (abs(r1 - r2) < 1e-9) {
            val f = factorTerm(r1)
            if (f == v) "${lead}${v}^2" else "$lead$f^2"
        } else {
            "$lead${factorTerm(r1)}${factorTerm(r2)}"
        }
    }

    fun formatValueWithFraction(v: Double): String {
        val dec = ExprFormatter.formatNumber(v)
        val frac = NumericCore.toExactFraction(v)
        return if (frac != null) "${frac.first}/${frac.second} (≈ $dec)" else dec
    }

    fun dependsOn(expr: Expr, variable: String): Boolean = when (expr) {
        is Expr.Var -> expr.name == variable
        is Expr.Unary -> dependsOn(expr.operand, variable)
        is Expr.Binary -> dependsOn(expr.left, variable) || dependsOn(expr.right, variable)
        is Expr.Call -> expr.args.any { dependsOn(it, variable) }
        else -> false
    }

    private fun asNumber(expr: Expr): Double? = when (expr) {
        is Expr.Num -> expr.text.toDoubleOrNull()
        is Expr.Unary -> if (expr.op == "-") asNumber(expr.operand)?.let { -it } else asNumber(expr.operand)
        else -> null
    }

    private fun numExpr(v: Double): Expr {
        val clean = if (abs(v) < 1e-12) 0.0 else v
        return if (clean < 0) Expr.Unary("-", Expr.Num(ExprFormatter.formatNumber(-clean)))
        else Expr.Num(ExprFormatter.formatNumber(clean))
    }

    fun solveQuadraticRoots(a: Double, b: Double, c: Double): Pair<Complex, Complex> {
        val disc = b * b - 4.0 * a * c
        return if (disc >= 0.0) {
            val sd = sqrt(disc)
            Complex((-b + sd) / (2.0 * a), 0.0) to Complex((-b - sd) / (2.0 * a), 0.0)
        } else {
            val sd = sqrt(-disc)
            val re = -b / (2.0 * a)
            val im = sd / (2.0 * a)
            Complex(re, im) to Complex(re, -im)
        }
    }
}
