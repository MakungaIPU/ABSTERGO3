package com.abstergo.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Xml
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.util.zip.ZipFile

enum class Kind(val page: String) {
    PDF("pdf.html"), DOCX("docx.html"), PROSE("prose.html"), XLSX("xlsx.html"), PPTX("pptx.html"),
    EPUB("epub.html"), MD("md.html"), TEXT("text.html"), MODEL("model.html"), IMAGE_WEB("imgweb.html"),
    HTML(""), IMAGE(""), VIDEO(""), AUDIO(""), OTHER("")
}

private val BINARY_EXT = setOf("mobi", "apk", "zip", "rar", "7z", "ppt", "pps", "pot")
private val SLIDE_NAME_RE = Regex("ppt/slides/slide\\d+\\.xml")
private val DIGITS_RE = Regex("\\d+")

private val EXT_KIND: Map<String, Kind> = listOf(
    Kind.PDF to listOf("pdf"),
    Kind.DOCX to listOf("docx", "docm", "dotx"),
    Kind.PROSE to listOf("odt", "ott", "fodt", "rtf", "doc", "dot"),
    Kind.XLSX to listOf("xlsx", "xls", "xlsm", "xlsb", "xltx", "csv", "ods"),
    Kind.PPTX to listOf("pptx", "ppsx", "pptm", "potx"),
    Kind.EPUB to listOf("epub"),
    Kind.MD to listOf("md", "markdown"),
    Kind.MODEL to listOf("stl"),
    Kind.HTML to listOf("html", "htm", "xhtml"),
    Kind.IMAGE to listOf("jpg", "jpeg", "png", "webp", "bmp", "heic", "heif"),
    Kind.IMAGE_WEB to listOf("gif", "svg", "avif", "ico"),
    Kind.VIDEO to listOf("mp4", "m4v", "mov", "mkv", "webm", "3gp", "3g2", "avi", "flv"),
    Kind.AUDIO to listOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "oga", "opus", "amr")
).flatMap { (k, exts) -> exts.map { it to k } }.toMap()

private val cachedWebViewMajor: Int? by lazy { webViewMajor() }

/** Detecta el tipo mirando el contenido del archivo y, si no basta, la extensión. */
fun detectKind(f: File, ext: String): Kind {
    try {
        val head = ByteArray(2048)
        val n = f.inputStream().use { it.read(head) }.coerceAtLeast(0)
        if (n >= 4 && head[0] == 0x25.toByte() && head[1] == 0x50.toByte() && head[2] == 0x44.toByte() && head[3] == 0x46.toByte()) return Kind.PDF
        if (n >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()) {
            val z = ZipFile(f)
            try {
                if (z.getEntry("word/document.xml") != null) return Kind.DOCX
                if (z.getEntry("ppt/presentation.xml") != null) return Kind.PPTX
                if (z.getEntry("xl/workbook.xml") != null) return Kind.XLSX
            } finally { z.close() }
        }
        EXT_KIND[ext]?.let { return it }
        if (ext in BINARY_EXT) return Kind.OTHER
        for (i in 0 until n) if (head[i] == 0.toByte()) return Kind.OTHER
        val sample = String(head, 0, n, Charsets.UTF_8).lowercase()
        if (sample.contains("<!doctype html") || sample.contains("<html")) return Kind.HTML
        return Kind.TEXT
    } catch (_: Exception) {
        return Kind.OTHER
    }
}

private fun readText(f: File, limit: Int = 3 * 1024 * 1024): String = f.inputStream().use { s ->
    val b = ByteArray(minOf(f.length(), limit.toLong()).toInt())
    var n = 0
    while (n < b.size) { val r = s.read(b, n, b.size - n); if (r < 0) break; n += r }
    String(b, 0, n, Charsets.UTF_8)
}

// ---------- Utilidades de Office (.docx / .pptx): relaciones e imágenes ----------
private fun resolveRel(baseDir: String, target: String): String {
    if (target.startsWith("/")) return target.drop(1)
    val parts = ArrayList<String>(baseDir.split('/').filter { it.isNotEmpty() })
    for (p in target.split('/')) {
        when (p) {
            "", "." -> {}
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
            else -> parts.add(p)
        }
    }
    return parts.joinToString("/")
}

/** Devuelve id de relación -> ruta de la imagen dentro del zip. */
private fun readRels(z: ZipFile, relsPath: String, baseDir: String): Map<String, String> {
    val e = z.getEntry(relsPath) ?: return emptyMap()
    val p = Xml.newPullParser(); p.setInput(z.getInputStream(e), "UTF-8")
    val m = HashMap<String, String>()
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
            val type = p.getAttributeValue(null, "Type") ?: ""
            val id = p.getAttributeValue(null, "Id")
            val tg = p.getAttributeValue(null, "Target")
            if (id != null && tg != null && type.endsWith("/image") && p.getAttributeValue(null, "TargetMode") != "External") {
                m[id] = resolveRel(baseDir, tg)
            }
        }
        ev = p.next()
    }
    return m
}

fun decodeZipImage(f: File, entry: String, maxW: Int = 1080): ImageBitmap? {
    val z = ZipFile(f)
    try {
        val e = z.getEntry(entry) ?: return null
        val bytes = z.getInputStream(e).readBytes()
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= maxW) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.RGB_565 })?.asImageBitmap()
    } catch (_: Throwable) {
        return null
    } finally { z.close() }
}

// ---------- Word (.docx): texto, títulos, viñetas e imágenes ----------
data class DocPara(val text: String, val heading: Int, val image: String? = null)

fun readDocx(f: File): List<DocPara> {
    val z = ZipFile(f)
    try {
        val e = z.getEntry("word/document.xml") ?: return emptyList()
        val rels = readRels(z, "word/_rels/document.xml.rels", "word/")
        val p = Xml.newPullParser(); p.setInput(z.getInputStream(e), "UTF-8")
        val out = ArrayList<DocPara>(); val sb = StringBuilder(); val imgs = ArrayList<String>()
        var heading = 0; var bullet = false; var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && out.size < 20000) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "w:p" -> { sb.setLength(0); imgs.clear(); heading = 0; bullet = false }
                    "w:pStyle" -> {
                        val v = p.getAttributeValue(null, "w:val") ?: ""
                        if (v.startsWith("Heading") || v.startsWith("Ttulo") || v.startsWith("Title")) heading = v.filter { it.isDigit() }.toIntOrNull() ?: 1
                    }
                    "w:numPr" -> bullet = true
                    "w:t" -> inT = true
                    "w:tab" -> sb.append('\t')
                    "w:br" -> sb.append('\n')
                    "a:blip" -> rels[p.getAttributeValue(null, "r:embed") ?: ""]?.let { if (it !in imgs) imgs.add(it) }
                    "v:imagedata" -> rels[p.getAttributeValue(null, "r:id") ?: ""]?.let { if (it !in imgs) imgs.add(it) }
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inT) sb.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                if (p.name == "w:t") inT = false
                else if (p.name == "w:p") {
                    if (sb.isNotBlank()) out.add(DocPara((if (bullet) "• " else "") + sb.toString(), heading))
                    imgs.forEach { out.add(DocPara("", 0, it)) }
                    imgs.clear()
                }
            }
            ev = p.next()
        }
        return out
    } finally { z.close() }
}

// ---------- PowerPoint (.pptx): texto e imágenes de cada diapositiva ----------
data class Slide(val n: Int, val lines: List<String>, val images: List<String> = emptyList())

fun readPptx(f: File): List<Slide> {
    val z = ZipFile(f)
    try {
        val names = z.entries().asSequence().map { it.name }
            .filter { SLIDE_NAME_RE.matches(it) }
            .sortedBy { DIGITS_RE.find(it.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0 }.toList()
        return names.mapIndexed { i, name ->
            val rels = readRels(z, "ppt/slides/_rels/" + name.substringAfterLast('/') + ".rels", "ppt/slides/")
            val p = Xml.newPullParser(); p.setInput(z.getInputStream(z.getEntry(name)), "UTF-8")
            val lines = ArrayList<String>(); val imgs = ArrayList<String>(); val sb = StringBuilder(); var inT = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    if (p.name == "a:p") sb.setLength(0)
                    else if (p.name == "a:t") inT = true
                    else if (p.name == "a:br") sb.append(' ')
                    else if (p.name == "a:blip") rels[p.getAttributeValue(null, "r:embed") ?: ""]?.let { if (it !in imgs && imgs.size < 10) imgs.add(it) }
                } else if (ev == XmlPullParser.TEXT) {
                    if (inT) sb.append(p.text)
                } else if (ev == XmlPullParser.END_TAG) {
                    if (p.name == "a:t") inT = false else if (p.name == "a:p" && sb.isNotBlank()) lines.add(sb.toString())
                }
                ev = p.next()
            }
            Slide(i + 1, lines, imgs.toList())
        }
    } finally { z.close() }
}

// ---------- Pantalla del visor ----------
@Composable
fun ViewerScreen(item: LibItem, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = remember(item.id) { libFile(ctx, item) }
    val kind by produceState<Kind?>(null, item.id) { value = withContext(Dispatchers.IO) { detectKind(file, item.ext) } }
    val web = remember { arrayOfNulls<WebView>(1) }
    var fullscreen by remember { mutableStateOf(false) }
    val activity = ctx as? Activity

    // Pantalla completa inmersiva (idea de HTMLOpen): oculta las barras y permite girar el teléfono
    DisposableEffect(fullscreen) {
        if (activity != null && fullscreen) {
            val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
        onDispose {
            if (activity != null) {
                WindowCompat.getInsetsController(activity.window, activity.window.decorView).show(WindowInsetsCompat.Type.systemBars())
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }
    }
    BackHandler {
        val w = web[0]
        if (w != null && w.canGoBack()) w.goBack()
        else if (fullscreen) fullscreen = false
        else onBack()
    }

    Column(Modifier.fillMaxSize().then(if (fullscreen) Modifier else Modifier.systemBarsPadding())) {
        if (!fullscreen) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onBack, shape = RoundedCornerShape(14.dp)) { Text("Volver") }
                Text(item.name, Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                if (kind == Kind.HTML) TextButton({ fullscreen = true }) { Text("Completa") }
                TextButton({ openLibItem(ctx, item) }) { Text("Abrir con…") }
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val k = kind
            val night = MaterialTheme.colorScheme.background.luminance() < 0.5f
            when (k) {
                null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                // PDF: pdf.js de Gander si el WebView es reciente; si no, el lector nativo con zoom
                Kind.PDF -> if ((cachedWebViewMajor ?: 200) >= 125) GanderView(file, k.page, item.name, item.ext, night, web) else PdfView(file)
                Kind.DOCX, Kind.PROSE, Kind.XLSX, Kind.PPTX, Kind.EPUB, Kind.MD, Kind.TEXT, Kind.MODEL, Kind.IMAGE_WEB ->
                    GanderView(file, k.page, item.name, item.ext, night, web)
                Kind.HTML -> HtmlView(file, item.id, web)
                Kind.IMAGE -> ImageView(file)
                Kind.VIDEO, Kind.AUDIO -> MediaView(file, k == Kind.AUDIO)
                Kind.OTHER -> Message("Este formato aún no se puede ver aquí. Usa «Abrir con…» para verlo con otra app.")
            }
            if (fullscreen) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(10.dp).size(38.dp).clip(CircleShape)
                        .background(Color(0x99000000)).clickable { fullscreen = false },
                    contentAlignment = Alignment.Center
                ) { Text("✕", color = Color.White) }
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PdfView(f: File) {
    val opened = remember(f) {
        try { val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY); Pair(PdfRenderer(pfd), pfd) } catch (_: Exception) { null }
    }
    DisposableEffect(f) { onDispose { try { opened?.first?.close(); opened?.second?.close() } catch (_: Exception) {} } }
    if (opened == null) { Message("No pude abrir este PDF (puede estar protegido)."); return }
    val r = opened.first
    var zoom by remember { mutableStateOf(1f) }
    val hScroll = rememberScrollState()
    val renderW = if (zoom > 1.4f) 1440 else 1024

    // Pellizcar con dos dedos para acercar o alejar; doble toque para alternar; un dedo desplaza
    BoxWithConstraints(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.changes.size >= 2) {
                            val z = ev.calculateZoom()
                            if (z != 1f) {
                                zoom = (zoom * z).coerceIn(1f, 4f)
                                ev.changes.forEach { it.consume() }
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 2.5f }) }
    ) {
        val vw = maxWidth
        Row(Modifier.fillMaxSize().horizontalScroll(hScroll)) {
            LazyColumn(Modifier.width(vw * zoom).fillMaxHeight(), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(r.pageCount, key = { it }) { i ->
                    val page by produceState<ImageBitmap?>(null, i, renderW) { value = withContext(Dispatchers.IO) { renderPage(r, i, renderW) } }
                    val bm = page
                    if (bm == null) {
                        Box(Modifier.fillMaxWidth().height(420.dp).background(Color.White))
                    } else {
                        Image(bm, "Página ${i + 1}", Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    }
                }
            }
        }
    }
}

private fun renderPage(r: PdfRenderer, i: Int, width: Int): ImageBitmap? = synchronized(r) {
    try {
        val p = r.openPage(i)
        try {
            val h = (width.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
            // PdfRenderer exige ARGB_8888; el ancho acotado protege la RAM en equipos de 32 bits
            val bm = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            Canvas(bm).drawColor(android.graphics.Color.WHITE)
            p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bm.asImageBitmap()
        } finally { p.close() }
    } catch (_: Throwable) { null }
}

@Composable
private fun ZipImage(f: File, entry: String) {
    val bm by produceState<ImageBitmap?>(null, entry) { value = withContext(Dispatchers.IO) { decodeZipImage(f, entry) } }
    val b = bm
    if (b != null) Image(b, null, Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.FillWidth)
}

@Composable
private fun DocxView(f: File) {
    val paras by produceState<List<DocPara>?>(null, f) {
        value = withContext(Dispatchers.IO) { try { readDocx(f) } catch (_: Exception) { emptyList() } }
    }
    val list = paras
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> Message("No pude leer este documento.")
        else -> SelectionContainer {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(list, key = { idx, _ -> idx }) { _, p ->
                    if (p.image != null) {
                        ZipImage(f, p.image)
                    } else {
                        Text(
                            p.text, fontSize = when (p.heading) { 0 -> 16.sp; 1 -> 26.sp; 2 -> 22.sp; else -> 19.sp },
                            fontWeight = if (p.heading > 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PptxView(f: File) {
    val slides by produceState<List<Slide>?>(null, f) {
        value = withContext(Dispatchers.IO) { try { readPptx(f) } catch (_: Exception) { emptyList() } }
    }
    val list = slides
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> Message("No pude leer las diapositivas.")
        else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.n }) { s ->
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Diapositiva ${s.n}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    s.lines.forEachIndexed { i, l -> Text(l, fontSize = if (i == 0) 20.sp else 15.sp, fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal) }
                    s.images.forEach { ZipImage(f, it) }
                    if (s.lines.isEmpty() && s.images.isEmpty()) Text("(vacía)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/**
 * Visor HTML dentro de Abstergo. Basado en los ajustes de WebView de HTMLOpen (Gilzone, MIT):
 * JavaScript, almacenamiento web, audio automático y zoom. A propósito NO se activa el acceso a
 * archivos locales, para que un HTML no pueda leer los datos privados de la app.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun HtmlView(f: File, id: String, holder: Array<WebView?>) {
    val html by produceState<String?>(null, f) { value = withContext(Dispatchers.IO) { try { readText(f, 20 * 1024 * 1024) } catch (_: Exception) { "" } } }
    val content = html
    if (content == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    webChromeClient = WebChromeClient()
                    webViewClient = WebViewClient()
                    setBackgroundColor(android.graphics.Color.WHITE)
                    holder[0] = this
                    // Cada archivo tiene su propio "origen", así su almacenamiento web no se mezcla con otros
                    loadDataWithBaseURL("https://h" + id.replace("-", "") + ".abstergo.invalid/", content, "text/html", "UTF-8", null)
                }
            },
            onRelease = { it.destroy(); holder[0] = null }
        )
    }
}

@Composable
private fun TextFileView(f: File, mono: Boolean) {
    val text by produceState<String?>(null, f) { value = withContext(Dispatchers.IO) { try { readText(f) } catch (_: Exception) { "" } } }
    val t = text
    if (t == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        val lines = remember(t) { t.split('\n') }
        SelectionContainer {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                itemsIndexed(lines, key = { idx, _ -> idx }) { _, l ->
                    Text(l.ifEmpty { " " }, fontSize = 14.sp, fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)
                }
            }
        }
    }
}

// ---------- Imágenes, video y audio ----------
private fun decodeImage(f: File): ImageBitmap? = uprightBitmap(f, 2048)?.asImageBitmap()

@Composable
private fun ImageView(f: File) {
    val bm by produceState<ImageBitmap?>(null, f) { value = withContext(Dispatchers.IO) { try { decodeImage(f) } catch (_: Throwable) { null } } }
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val b = bm
    if (b == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        Image(
            b, null,
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 6f)
                        offset = if (scale > 1f) offset + pan else Offset.Zero
                    }
                }
                .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y },
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun MediaView(f: File, audio: Boolean) {
    val ctx = LocalContext.current
    val exo = remember(f) {
        ExoPlayer.Builder(ctx).setAudioAttributes(AudioAttributes.DEFAULT, true).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(f)))
            prepare()
            playWhenReady = true
        }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(exo, owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) exo.pause() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs); exo.release() }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            PlayerView(c).apply {
                player = exo
                useController = true
                if (audio) controllerShowTimeoutMs = 0
            }
        }
    )
}
