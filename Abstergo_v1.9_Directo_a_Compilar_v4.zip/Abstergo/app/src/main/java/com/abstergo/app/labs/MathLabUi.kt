@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.abstergo.app.labs

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abstergo.app.LineSymbol
import com.abstergo.app.RedDot
import com.abstergo.app.labs.math.InteractiveElement
import com.abstergo.app.labs.math.MathBoardView
import com.abstergo.app.labs.math.MathElementKind
import com.abstergo.app.labs.math.MathLabEngine
import com.abstergo.app.labs.math.MathSolution
import com.abstergo.app.labs.math.MathSolveMode
import com.abstergo.app.labs.math.MathStep
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Pestaña principal de Labs (evolución del antiguo módulo Entrenar).
 * Muestra la galería de Laboratorios por asignatura estilo APK y abre Matemática Labs.
 */
@Composable
fun LabsTab(
    labExercises: List<LabExercise>,
    authorName: String,
    openSubject: String?,
    onOpenSubject: (String?) -> Unit,
    onChangeExercises: (List<LabExercise>) -> Unit,
    onImportAbsLabClick: () -> Unit,
    onOpenOcrScanner: (onRecognized: (String) -> Unit) -> Unit
) {
    if (openSubject == "m") {
        MathLabWorkspace(
            allExercises = labExercises,
            authorName = authorName,
            onBack = { onOpenSubject(null) },
            onChangeExercises = onChangeExercises,
            onImportAbsLabClick = onImportAbsLabClick,
            onOpenOcrScanner = onOpenOcrScanner
        )
    } else {
        LabsGalleryScreen(
            labExercises = labExercises,
            onSelectLab = { key -> onOpenSubject(key) },
            onImportAbsLabClick = onImportAbsLabClick
        )
    }
}

// ==============================================================================
// Galería de Labs por asignatura (estilo catálogo de módulos/APKs)
// ==============================================================================
@Composable
private fun LabsGalleryScreen(
    labExercises: List<LabExercise>,
    onSelectLab: (String) -> Unit,
    onImportAbsLabClick: () -> Unit
) {
    val ctx = LocalContext.current
    val bySubject = remember(labExercises) { labExercises.groupBy { it.subject } }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Labs", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton(onImportAbsLabClick, shape = RoundedCornerShape(14.dp)) {
                Text("Importar .abslab")
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Laboratorios interactivos offline por asignatura",
            Modifier.padding(horizontal = 20.dp),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(LAB_CATALOG, key = { it.key }) { lab ->
                val list = bySubject[lab.key].orEmpty()
                val done = list.count { it.done }
                val hasNew = list.any { it.isNew }
                Row(
                    Modifier.fillMaxWidth()
                        .alpha(if (lab.active) 1f else 0.62f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable {
                            if (lab.active) onSelectLab(lab.key)
                            else Toast.makeText(ctx, "${lab.title} llega en una próxima versión.", Toast.LENGTH_SHORT).show()
                        }
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (lab.active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        LineSymbol(
                            lab.symbol, 1f,
                            if (lab.active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            Modifier.size(32.dp), 4.5f
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(lab.title, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = false))
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier.clip(RoundedCornerShape(50))
                                    .background(if (lab.active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    if (lab.active) "ACTIVO" else "PRONTO",
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                    color = if (lab.active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (hasNew) {
                                Spacer(Modifier.width(8.dp))
                                RedDot()
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(lab.subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
                        if (lab.active && list.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text("${list.size} ejercicios · $done completados", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { done.toFloat() / list.size.coerceAtLeast(1) },
                                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// Espacio de trabajo de Matemática Labs (Lista + Consola + Reproductor Play)
// ==============================================================================
@Composable
private fun MathLabWorkspace(
    allExercises: List<LabExercise>,
    authorName: String,
    onBack: () -> Unit,
    onChangeExercises: (List<LabExercise>) -> Unit,
    onImportAbsLabClick: () -> Unit,
    onOpenOcrScanner: (onRecognized: (String) -> Unit) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val mathList = remember(allExercises) { allExercises.filter { it.subject == "m" } }

    var activeExercise by remember { mutableStateOf<LabExercise?>(null) }
    var quickInput by remember { mutableStateOf("") }
    var quickMode by remember { mutableStateOf(MathSolveMode.AUTO) }
    var addingDialog by remember { mutableStateOf(false) }

    // Exportar ejercicios de Matemática Labs en formato propietario .abslab
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val toExport = if (mathList.isEmpty()) MATH_LAB_SAMPLES else mathList
                    val json = AbsLabCodec.encode("Matemática Labs", "m", authorName, toExport)
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (_: Exception) { false }
            }
            Toast.makeText(
                ctx,
                if (ok) "Paquete .abslab exportado correctamente." else "No se pudo exportar el archivo .abslab.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    BackHandler {
        if (activeExercise != null) activeExercise = null else onBack()
    }

    // Si hay un ejercicio abierto, mostrar el Reproductor Interactivo (Play + Inspector + JSXGraph)
    val openEx = activeExercise
    if (openEx != null) {
        val synced = mathList.firstOrNull { it.id == openEx.id } ?: openEx
        MathLabPlayerScreen(
            exercise = synced,
            isSaved = mathList.any { it.id == synced.id },
            onBack = { activeExercise = null },
            onToggleDone = {
                if (mathList.any { it.id == synced.id }) {
                    onChangeExercises(allExercises.map { if (it.id == synced.id) it.copy(done = !it.done, isNew = false) else it })
                }
            },
            onSaveExercise = { exToSave ->
                val exists = allExercises.any { it.id == exToSave.id }
                val updated = if (exists) allExercises.map { if (it.id == exToSave.id) exToSave else it } else allExercises + exToSave
                onChangeExercises(updated)
                activeExercise = exToSave
                Toast.makeText(ctx, "Guardado en Matemática Labs", Toast.LENGTH_SHORT).show()
            },
            onDelete = {
                onChangeExercises(allExercises.filterNot { it.id == synced.id })
                activeExercise = null
            }
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        // Cabecera
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "‹  Matemática Labs",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f).clickable { onBack() }
            )
            OutlinedButton({ addingDialog = true }, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) {
                Text("+ Nuevo", fontSize = 13.sp)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Tarjeta 1: Consola rápida de resolución + OCR Nivel 2
            item(key = "__quick_solver__") {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Resolver o explorar paso a paso", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = quickInput,
                        onValueChange = { quickInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Ej: x^2 - 5x + 6 = 0  o  x+y=5; 2x-y=1") },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        trailingIcon = {
                            if (quickInput.isNotEmpty()) {
                                Text("✕", Modifier.clickable { quickInput = "" }.padding(10.dp))
                            }
                        }
                    )
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MathSolveMode.entries.forEach { m ->
                            FilterChip(
                                selected = quickMode == m,
                                onClick = { quickMode = m },
                                label = { Text(m.label, fontSize = 12.sp) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val expr = quickInput.trim()
                                if (expr.isEmpty()) {
                                    Toast.makeText(ctx, "Escribe una expresión o escanea una foto.", Toast.LENGTH_SHORT).show()
                                } else {
                                    activeExercise = LabExercise(
                                        id = UUID.randomUUID().toString(),
                                        subject = "m",
                                        title = expr.take(60),
                                        prompt = "Ejercicio interactivo en Matemática Labs",
                                        expression = expr,
                                        mode = quickMode.name,
                                        source = "quick"
                                    )
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("▶  Play paso a paso", fontWeight = FontWeight.Bold) }

                        OutlinedButton(
                            onClick = {
                                onOpenOcrScanner { recognized ->
                                    quickInput = recognized
                                    activeExercise = LabExercise(
                                        id = UUID.randomUUID().toString(),
                                        subject = "m",
                                        title = "Escaneado: ${recognized.take(40)}",
                                        prompt = "Fórmula capturada con OCR Nivel 2 Offline",
                                        expression = recognized,
                                        mode = MathSolveMode.AUTO.name,
                                        source = "ocr"
                                    )
                                }
                            },
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Foto OCR") }
                    }
                }
            }

            // Barra de acciones rápidas (.abslab + ejemplos)
            item(key = "__abslab_actions__") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onImportAbsLabClick, Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Importar .abslab", fontSize = 13.sp)
                    }
                    OutlinedButton(
                        { exportLauncher.launch("matematica_labs.abslab") },
                        Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Exportar .abslab", fontSize = 13.sp)
                    }
                }
            }

            // Mis ejercicios guardados / recibidos
            item(key = "__header_saved__") {
                Text(
                    if (mathList.isEmpty()) "Ejercicios de práctica incluidos" else "Mis ejercicios (${mathList.size})",
                    fontSize = 16.sp, fontWeight = FontWeight.Bold
                )
            }

            if (mathList.isEmpty()) {
                items(MATH_LAB_SAMPLES, key = { it.id }) { sample ->
                    LabExerciseCard(sample, onOpen = { activeExercise = sample }, onToggleDone = null)
                }
            } else {
                items(mathList, key = { it.id }) { ex ->
                    LabExerciseCard(
                        exercise = ex,
                        onOpen = {
                            if (ex.isNew) {
                                onChangeExercises(allExercises.map { if (it.id == ex.id) it.copy(isNew = false) else it })
                            }
                            activeExercise = ex.copy(isNew = false)
                        },
                        onToggleDone = {
                            onChangeExercises(allExercises.map { if (it.id == ex.id) it.copy(done = !it.done, isNew = false) else it })
                        }
                    )
                }
                item(key = "__header_samples__") {
                    Spacer(Modifier.height(6.dp))
                    Text("Ejemplos rápidos del laboratorio", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(MATH_LAB_SAMPLES, key = { it.id }) { sample ->
                    LabExerciseCard(sample, onOpen = { activeExercise = sample }, onToggleDone = null)
                }
            }
        }
    }

    if (addingDialog) {
        NewMathLabDialog(
            onDismiss = { addingDialog = false },
            onCreate = { title, prompt, expression, mode ->
                val created = LabExercise(
                    id = UUID.randomUUID().toString(),
                    subject = "m",
                    title = title,
                    prompt = prompt,
                    expression = expression,
                    mode = mode.name,
                    source = "local"
                )
                onChangeExercises(allExercises + created)
                addingDialog = false
                activeExercise = created
            }
        )
    }
}

@Composable
private fun LabExerciseCard(
    exercise: LabExercise,
    onOpen: () -> Unit,
    onToggleDone: (() -> Unit)?
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable { onOpen() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onToggleDone != null) {
            Box(
                Modifier.size(30.dp).clip(CircleShape)
                    .background(if (exercise.done) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable { onToggleDone() },
                contentAlignment = Alignment.Center
            ) {
                if (exercise.done) Text("✓", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(
                exercise.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textDecoration = if (exercise.done) TextDecoration.LineThrough else null,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (exercise.expression.isNotBlank()) {
                Text(
                    exercise.expression,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (exercise.prompt.isNotBlank()) {
                Text(
                    exercise.prompt,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (exercise.isNew) {
            Spacer(Modifier.width(8.dp))
            RedDot()
        }
    }
}

// ==============================================================================
// Reproductor Interactivo: Play paso a paso + Inspector táctil + JSXGraph 2D
// ==============================================================================
@Composable
private fun MathLabPlayerScreen(
    exercise: LabExercise,
    isSaved: Boolean,
    onBack: () -> Unit,
    onToggleDone: () -> Unit,
    onSaveExercise: (LabExercise) -> Unit,
    onDelete: () -> Unit
) {
    var exprInput by remember(exercise.id) { mutableStateOf(exercise.expression) }
    var mode by remember(exercise.id) {
        mutableStateOf(
            MathSolveMode.entries.firstOrNull { it.name == exercise.mode } ?: MathSolveMode.AUTO
        )
    }
    var solution by remember { mutableStateOf<MathSolution?>(null) }
    var computing by remember { mutableStateOf(true) }

    // Controles del botón Play paso a paso
    var visibleStepCount by remember { mutableStateOf(1) }
    var isPlaying by remember { mutableStateOf(false) }

    // Elemento tocado por el estudiante (dígito, signo, variable, línea o punto JSXGraph)
    var inspectedTitle by remember { mutableStateOf<String?>(null) }
    var inspectedText by remember { mutableStateOf<String?>(null) }
    var inspectedKind by remember { mutableStateOf<String?>(null) }
    var showHints by remember { mutableStateOf(false) }
    var showGraph by remember { mutableStateOf(true) }
    var askDelete by remember { mutableStateOf(false) }

    // Resolver en Dispatchers.Default para no bloquear jamás el hilo UI
    LaunchedEffect(exprInput, mode) {
        computing = true
        isPlaying = false
        val sol = withContext(Dispatchers.Default) {
            MathLabEngine.solve(exprInput, mode)
        }
        solution = sol
        visibleStepCount = if (sol.steps.isNotEmpty()) 1 else 0
        computing = false
    }

    // Reproducción automática del botón Play
    LaunchedEffect(isPlaying, solution) {
        val total = solution?.steps?.size ?: 0
        if (!isPlaying || total == 0) return@LaunchedEffect
        if (visibleStepCount >= total) visibleStepCount = 1
        while (isPlaying && visibleStepCount < total) {
            delay(1300)
            visibleStepCount++
        }
        isPlaying = false
    }

    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    Column(Modifier.fillMaxSize()) {
        // Barra superior del reproductor
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onBack, shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                Text("Volver", fontSize = 13.sp)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                exercise.title,
                modifier = Modifier.weight(1f),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!isSaved) {
                TextButton({
                    onSaveExercise(exercise.copy(expression = exprInput, mode = mode.name))
                }) { Text("Guardar") }
            } else {
                TextButton(onToggleDone) {
                    Text(if (exercise.done) "✓ Hecho" else "Marcar hecho")
                }
            }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Enunciado y entrada editable
            if (exercise.prompt.isNotBlank()) {
                Text(exercise.prompt, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedTextField(
                value = exprInput,
                onValueChange = { exprInput = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Expresión / Ecuación") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MathSolveMode.entries.forEach { m ->
                    FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label, fontSize = 12.sp) })
                }
            }

            if (exercise.hints.isNotEmpty()) {
                OutlinedButton({ showHints = !showHints }, shape = RoundedCornerShape(12.dp)) {
                    Text(if (showHints) "Ocultar pistas" else "Ver pistas (${exercise.hints.size})", fontSize = 13.sp)
                }
                AnimatedVisibility(showHints) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.secondaryContainer).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        exercise.hints.forEachIndexed { idx, h ->
                            Text("${idx + 1}. $h", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
            }

            // Estado de cálculo / solución
            val sol = solution
            if (computing || sol == null) {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (!sol.ok) {
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.errorContainer).padding(14.dp)
                ) {
                    Text(sol.error ?: "No se pudo resolver.", color = MaterialTheme.colorScheme.onErrorContainer)
                }
            } else {
                // Tarjeta de controles PLAY paso a paso
                val totalSteps = sol.steps.size
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(sol.problemType.label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Text("Paso $visibleStepCount de $totalSteps", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        TextButton({
                            isPlaying = false
                            visibleStepCount = if (visibleStepCount < totalSteps) totalSteps else 1
                        }) {
                            Text(if (visibleStepCount < totalSteps) "Ver todo" else "Reiniciar", fontSize = 12.sp)
                        }
                    }
                    LinearProgressIndicator(
                        progress = { if (totalSteps == 0) 0f else visibleStepCount.toFloat() / totalSteps },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp))
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            enabled = visibleStepCount > 1,
                            onClick = { isPlaying = false; visibleStepCount = (visibleStepCount - 1).coerceAtLeast(1) },
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("◀") }
                        Button(
                            onClick = { isPlaying = !isPlaying },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(if (isPlaying) "⏸  Pausar" else "▶  Play paso a paso", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            enabled = visibleStepCount < totalSteps,
                            onClick = { isPlaying = false; visibleStepCount = (visibleStepCount + 1).coerceAtMost(totalSteps) },
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("▶") }
                    }
                }

                // Tarjeta del inspector interactivo (aparece al tocar cualquier símbolo, dígito o línea)
                AnimatedVisibility(inspectedTitle != null) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                inspectedKind?.let {
                                    Text(it, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                }
                                Text(inspectedTitle.orEmpty(), fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            }
                            Text("✕", Modifier.clickable { inspectedTitle = null }.padding(6.dp), color = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                        Text(inspectedText.orEmpty(), fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer, lineHeight = 19.sp)
                    }
                }

                Text(
                    "Toca cualquier número, signo, variable o línea para inspeccionar qué hace:",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Pasos visibles hasta visibleStepCount
                sol.steps.take(visibleStepCount).forEach { step ->
                    MathStepCard(
                        step = step,
                        isCurrent = step.index == visibleStepCount,
                        onInspectStep = {
                            inspectedKind = "Línea · Paso ${step.index} (${step.ruleTag})"
                            inspectedTitle = step.title
                            inspectedText = step.explanation
                        },
                        onInspectElement = { el ->
                            inspectedKind = el.kind.label
                            inspectedTitle = el.title
                            inspectedText = el.explanation
                        }
                    )
                }

                // Tarjeta de Resultado Final (se muestra cuando Play llega al último paso)
                if (visibleStepCount >= totalSteps && sol.finalAnswer.isNotBlank()) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                            .background(MaterialTheme.colorScheme.primary).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Resultado final", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f))
                        Text(sol.finalAnswer, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    }
                }

                // Gráfica interactiva 2D con JSXGraph 1.14.3 offline
                val scene = sol.plotScene
                if (scene != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Plano interactivo 2D (JSXGraph)", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton({ showGraph = !showGraph }) { Text(if (showGraph) "Ocultar" else "Mostrar") }
                    }
                    if (showGraph) {
                        Box(
                            Modifier.fillMaxWidth().height(300.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                        ) {
                            MathBoardView(
                                scene = scene,
                                dark = dark,
                                onInspect = { title, detail ->
                                    inspectedKind = "Plano cartesiano 2D (JSXGraph)"
                                    inspectedTitle = title
                                    inspectedText = detail
                                }
                            )
                        }
                    }
                }

                if (isSaved) {
                    Spacer(Modifier.height(4.dp))
                    OutlinedButton(
                        onClick = { askDelete = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("Eliminar ejercicio") }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            containerColor = MaterialTheme.colorScheme.surface,
            text = { Text("¿Eliminar este ejercicio de Matemática Labs?") },
            confirmButton = { TextButton({ askDelete = false; onDelete() }) { Text("Eliminar") } },
            dismissButton = { TextButton({ askDelete = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun MathStepCard(
    step: MathStep,
    isCurrent: Boolean,
    onInspectStep: () -> Unit,
    onInspectElement: (InteractiveElement) -> Unit
) {
    val borderColor = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    Column(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(if (isCurrent) 2.dp else 1.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable { onInspectStep() }
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text("${step.index}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(8.dp))
            Text(step.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(
                Modifier.clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(step.ruleTag, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Fichas táctiles por cada símbolo, dígito, variable u operador de la línea
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            step.elements.forEach { el ->
                val chipBg = when (el.kind) {
                    MathElementKind.VARIABLE -> MaterialTheme.colorScheme.primaryContainer
                    MathElementKind.EQUALS -> MaterialTheme.colorScheme.secondaryContainer
                    MathElementKind.FUNCTION -> MaterialTheme.colorScheme.tertiaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                val chipFg = when (el.kind) {
                    MathElementKind.VARIABLE -> MaterialTheme.colorScheme.onPrimaryContainer
                    MathElementKind.EQUALS -> MaterialTheme.colorScheme.onSecondaryContainer
                    MathElementKind.FUNCTION -> MaterialTheme.colorScheme.onTertiaryContainer
                    else -> MaterialTheme.colorScheme.onSurface
                }
                Box(
                    Modifier.clip(RoundedCornerShape(8.dp))
                        .background(chipBg)
                        .clickable { onInspectElement(el) }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(el.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = chipFg)
                }
            }
        }

        Text(step.explanation, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 19.sp)
    }
}

@Composable
private fun NewMathLabDialog(
    onDismiss: () -> Unit,
    onCreate: (title: String, prompt: String, expression: String, mode: MathSolveMode) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var expr by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(MathSolveMode.AUTO) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("Nuevo ejercicio · Matemática Labs") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Título") }, singleLine = true)
                OutlinedTextField(expr, { expr = it }, Modifier.fillMaxWidth(), label = { Text("Fórmula o ecuación") }, placeholder = { Text("Ej: 2x^2 - 8 = 0") }, singleLine = true)
                OutlinedTextField(prompt, { prompt = it }, Modifier.fillMaxWidth(), label = { Text("Enunciado (opcional)") }, minLines = 2)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MathSolveMode.entries.forEach { m ->
                        FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label, fontSize = 11.sp) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                val e = expr.trim()
                val t = title.trim().ifEmpty { e.take(60) }
                if (t.isNotBlank() || e.isNotBlank()) {
                    onCreate(t.ifBlank { "Ejercicio" }, prompt.trim(), e.ifBlank { t }, mode)
                }
            }) { Text("Crear") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancelar") } }
    )
}
