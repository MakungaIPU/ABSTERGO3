package com.abstergo.app.labs.math

/**
 * Normaliza entradas humanas o salidas LaTeX provenientes del OCR Nivel 2
 * hacia la sintaxis natural del parser (fracciones, raíces, potencias, símbolos Unicode).
 */
object LatexToMath {

    private val SPACE_RE = Regex("\\s+")
    private val FRAC_SIMPLE_RE = Regex("\\\\(?:d|t)?frac\\s*\\{([^{}]+)\\}\\s*\\{([^{}]+)\\}")
    private val SQRT_N_RE = Regex("\\\\sqrt\\s*\\[([^\\]]+)\\]\\s*\\{([^{}]+)\\}")
    private val SQRT_RE = Regex("\\\\sqrt\\s*\\{([^{}]+)\\}")
    private val SUP_BRACE_RE = Regex("\\^\\s*\\{([^{}]+)\\}")
    private val FUNC_LATEX_RE = Regex("\\\\(sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|sinh|cosh|tanh|ln|log|exp|abs|min|max)\\b")
    private val LEFT_RIGHT_RE = Regex("\\\\(?:left|right)\\s*")
    private val TEXT_CMD_RE = Regex("\\\\(?:text|mathrm|operatorname)\\s*\\{([^{}]+)\\}")

    fun normalize(raw: String): String {
        var s = raw.trim()
        if (s.isEmpty()) return s

        // Quitar delimitadores LaTeX comunes ($...$, $$...$$, \(...\), \[...\])
        s = s.replace("$$", "").replace("$", "")
            .replace("\\(", "(").replace("\\)", ")")
            .replace("\\[", "").replace("\\]", "")

        // Símbolos tipográficos y Unicode frecuentes en fotos/teclado
        s = s.replace('−', '-')
            .replace('–', '-')
            .replace('—', '-')
            .replace('×', '*')
            .replace('·', '*')
            .replace('÷', '/')
            .replace("≤", "<=")
            .replace("≥", ">=")
            .replace("≠", "!=")
            .replace("²", "^2")
            .replace("³", "^3")
            .replace("⁴", "^4")
            .replace("⁵", "^5")
            .replace("⁰", "^0")
            .replace("¹", "^1")
            .replace("\\cdot", "*")
            .replace("\\times", "*")
            .replace("\\div", "/")
            .replace("\\pm", "+")
            .replace("\\pi", "pi")
            .replace("\\le", "<=")
            .replace("\\leq", "<=")
            .replace("\\ge", ">=")
            .replace("\\geq", ">=")
            .replace("\\ne", "!=")
            .replace("\\neq", "!=")
            .replace(LEFT_RIGHT_RE, "")

        // Desenrollar comandos anidados de adentro hacia afuera (hasta 6 niveles)
        repeat(6) {
            val before = s
            s = TEXT_CMD_RE.replace(s) { it.groupValues[1] }
            s = FRAC_SIMPLE_RE.replace(s) { "(${it.groupValues[1]})/(${it.groupValues[2]})" }
            s = SQRT_N_RE.replace(s) { "((${it.groupValues[2]})^(1/(${it.groupValues[1]})))" }
            s = SQRT_RE.replace(s) { "sqrt(${it.groupValues[1]})" }
            s = SUP_BRACE_RE.replace(s) { "^(${it.groupValues[1]})" }
            if (s == before) return@repeat
        }

        s = FUNC_LATEX_RE.replace(s) { m ->
            when (val fn = m.groupValues[1]) {
                "arcsin" -> "asin"
                "arccos" -> "acos"
                "arctan" -> "atan"
                else -> fn
            }
        }

        // Llaves residuales usadas como agrupación en LaTeX
        s = s.replace('{', '(').replace('}', ')')
        // Quitar barra inversa suelta si quedó alguna
        s = s.replace("\\", "")
        // Espacios sobrantes
        return s.replace(SPACE_RE, " ").trim()
    }
}

/**
 * Analizador léxico adaptado del motor MaxMath:
 * soporta decimales, identificadores, operadores aritméticos/relacionales, √, π y sistemas con ';'.
 */
class MathLexer(private val input: String) {

    private var pos = 0

    fun tokenize(): List<MathToken> {
        val tokens = ArrayList<MathToken>(input.length / 2 + 4)
        while (pos < input.length) {
            val c = input[pos]
            when {
                c.isWhitespace() -> pos++
                c.isDigit() || c == '.' -> tokens.add(readNumber())
                c.isLetter() || c == '_' || c == 'π' -> tokens.add(readIdent())
                c == '√' -> {
                    tokens.add(MathToken(TokenType.SQRT, "√", pos))
                    pos++
                }
                c == '<' || c == '>' || c == '!' || c == '=' -> {
                    val start = pos
                    val two = if (pos + 1 < input.length) input.substring(pos, pos + 2) else ""
                    if (two == "<=" || two == ">=" || two == "!=" || two == "==") {
                        tokens.add(MathToken(TokenType.OP, two, start))
                        pos += 2
                    } else if (c == '!') {
                        tokens.add(MathToken(TokenType.OP, "!", start))
                        pos++
                    } else {
                        tokens.add(MathToken(TokenType.OP, c.toString(), start))
                        pos++
                    }
                }
                c == '+' || c == '-' || c == '*' || c == '/' || c == '^' ||
                    c == ';' || c == ',' || c == '%' -> {
                    tokens.add(MathToken(TokenType.OP, c.toString(), pos))
                    pos++
                }
                c == '(' -> { tokens.add(MathToken(TokenType.LPAREN, "(", pos)); pos++ }
                c == ')' -> { tokens.add(MathToken(TokenType.RPAREN, ")", pos)); pos++ }
                c == '[' -> { tokens.add(MathToken(TokenType.LBRACKET, "[", pos)); pos++ }
                c == ']' -> { tokens.add(MathToken(TokenType.RBRACKET, "]", pos)); pos++ }
                else -> throw MathParseException("Carácter no reconocido: «$c»", pos)
            }
        }
        tokens.add(MathToken(TokenType.END, "", input.length))
        return tokens
    }

    private fun readNumber(): MathToken {
        val start = pos
        var seenDot = false
        while (pos < input.length) {
            val c = input[pos]
            if (c.isDigit()) {
                pos++
            } else if (c == '.' && !seenDot) {
                seenDot = true
                pos++
            } else {
                break
            }
        }
        val text = input.substring(start, pos)
        if (text == ".") throw MathParseException("Número decimal incompleto", start)
        return MathToken(TokenType.NUMBER, text, start)
    }

    private fun readIdent(): MathToken {
        val start = pos
        if (input[pos] == 'π') {
            pos++
            return MathToken(TokenType.IDENT, "π", start)
        }
        while (pos < input.length && (input[pos].isLetterOrDigit() || input[pos] == '_')) {
            pos++
        }
        return MathToken(TokenType.IDENT, input.substring(start, pos), start)
    }
}

/**
 * Parser Pratt (basado en MaxMath) con multiplicación implícita, asociatividad derecha en '^',
 * factorial postfijo '!', comparadores (de microMathematics) y sistemas separados por ';'.
 */
class MathParser(input: String) {

    private val tokens: List<MathToken> = MathLexer(input).tokenize()
    private var pos = 0

    fun parseExpression(): Expr {
        val expr = parseExpr(0)
        if (!atEnd()) {
            throw MathParseException("Elemento inesperado «${peek().text}»", peek().pos)
        }
        return expr
    }

    fun parseEquation(): Expr {
        val left = parseExpr(0)
        if (peek().type == TokenType.OP && peek().text == "=") {
            next()
            val right = parseExpr(0)
            return Expr.Binary("=", left, right)
        }
        return left
    }

    fun parseSystem(): ParsedSystem {
        val equations = ArrayList<Expr>()
        while (!atEnd()) {
            equations.add(parseEquation())
            if (peek().type == TokenType.OP && peek().text == ";") {
                next()
                if (atEnd()) break
                continue
            }
            if (atEnd()) break
            throw MathParseException("Separa cada ecuación con punto y coma (;), se encontró «${peek().text}»", peek().pos)
        }
        if (equations.isEmpty()) throw MathParseException("La entrada matemática está vacía", 0)
        val variables = collectVariables(equations)
        return ParsedSystem(equations, variables)
    }

    private fun parseExpr(minPrec: Int): Expr {
        var left = parsePrefix()
        while (true) {
            val t = peek()
            if (t.type == TokenType.OP && t.text == "!") {
                if (90 < minPrec) break
                next()
                left = Expr.Call("factorial", listOf(left))
            } else if (t.type == TokenType.OP) {
                val op = t.text
                val prec = infixPrecedence(op)
                if (prec < minPrec) break
                next()
                val rightMin = if (op == "^") prec else prec + 1
                val right = parseExpr(rightMin)
                left = Expr.Binary(op, left, right)
            } else if (startsPrimary(t)) {
                // Multiplicación implícita: 2x, 2(x+1), (x+1)(x-1), x sin(x)
                if (60 < minPrec) break
                val right = parseExpr(61)
                left = Expr.Binary("*", left, right)
            } else {
                break
            }
        }
        return left
    }

    private fun parsePrefix(): Expr {
        val t = peek()
        return when {
            t.type == TokenType.OP && t.text == "-" -> {
                next()
                Expr.Unary("-", parseExpr(70))
            }
            t.type == TokenType.OP && t.text == "+" -> {
                next()
                parseExpr(70)
            }
            t.type == TokenType.NUMBER -> {
                next()
                Expr.Num(t.text)
            }
            t.type == TokenType.SQRT -> {
                next()
                Expr.Call("sqrt", listOf(parseExpr(80)))
            }
            t.type == TokenType.LPAREN -> {
                next()
                val inner = parseExpr(0)
                expect(TokenType.RPAREN, ")")
                inner
            }
            t.type == TokenType.LBRACKET -> {
                next()
                val inner = parseExpr(0)
                expect(TokenType.RBRACKET, "]")
                inner
            }
            t.type == TokenType.IDENT -> {
                next()
                parseIdent(t)
            }
            else -> throw MathParseException("Se esperaba una expresión, pero apareció «${t.text}»", t.pos)
        }
    }

    private fun parseIdent(t: MathToken): Expr {
        val lower = t.text.lowercase()
        if (t.text == "π" || lower == "pi") return Expr.Const("pi")
        if (lower == "e") return Expr.Const("e")
        if (lower == "i") return Expr.Const("i")
        if (peek().type == TokenType.LPAREN && isFunctionName(lower)) {
            next()
            val args = ArrayList<Expr>()
            if (peek().type != TokenType.RPAREN) {
                args.add(parseExpr(0))
                while (peek().type == TokenType.OP && peek().text == ",") {
                    next()
                    args.add(parseExpr(0))
                }
            }
            expect(TokenType.RPAREN, ")")
            val canonical = when (lower) {
                "ceil" -> "ceiling"
                "fact" -> "factorial"
                "sen" -> "sin"
                "tg" -> "tan"
                "ctg" -> "cot"
                else -> lower
            }
            return Expr.Call(canonical, args)
        }
        return Expr.Var(t.text)
    }

    private fun startsPrimary(t: MathToken): Boolean = when (t.type) {
        TokenType.NUMBER, TokenType.IDENT, TokenType.LPAREN, TokenType.SQRT -> true
        else -> false
    }

    private fun infixPrecedence(op: String): Int = when (op) {
        "=" -> 10
        "<", "<=", ">", ">=", "!=", "==" -> 20
        "+", "-" -> 50
        "*", "/", "%" -> 60
        "^" -> 80
        else -> -1
    }

    private fun atEnd(): Boolean = peek().type == TokenType.END
    private fun peek(): MathToken = tokens[pos]
    private fun next(): MathToken = tokens[pos++]

    private fun expect(type: TokenType, expected: String) {
        val t = peek()
        if (t.type != type) {
            throw MathParseException("Falta «$expected», se encontró «${t.text}»", t.pos)
        }
        next()
    }

    companion object {
        internal val FUNCTION_NAMES = setOf(
            "sin", "sen", "cos", "tan", "tg", "cot", "ctg", "sec", "csc",
            "asin", "acos", "atan", "acot", "asec", "acsc",
            "sinh", "cosh", "tanh", "coth", "sech", "csch",
            "asinh", "acosh", "atanh", "acoth", "asech", "acsch",
            "log", "log10", "ln", "exp", "sqrt", "abs",
            "floor", "ceil", "ceiling", "round", "sign",
            "factorial", "fact", "min", "max", "mod", "nthrt"
        )

        fun isFunctionName(name: String): Boolean = name.lowercase() in FUNCTION_NAMES

        fun collectVariables(expr: Expr): List<String> = collectVariables(listOf(expr))

        fun collectVariables(equations: List<Expr>): List<String> {
            val vars = LinkedHashSet<String>()
            fun walk(e: Expr) {
                when (e) {
                    is Expr.Var -> if (!isFunctionName(e.name.lowercase())) vars.add(e.name)
                    is Expr.Unary -> walk(e.operand)
                    is Expr.Binary -> { walk(e.left); walk(e.right) }
                    is Expr.Call -> e.args.forEach(::walk)
                    else -> Unit
                }
            }
            equations.forEach(::walk)
            return vars.toList()
        }
    }
}

/** Entrada única para parsear expresiones o sistemas naturales / LaTeX. */
object MathInputParser {
    fun parseExpression(input: String): Expr {
        val clean = LatexToMath.normalize(input)
        if (clean.isBlank()) throw MathParseException("Escribe una expresión matemática", 0)
        return MathParser(clean).parseExpression()
    }

    fun parseSystem(input: String): ParsedSystem {
        val clean = LatexToMath.normalize(input)
        if (clean.isBlank()) throw MathParseException("Escribe una ecuación o sistema", 0)
        return MathParser(clean).parseSystem()
    }
}
