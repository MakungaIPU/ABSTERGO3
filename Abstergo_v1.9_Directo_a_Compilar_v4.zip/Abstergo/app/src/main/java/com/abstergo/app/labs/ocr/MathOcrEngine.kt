package com.abstergo.app.labs.ocr

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.RectF
import com.abstergo.app.labs.math.LatexToMath
import com.abstergo.app.uprightBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.nio.FloatBuffer
import java.nio.LongBuffer
import kotlin.math.min

sealed class OcrModelStatus {
    data object Ready : OcrModelStatus()
    data class MissingFiles(val missing: List<String>) : OcrModelStatus()
    data class Error(val message: String) : OcrModelStatus()
}

data class OcrResult(
    val ok: Boolean,
    val rawLatex: String = "",
    val normalizedMath: String = "",
    val elapsedMs: Long = 0L,
    val error: String? = null
)

/**
 * Decodificador ligero de tokenizer.json (formato HuggingFace / RapidLaTeXOCR / pix2tex).
 * Lee el vocabulario directo con JSONObject sin dependencias pesadas.
 */
internal class MathTokenizer(
    private val idToToken: Map<Int, String>,
    val bosId: Int,
    val eosId: Int,
    val padId: Int
) {
    fun decode(ids: List<Int>): String {
        val sb = StringBuilder(ids.size * 3)
        for (id in ids) {
            if (id == bosId || id == padId) continue
            if (id == eosId) break
            val tok = idToToken[id] ?: continue
            if (tok == "[BOS]" || tok == "[EOS]" || tok == "[PAD]" || tok == "<s>" || tok == "</s>" || tok == "<pad>") continue
            sb.append(
                tok.replace("Ġ", " ")
                    .replace("▁", " ")
                    .replace("Ċ", " ")
            )
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    companion object {
        fun fromJson(jsonText: String): MathTokenizer {
            val root = JSONObject(jsonText)
            val idToTok = HashMap<Int, String>(2048)
            val tokToId = HashMap<String, Int>(2048)

            val modelObj = root.optJSONObject("model")
            val vocabObj = modelObj?.optJSONObject("vocab") ?: root.optJSONObject("vocab")
            if (vocabObj != null) {
                val keys = vocabObj.keys()
                while (keys.hasNext()) {
                    val token = keys.next()
                    val id = vocabObj.optInt(token, -1)
                    if (id >= 0) {
                        idToTok[id] = token
                        tokToId[token] = id
                    }
                }
            }
            val added = root.optJSONArray("added_tokens")
            if (added != null) {
                for (i in 0 until added.length()) {
                    val item = added.optJSONObject(i) ?: continue
                    val id = item.optInt("id", -1)
                    val content = item.optString("content")
                    if (id >= 0 && content.isNotEmpty()) {
                        idToTok[id] = content
                        tokToId[content] = id
                    }
                }
            }

            fun findId(candidates: List<String>, fallback: Int): Int =
                candidates.firstNotNullOfOrNull { tokToId[it] } ?: fallback

            val padId = findId(listOf("[PAD]", "<pad>", "<|pad|>"), 0)
            val bosId = findId(listOf("[BOS]", "<s>", "<bos>", "<|startoftext|>"), 1)
            val eosId = findId(listOf("[EOS]", "</s>", "<eos>", "<|endoftext|>"), 2)
            return MathTokenizer(idToTok, bosId, eosId, padId)
        }
    }
}

/**
 * Motor OCR Matemático Nivel 2 Offline sobre ONNX Runtime Android (32 y 64 bits).
 * - Carga diferida (lazy): no ocupa RAM hasta que el estudiante escanea una fórmula.
 * - Carga por ruta de archivo (mmap en C++) en vez de readBytes() para proteger teléfonos de 32 bits.
 * - Soporta modelos cuantizados INT8 (<100 MB en total) en assets/labs/ocr/ o filesDir/labs/ocr/:
 *   encoder.onnx, decoder.onnx y tokenizer.json.
 */
object MathOcrEngine {

    private const val ASSET_DIR = "labs/ocr"
    private const val ENCODER_FILE = "encoder.onnx"
    private const val DECODER_FILE = "decoder.onnx"
    private const val TOKENIZER_FILE = "tokenizer.json"
    private const val MAX_TOKENS = 160

    private val REQUIRED_FILES = listOf(ENCODER_FILE, DECODER_FILE, TOKENIZER_FILE)

    private val lock = Mutex()
    private var env: OrtEnvironment? = null
    private var encoderSession: OrtSession? = null
    private var decoderSession: OrtSession? = null
    private var tokenizer: MathTokenizer? = null

    fun localModelDir(ctx: Context): File = File(ctx.filesDir, ASSET_DIR).also { it.mkdirs() }

    /** Verifica si los 3 archivos del modelo OCR están presentes en assets o en almacenamiento local. */
    fun checkStatus(ctx: Context): OcrModelStatus {
        val assetList = try {
            ctx.assets.list(ASSET_DIR)?.toSet().orEmpty()
        } catch (_: Exception) {
            emptySet()
        }
        val localDir = localModelDir(ctx)
        val missing = REQUIRED_FILES.filter { name ->
            name !in assetList && !File(localDir, name).let { it.exists() && it.length() > 0L }
        }
        return if (missing.isEmpty()) OcrModelStatus.Ready else OcrModelStatus.MissingFiles(missing)
    }

    /** Extrae un archivo de assets/labs/ocr a filesDir/labs/ocr en streaming (sin picos de RAM). */
    private fun ensureLocalFile(ctx: Context, fileName: String): File? {
        val dest = File(localModelDir(ctx), fileName)
        if (dest.exists() && dest.length() > 0L) return dest
        return try {
            ctx.assets.open("$ASSET_DIR/$fileName").use { input ->
                val tmp = File(dest.parentFile, "$fileName.tmp")
                tmp.outputStream().use { out -> input.copyTo(out, 64 * 1024) }
                if (!tmp.renameTo(dest)) {
                    tmp.copyTo(dest, overwrite = true)
                    tmp.delete()
                }
            }
            dest
        } catch (_: Exception) {
            null
        }
    }

    private fun ensureLoaded(ctx: Context): String? {
        if (encoderSession != null && decoderSession != null && tokenizer != null) return null
        val encFile = ensureLocalFile(ctx, ENCODER_FILE)
            ?: return "Falta $ENCODER_FILE en assets/labs/ocr/."
        val decFile = ensureLocalFile(ctx, DECODER_FILE)
            ?: return "Falta $DECODER_FILE en assets/labs/ocr/."
        val tokFile = ensureLocalFile(ctx, TOKENIZER_FILE)
            ?: return "Falta $TOKENIZER_FILE en assets/labs/ocr/."

        return try {
            val ortEnv = env ?: OrtEnvironment.getEnvironment().also { env = it }
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
            OrtSession.SessionOptions().use { opts ->
                opts.setIntraOpNumThreads(threads)
                opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                encoderSession = ortEnv.createSession(encFile.absolutePath, opts)
                decoderSession = ortEnv.createSession(decFile.absolutePath, opts)
            }
            tokenizer = MathTokenizer.fromJson(tokFile.readText(Charsets.UTF_8))
            null
        } catch (t: Throwable) {
            releaseInternal()
            "No se pudo inicializar el modelo OCR: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    /** Libera sesiones nativas ONNX al salir del escáner matemático para ahorrar RAM. */
    suspend fun release() {
        lock.withLock { releaseInternal() }
    }

    private fun releaseInternal() {
        try { encoderSession?.close() } catch (_: Exception) {}
        try { decoderSession?.close() } catch (_: Exception) {}
        encoderSession = null
        decoderSession = null
        tokenizer = null
    }

    /**
     * Ejecuta reconocimiento neuronal offline sobre un archivo de foto (con recorte opcional normalizado [0..1]).
     */
    suspend fun recognizeFile(
        ctx: Context,
        imageFile: File,
        normalizedCrop: RectF? = null
    ): OcrResult = withContext(Dispatchers.Default) {
        val start = System.currentTimeMillis()
        val fullBmp = uprightBitmap(imageFile, 1280)
            ?: return@withContext OcrResult(false, error = "No se pudo leer la fotografía.")
        val cropped = try {
            cropNormalized(fullBmp, normalizedCrop)
        } finally {
            if (normalizedCrop != null) fullBmp.recycle()
        }
        try {
            recognizeBitmap(ctx, cropped, start)
        } finally {
            cropped.recycle()
        }
    }

    private suspend fun recognizeBitmap(ctx: Context, source: Bitmap, startMs: Long): OcrResult {
        return lock.withLock {
        val loadErr = ensureLoaded(ctx)
        if (loadErr != null) {
            return OcrResult(false, error = loadErr)
        }
        val ortEnv = env ?: return OcrResult(false, error = "Entorno ONNX no disponible.")
        val enc = encoderSession ?: return OcrResult(false, error = "Encoder no cargado.")
        val dec = decoderSession ?: return OcrResult(false, error = "Decoder no cargado.")
        val tok = tokenizer ?: return OcrResult(false, error = "Vocabulario no cargado.")

        try {
            // Detectar dimensiones esperadas por el encoder (ej. [1, 1, 192, 672] o [1, 3, 224, 224])
            val encInputEntry = enc.inputInfo.entries.first()
            val encInputName = encInputEntry.key
            val encShape = (encInputEntry.value.info as? TensorInfo)?.shape
            val channels = (encShape?.getOrNull(1)?.toInt() ?: 3).let { if (it == 1 || it == 3) it else 3 }
            val defH = if (channels == 3) 420 else 192
            val defW = if (channels == 3) 420 else 672
            val targetH = (encShape?.getOrNull(2)?.toInt() ?: defH).let { if (it in 32..768) it else defH }
            val targetW = (encShape?.getOrNull(3)?.toInt() ?: defW).let { if (it in 32..1024) it else defW }

            val inputFloats = preprocessBitmap(source, channels, targetH, targetW)
            val inputShape = longArrayOf(1L, channels.toLong(), targetH.toLong(), targetW.toLong())

            OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(inputFloats), inputShape).use { imgTensor ->
                enc.run(mapOf(encInputName to imgTensor)).use { encOut ->
                    val hiddenTensor = encOut[0] as OnnxTensor
                    val hiddenShape = hiddenTensor.info.shape
                    val hiddenBuf = hiddenTensor.floatBuffer
                    val hiddenArr = FloatArray(hiddenBuf.remaining())
                    hiddenBuf.get(hiddenArr)

                    // Re-envolver hidden states para el bucle autoregresivo del decoder
                    OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(hiddenArr), hiddenShape).use { memTensor ->
                        val tokenIds = decodeGreedy(ortEnv, dec, memTensor, tok)
                        val rawLatex = tok.decode(tokenIds)
                        if (rawLatex.isBlank()) {
                            return OcrResult(
                                ok = false,
                                elapsedMs = System.currentTimeMillis() - startMs,
                                error = "No se detectó una fórmula clara. Acerca la cámara y mejora la luz."
                            )
                        }
                        val normalized = LatexToMath.normalize(rawLatex)
                        return OcrResult(
                            ok = true,
                            rawLatex = rawLatex,
                            normalizedMath = normalized,
                            elapsedMs = System.currentTimeMillis() - startMs
                        )
                    }
                }
            }
        } catch (t: Throwable) {
            return OcrResult(
                ok = false,
                elapsedMs = System.currentTimeMillis() - startMs,
                error = "Error al reconocer la fórmula: ${t.message ?: t.javaClass.simpleName}"
            )
        }
        }
    }

    /** Decodificación greedy paso a paso cerrando cada tensor en cada iteración (cero fugas en 32 bits). */
    private fun decodeGreedy(
        ortEnv: OrtEnvironment,
        dec: OrtSession,
        memoryTensor: OnnxTensor,
        tok: MathTokenizer
    ): List<Int> {
        val inputNames = dec.inputInfo.keys.toList()
        val idsName = inputNames.firstOrNull {
            val l = it.lowercase()
            "input" in l || "tgt" in l || "token" in l || "ids" in l
        } ?: inputNames[0]
        val memName = inputNames.firstOrNull {
            val l = it.lowercase()
            it != idsName && ("enc" in l || "mem" in l || "hidden" in l || "context" in l)
        } ?: inputNames.firstOrNull { it != idsName }
        val maskName = inputNames.firstOrNull {
            val l = it.lowercase()
            it != idsName && it != memName && "mask" in l
        }

        val generated = ArrayList<Int>(64)
        generated.add(tok.bosId)

        for (step in 0 until MAX_TOKENS) {
            val seqLen = generated.size
            val idsArray = LongArray(seqLen) { generated[it].toLong() }
            val idsShape = longArrayOf(1L, seqLen.toLong())

            OnnxTensor.createTensor(ortEnv, LongBuffer.wrap(idsArray), idsShape).use { idsTensor ->
                val maskTensor = if (maskName != null) {
                    val ones = LongArray(seqLen) { 1L }
                    OnnxTensor.createTensor(ortEnv, LongBuffer.wrap(ones), idsShape)
                } else null

                try {
                    val feeds = LinkedHashMap<String, OnnxTensor>(3)
                    feeds[idsName] = idsTensor
                    if (memName != null) feeds[memName] = memoryTensor
                    if (maskName != null && maskTensor != null) feeds[maskName] = maskTensor

                    dec.run(feeds).use { decOut ->
                        val logitsTensor = decOut[0] as OnnxTensor
                        val shape = logitsTensor.info.shape
                        val fb = logitsTensor.floatBuffer
                        val vocabSize = shape.last().toInt()
                        if (vocabSize <= 0) return generated

                        // Posicionarse en los logits del último token de la secuencia
                        val offset = fb.limit() - vocabSize
                        if (offset < 0) return generated
                        var bestId = 0
                        var bestScore = Float.NEGATIVE_INFINITY
                        for (v in 0 until vocabSize) {
                            val score = fb.get(offset + v)
                            if (score > bestScore) {
                                bestScore = score
                                bestId = v
                            }
                        }
                        if (bestId == tok.eosId) return generated
                        generated.add(bestId)
                    }
                } finally {
                    maskTensor?.close()
                }
            }
        }
        return generated
    }

    private fun cropNormalized(src: Bitmap, crop: RectF?): Bitmap {
        if (crop == null) return src
        val left = (crop.left.coerceIn(0f, 0.95f) * src.width).toInt()
        val top = (crop.top.coerceIn(0f, 0.95f) * src.height).toInt()
        val right = (crop.right.coerceIn(crop.left + 0.05f, 1f) * src.width).toInt()
        val bottom = (crop.bottom.coerceIn(crop.top + 0.05f, 1f) * src.height).toInt()
        val w = (right - left).coerceAtLeast(16)
        val h = (bottom - top).coerceAtLeast(16)
        return Bitmap.createBitmap(src, left, top, min(w, src.width - left), min(h, src.height - top))
    }

    /**
     * Preprocesa la imagen manteniendo relación de aspecto sobre fondo blanco,
     * normalizando contraste a [-1, 1] en formato NCHW.
     */
    private fun preprocessBitmap(src: Bitmap, channels: Int, targetH: Int, targetW: Int): FloatArray {
        val scale = min(targetW.toFloat() / src.width, targetH.toFloat() / src.height)
        val drawW = (src.width * scale).toInt().coerceIn(1, targetW)
        val drawH = (src.height * scale).toInt().coerceIn(1, targetH)
        val resized = Bitmap.createScaledBitmap(src, drawW, drawH, true)
        val canvasBmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(canvasBmp)
            canvas.drawColor(Color.WHITE)
            val dx = ((targetW - drawW) / 2f)
            val dy = ((targetH - drawH) / 2f)
            canvas.drawBitmap(resized, dx, dy, null)

            val pixels = IntArray(targetW * targetH)
            canvasBmp.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH)
            val planeSize = targetW * targetH
            val out = FloatArray(channels * planeSize)

            if (channels == 1) {
                for (i in 0 until planeSize) {
                    val p = pixels[i]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val gray = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                    out[i] = (gray - 0.5f) / 0.5f
                }
            } else {
                for (i in 0 until planeSize) {
                    val p = pixels[i]
                    val r = ((p shr 16) and 0xFF) / 255f
                    val g = ((p shr 8) and 0xFF) / 255f
                    val b = (p and 0xFF) / 255f
                    out[i] = (r - 0.5f) / 0.5f
                    out[planeSize + i] = (g - 0.5f) / 0.5f
                    out[2 * planeSize + i] = (b - 0.5f) / 0.5f
                }
            }
            return out
        } finally {
            if (resized !== src) resized.recycle()
            canvasBmp.recycle()
        }
    }
}
