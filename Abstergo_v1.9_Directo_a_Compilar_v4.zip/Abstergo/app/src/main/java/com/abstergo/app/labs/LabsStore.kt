package com.abstergo.app.labs

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.Immutable
import com.abstergo.app.SUBJECTS
import com.abstergo.app.labs.math.MathSolveMode
import com.abstergo.app.loadExercises
import com.abstergo.app.subjectLabel
import com.abstergo.app.writeTextAtomic
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Ejercicio interactivo de un Laboratorio de Asignatura (Matemática Labs y futuros Labs). */
@Immutable
data class LabExercise(
    val id: String,
    val subject: String,
    val title: String,
    val prompt: String,
    val expression: String,
    val mode: String = MathSolveMode.AUTO.name,
    val hints: List<String> = emptyList(),
    val done: Boolean = false,
    val isNew: Boolean = false,
    val source: String = "local",
    val createdAt: Long = System.currentTimeMillis()
)

/** Paquete exportable/importable en formato propietario .abslab */
@Immutable
data class AbsLabPack(
    val version: Int,
    val subject: String,
    val packTitle: String,
    val author: String,
    val exercises: List<LabExercise>
)

@Immutable
data class LabSubjectMeta(
    val key: String,
    val title: String,
    val subtitle: String,
    val active: Boolean,
    val symbol: Int
)

/** Galería de Laboratorios por asignatura estilo APK (Matemática activo en v1.9). */
val LAB_CATALOG = listOf(
    LabSubjectMeta(
        key = "m",
        title = "Matemática Labs",
        subtitle = "Álgebra paso a paso, Play interactivo, JSXGraph 2D y escáner OCR offline",
        active = true,
        symbol = 13
    ),
    LabSubjectMeta("f", "Física Labs", "Cinemática, vectores y simulaciones (próxima versión)", false, 2),
    LabSubjectMeta("q", "Química Labs", "Estequiometría, balanceo y tabla periódica (próxima versión)", false, 3),
    LabSubjectMeta("b", "Biología Labs", "Genética, esquemas y guías interactivas (próxima versión)", false, 7)
)

/** Ejercicios de muestra preuniversitarios para probar Matemática Labs al instante. */
val MATH_LAB_SAMPLES = listOf(
    LabExercise(
        id = "sample_quad_1",
        subject = "m",
        title = "Ecuación cuadrática con raíces reales",
        prompt = "Resuelve la ecuación paso a paso y analiza el vértice y cortes en la gráfica.",
        expression = "x^2 - 5x + 6 = 0",
        mode = MathSolveMode.SOLVE.name,
        hints = listOf("Identifica a = 1, b = -5 y c = 6.", "Calcula el discriminante Δ = b² - 4ac."),
        source = "sample"
    ),
    LabExercise(
        id = "sample_sys_1",
        subject = "m",
        title = "Sistema lineal 2×2 e intersección",
        prompt = "Halla el punto (x, y) donde se cortan ambas rectas.",
        expression = "x + y = 5; 2x - y = 1",
        mode = MathSolveMode.SOLVE.name,
        hints = listOf("Separa las ecuaciones con punto y coma (;).", "El cruce de las rectas en JSXGraph es la solución."),
        source = "sample"
    ),
    LabExercise(
        id = "sample_deriv_1",
        subject = "m",
        title = "Derivada simbólica de un polinomio",
        prompt = "Deriva la función respecto a x y compara f(x) con f'(x) en el plano.",
        expression = "x^3 - 3x^2 + 2x",
        mode = MathSolveMode.DERIVE.name,
        hints = listOf("Aplica la regla de la potencia (xⁿ)' = n·xⁿ⁻¹ a cada término."),
        source = "sample"
    ),
    LabExercise(
        id = "sample_lin_1",
        subject = "m",
        title = "Despeje lineal con paréntesis",
        prompt = "Aplica la propiedad distributiva y despeja la incógnita x.",
        expression = "2(x + 3) - 4 = 10",
        mode = MathSolveMode.SOLVE.name,
        hints = listOf("Expande 2(x + 3) primero y luego pasa los números al miembro derecho."),
        source = "sample"
    )
)

private fun labsFile(ctx: Context): File = File(ctx.filesDir, "labs.json")

/**
 * Carga todos los ejercicios de Labs; si es la primera vez tras actualizar desde v1.8,
 * migra automáticamente los ejercicios anteriores de exercises.json sin perder nada.
 */
fun loadLabExercises(ctx: Context): List<LabExercise> {
    val file = labsFile(ctx)
    if (!file.exists()) {
        val legacy = loadExercises(ctx)
        if (legacy.isNotEmpty()) {
            val migrated = legacy.map { e ->
                LabExercise(
                    id = e.id,
                    subject = e.subject,
                    title = e.title,
                    prompt = e.text,
                    expression = extractFirstMathLine(e.text).ifBlank { e.title },
                    mode = MathSolveMode.AUTO.name,
                    done = e.done,
                    isNew = e.isNew,
                    source = "migrated"
                )
            }
            saveLabExercises(ctx, migrated)
            return migrated
        }
        return emptyList()
    }
    return try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i -> parseLabExerciseJson(arr.getJSONObject(i)) }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveLabExercises(ctx: Context, list: List<LabExercise>) {
    val arr = JSONArray()
    list.forEach { e -> arr.put(toJsonObject(e)) }
    writeTextAtomic(labsFile(ctx), arr.toString())
}

internal fun parseLabExerciseJson(o: JSONObject, forceNew: Boolean = false, defaultSubject: String = "m"): LabExercise {
    val hintsArr = o.optJSONArray("hints")
    val hints = if (hintsArr != null) {
        (0 until hintsArr.length()).mapNotNull { idx -> hintsArr.optString(idx).takeIf { it.isNotBlank() } }
    } else emptyList()
    val rawSubj = o.optString("subject", defaultSubject).lowercase()
    val subj = if (rawSubj in SUBJECTS) rawSubj else defaultSubject
    val prompt = o.optString("prompt", o.optString("text", ""))
    val expr = o.optString("expression", "").ifBlank { extractFirstMathLine(prompt) }
    return LabExercise(
        id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
        subject = subj,
        title = o.optString("title", "Ejercicio").take(200).ifBlank { "Ejercicio" },
        prompt = prompt.take(5000),
        expression = expr.take(500),
        mode = o.optString("mode", MathSolveMode.AUTO.name),
        hints = hints,
        done = o.optBoolean("done", false),
        isNew = if (forceNew) true else o.optBoolean("new", false),
        source = o.optString("source", "local"),
        createdAt = o.optLong("createdAt", System.currentTimeMillis())
    )
}

internal fun toJsonObject(e: LabExercise): JSONObject {
    val hints = JSONArray()
    e.hints.forEach { hints.put(it) }
    return JSONObject()
        .put("id", e.id)
        .put("subject", e.subject)
        .put("title", e.title)
        .put("prompt", e.prompt)
        .put("expression", e.expression)
        .put("mode", e.mode)
        .put("hints", hints)
        .put("done", e.done)
        .put("new", e.isNew)
        .put("source", e.source)
        .put("createdAt", e.createdAt)
}

private fun extractFirstMathLine(text: String): String {
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    return lines.firstOrNull { line ->
        line.any { it in "=+-*/^√" } && line.any { it.isDigit() || it in "xyzt" }
    } ?: lines.firstOrNull().orEmpty()
}

// ==============================================================================
// Formato propietario .abslab (importación y exportación 100% offline)
// ==============================================================================
object AbsLabCodec {

    const val FORMAT_ID = "abstergo-lab"
    const val CURRENT_VERSION = 1

    fun isAbsLabFilename(name: String): Boolean =
        name.lowercase().endsWith(".abslab")

    fun parse(jsonText: String): AbsLabPack? {
        return try {
            val root = JSONObject(jsonText)
            if (root.optString("format") != FORMAT_ID && !root.has("exercises")) return null
            val version = root.optInt("version", 1)
            val rawSubj = root.optString("subject", "m").lowercase()
            val subject = if (rawSubj in SUBJECTS) rawSubj else "m"
            val packTitle = root.optString("title", "${subjectLabel(subject)} Labs").take(140)
            val author = root.optString("author", "Profesor").take(80)
            val arr = root.optJSONArray("exercises") ?: return null
            val items = ArrayList<LabExercise>(arr.length())
            for (i in 0 until minOf(arr.length(), 300)) {
                val eo = arr.optJSONObject(i) ?: continue
                val ex = parseLabExerciseJson(eo, forceNew = true, defaultSubject = subject).copy(source = "abslab")
                if (ex.title.isNotBlank() || ex.expression.isNotBlank()) {
                    items.add(ex)
                }
            }
            if (items.isEmpty()) null
            else AbsLabPack(version, subject, packTitle, author, items)
        } catch (_: Exception) {
            null
        }
    }

    fun encode(packTitle: String, subject: String, author: String, exercises: List<LabExercise>): String {
        val arr = JSONArray()
        exercises.forEach { arr.put(toJsonObject(it.copy(done = false, isNew = false))) }
        return JSONObject()
            .put("format", FORMAT_ID)
            .put("version", CURRENT_VERSION)
            .put("subject", subject)
            .put("title", packTitle)
            .put("author", author)
            .put("exportedAt", System.currentTimeMillis())
            .put("exercises", arr)
            .toString(2)
    }

    data class ImportResult(
        val ok: Boolean,
        val subject: String = "m",
        val packTitle: String = "",
        val addedCount: Int = 0,
        val error: String? = null
    )

    /** Lee un Uri .abslab y guarda sus ejercicios automáticamente en la asignatura Lab correspondiente. */
    fun importFromUri(ctx: Context, uri: Uri): ImportResult {
        val raw = try {
            ctx.contentResolver.openInputStream(uri)?.use { inp ->
                val bytes = inp.readBytes()
                if (bytes.size > 4 * 1024 * 1024) return ImportResult(false, error = "El archivo .abslab supera el límite de 4 MB.")
                String(bytes, Charsets.UTF_8)
            } ?: return ImportResult(false, error = "No se pudo abrir el archivo .abslab.")
        } catch (e: Exception) {
            return ImportResult(false, error = "Error leyendo el archivo: ${e.message}")
        }
        val pack = parse(raw)
            ?: return ImportResult(false, error = "El archivo no tiene un formato .abslab válido.")
        val current = loadLabExercises(ctx)
        val knownIds = current.map { it.id }.toHashSet()
        val toAdd = pack.exercises.filter { it.id !in knownIds }
        val merged = if (toAdd.isEmpty()) {
            // Si ya existían con el mismo ID, clonar con ID nuevo para permitir reimportar sin perder cambios
            val cloned = pack.exercises.map { it.copy(id = UUID.randomUUID().toString(), isNew = true) }
            saveLabExercises(ctx, current + cloned)
            cloned.size
        } else {
            saveLabExercises(ctx, current + toAdd)
            toAdd.size
        }
        return ImportResult(
            ok = true,
            subject = pack.subject,
            packTitle = pack.packTitle,
            addedCount = merged
        )
    }
}
