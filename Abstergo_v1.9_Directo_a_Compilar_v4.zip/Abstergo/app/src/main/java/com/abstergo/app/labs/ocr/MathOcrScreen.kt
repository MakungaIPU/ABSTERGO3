package com.abstergo.app.labs.ocr

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.RectF
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Escáner matemático Nivel 2 100% offline:
 * - Captura con CameraX usando marco de recorte para aislar la ecuación (pizarra o libreta).
 * - También permite importar una foto existente de la galería.
 * - Corre inferencia ONNX Runtime en Dispatchers.Default y libera sesiones al salir.
 */
@Composable
fun MathOcrScreen(
    onClose: () -> Unit,
    onFormulaRecognized: (normalizedMath: String, rawLatex: String) -> Unit
) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val modelStatus = remember { MathOcrEngine.checkStatus(ctx) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permReq = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) permReq.launch(Manifest.permission.CAMERA) }

    // Liberar las sesiones nativas ONNX al salir para proteger la RAM (especialmente en 32 bits)
    DisposableEffect(Unit) {
        onDispose {
            scope.launch { MathOcrEngine.release() }
        }
    }

    var processing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<OcrResult?>(null) }
    var editableFormula by remember { mutableStateOf("") }
    var flash by remember { mutableStateOf(ImageCapture.FLASH_MODE_OFF) }
    var zoom by remember { mutableStateOf(0f) }
    var camera by remember { mutableStateOf<Camera?>(null) }

    BackHandler {
        if (result != null) result = null else onClose()
    }

    // Marco centrado normalizado [0..1] donde el estudiante encuadra la fórmula
    val cropRect = remember { RectF(0.08f, 0.34f, 0.92f, 0.62f) }

    fun runOcrOnFile(file: File, applyCrop: Boolean) {
        processing = true
        scope.launch {
            val ocr = MathOcrEngine.recognizeFile(ctx, file, if (applyCrop) cropRect else null)
            withContext(Dispatchers.IO) { file.delete() }
            processing = false
            result = ocr
            if (ocr.ok) {
                editableFormula = ocr.normalizedMath
            }
        }
    }

    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        processing = true
        scope.launch {
            val tmp = withContext(Dispatchers.IO) {
                try {
                    val f = File(ctx.cacheDir, "ocr_pick_${System.currentTimeMillis()}.jpg")
                    ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    f
                } catch (_: Exception) { null }
            }
            if (tmp != null && tmp.exists()) {
                runOcrOnFile(tmp, applyCrop = false)
            } else {
                processing = false
                Toast.makeText(ctx, "No se pudo leer la imagen seleccionada.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (modelStatus is OcrModelStatus.MissingFiles) {
        Column(
            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("OCR Matemático Nivel 2 (Offline)", fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(
                "El motor ONNX Runtime está integrado y listo para 32/64 bits, pero faltan los archivos del modelo cuantizado en assets/labs/ocr/:",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                modelStatus.missing.forEach { file ->
                    Text("• assets/labs/ocr/$file", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(onClose, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Text("Volver a Matemática Labs")
            }
        }
        return
    }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().background(Color.Black).padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Necesito permiso de cámara para escanear fórmulas matemáticas.", color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton({
                    galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, shape = RoundedCornerShape(14.dp)) { Text("Elegir foto", color = Color.White) }
                OutlinedButton(onClose, shape = RoundedCornerShape(14.dp)) { Text("Cerrar", color = Color.White) }
            }
        }
        return
    }

    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val selector = remember {
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .build()
    }
    val capture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setResolutionSelector(selector)
            .build()
    }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().setResolutionSelector(selector).build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                p.unbindAll()
                camera = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            } catch (_: Exception) {
                Toast.makeText(ctx, "No se pudo abrir la cámara.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { provider?.unbindAll() }
    }

    LaunchedEffect(flash) { capture.flashMode = flash }
    LaunchedEffect(zoom, camera) { camera?.cameraControl?.setLinearZoom(zoom) }

    fun captureFormula() {
        if (processing) return
        processing = true
        val f = File(ctx.cacheDir, "ocr_shot_${System.currentTimeMillis()}.jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(f).build(),
            ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    runOcrOnFile(f, applyCrop = true)
                }

                override fun onError(e: ImageCaptureException) {
                    processing = false
                    Toast.makeText(ctx, "No se pudo capturar la imagen.", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { previewView })

        // Gestos de zoom y toque para enfocar
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, _, z, _ ->
                        if (z != 1f) zoom = (zoom + (z - 1f) * 0.6f).coerceIn(0f, 1f)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val c = camera ?: return@detectTapGestures
                        val pt = previewView.meteringPointFactory.createPoint(o.x, o.y)
                        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                    }
                }
        )

        // Marco guía de recorte para la ecuación
        val accent = MaterialTheme.colorScheme.primary
        Canvas(Modifier.fillMaxSize()) {
            val l = size.width * cropRect.left
            val t = size.height * cropRect.top
            val w = size.width * (cropRect.right - cropRect.left)
            val h = size.height * (cropRect.bottom - cropRect.top)
            // Sombra fuera del marco
            val dim = Color(0x88000000)
            drawRect(dim, Offset(0f, 0f), Size(size.width, t))
            drawRect(dim, Offset(0f, t + h), Size(size.width, size.height - (t + h)))
            drawRect(dim, Offset(0f, t), Size(l, h))
            drawRect(dim, Offset(l + w, t), Size(size.width - (l + w), h))
            // Borde del marco
            drawRoundRect(
                color = accent,
                topLeft = Offset(l, t),
                size = Size(w, h),
                cornerRadius = CornerRadius(24f, 24f),
                style = Stroke(width = 5f)
            )
        }

        // Barra superior
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color(0x99000000)).clickable { onClose() },
                contentAlignment = Alignment.Center
            ) { Text("✕", color = Color.White, fontSize = 18.sp) }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0x99000000)).clickable {
                    flash = when (flash) {
                        ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_ON
                        else -> ImageCapture.FLASH_MODE_OFF
                    }
                }.padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(if (flash == ImageCapture.FLASH_MODE_ON) "Flash: ON" else "Flash: OFF", color = Color.White, fontSize = 13.sp)
            }
        }

        // Indicaciones + botones inferiores
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "Encuadra la fórmula dentro del rectángulo · 100% offline",
                color = Color.White, fontSize = 13.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                OutlinedButton(
                    enabled = !processing,
                    onClick = { galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Galería", color = Color.White) }

                Box(
                    Modifier.size(74.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape).padding(6.dp)
                        .clip(CircleShape).background(if (processing) Color.Gray else Color.White)
                        .clickable(enabled = !processing) { captureFormula() }
                )

                Spacer(Modifier.width(72.dp))
            }
        }

        if (processing) {
            Box(Modifier.fillMaxSize().background(Color(0xAA000000)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Color.White)
                    Spacer(Modifier.height(12.dp))
                    Text("Reconociendo fórmula offline (ONNX)…", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // Diálogo de revisión / edición rápida del resultado OCR
    result?.let { ocr ->
        AlertDialog(
            onDismissRequest = { result = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text(if (ocr.ok) "Fórmula reconocida (${ocr.elapsedMs} ms)" else "No se pudo reconocer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (ocr.ok) {
                        Text("Puedes corregir cualquier símbolo antes de enviarla a Matemática Labs:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(
                            value = editableFormula,
                            onValueChange = { editableFormula = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Expresión") },
                            minLines = 2
                        )
                        if (ocr.rawLatex.isNotBlank() && ocr.rawLatex != editableFormula) {
                            Text("LaTeX detectado: ${ocr.rawLatex}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        Text(ocr.error ?: "Intenta nuevamente con mejor enfoque e iluminación.")
                    }
                }
            },
            confirmButton = {
                if (ocr.ok) {
                    TextButton({
                        val expr = editableFormula.trim()
                        if (expr.isNotEmpty()) {
                            result = null
                            onFormulaRecognized(expr, ocr.rawLatex)
                        }
                    }) { Text("Usar en Labs") }
                } else {
                    TextButton({ result = null }) { Text("Reintentar") }
                }
            },
            dismissButton = { TextButton({ result = null }) { Text("Cancelar") } }
        )
    }
}
