package com.abstergo.app

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

val GRADES = listOf("10mo", "11no", "12mo")

@Composable
fun GradeGroupPicker(grade: String?, group: Int?, onGrade: (String) -> Unit, onGroup: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Grado", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GRADES.forEach { g -> RoleButton(g, grade == g, Modifier.weight(1f)) { onGrade(g) } }
        }
        Text("Grupo", fontWeight = FontWeight.SemiBold)
        (1..8).chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { n -> RoleButton("$n", group == n, Modifier.weight(1f)) { onGroup(n) } }
            }
        }
    }
}

@Composable
fun SubjectPicker(subject: String?, onPick: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Asignatura que impartes", fontWeight = FontWeight.SemiBold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SUBJECTS.values.forEach { v -> FilterChip(selected = subject == v, onClick = { onPick(v) }, label = { Text(v) }) }
        }
    }
}

@Composable
private fun ErrorBox(text: String) {
    Box(Modifier.fillMaxWidth().border(2.dp, MaterialTheme.colorScheme.onBackground, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text("⚠  $text", fontWeight = FontWeight.SemiBold)
    }
}

private fun savePhoto(ctx: Context, photo: Uri?) {
    val f = File(ctx.filesDir, "profile.jpg")
    if (photo == null) return
    try { ctx.contentResolver.openInputStream(photo)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } } } catch (_: Exception) {}
}

// ---------- Crear perfil ----------
@Composable
fun ProfileScreen(onSaved: (Profile) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("abstergo", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var role by remember { mutableStateOf("student") }
    var photo by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf<String?>(null) }
    var group by remember { mutableStateOf<Int?>(null) }
    var subject by remember { mutableStateOf<String?>(null) }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { if (it != null) photo = it }
    val bitmap by produceState<ImageBitmap?>(null, photo) {
        value = photo?.let { u -> withContext(Dispatchers.IO) { loadBitmap(ctx, u) } }
    }
    val student = role == "student"

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        TopBar()
        Text("Crear perfil", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            RoleButton("Estudiante", student, Modifier.weight(1f)) { role = "student"; error = null }
            RoleButton("Profesor", !student, Modifier.weight(1f)) { role = "teacher"; error = null }
        }
        if (student) {
            Avatar(bitmap, 128, Modifier.align(Alignment.CenterHorizontally).clickable {
                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            })
            Text("Toca para elegir foto de perfil (opcional)", Modifier.align(Alignment.CenterHorizontally),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        OutlinedTextField(name, { name = it; error = null }, Modifier.fillMaxWidth(),
            label = { Text("Nombre completo") }, singleLine = true, shape = RoundedCornerShape(14.dp))
        if (student) {
            GradeGroupPicker(grade, group, { grade = it; error = null }, { group = it; error = null })
        } else {
            SubjectPicker(subject) { subject = it; error = null }
            OutlinedTextField(password, { password = it; error = null }, Modifier.fillMaxWidth(),
                label = { Text("Contraseña de profesor") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), shape = RoundedCornerShape(14.dp))
        }
        error?.let { ErrorBox(it) }
        Button(
            enabled = !saving,
            onClick = {
                error = when {
                    name.isBlank() -> "Escribe tu nombre completo."
                    student && (grade == null || group == null) -> "Elige tu grado y tu grupo."
                    !student && subject == null -> "Elige la asignatura que impartes."
                    !student -> teacherError(prefs, password)
                    else -> null
                }
                if (error == null) {
                    saving = true
                    val extra = if (student) (grade ?: "") + (group ?: 0) else (subject ?: "")
                    val trimmed = name.trim()
                    scope.launch {
                        if (student) {
                            withContext(Dispatchers.IO) {
                                if (photo == null) File(ctx.filesDir, "profile.jpg").delete() else savePhoto(ctx, photo)
                            }
                        }
                        prefs.edit().putString("role", role).putString("name", trimmed).putString("extra", extra).apply()
                        saving = false
                        onSaved(Profile(role, trimmed, extra))
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)
        ) { Text("Continuar", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

// ---------- Editar perfil ----------
@Composable
fun EditProfileScreen(profile: Profile, onSave: (Profile) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("abstergo", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val student = profile.role == "student"
    val e0 = remember(profile.extra) { norm(profile.extra).replace(" ", "") }
    var name by remember { mutableStateOf(profile.name) }
    var grade by remember { mutableStateOf<String?>(if (student) e0.take(4) else null) }
    var group by remember { mutableStateOf<Int?>(if (student) e0.drop(4).toIntOrNull() else null) }
    var subject by remember { mutableStateOf<String?>(if (!student) profile.extra else null) }
    var photo by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    val bitmap by produceState<ImageBitmap?>(null, photo) {
        value = withContext(Dispatchers.IO) {
            val u = photo
            if (u != null) loadBitmap(ctx, u)
            else File(ctx.filesDir, "profile.jpg").takeIf { it.exists() }?.let { loadBitmap(ctx, Uri.fromFile(it)) }
        }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { if (it != null) photo = it }
    BackHandler { onBack() }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Editar perfil", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton(onBack, shape = RoundedCornerShape(14.dp)) { Text("Volver") }
        }
        if (student) {
            Avatar(bitmap, 128, Modifier.align(Alignment.CenterHorizontally).clickable {
                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            })
            Text("Toca la foto para cambiarla", Modifier.align(Alignment.CenterHorizontally),
                color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        }
        OutlinedTextField(name, { name = it; error = null }, Modifier.fillMaxWidth(),
            label = { Text("Nombre completo") }, singleLine = true, shape = RoundedCornerShape(14.dp))
        if (student) GradeGroupPicker(grade, group, { grade = it; error = null }, { group = it; error = null })
        else SubjectPicker(subject) { subject = it; error = null }
        error?.let { ErrorBox(it) }
        Button(
            enabled = !saving,
            onClick = {
                error = when {
                    name.isBlank() -> "Escribe tu nombre completo."
                    student && (grade == null || group == null || grade !in GRADES) -> "Elige tu grado y tu grupo."
                    !student && subject == null -> "Elige la asignatura que impartes."
                    else -> null
                }
                if (error == null) {
                    saving = true
                    val extra = if (student) (grade ?: "") + (group ?: 0) else (subject ?: "")
                    val trimmed = name.trim()
                    scope.launch {
                        if (student && photo != null) withContext(Dispatchers.IO) { savePhoto(ctx, photo) }
                        prefs.edit().putString("name", trimmed).putString("extra", extra).apply()
                        saving = false
                        onSave(Profile(profile.role, trimmed, extra))
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)
        ) { Text("Guardar cambios", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}
