package com.abstergo.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.File

/*
 * Visores de documentos tomados de Gander (https://github.com/mokshablr/gander), licencia MIT,
 * © 2026 Arjun Maniyani. Las páginas están en assets/viewer e incluyen pdf.js, docx-preview,
 * SheetJS, PPTXjs, marked y otras (licencias en assets/viewer/licences.md). Aquí está solo el
 * pegamento: sirve la página y el archivo abierto, sin internet, con la misma política de
 * seguridad que Gander.
 */
const val ASSET_HOST = "appassets.androidplatform.net"

private const val CSP = "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; " +
    "img-src 'self' data: blob:; font-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self'; " +
    "worker-src 'self'; frame-src 'none'; object-src 'none'; form-action 'none'; base-uri 'none'"

fun mimeOf(ext: String): String = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.lowercase()) ?: "application/octet-stream"

/** Responde a todo lo que pide una página del visor: sus archivos, y el documento abierto en /doc/. */
private class DocServer(private val file: File, private val mime: String, private val assets: WebViewAssetLoader) {
    fun respond(request: WebResourceRequest): WebResourceResponse? {
        val url = request.url
        if (url.scheme == "https" && url.host == ASSET_HOST && url.path?.startsWith("/doc/") == true) {
            return try {
                WebResourceResponse(
                    mime, null, 200, "OK",
                    mapOf("X-Content-Type-Options" to "nosniff", "Content-Length" to file.length().toString()),
                    file.inputStream()
                )
            } catch (e: Exception) { notFound() }
        }
        val r = assets.shouldInterceptRequest(url)
        if (r != null) {
            val path = url.path ?: ""
            if (path.endsWith(".mjs")) r.mimeType = "text/javascript"
            if (path.endsWith(".wasm")) r.mimeType = "application/wasm"
            // La política viaja en la cabecera porque es la única forma de que llegue al worker de pdf.js
            r.responseHeaders = r.responseHeaders.orEmpty() + ("Content-Security-Policy" to CSP)
            return r
        }
        // Nada sale a internet: todo lo que no sea del visor se responde vacío
        return if (url.scheme == "http" || url.scheme == "https") notFound() else null
    }

    private fun notFound() = WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null, ByteArrayInputStream(ByteArray(0)))
}

/** Versión principal de Chromium del WebView del teléfono (pdf.js necesita 125 o más). */
fun webViewMajor(): Int? = try {
    WebView.getCurrentWebViewPackage()?.versionName?.substringBefore('.')?.toIntOrNull()
} catch (e: Exception) { null }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GanderView(file: File, page: String, name: String, ext: String, night: Boolean, holder: Array<WebView?>) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c: Context ->
            val assets = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(c)).build()
            val server = DocServer(file, mimeOf(ext), assets)
            WebView(c).apply {
                with(settings) {
                    javaScriptEnabled = true
                    domStorageEnabled = false
                    builtInZoomControls = true
                    displayZoomControls = false
                    setSupportZoom(true)
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    allowFileAccess = false
                    allowContentAccess = false
                    if (page == "pdf.html" || page == "xlsx.html") minimumFontSize = 1
                    if (page == "epub.html") { minimumFontSize = 1; minimumLogicalFontSize = 8 }
                }
                val webView = this
                CookieManager.getInstance().apply { setAcceptCookie(false); setAcceptThirdPartyCookies(webView, false) }
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = server.respond(request)

                    // Solo se navega entre las páginas del visor; ningún enlace del documento sale de aquí
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val u = request.url
                        val ok = u.scheme == "https" && u.host == ASSET_HOST && (u.path ?: "").let { it.startsWith("/assets/viewer/") && it.endsWith(".html") && ".." !in it }
                        return !ok
                    }

                    // Si Android mata el proceso del WebView, la app sigue viva (por defecto se cerraría)
                    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean = true
                }
                holder[0] = this
                loadUrl("https://$ASSET_HOST/assets/viewer/$page?name=${Uri.encode(name)}&ext=${Uri.encode(ext)}&ranged=0&night=$night")
            }
        },
        onRelease = { it.destroy(); holder[0] = null }
    )
}
