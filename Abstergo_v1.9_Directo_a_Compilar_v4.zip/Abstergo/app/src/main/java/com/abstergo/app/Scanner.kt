package com.abstergo.app

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.DecoratedBarcodeView
import com.journeyapps.barcodescanner.DefaultDecoderFactory

/** Escáner QR propio de la app, siempre en vertical (dentro de la misma pantalla, sin otra actividad). */
@Composable
fun QrScanner(onResult: (String) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) req.launch(Manifest.permission.CAMERA) }

    val owner = LocalLifecycleOwner.current
    var view by remember { mutableStateOf<DecoratedBarcodeView?>(null) }
    var done by remember { mutableStateOf(false) }

    DisposableEffect(owner, view, granted) {
        val v = view
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) v?.resume()
            if (e == Lifecycle.Event.ON_PAUSE) v?.pause()
        }
        owner.lifecycle.addObserver(obs)
        if (granted) v?.resume()
        onDispose { owner.lifecycle.removeObserver(obs); v?.pause() }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (granted) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    DecoratedBarcodeView(c).apply {
                        barcodeView.decoderFactory = DefaultDecoderFactory(listOf(BarcodeFormat.QR_CODE))
                        setStatusText("")
                        decodeSingle(BarcodeCallback { r ->
                            val t = r.text
                            if (!done && t != null) { done = true; onResult(t) }
                        })
                        view = this
                    }
                }
            )
        } else {
            Text(
                "Necesito permiso de cámara para escanear el código.", Modifier.align(Alignment.Center).padding(32.dp),
                color = Color.White, textAlign = TextAlign.Center
            )
        }
        Text(
            "Escanea el código del otro dispositivo",
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(24.dp),
            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
        )
        OutlinedButton(
            onClick = onCancel, shape = RoundedCornerShape(14.dp),
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp)
        ) { Text("Cancelar", color = Color.White) }
    }
}
