package com.abstergo.app.labs.math

import androidx.compose.runtime.Immutable

enum class TokenType {
    NUMBER,
    IDENT,
    OP,
    LPAREN,
    RPAREN,
    LBRACKET,
    RBRACKET,
    SQRT,
    END
}

data class MathToken(
    val type: TokenType,
    val text: String,
    val pos: Int
)

class MathParseException(
    val userMessage: String,
    val position: Int
) : RuntimeException("$userMessage (posición $position)")

/** Árbol de sintaxis abstracta (AST) unificado del motor matemático de Abstergo. */
@Immutable
sealed class Expr {
    data class Num(val text: String) : Expr()
    data class Var(val name: String) : Expr()
    data class Const(val name: String) : Expr()
    data class Unary(val op: String, val operand: Expr) : Expr()
    data class Binary(val op: String, val left: Expr, val right: Expr) : Expr()
    data class Call(val name: String, val args: List<Expr>) : Expr()
}

@Immutable
data class ParsedSystem(
    val equations: List<Expr>,
    val variables: List<String>
)

/** Rol semántico de cada elemento táctil dentro de una fórmula o paso. */
enum class MathElementKind(val label: String) {
    NUMBER("Número / Constante numérica"),
    VARIABLE("Variable / Incógnita"),
    CONSTANT("Constante matemática"),
    OPERATOR("Operador"),
    FUNCTION("Función matemática"),
    EXPONENT("Exponente / Potencia"),
    EQUALS("Signo de igualdad"),
    GROUP("Paréntesis / Agrupación")
}

/** Elemento individual interactivo: al tocarlo muestra su rol y explicación en el contexto del paso. */
@Immutable
data class InteractiveElement(
    val id: String,
    val text: String,
    val kind: MathElementKind,
    val title: String,
    val explanation: String
)

/** Convierte un AST en texto legible natural o LaTeX limpio. */
object ExprFormatter {

    fun toPlain(expr: Expr): String = formatPlain(expr, 0)

    private fun precedence(expr: Expr): Int = when (expr) {
        is Expr.Binary -> when (expr.op) {
            "=" -> 10
            "<", "<=", ">", ">=", "!=", "==" -> 20
            "+", "-" -> 50
            "*", "/" -> 60
            "^" -> 80
            else -> 40
        }
        is Expr.Unary -> 70
        else -> 100
    }

    private fun formatPlain(expr: Expr, parentPrec: Int): String = when (expr) {
        is Expr.Num -> formatNumberText(expr.text)
        is Expr.Var -> expr.name
        is Expr.Const -> when (expr.name) {
            "pi" -> "π"
            "e" -> "e"
            "i" -> "i"
            else -> expr.name
        }
        is Expr.Unary -> {
            val inner = formatPlain(expr.operand, 70)
            val needsParen = expr.operand is Expr.Binary && precedence(expr.operand) < 70
            val rendered = if (needsParen) "${expr.op}($inner)" else "${expr.op}$inner"
            if (parentPrec > 70) "($rendered)" else rendered
        }
        is Expr.Binary -> {
            val p = precedence(expr)
            val rendered = when (expr.op) {
                "+" -> {
                    val l = formatPlain(expr.left, p)
                    val r = formatPlain(expr.right, p)
                    if (r.startsWith("-")) "$l - ${r.drop(1)}" else "$l + $r"
                }
                "-" -> {
                    val l = formatPlain(expr.left, p)
                    val r = formatPlain(expr.right, p + 1)
                    "$l - $r"
                }
                "*" -> {
                    val l = formatPlain(expr.left, p)
                    val r = formatPlain(expr.right, p)
                    if (canUseImplicitMult(expr.left, expr.right)) "$l$r" else "$l·$r"
                }
                "/" -> {
                    val l = formatPlain(expr.left, p)
                    val r = formatPlain(expr.right, p + 1)
                    "$l/$r"
                }
                "^" -> {
                    val l = formatPlain(expr.left, p + 1)
                    val r = formatPlain(expr.right, p)
                    "$l^$r"
                }
                else -> "${formatPlain(expr.left, p)} ${expr.op} ${formatPlain(expr.right, p)}"
            }
            if (p < parentPrec) "($rendered)" else rendered
        }
        is Expr.Call -> {
            if (expr.name == "sqrt" && expr.args.size == 1) {
                val arg = expr.args[0]
                val inner = formatPlain(arg, 0)
                if (arg is Expr.Num || arg is Expr.Var || arg is Expr.Const) "√$inner" else "√($inner)"
            } else {
                "${expr.name}(${expr.args.joinToString(", ") { formatPlain(it, 0) }})"
            }
        }
    }

    private fun canUseImplicitMult(left: Expr, right: Expr): Boolean {
        val leftIsNum = left is Expr.Num || (left is Expr.Unary && left.operand is Expr.Num)
        val rightIsVarOrConst = right is Expr.Var || right is Expr.Const || right is Expr.Call ||
            (right is Expr.Binary && right.op == "^" && (right.left is Expr.Var || right.left is Expr.Const))
        return leftIsNum && rightIsVarOrConst
    }

    fun toLatex(expr: Expr): String = formatLatex(expr, 0)

    private fun formatLatex(expr: Expr, parentPrec: Int): String = when (expr) {
        is Expr.Num -> formatNumberText(expr.text)
        is Expr.Var -> expr.name
        is Expr.Const -> when (expr.name) {
            "pi" -> "\\pi"
            "e" -> "e"
            "i" -> "i"
            else -> expr.name
        }
        is Expr.Unary -> {
            val inner = formatLatex(expr.operand, 70)
            val s = if (expr.operand is Expr.Binary && precedence(expr.operand) < 70) "${expr.op}($inner)" else "${expr.op}$inner"
            if (parentPrec > 70) "($s)" else s
        }
        is Expr.Binary -> {
            val p = precedence(expr)
            val s = when (expr.op) {
                "/" -> "\\frac{${formatLatex(expr.left, 0)}}{${formatLatex(expr.right, 0)}}"
                "*" -> {
                    val l = formatLatex(expr.left, p)
                    val r = formatLatex(expr.right, p)
                    if (canUseImplicitMult(expr.left, expr.right)) "$l$r" else "$l \\cdot $r"
                }
                "^" -> {
                    val base = formatLatex(expr.left, p + 1)
                    val exp = formatLatex(expr.right, 0)
                    "$base^{$exp}"
                }
                "+" -> {
                    val l = formatLatex(expr.left, p)
                    val r = formatLatex(expr.right, p)
                    if (r.startsWith("-")) "$l - ${r.drop(1)}" else "$l + $r"
                }
                "-" -> "${formatLatex(expr.left, p)} - ${formatLatex(expr.right, p + 1)}"
                "<=" -> "${formatLatex(expr.left, p)} \\le ${formatLatex(expr.right, p)}"
                ">=" -> "${formatLatex(expr.left, p)} \\ge ${formatLatex(expr.right, p)}"
                "!=" -> "${formatLatex(expr.left, p)} \\ne ${formatLatex(expr.right, p)}"
                else -> "${formatLatex(expr.left, p)} ${expr.op} ${formatLatex(expr.right, p)}"
            }
            if (p < parentPrec && expr.op != "/") "\\left($s\\right)" else s
        }
        is Expr.Call -> when (expr.name) {
            "sqrt" -> if (expr.args.size == 1) "\\sqrt{${formatLatex(expr.args[0], 0)}}" else "\\sqrt{}"
            "abs" -> if (expr.args.size == 1) "\\left|${formatLatex(expr.args[0], 0)}\\right|" else "| |"
            "sin", "cos", "tan", "cot", "sec", "csc", "ln", "log", "exp", "sinh", "cosh", "tanh" ->
                "\\${expr.name}\\left(${expr.args.joinToString(", ") { formatLatex(it, 0) }}\\right)"
            else -> "\\operatorname{${expr.name}}\\left(${expr.args.joinToString(", ") { formatLatex(it, 0) }}\\right)"
        }
    }

    fun formatNumber(value: Double): String {
        if (value.isNaN()) return "Indefinido"
        if (value.isInfinite()) return if (value > 0) "+∞" else "-∞"
        val clean = if (kotlin.math.abs(value) < 1e-12) 0.0 else value
        val rounded = kotlin.math.round(clean)
        if (kotlin.math.abs(clean - rounded) < 1e-10 && kotlin.math.abs(rounded) < 1e14) {
            return rounded.toLong().toString()
        }
        val text = "%.6f".format(java.util.Locale.US, clean).trimEnd('0').trimEnd('.')
        return if (text == "-0") "0" else text
    }

    private fun formatNumberText(raw: String): String {
        val d = raw.toDoubleOrNull() ?: return raw
        return formatNumber(d)
    }
}

/**
 * Construye los elementos táctiles de cualquier línea matemática para que el estudiante
 * pueda tocar dígitos, signos, variables, funciones o potencias y ver su explicación exacta.
 */
object InteractiveInspector {

    fun inspectLine(expressionText: String, stepIndex: Int, contextHint: String = ""): List<InteractiveElement> {
        val tokens = try {
            MathLexer(LatexToMath.normalize(expressionText)).tokenize()
        } catch (_: Exception) {
            return listOf(
                InteractiveElement(
                    id = "s${stepIndex}_raw",
                    text = expressionText,
                    kind = MathElementKind.GROUP,
                    title = "Expresión matemática",
                    explanation = contextHint.ifBlank { "Toca los pasos anteriores o siguientes para ver la transformación." }
                )
            )
        }
        val out = ArrayList<InteractiveElement>(tokens.size)
        for (i in tokens.indices) {
            val t = tokens[i]
            if (t.type == TokenType.END) break
            val prev = if (i > 0) tokens[i - 1] else null
            val next = if (i + 1 < tokens.size) tokens[i + 1] else null
            val id = "s${stepIndex}_t$i"

            val elem = when (t.type) {
                TokenType.NUMBER -> {
                    val isExp = prev?.type == TokenType.OP && prev.text == "^"
                    val isCoeff = next?.type == TokenType.IDENT || next?.type == TokenType.LPAREN || next?.type == TokenType.SQRT
                    val isDenom = prev?.type == TokenType.OP && prev.text == "/"
                    val (kind, title, desc) = when {
                        isExp -> Triple(
                            MathElementKind.EXPONENT,
                            "Exponente ${t.text}",
                            "Indica cuántas veces se multiplica la base por sí misma. Si la base es negativa y el exponente es par, el resultado es positivo."
                        )
                        isDenom -> Triple(
                            MathElementKind.NUMBER,
                            "Denominador ${t.text}",
                            "Divide al numerador anterior en ${t.text} partes iguales. Recuerda que nunca puede ser cero."
                        )
                        isCoeff -> Triple(
                            MathElementKind.NUMBER,
                            "Coeficiente ${t.text}",
                            "Multiplica de forma implícita a «${next?.text ?: ""}». En álgebra, un número pegado a una letra o paréntesis indica multiplicación."
                        )
                        else -> Triple(
                            MathElementKind.NUMBER,
                            "Término numérico ${t.text}",
                            "Valor constante independiente en esta línea de la operación."
                        )
                    }
                    InteractiveElement(id, t.text, kind, title, desc)
                }

                TokenType.IDENT -> {
                    val lower = t.text.lowercase()
                    when {
                        lower == "pi" || t.text == "π" -> InteractiveElement(
                            id, "π", MathElementKind.CONSTANT, "Constante Pi (π)",
                            "Relación entre la circunferencia y su diámetro (≈ 3.14159265)."
                        )
                        lower == "e" -> InteractiveElement(
                            id, "e", MathElementKind.CONSTANT, "Número de Euler (e)",
                            "Base del logaritmo natural (≈ 2.71828182)."
                        )
                        lower == "i" -> InteractiveElement(
                            id, "i", MathElementKind.CONSTANT, "Unidad imaginaria (i)",
                            "Definida por i² = -1; permite representar raíces cuadradas de números negativos."
                        )
                        MathParser.isFunctionName(lower) && next?.type == TokenType.LPAREN -> InteractiveElement(
                            id, t.text, MathElementKind.FUNCTION, "Función $lower(...)",
                            functionDescription(lower)
                        )
                        else -> InteractiveElement(
                            id, t.text, MathElementKind.VARIABLE, "Variable «${t.text}»",
                            if (contextHint.isNotBlank()) "Incógnita o variable del ejercicio. $contextHint"
                            else "Representa un valor desconocido o variable que puede evaluarse o despejarse."
                        )
                    }
                }

                TokenType.SQRT -> InteractiveElement(
                    id, "√", MathElementKind.FUNCTION, "Raíz cuadrada (√)",
                    "Operación inversa de elevar al cuadrado: busca un número que multiplicado por sí mismo dé el radicando."
                )

                TokenType.OP -> {
                    val (kind, title, desc) = when (t.text) {
                        "+" -> Triple(MathElementKind.OPERATOR, "Suma (+)", "Agrega términos. Solo puedes sumar directamente términos semejantes (misma variable y mismo exponente).")
                        "-" -> Triple(MathElementKind.OPERATOR, "Resta / Signo negativo (−)", "Sustrae el término siguiente o invierte su signo. Cuidado al distribuir un signo menos frente a un paréntesis.")
                        "*" -> Triple(MathElementKind.OPERATOR, "Multiplicación (·)", "Multiplica los factores adyacentes. Tiene prioridad sobre la suma y la resta.")
                        "/" -> Triple(MathElementKind.OPERATOR, "División / Fracción (/)", "Divide el numerador entre el denominador. Tiene mayor prioridad que suma y resta.")
                        "^" -> Triple(MathElementKind.EXPONENT, "Potenciación (^)", "Eleva la base de la izquierda al exponente de la derecha. Se evalúa antes que multiplicaciones y sumas.")
                        "=" -> Triple(MathElementKind.EQUALS, "Igualdad (=)", "Indica equilibrio entre ambos miembros: lo que sumes, restes, multipliques o dividas de un lado debes hacerlo también del otro.")
                        ";" -> Triple(MathElementKind.GROUP, "Separador de ecuaciones (;)", "Separa dos ecuaciones que deben cumplirse al mismo tiempo dentro de un sistema.")
                        "," -> Triple(MathElementKind.GROUP, "Separador de argumentos (,)", "Separa los parámetros dentro de una función o intervalo.")
                        "<", "<=", ">", ">=", "!=", "==" -> Triple(MathElementKind.OPERATOR, "Comparador (${t.text})", "Compara el valor del miembro izquierdo respecto al derecho.")
                        else -> Triple(MathElementKind.OPERATOR, "Operador ${t.text}", "Conecta los términos adyacentes.")
                    }
                    val display = when (t.text) {
                        "*" -> "·"
                        "-" -> "−"
                        else -> t.text
                    }
                    InteractiveElement(id, display, kind, title, desc)
                }

                TokenType.LPAREN, TokenType.RPAREN, TokenType.LBRACKET, TokenType.RBRACKET -> InteractiveElement(
                    id, t.text, MathElementKind.GROUP, "Agrupación «${t.text}»",
                    "Delimita una subexpresión que se evalúa con prioridad antes de combinarse con el exterior."
                )

                TokenType.END -> continue
            }
            out.add(elem)
        }
        return out
    }

    private fun functionDescription(name: String): String = when (name) {
        "sin" -> "Seno trigonométrico (en radianes): razón entre cateto opuesto e hipotenusa."
        "cos" -> "Coseno trigonométrico (en radianes): razón entre cateto adyacente e hipotenusa."
        "tan" -> "Tangente trigonométrica: equivale a sin(x)/cos(x)."
        "cot" -> "Cotangente: recíproca de la tangente, cos(x)/sin(x)."
        "sec" -> "Secante: recíproca del coseno, 1/cos(x)."
        "csc" -> "Cosecante: recíproca del seno, 1/sin(x)."
        "asin", "acos", "atan" -> "Función trigonométrica inversa: devuelve el ángulo en radianes."
        "ln" -> "Logaritmo natural (base e): inverso de la función exponencial e^x."
        "log", "log10" -> "Logaritmo: exponente al que hay que elevar la base para obtener el argumento."
        "exp" -> "Función exponencial natural e^x."
        "sqrt" -> "Raíz cuadrada principal del argumento."
        "abs" -> "Valor absoluto: distancia al cero, siempre mayor o igual que 0."
        "floor" -> "Parte entera inferior: mayor entero menor o igual que el número."
        "ceil", "ceiling" -> "Techo entero: menor entero mayor o igual que el número."
        "fact", "factorial" -> "Factorial n!: producto de todos los enteros positivos desde 1 hasta n."
        "min" -> "Devuelve el valor mínimo entre sus argumentos."
        "max" -> "Devuelve el valor máximo entre sus argumentos."
        else -> "Función matemática evaluada sobre su argumento."
    }
}
