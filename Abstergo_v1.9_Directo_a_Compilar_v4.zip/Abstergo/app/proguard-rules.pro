# Abstergo R8 / ProGuard rules (Universal 32/64 bits)
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Puente JavaScript <-> Kotlin para JSXGraph y visores WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ONNX Runtime Android (JNI)
-keep class ai.onnxruntime.** { *; }
-dontwarn ai.onnxruntime.**

# Apache Commons Math3
-keep class org.apache.commons.math3.** { *; }
-dontwarn org.apache.commons.math3.**

# Modelos de Abstergo Labs
-keep class com.abstergo.app.labs.** { *; }
