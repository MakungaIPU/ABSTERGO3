import java.io.File
import java.net.HttpURLConnection
import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abstergo.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.abstergo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "1.9"
        ndk {
            // Soporte universal para teléfonos Android de 32 bits y 64 bits
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }
    signingConfigs {
        getByName("debug") {
            val ks = file("debug.keystore")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }
    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    androidResources {
        // Evita recomprimir archivos ONNX dentro del APK (mejor arranque y menos RAM)
        noCompress += listOf("onnx")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*"
            )
        }
    }
}

// ==============================================================================
// Descarga automática durante la compilación en GitHub Actions (si faltan):
// 1) JSXGraph 1.14.3 -> app/src/main/assets/labs/math/jsxgraphcore.js
// 2) Modelo OCR Matemático Nivel 2 (ONNX INT8) -> app/src/main/assets/labs/ocr/
// Si ya colocaste los archivos a mano o compilas sin internet, respeta tus archivos.
// ==============================================================================
val prepareLabsAssets by tasks.registering {
    val mathDir = file("src/main/assets/labs/math")
    val ocrDir = file("src/main/assets/labs/ocr")
    doLast {
        mathDir.mkdirs()
        ocrDir.mkdirs()

        fun downloadIfMissing(dest: File, minBytes: Long, urls: List<String>, label: String) {
            if (dest.exists() && dest.length() >= minBytes) {
                logger.lifecycle("[Abstergo Labs] OK (ya existe): ${dest.name} (${dest.length() / 1024} KB)")
                return
            }
            for (rawUrl in urls) {
                try {
                    logger.lifecycle("[Abstergo Labs] Descargando $label desde $rawUrl ...")
                    var current = URL(rawUrl)
                    var conn: HttpURLConnection? = null
                    var redirects = 0
                    while (redirects < 6) {
                        val c = (current.openConnection() as HttpURLConnection).apply {
                            instanceFollowRedirects = false
                            connectTimeout = 25000
                            readTimeout = 120000
                            setRequestProperty("User-Agent", "Abstergo-Gradle-Builder/1.9")
                        }
                        val code = c.responseCode
                        if (code in 301..308) {
                            val loc = c.getHeaderField("Location") ?: break
                            c.disconnect()
                            current = URL(current, loc)
                            redirects++
                        } else {
                            conn = c
                            break
                        }
                    }
                    val c = conn ?: continue
                    try {
                        if (c.responseCode == 200) {
                            val tmp = File(dest.parentFile, "${dest.name}.part")
                            c.inputStream.use { inp ->
                                tmp.outputStream().use { out -> inp.copyTo(out, 65536) }
                            }
                            if (tmp.length() >= minBytes) {
                                if (dest.exists()) dest.delete()
                                if (!tmp.renameTo(dest)) {
                                    tmp.copyTo(dest, overwrite = true)
                                    tmp.delete()
                                }
                                logger.lifecycle("[Abstergo Labs] Listo: ${dest.name} (${dest.length() / 1024} KB)")
                                return
                            } else {
                                tmp.delete()
                            }
                        } else {
                            logger.warn("[Abstergo Labs] HTTP ${c.responseCode} en $rawUrl")
                        }
                    } finally {
                        c.disconnect()
                    }
                } catch (e: Exception) {
                    logger.warn("[Abstergo Labs] No se pudo bajar $label desde $rawUrl: ${e.message}")
                }
            }
            logger.warn("[Abstergo Labs] AVISO: $label no se descargó; la app compilará igual pero puedes colocarlo manualmente en ${dest.path}")
        }

        // 1) JSXGraph 1.14.3
        downloadIfMissing(
            dest = File(mathDir, "jsxgraphcore.js"),
            minBytes = 100_000L,
            urls = listOf(
                "https://cdn.jsdelivr.net/npm/jsxgraph@1.14.3/distrib/jsxgraphcore.js",
                "https://unpkg.com/jsxgraph@1.14.3/distrib/jsxgraphcore.js",
                "https://raw.githubusercontent.com/jsxgraph/jsxgraph/v1.14.3/distrib/jsxgraphcore.js"
            ),
            label = "JSXGraph 1.14.3"
        )

        // 2) Modelo OCR Nivel 2 ONNX cuantizado INT8 (Xenova/texify, universal 32/64 bits)
        downloadIfMissing(
            dest = File(ocrDir, "encoder.onnx"),
            minBytes = 1_000_000L,
            urls = listOf(
                "https://huggingface.co/Xenova/texify/resolve/main/onnx/encoder_model_quantized.onnx"
            ),
            label = "OCR encoder.onnx (INT8)"
        )
        downloadIfMissing(
            dest = File(ocrDir, "decoder.onnx"),
            minBytes = 1_000_000L,
            urls = listOf(
                "https://huggingface.co/Xenova/texify/resolve/main/onnx/decoder_model_quantized.onnx"
            ),
            label = "OCR decoder.onnx (INT8)"
        )
        downloadIfMissing(
            dest = File(ocrDir, "tokenizer.json"),
            minBytes = 10_000L,
            urls = listOf(
                "https://huggingface.co/Xenova/texify/resolve/main/tokenizer.json"
            ),
            label = "OCR tokenizer.json"
        )
    }
}

tasks.named("preBuild").configure {
    dependsOn(prepareLabsAssets)
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Escáner QR y utilidades existentes
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")

    // Motor Matemático Fusionado (núcleo numérico microMathematics, 100% JVM universal)
    implementation("org.apache.commons:commons-math3:3.6.1")

    // OCR Matemático Nivel 2 Offline (ONNX Runtime universal 32/64 bits)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
}
