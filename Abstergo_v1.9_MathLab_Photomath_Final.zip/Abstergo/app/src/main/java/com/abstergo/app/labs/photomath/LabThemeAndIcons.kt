package com.abstergo.app.labs.photomath

import androidx.compose.foundation.Canvas
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.luminance

/**
 * Paleta de Abstergo Matemática Labs:
 * fusiona la identidad verde esmeralda/menta (#86FF8E) de Abstergo con el contraste limpio de Photomath.
 */
@Composable
fun labAccent(): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) Color(0xFF86FF8E) else Color(0xFF00A859)
}

@Composable
fun labOnAccent(): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) Color(0xFF07210D) else Color.White
}

@Composable
fun labHighlight(): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) Color(0xFF5EEAD4) else Color(0xFF059669)
}

@Composable
fun labSecondaryAccent(): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (dark) Color(0xFF60A5FA) else Color(0xFF1D4ED8)
}

/** Alias de compatibilidad interna para toda la suite Photomath × Abstergo. */
@Composable
fun photomathRed(): Color = labAccent()

/** Fondo sutil de cuadrícula de laboratorio (plano cartesiano minimalista a 60 fps). */
@Composable
fun LabBlueprintGrid(modifier: Modifier = Modifier) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val lineColor = if (dark) Color(0x1486FF8E) else Color(0x1200A859)
    Canvas(modifier = modifier) {
        val step = 28f * density
        if (step <= 4f) return@Canvas
        var x = step
        while (x < size.width) {
            drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
            x += step
        }
        var y = step
        while (y < size.height) {
            drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            y += step
        }
    }
}

enum class LabIconKind {
    CAMERA,
    CALCULATOR,
    LAB_CUBE,
    HISTORY,
    FLASH,
    GALLERY,
    PLAY,
    PAUSE,
    BACK,
    EDIT,
    SAVE,
    EXPAND,
    PACK,
    GEOM_2D3D,
    FUNCTIONS,
    INEQUALITIES,
    TRIG,
    COMPLEX,
    COMBINATORICS,
    INDUCTION,
    STATS
}

/**
 * Iconos vectoriales minimalistas en cuadrícula 100×100 con el mismo lenguaje geométrico
 * de trazos limpios de Abstergo (cero emojis del sistema).
 */
@Composable
fun LabIcon(
    kind: LabIconKind,
    color: Color,
    modifier: Modifier = Modifier,
    strokeWidth: Float = 6.5f
) {
    Canvas(modifier = modifier) {
        val sc = size.minDimension / 100f
        val st = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
        withTransform({ scale(sc, sc, Offset.Zero) }) {
            when (kind) {
                LabIconKind.CAMERA -> {
                    // Visor de esquinas estilo Photomath + lente central
                    val c = 24f
                    drawLine(color, Offset(14f, 14f), Offset(14f + c, 14f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(14f, 14f), Offset(14f, 14f + c), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(86f, 14f), Offset(86f - c, 14f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(86f, 14f), Offset(86f, 14f + c), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(14f, 86f), Offset(14f + c, 86f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(14f, 86f), Offset(14f, 86f - c), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(86f, 86f), Offset(86f - c, 86f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(86f, 86f), Offset(86f, 86f - c), strokeWidth, StrokeCap.Round)
                    drawCircle(color, radius = 15f, center = Offset(50f, 50f), style = st)
                }

                LabIconKind.CALCULATOR -> {
                    drawRoundRect(color, Offset(18f, 12f), Size(64f, 76f), CornerRadius(12f, 12f), style = st)
                    drawLine(color, Offset(28f, 32f), Offset(72f, 32f), strokeWidth, StrokeCap.Round)
                    // 4 teclas minimalistas
                    drawLine(color, Offset(32f, 52f), Offset(42f, 52f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(37f, 47f), Offset(37f, 57f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(58f, 52f), Offset(68f, 52f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(32f, 70f), Offset(42f, 70f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(58f, 67f), Offset(68f, 67f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(58f, 74f), Offset(68f, 74f), strokeWidth, StrokeCap.Round)
                }

                LabIconKind.LAB_CUBE, LabIconKind.GEOM_2D3D -> {
                    // Cubo isométrico 3D
                    val hex = Path().apply {
                        moveTo(50f, 12f); lineTo(84f, 31f); lineTo(84f, 69f)
                        lineTo(50f, 88f); lineTo(16f, 69f); lineTo(16f, 31f); close()
                    }
                    drawPath(hex, color, style = st)
                    drawLine(color, Offset(16f, 31f), Offset(50f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(84f, 31f), Offset(50f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(50f, 50f), Offset(50f, 88f), strokeWidth, StrokeCap.Round)
                }

                LabIconKind.HISTORY -> {
                    drawArc(color, startAngle = -60f, sweepAngle = 290f, useCenter = false, topLeft = Offset(16f, 16f), size = Size(68f, 68f), style = st)
                    drawLine(color, Offset(16f, 36f), Offset(16f, 18f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(16f, 36f), Offset(34f, 36f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(50f, 32f), Offset(50f, 52f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(50f, 52f), Offset(65f, 60f), strokeWidth, StrokeCap.Round)
                }

                LabIconKind.FLASH -> {
                    val bolt = Path().apply {
                        moveTo(58f, 12f); lineTo(24f, 54f); lineTo(50f, 54f)
                        lineTo(42f, 88f); lineTo(76f, 46f); lineTo(50f, 46f); close()
                    }
                    drawPath(bolt, color, style = st)
                }

                LabIconKind.GALLERY -> {
                    drawRoundRect(color, Offset(14f, 18f), Size(72f, 64f), CornerRadius(12f, 12f), style = st)
                    drawCircle(color, radius = 7f, center = Offset(34f, 38f), style = st)
                    val m = Path().apply {
                        moveTo(20f, 74f); lineTo(42f, 52f); lineTo(56f, 64f); lineTo(70f, 48f); lineTo(82f, 74f)
                    }
                    drawPath(m, color, style = st)
                }

                LabIconKind.PLAY -> {
                    val tri = Path().apply { moveTo(30f, 20f); lineTo(80f, 50f); lineTo(30f, 80f); close() }
                    drawPath(tri, color)
                }

                LabIconKind.PAUSE -> {
                    drawLine(color, Offset(36f, 22f), Offset(36f, 78f), 11f, StrokeCap.Round)
                    drawLine(color, Offset(64f, 22f), Offset(64f, 78f), 11f, StrokeCap.Round)
                }

                LabIconKind.BACK -> {
                    val p = Path().apply { moveTo(64f, 18f); lineTo(32f, 50f); lineTo(64f, 82f) }
                    drawPath(p, color, style = st)
                }

                LabIconKind.EDIT -> {
                    val p = Path().apply {
                        moveTo(20f, 80f); lineTo(28f, 56f); lineTo(68f, 16f); lineTo(84f, 32f); lineTo(44f, 72f); close()
                    }
                    drawPath(p, color, style = st)
                }

                LabIconKind.SAVE -> {
                    val p = Path().apply {
                        moveTo(24f, 14f); lineTo(76f, 14f); lineTo(76f, 86f); lineTo(50f, 68f); lineTo(24f, 86f); close()
                    }
                    drawPath(p, color, style = st)
                }

                LabIconKind.EXPAND -> {
                    drawLine(color, Offset(18f, 40f), Offset(18f, 18f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(18f, 18f), Offset(40f, 18f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(82f, 60f), Offset(82f, 82f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(82f, 82f), Offset(60f, 82f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(18f, 18f), Offset(42f, 42f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(82f, 82f), Offset(58f, 58f), strokeWidth, StrokeCap.Round)
                }

                LabIconKind.PACK -> {
                    val p = Path().apply {
                        moveTo(22f, 14f); lineTo(60f, 14f); lineTo(78f, 32f); lineTo(78f, 86f); lineTo(22f, 86f); close()
                    }
                    drawPath(p, color, style = st)
                    drawLine(color, Offset(36f, 50f), Offset(64f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(36f, 66f), Offset(56f, 66f), strokeWidth, StrokeCap.Round)
                }

                LabIconKind.FUNCTIONS -> {
                    drawLine(color, Offset(16f, 82f), Offset(88f, 82f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(20f, 16f), Offset(20f, 84f), strokeWidth, StrokeCap.Round)
                    val curve = Path().apply {
                        moveTo(24f, 70f)
                        cubicTo(40f, 18f, 60f, 82f, 84f, 22f)
                    }
                    drawPath(curve, color, style = st)
                }

                LabIconKind.INEQUALITIES -> {
                    drawLine(color, Offset(14f, 56f), Offset(86f, 56f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(32f, 56f), Offset(72f, 56f), 11f, StrokeCap.Round)
                    drawCircle(color, radius = 9f, center = Offset(32f, 56f))
                    drawCircle(color, radius = 9f, center = Offset(72f, 56f), style = st)
                }

                LabIconKind.TRIG -> {
                    drawLine(color, Offset(12f, 50f), Offset(88f, 50f), 4f, StrokeCap.Round)
                    val wave = Path().apply {
                        moveTo(14f, 50f)
                        cubicTo(28f, 10f, 40f, 10f, 50f, 50f)
                        cubicTo(60f, 90f, 72f, 90f, 86f, 50f)
                    }
                    drawPath(wave, color, style = st)
                }

                LabIconKind.COMPLEX -> {
                    drawLine(color, Offset(14f, 50f), Offset(86f, 50f), 4f, StrokeCap.Round)
                    drawLine(color, Offset(50f, 14f), Offset(50f, 86f), 4f, StrokeCap.Round)
                    drawCircle(color, radius = 30f, center = Offset(50f, 50f), style = Stroke(3.5f))
                    drawLine(color, Offset(50f, 50f), Offset(72f, 28f), strokeWidth, StrokeCap.Round)
                    drawCircle(color, radius = 7f, center = Offset(72f, 28f))
                }

                LabIconKind.COMBINATORICS -> {
                    drawLine(color, Offset(24f, 50f), Offset(72f, 24f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(24f, 50f), Offset(72f, 50f), strokeWidth, StrokeCap.Round)
                    drawLine(color, Offset(24f, 50f), Offset(72f, 76f), strokeWidth, StrokeCap.Round)
                    drawCircle(color, radius = 8f, center = Offset(24f, 50f))
                    drawCircle(color, radius = 8f, center = Offset(72f, 24f))
                    drawCircle(color, radius = 8f, center = Offset(72f, 50f))
                    drawCircle(color, radius = 8f, center = Offset(72f, 76f))
                }

                LabIconKind.INDUCTION -> {
                    // Sigma ∑
                    val sigma = Path().apply {
                        moveTo(76f, 20f); lineTo(24f, 20f); lineTo(54f, 50f); lineTo(24f, 80f); lineTo(76f, 80f)
                    }
                    drawPath(sigma, color, style = st)
                }

                LabIconKind.STATS -> {
                    drawLine(color, Offset(14f, 84f), Offset(88f, 84f), strokeWidth, StrokeCap.Round)
                    drawRoundRect(color, Offset(20f, 54f), Size(14f, 30f), CornerRadius(4f, 4f), style = st)
                    drawRoundRect(color, Offset(44f, 34f), Size(14f, 50f), CornerRadius(4f, 4f), style = st)
                    drawRoundRect(color, Offset(68f, 20f), Size(14f, 64f), CornerRadius(4f, 4f), style = st)
                }
            }
        }
    }
}
