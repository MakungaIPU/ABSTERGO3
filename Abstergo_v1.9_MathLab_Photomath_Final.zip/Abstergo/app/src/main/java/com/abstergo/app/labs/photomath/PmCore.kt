package com.abstergo.app.labs.photomath

import androidx.compose.runtime.Immutable
import org.apache.commons.math3.complex.Complex
import org.apache.commons.math3.util.CombinatoricsUtils
import org.apache.commons.math3.util.FastMath
import java.math.BigInteger
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.round

// ==============================================================================
// 1. ARITMÉTICA RACIONAL EXACTA (BigRat) Y RADICALES EXACTOS
// ==============================================================================

/** Fracción exacta arbitraria p/q (siempre reducida con q > 0). Cero errores de coma flotante. */
@Immutable
class BigRat private constructor(
    val num: BigInteger,
    val den: BigInteger
) : Comparable<BigRat> {

    val isZero: Boolean get() = num == BigInteger.ZERO
    val isOne: Boolean get() = num == BigInteger.ONE && den == BigInteger.ONE
    val isNegOne: Boolean get() = num == BigInteger.valueOf(-1L) && den == BigInteger.ONE
    val isNegative: Boolean get() = num.signum() < 0
    val isPositive: Boolean get() = num.signum() > 0
    val isInt: Boolean get() = den == BigInteger.ONE

    operator fun unaryMinus(): BigRat = BigRat(num.negate(), den)
    fun abs(): BigRat = if (isNegative) -this else this

    operator fun plus(o: BigRat): BigRat = of(num * o.den + o.num * den, den * o.den)
    operator fun minus(o: BigRat): BigRat = of(num * o.den - o.num * den, den * o.den)
    operator fun times(o: BigRat): BigRat = of(num * o.num, den * o.den)
    operator fun div(o: BigRat): BigRat {
        require(!o.isZero) { "División entre cero" }
        return of(num * o.den, den * o.num)
    }

    fun pow(exp: Int): BigRat = when {
        exp == 0 -> ONE
        exp > 0 -> BigRat(num.pow(exp), den.pow(exp))
        else -> {
            require(!isZero) { "0 elevado a exponente negativo" }
            val p = -exp
            of(den.pow(p), num.pow(p))
        }
    }

    fun toDouble(): Double {
        if (isZero) return 0.0
        val bl = maxOf(num.bitLength(), den.bitLength())
        return if (bl > 900) {
            val shift = bl - 900
            num.shiftRight(shift).toDouble() / den.shiftRight(shift).toDouble()
        } else {
            num.toDouble() / den.toDouble()
        }
    }

    override fun compareTo(other: BigRat): Int = (num * other.den).compareTo(other.num * den)

    override fun equals(other: Any?): Boolean =
        other is BigRat && num == other.num && den == other.den

    override fun hashCode(): Int = 31 * num.hashCode() + den.hashCode()

    override fun toString(): String = if (isInt) num.toString() else "$num/$den"

    fun toDecimalString(maxDecimals: Int = 6): String = formatDecimal(toDouble(), maxDecimals)

    companion object {
        val ZERO = BigRat(BigInteger.ZERO, BigInteger.ONE)
        val ONE = BigRat(BigInteger.ONE, BigInteger.ONE)
        val NEG_ONE = BigRat(BigInteger.valueOf(-1L), BigInteger.ONE)
        val TWO = BigRat(BigInteger.valueOf(2L), BigInteger.ONE)
        val HALF = BigRat(BigInteger.ONE, BigInteger.valueOf(2L))

        fun of(n: Long, d: Long = 1L): BigRat = of(BigInteger.valueOf(n), BigInteger.valueOf(d))

        fun of(n: BigInteger, d: BigInteger = BigInteger.ONE): BigRat {
            require(d != BigInteger.ZERO) { "Denominador cero" }
            if (n == BigInteger.ZERO) return ZERO
            val signNeg = d.signum() < 0
            val nn = if (signNeg) n.negate() else n
            val dd = if (signNeg) d.negate() else d
            val g = nn.abs().gcd(dd)
            return if (g == BigInteger.ONE) BigRat(nn, dd) else BigRat(nn / g, dd / g)
        }

        fun parse(text: String): BigRat? {
            val s = text.trim()
            if (s.isEmpty()) return null
            if ('/' in s) {
                val parts = s.split('/')
                if (parts.size != 2) return null
                val a = parse(parts[0]) ?: return null
                val b = parse(parts[1]) ?: return null
                return if (b.isZero) null else a / b
            }
            val dot = s.indexOf('.')
            return try {
                if (dot < 0) {
                    of(BigInteger(s), BigInteger.ONE)
                } else {
                    val neg = s.startsWith("-")
                    val clean = if (neg || s.startsWith("+")) s.substring(1) else s
                    val dIdx = clean.indexOf('.')
                    val intPart = clean.substring(0, dIdx).ifEmpty { "0" }
                    val fracPart = clean.substring(dIdx + 1)
                    val digits = BigInteger(intPart + fracPart)
                    val denom = BigInteger.TEN.pow(fracPart.length)
                    of(if (neg) digits.negate() else digits, denom)
                }
            } catch (_: Exception) {
                null
            }
        }
    }
}

/** Raíz cuadrada simplificada exacta: √n = outside * √inside (con inside libre de cuadrados). */
data class SimplifiedSqrt(val outside: BigInteger, val inside: BigInteger) {
    val isExactInt: Boolean get() = inside == BigInteger.ONE || outside == BigInteger.ZERO
    fun format(): String = when {
        outside == BigInteger.ZERO -> "0"
        inside == BigInteger.ONE -> outside.toString()
        outside == BigInteger.ONE -> "√$inside"
        else -> "${outside}√$inside"
    }
}

object ExactMath {
    fun simplifySqrt(n: BigInteger): SimplifiedSqrt {
        if (n <= BigInteger.ZERO) return SimplifiedSqrt(BigInteger.ZERO, BigInteger.ONE)
        if (n == BigInteger.ONE) return SimplifiedSqrt(BigInteger.ONE, BigInteger.ONE)
        // Comprobar cuadrado perfecto primero (rápido para números grandes)
        val root = intSqrt(n)
        if (root * root == n) return SimplifiedSqrt(root, BigInteger.ONE)

        // Factorización controlada para radicandos manejables
        if (n.bitLength() > 48) return SimplifiedSqrt(BigInteger.ONE, n)
        var rem = n.toLong()
        var out = 1L
        var f = 2L
        while (f * f <= rem && f <= 200_000L) {
            while (rem % (f * f) == 0L) {
                out *= f
                rem /= (f * f)
            }
            f += if (f == 2L) 1L else 2L
        }
        return SimplifiedSqrt(BigInteger.valueOf(out), BigInteger.valueOf(rem))
    }

    fun intSqrt(n: BigInteger): BigInteger {
        if (n < BigInteger.ZERO) return BigInteger.ZERO
        if (n == BigInteger.ZERO || n == BigInteger.ONE) return n
        var x = BigInteger.ONE.shiftLeft((n.bitLength() + 1) / 2)
        while (true) {
            val y = (x + n / x).shiftRight(1)
            if (y >= x) return x
            x = y
        }
    }

    fun gcd(a: BigInteger, b: BigInteger): BigInteger = a.abs().gcd(b.abs())

    fun lcm(a: BigInteger, b: BigInteger): BigInteger {
        if (a == BigInteger.ZERO || b == BigInteger.ZERO) return BigInteger.ZERO
        return (a.abs() / gcd(a, b)) * b.abs()
    }

    fun factorial(n: Int): BigInteger {
        if (n <= 1) return BigInteger.ONE
        var acc = BigInteger.ONE
        for (i in 2..n) acc *= BigInteger.valueOf(i.toLong())
        return acc
    }

    fun variation(n: Int, k: Int): BigInteger {
        if (k < 0 || k > n) return BigInteger.ZERO
        var acc = BigInteger.ONE
        for (i in 0 until k) acc *= BigInteger.valueOf((n - i).toLong())
        return acc
    }

    fun comb(n: Int, k: Int): BigInteger {
        if (k < 0 || k > n) return BigInteger.ZERO
        val r = minOf(k, n - k)
        var acc = BigInteger.ONE
        for (i in 1..r) {
            acc = acc * BigInteger.valueOf((n - r + i).toLong()) / BigInteger.valueOf(i.toLong())
        }
        return acc
    }

    fun divisorsOf(n: BigInteger, maxCount: Int = 64): List<BigInteger> {
        val absN = n.abs()
        if (absN == BigInteger.ZERO || absN.bitLength() > 30) return emptyList()
        val v = absN.toLong()
        val small = ArrayList<BigInteger>()
        val large = ArrayList<BigInteger>()
        var d = 1L
        while (d * d <= v && small.size < maxCount) {
            if (v % d == 0L) {
                small.add(BigInteger.valueOf(d))
                if (d * d != v) large.add(BigInteger.valueOf(v / d))
            }
            d++
        }
        return small + large.reversed()
    }
}

fun formatDecimal(value: Double, maxDecimals: Int = 6): String {
    if (value.isNaN()) return "Indefinido"
    if (value.isInfinite()) return if (value > 0) "+∞" else "-∞"
    val clean = if (abs(value) < 1e-12) 0.0 else value
    val r = round(clean)
    if (abs(clean - r) < 1e-10 && abs(r) < 1e14) return r.toLong().toString()
    val formatted = "%.${maxDecimals}f".format(Locale.US, clean).trimEnd('0').trimEnd('.')
    return if (formatted == "-0") "0" else formatted
}

// ==============================================================================
// 2. AST SIMBÓLICO DE PHOTOMATH (PmExpr)
// ==============================================================================

@Immutable
sealed class PmExpr {
    data class Num(val rat: BigRat) : PmExpr()
    data class Sym(val name: String) : PmExpr()
    data class Const(val name: String) : PmExpr() // pi, e, i
    data class Neg(val inner: PmExpr) : PmExpr()
    data class Add(val left: PmExpr, val right: PmExpr) : PmExpr()
    data class Sub(val left: PmExpr, val right: PmExpr) : PmExpr()
    data class Mul(val left: PmExpr, val right: PmExpr) : PmExpr()
    data class Div(val num: PmExpr, val den: PmExpr) : PmExpr()
    data class Pow(val base: PmExpr, val exp: PmExpr) : PmExpr()
    data class Root(val radicand: PmExpr, val index: PmExpr? = null) : PmExpr()
    data class Abs(val inner: PmExpr) : PmExpr()
    data class Func(val name: String, val args: List<PmExpr>) : PmExpr()
    data class Deriv(val body: PmExpr, val variable: String) : PmExpr()
    data class Integral(
        val body: PmExpr,
        val variable: String,
        val lower: PmExpr? = null,
        val upper: PmExpr? = null
    ) : PmExpr()
    data class Limit(val body: PmExpr, val variable: String, val target: PmExpr) : PmExpr()
    data class Rel(val op: String, val left: PmExpr, val right: PmExpr) : PmExpr() // =, <, <=, >, >=
    data class System(val items: List<PmExpr>) : PmExpr()

    companion object {
        fun int(n: Long): PmExpr = Num(BigRat.of(n))
        fun rat(r: BigRat): PmExpr = if (r.isNegative) Neg(Num(r.abs())) else Num(r)
    }
}

// ==============================================================================
// 3. NORMALIZADOR DE ENTRADA NATURAL / LATEX (OCR + TECLADO)
// ==============================================================================

object PmLatexNormalizer {
    private val MULTI_SPACE = Regex("\\s+")
    private val FRAC_RE = Regex("\\\\(?:d|t)?frac\\s*\\{([^{}]+)\\}\\s*\\{([^{}]+)\\}")
    private val SQRT_N_RE = Regex("\\\\sqrt\\s*\\[([^\\]]+)\\]\\s*\\{([^{}]+)\\}")
    private val SQRT_RE = Regex("\\\\sqrt\\s*\\{([^{}]+)\\}")
    private val SUP_RE = Regex("\\^\\s*\\{([^{}]+)\\}")
    private val SUB_RE = Regex("_\\s*\\{([^{}]+)\\}")
    private val LEFT_RIGHT = Regex("\\\\(?:left|right)\\s*")
    private val TEXT_CMD = Regex("\\\\(?:text|mathrm|operatorname)\\s*\\{([^{}]+)\\}")
    private val FUNC_LATEX = Regex("\\\\(sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|sinh|cosh|tanh|ln|log|exp|abs|lim)\\b")
    private val DERIV_PREFIX = Regex("^(?:d\\s*/\\s*d([a-zA-Z]))\\s*\\(?(.+)\\)?$")

    fun normalize(raw: String): String {
        var s = raw.trim()
        if (s.isEmpty()) return s

        // Delimitadores LaTeX
        s = s.replace("$$", "").replace("$", "")
            .replace("\\(", "(").replace("\\)", ")")
            .replace("\\[", "").replace("\\]", "")

        // Símbolos Unicode y operadores LaTeX
        s = s.replace('−', '-')
            .replace('–', '-')
            .replace('—', '-')
            .replace('×', '*')
            .replace('·', '*')
            .replace('÷', '/')
            .replace("≤", "<=")
            .replace("≥", ">=")
            .replace("≠", "!=")
            .replace("→", "->")
            .replace("∞", "inf")
            .replace("²", "^2")
            .replace("³", "^3")
            .replace("⁴", "^4")
            .replace("⁵", "^5")
            .replace("⁰", "^0")
            .replace("¹", "^1")
            .replace("\\cdot", "*")
            .replace("\\times", "*")
            .replace("\\div", "/")
            .replace("\\pi", "pi")
            .replace("\\infty", "inf")
            .replace("\\to", "->")
            .replace("\\rightarrow", "->")
            .replace("\\le", "<=")
            .replace("\\leq", "<=")
            .replace("\\ge", ">=")
            .replace("\\geq", ">=")
            .replace("\\ne", "!=")
            .replace("\\neq", "!=")
            .replace(LEFT_RIGHT, "")

        // Desenrollar comandos LaTeX anidados (hasta 6 niveles)
        repeat(6) {
            val prev = s
            s = TEXT_CMD.replace(s) { it.groupValues[1] }
            s = FRAC_RE.replace(s) { "(${it.groupValues[1]})/(${it.groupValues[2]})" }
            s = SQRT_N_RE.replace(s) { "nthrt(${it.groupValues[1]}, ${it.groupValues[2]})" }
            s = SQRT_RE.replace(s) { "sqrt(${it.groupValues[1]})" }
            s = SUP_RE.replace(s) { "^(${it.groupValues[1]})" }
            s = SUB_RE.replace(s) { "_${it.groupValues[1]}" }
            if (s == prev) return@repeat
        }

        s = FUNC_LATEX.replace(s) { m ->
            when (val fn = m.groupValues[1]) {
                "arcsin" -> "asin"
                "arccos" -> "acos"
                "arctan" -> "atan"
                else -> fn
            }
        }

        // Saltos de línea entre ecuaciones se convierten en ';' para sistemas
        s = s.replace("\r\n", ";").replace("\n", ";")
        s = s.replace('{', '(').replace('}', ')')
        s = s.replace("\\", "")

        // Convertir notación humana "d/dx(...)" en deriv(..., x) respetando paréntesis balanceados
        val dHead = Regex("^d\\s*/\\s*d([a-zA-Z])\\s*(.+)$").matchEntire(s.trim())
        if (dHead != null) {
            val v = dHead.groupValues[1]
            var body = dHead.groupValues[2].trim()
            if (body.startsWith("(") && body.endsWith(")")) {
                var depth = 0
                var matchesOuter = true
                for (idx in body.indices) {
                    val ch = body[idx]
                    if (ch == '(') depth++
                    else if (ch == ')') {
                        depth--
                        if (depth == 0 && idx < body.lastIndex) {
                            matchesOuter = false
                            break
                        }
                    }
                }
                if (matchesOuter && depth == 0) body = body.substring(1, body.length - 1).trim()
            }
            s = "deriv($body, $v)"
        }

        return s.replace(MULTI_SPACE, " ").trim().trimEnd(';')
    }
}

// ==============================================================================
// 4. LEXER Y PARSER PRATT (SOPORTA FRACCIONES, RAÍCES, |x|, d/dx, ∫, lim, SISTEMAS)
// ==============================================================================

enum class PmTokKind {
    NUM, IDENT, OP, LPAREN, RPAREN, PIPE, SQRT, INT_SIGN, COMMA, SEMI, ARROW, END
}

data class PmTok(val kind: PmTokKind, val text: String, val pos: Int)

class PmParseException(val userMsg: String, val pos: Int) : RuntimeException("$userMsg (pos $pos)")

class PmLexer(private val src: String) {
    private var i = 0

    fun tokenize(): List<PmTok> {
        val out = ArrayList<PmTok>(src.length / 2 + 4)
        while (i < src.length) {
            val c = src[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || c == '.' -> out.add(readNumber())
                c == 'π' -> { out.add(PmTok(PmTokKind.IDENT, "pi", i)); i++ }
                c == '√' -> { out.add(PmTok(PmTokKind.SQRT, "√", i)); i++ }
                c == '∫' -> { out.add(PmTok(PmTokKind.INT_SIGN, "∫", i)); i++ }
                c == '|' -> { out.add(PmTok(PmTokKind.PIPE, "|", i)); i++ }
                c == '(' || c == '[' -> { out.add(PmTok(PmTokKind.LPAREN, "(", i)); i++ }
                c == ')' || c == ']' -> { out.add(PmTok(PmTokKind.RPAREN, ")", i)); i++ }
                c == ',' -> { out.add(PmTok(PmTokKind.COMMA, ",", i)); i++ }
                c == ';' -> { out.add(PmTok(PmTokKind.SEMI, ";", i)); i++ }
                c == '-' && i + 1 < src.length && src[i + 1] == '>' -> {
                    out.add(PmTok(PmTokKind.ARROW, "->", i)); i += 2
                }
                c == '<' || c == '>' || c == '=' || c == '!' -> {
                    val start = i
                    val two = if (i + 1 < src.length) src.substring(i, i + 2) else ""
                    if (two == "<=" || two == ">=" || two == "!=" || two == "==") {
                        out.add(PmTok(PmTokKind.OP, two, start)); i += 2
                    } else {
                        out.add(PmTok(PmTokKind.OP, c.toString(), start)); i++
                    }
                }
                c in "+-*/^%" -> { out.add(PmTok(PmTokKind.OP, c.toString(), i)); i++ }
                c.isLetter() || c == '_' -> out.add(readIdent())
                else -> throw PmParseException("Símbolo no reconocido: «$c»", i)
            }
        }
        out.add(PmTok(PmTokKind.END, "", src.length))
        return out
    }

    private fun readNumber(): PmTok {
        val start = i
        var dot = false
        while (i < src.length) {
            val c = src[i]
            if (c.isDigit()) i++
            else if (c == '.' && !dot) { dot = true; i++ }
            else break
        }
        val text = src.substring(start, i)
        if (text == ".") throw PmParseException("Número decimal incompleto", start)
        return PmTok(PmTokKind.NUM, text, start)
    }

    private fun readIdent(): PmTok {
        val start = i
        while (i < src.length && (src[i].isLetterOrDigit() || src[i] == '_')) i++
        return PmTok(PmTokKind.IDENT, src.substring(start, i), start)
    }
}

class PmParser private constructor(private val toks: List<PmTok>) {
    private var p = 0
    private var pipeDepth = 0

    fun parseTop(): PmExpr {
        val items = ArrayList<PmExpr>()
        while (!atEnd()) {
            if (peek().kind == PmTokKind.SEMI) { next(); continue }
            items.add(parseRelation())
            if (peek().kind == PmTokKind.SEMI) {
                next()
                continue
            }
            if (!atEnd()) throw PmParseException("Elemento inesperado «${peek().text}»", peek().pos)
        }
        if (items.isEmpty()) throw PmParseException("Escribe una expresión matemática", 0)
        return if (items.size == 1) items[0] else PmExpr.System(items)
    }

    private fun parseRelation(): PmExpr {
        val left = parseExpr(0)
        val t = peek()
        if (t.kind == PmTokKind.OP && t.text in REL_OPS) {
            next()
            val op = if (t.text == "==") "=" else t.text
            val right = parseExpr(0)
            return PmExpr.Rel(op, left, right)
        }
        return left
    }

    private fun parseExpr(minPrec: Int): PmExpr {
        var left = parsePrefix()
        while (true) {
            val t = peek()
            if (t.kind == PmTokKind.OP && t.text == "!") {
                if (90 < minPrec) break
                next()
                left = PmExpr.Func("factorial", listOf(left))
            } else if (t.kind == PmTokKind.OP && t.text in BIN_PREC) {
                val prec = BIN_PREC.getValue(t.text)
                if (prec < minPrec) break
                next()
                val rightMin = if (t.text == "^") prec else prec + 1
                val right = parseExpr(rightMin)
                left = when (t.text) {
                    "+" -> PmExpr.Add(left, right)
                    "-" -> PmExpr.Sub(left, right)
                    "*" -> PmExpr.Mul(left, right)
                    "/" -> PmExpr.Div(left, right)
                    "^" -> PmExpr.Pow(left, right)
                    "%" -> PmExpr.Func("mod", listOf(left, right))
                    else -> left
                }
            } else if (canImplicitMul(t)) {
                if (60 < minPrec) break
                val right = parseExpr(61)
                left = PmExpr.Mul(left, right)
            } else {
                break
            }
        }
        return left
    }

    private fun parsePrefix(): PmExpr {
        val t = peek()
        return when (t.kind) {
            PmTokKind.OP -> when (t.text) {
                "-" -> { next(); PmExpr.Neg(parseExpr(70)) }
                "+" -> { next(); parseExpr(70) }
                else -> throw PmParseException("Operador inesperado «${t.text}»", t.pos)
            }
            PmTokKind.NUM -> {
                next()
                val rat = BigRat.parse(t.text) ?: throw PmParseException("Número inválido «${t.text}»", t.pos)
                PmExpr.Num(rat)
            }
            PmTokKind.SQRT -> {
                next()
                PmExpr.Root(parseExpr(80), null)
            }
            PmTokKind.INT_SIGN -> {
                next()
                parseIntegralSyntax()
            }
            PmTokKind.LPAREN -> {
                next()
                val inner = parseExpr(0)
                expect(PmTokKind.RPAREN, ")")
                inner
            }
            PmTokKind.PIPE -> {
                next()
                pipeDepth++
                val inner = parseExpr(0)
                pipeDepth--
                expect(PmTokKind.PIPE, "|")
                PmExpr.Abs(inner)
            }
            PmTokKind.IDENT -> {
                next()
                parseIdent(t)
            }
            else -> throw PmParseException("Se esperaba una expresión, apareció «${t.text}»", t.pos)
        }
    }

    private fun parseIntegralSyntax(): PmExpr {
        val body = if (peek().kind == PmTokKind.LPAREN) {
            next()
            val e = parseExpr(0)
            expect(PmTokKind.RPAREN, ")")
            e
        } else {
            parseExpr(0)
        }
        // Opcional "dx" al final
        var v = collectVars(body).firstOrNull() ?: "x"
        if (peek().kind == PmTokKind.IDENT && peek().text.length == 2 && peek().text.startsWith("d")) {
            v = peek().text.substring(1)
            next()
        }
        return PmExpr.Integral(body, v)
    }

    private fun parseIdent(t: PmTok): PmExpr {
        val lower = t.text.lowercase()
        if (lower == "pi") return PmExpr.Const("pi")
        if (lower == "e") return PmExpr.Const("e")
        if (lower == "i") return PmExpr.Const("i")
        if (lower == "inf" || lower == "infinity") return PmExpr.Const("inf")

        // d/dx(...) estilo natural dentro de subexpresiones
        if (lower == "deriv" || lower == "diff") {
            if (peek().kind == PmTokKind.LPAREN) {
                next()
                val body = parseExpr(0)
                var v = collectVars(body).firstOrNull() ?: "x"
                if (peek().kind == PmTokKind.COMMA) {
                    next()
                    val vt = peek()
                    if (vt.kind == PmTokKind.IDENT) { v = vt.text; next() }
                }
                expect(PmTokKind.RPAREN, ")")
                return PmExpr.Deriv(body, v)
            }
        }

        if (lower == "int" || lower == "integrate") {
            if (peek().kind == PmTokKind.LPAREN) {
                next()
                val body = parseExpr(0)
                var v = collectVars(body).firstOrNull() ?: "x"
                var lo: PmExpr? = null
                var hi: PmExpr? = null
                if (peek().kind == PmTokKind.COMMA) {
                    next()
                    if (peek().kind == PmTokKind.IDENT && peekNext().kind in listOf(PmTokKind.RPAREN, PmTokKind.COMMA)) {
                        v = next().text
                    } else {
                        lo = parseExpr(0)
                    }
                    if (peek().kind == PmTokKind.COMMA) {
                        next()
                        if (lo == null) lo = parseExpr(0) else hi = parseExpr(0)
                    }
                    if (peek().kind == PmTokKind.COMMA) {
                        next()
                        hi = parseExpr(0)
                    }
                }
                expect(PmTokKind.RPAREN, ")")
                return PmExpr.Integral(body, v, lo, hi)
            }
        }

        if (lower == "lim" || lower == "limit") {
            if (peek().kind == PmTokKind.LPAREN) {
                next()
                // Soportar lim(x->2, expr) o lim(expr, x, 2)
                if (peek().kind == PmTokKind.IDENT && peekNext().kind == PmTokKind.ARROW) {
                    val v = next().text
                    next() // ->
                    val target = parseExpr(0)
                    expect(PmTokKind.COMMA, ",")
                    val body = parseExpr(0)
                    expect(PmTokKind.RPAREN, ")")
                    return PmExpr.Limit(body, v, target)
                } else {
                    val body = parseExpr(0)
                    expect(PmTokKind.COMMA, ",")
                    val v = if (peek().kind == PmTokKind.IDENT) next().text else "x"
                    expect(PmTokKind.COMMA, ",")
                    val target = parseExpr(0)
                    expect(PmTokKind.RPAREN, ")")
                    return PmExpr.Limit(body, v, target)
                }
            }
        }

        // Funciones con paréntesis: sin(x), log_2(8), sqrt(x), nthrt(3, 8), abs(x)
        if (lower.startsWith("log_") && peek().kind == PmTokKind.LPAREN) {
            val baseStr = lower.removePrefix("log_")
            val baseRat = BigRat.parse(baseStr)
            next()
            val arg = parseExpr(0)
            expect(PmTokKind.RPAREN, ")")
            return if (baseRat != null) PmExpr.Func("log", listOf(PmExpr.Num(baseRat), arg))
            else PmExpr.Func("log10", listOf(arg))
        }

        val upperComb = when (t.text) {
            "C" -> "comb"
            "V" -> "var"
            "P" -> "perm"
            "CR" -> "combrep"
            "VR" -> "varrep"
            else -> null
        }
        val canonical = upperComb ?: FUNCTION_ALIASES[lower]
        if (canonical != null && peek().kind == PmTokKind.LPAREN) {
            next()
            val args = ArrayList<PmExpr>()
            if (peek().kind != PmTokKind.RPAREN) {
                args.add(parseExpr(0))
                while (peek().kind == PmTokKind.COMMA) {
                    next()
                    args.add(parseExpr(0))
                }
            }
            expect(PmTokKind.RPAREN, ")")
            return when (canonical) {
                "sqrt" -> if (args.size == 1) PmExpr.Root(args[0], null) else throw PmParseException("sqrt requiere 1 argumento", t.pos)
                "nthrt" -> if (args.size == 2) PmExpr.Root(args[1], args[0]) else throw PmParseException("nthrt(n, x) requiere 2 argumentos", t.pos)
                "abs" -> if (args.size == 1) PmExpr.Abs(args[0]) else throw PmParseException("abs requiere 1 argumento", t.pos)
                else -> PmExpr.Func(canonical, args)
            }
        }

        // Soporte para "sin x" sin paréntesis (frecuente en OCR/escritura rápida)
        if (canonical != null && canonical !in setOf("comb", "var", "perm", "combrep", "varrep") && canImplicitMul(peek())) {
            val arg = parseExpr(70)
            return when (canonical) {
                "sqrt" -> PmExpr.Root(arg, null)
                "abs" -> PmExpr.Abs(arg)
                else -> PmExpr.Func(canonical, listOf(arg))
            }
        }

        // Separar variables pegadas como "xy" -> x * y cuando no es función
        if (t.text.length in 2..4 && t.text.all { it.isLetter() } && canonical == null && !lower.startsWith("log_")) {
            var acc: PmExpr = PmExpr.Sym(t.text[0].toString())
            for (k in 1 until t.text.length) {
                val ch = t.text[k].toString()
                val factor: PmExpr = if (ch.equals("e", true)) PmExpr.Const("e") else PmExpr.Sym(ch)
                acc = PmExpr.Mul(acc, factor)
            }
            return acc
        }

        return PmExpr.Sym(t.text)
    }

    private fun canImplicitMul(t: PmTok): Boolean = when (t.kind) {
        PmTokKind.NUM, PmTokKind.IDENT, PmTokKind.LPAREN, PmTokKind.SQRT -> true
        PmTokKind.PIPE -> pipeDepth == 0
        else -> false
    }

    private fun atEnd(): Boolean = peek().kind == PmTokKind.END
    private fun peek(): PmTok = toks[p]
    private fun peekNext(): PmTok = if (p + 1 < toks.size) toks[p + 1] else toks.last()
    private fun next(): PmTok = toks[p++]

    private fun expect(kind: PmTokKind, label: String) {
        if (peek().kind != kind) throw PmParseException("Falta «$label», se encontró «${peek().text}»", peek().pos)
        next()
    }

    companion object {
        private val REL_OPS = setOf("=", "==", "<", "<=", ">", ">=")
        private val BIN_PREC = mapOf("+" to 50, "-" to 50, "*" to 60, "/" to 60, "%" to 60, "^" to 80)

        private val FUNCTION_ALIASES = mapOf(
            "sin" to "sin", "sen" to "sin",
            "cos" to "cos",
            "tan" to "tan", "tg" to "tan",
            "cot" to "cot", "ctg" to "cot",
            "sec" to "sec", "csc" to "csc",
            "asin" to "asin", "arcsin" to "asin",
            "acos" to "acos", "arccos" to "acos",
            "atan" to "atan", "arctan" to "atan",
            "sinh" to "sinh", "cosh" to "cosh", "tanh" to "tanh",
            "ln" to "ln", "log" to "log10", "log10" to "log10",
            "exp" to "exp", "sqrt" to "sqrt", "nthrt" to "nthrt",
            "abs" to "abs", "floor" to "floor", "ceil" to "ceil",
            "round" to "round", "fact" to "factorial", "factorial" to "factorial",
            "comb" to "comb", "ncr" to "comb",
            "var" to "var", "npr" to "var",
            "perm" to "perm",
            "combrep" to "combrep", "varrep" to "varrep"
        )

        fun parse(raw: String): PmExpr {
            val clean = PmLatexNormalizer.normalize(raw)
            if (clean.isBlank()) throw PmParseException("Escribe o escanea un problema matemático", 0)
            return PmParser(PmLexer(clean).tokenize()).parseTop()
        }

        fun collectVars(expr: PmExpr): List<String> {
            val set = LinkedHashSet<String>()
            fun walk(e: PmExpr) {
                when (e) {
                    is PmExpr.Sym -> set.add(e.name)
                    is PmExpr.Neg -> walk(e.inner)
                    is PmExpr.Add -> { walk(e.left); walk(e.right) }
                    is PmExpr.Sub -> { walk(e.left); walk(e.right) }
                    is PmExpr.Mul -> { walk(e.left); walk(e.right) }
                    is PmExpr.Div -> { walk(e.num); walk(e.den) }
                    is PmExpr.Pow -> { walk(e.base); walk(e.exp) }
                    is PmExpr.Root -> { walk(e.radicand); e.index?.let(::walk) }
                    is PmExpr.Abs -> walk(e.inner)
                    is PmExpr.Func -> e.args.forEach(::walk)
                    is PmExpr.Deriv -> walk(e.body)
                    is PmExpr.Integral -> { walk(e.body); e.lower?.let(::walk); e.upper?.let(::walk) }
                    is PmExpr.Limit -> { walk(e.body); walk(e.target) }
                    is PmExpr.Rel -> { walk(e.left); walk(e.right) }
                    is PmExpr.System -> e.items.forEach(::walk)
                    else -> Unit
                }
            }
            walk(expr)
            return set.toList()
        }
    }
}

// ==============================================================================
// 5. EVALUADOR NUMÉRICO (REAL Y COMPLEJO) Y FORMATEADOR LIMPIO
// ==============================================================================

object PmEval {
    fun evalDouble(expr: PmExpr, vars: Map<String, Double> = emptyMap()): Double = when (expr) {
        is PmExpr.Num -> expr.rat.toDouble()
        is PmExpr.Sym -> vars[expr.name] ?: Double.NaN
        is PmExpr.Const -> when (expr.name) {
            "pi" -> Math.PI
            "e" -> Math.E
            "inf" -> Double.POSITIVE_INFINITY
            else -> Double.NaN
        }
        is PmExpr.Neg -> -evalDouble(expr.inner, vars)
        is PmExpr.Add -> evalDouble(expr.left, vars) + evalDouble(expr.right, vars)
        is PmExpr.Sub -> evalDouble(expr.left, vars) - evalDouble(expr.right, vars)
        is PmExpr.Mul -> evalDouble(expr.left, vars) * evalDouble(expr.right, vars)
        is PmExpr.Div -> evalDouble(expr.num, vars) / evalDouble(expr.den, vars)
        is PmExpr.Pow -> evalDouble(expr.base, vars).pow(evalDouble(expr.exp, vars))
        is PmExpr.Root -> {
            val x = evalDouble(expr.radicand, vars)
            val n = expr.index?.let { evalDouble(it, vars) } ?: 2.0
            if (n == 2.0) FastMath.sqrt(x)
            else if (x < 0.0 && n == floor(n) && n.toInt() % 2 != 0) -(-x).pow(1.0 / n)
            else x.pow(1.0 / n)
        }
        is PmExpr.Abs -> abs(evalDouble(expr.inner, vars))
        is PmExpr.Rel -> evalDouble(expr.left, vars) - evalDouble(expr.right, vars)
        is PmExpr.Func -> evalFunc(expr.name, expr.args.map { evalDouble(it, vars) })
        else -> Double.NaN
    }

    private fun evalFunc(name: String, args: List<Double>): Double {
        if (args.size == 2) {
            return when (name) {
                "log" -> FastMath.log(args[1]) / FastMath.log(args[0])
                "mod" -> if (args[1] == 0.0) Double.NaN else args[0] % args[1]
                "comb" -> {
                    val n = args[0].toInt(); val k = args[1].toInt()
                    if (n >= 0 && k in 0..n && args[0] == n.toDouble() && args[1] == k.toDouble()) {
                        ExactMath.comb(n, k).toDouble()
                    } else Double.NaN
                }
                "var" -> {
                    val n = args[0].toInt(); val k = args[1].toInt()
                    if (n >= 0 && k in 0..n && args[0] == n.toDouble() && args[1] == k.toDouble()) {
                        ExactMath.variation(n, k).toDouble()
                    } else Double.NaN
                }
                "combrep" -> {
                    val n = args[0].toInt(); val k = args[1].toInt()
                    if (n >= 1 && k >= 0 && args[0] == n.toDouble() && args[1] == k.toDouble()) {
                        ExactMath.comb(n + k - 1, k).toDouble()
                    } else Double.NaN
                }
                "varrep" -> {
                    val n = args[0].toInt(); val k = args[1].toInt()
                    if (n >= 0 && k >= 0 && args[0] == n.toDouble() && args[1] == k.toDouble()) {
                        BigInteger.valueOf(n.toLong()).pow(k).toDouble()
                    } else Double.NaN
                }
                else -> Double.NaN
            }
        }
        if (args.size != 1) return Double.NaN
        val x = args[0]
        return when (name) {
            "sin" -> FastMath.sin(x)
            "cos" -> FastMath.cos(x)
            "tan" -> FastMath.tan(x)
            "cot" -> 1.0 / FastMath.tan(x)
            "sec" -> 1.0 / FastMath.cos(x)
            "csc" -> 1.0 / FastMath.sin(x)
            "asin" -> FastMath.asin(x)
            "acos" -> FastMath.acos(x)
            "atan" -> FastMath.atan(x)
            "sinh" -> FastMath.sinh(x)
            "cosh" -> FastMath.cosh(x)
            "tanh" -> FastMath.tanh(x)
            "ln" -> FastMath.log(x)
            "log10" -> FastMath.log10(x)
            "log" -> FastMath.log10(x)
            "exp" -> FastMath.exp(x)
            "floor" -> floor(x)
            "ceil" -> ceil(x)
            "round" -> round(x)
            "perm", "factorial" -> {
                val n = x.toInt()
                if (x.isNaN() || x < 0.0 || x > 170.0 || x != n.toDouble()) Double.NaN
                else CombinatoricsUtils.factorialDouble(n)
            }
            else -> Double.NaN
        }
    }

    fun evalComplex(expr: PmExpr, vars: Map<String, Complex> = emptyMap()): Complex = when (expr) {
        is PmExpr.Num -> Complex(expr.rat.toDouble(), 0.0)
        is PmExpr.Sym -> vars[expr.name] ?: Complex.NaN
        is PmExpr.Const -> when (expr.name) {
            "pi" -> Complex(Math.PI, 0.0)
            "e" -> Complex(Math.E, 0.0)
            "i" -> Complex.I
            else -> Complex.NaN
        }
        is PmExpr.Neg -> evalComplex(expr.inner, vars).negate()
        is PmExpr.Add -> evalComplex(expr.left, vars).add(evalComplex(expr.right, vars))
        is PmExpr.Sub -> evalComplex(expr.left, vars).subtract(evalComplex(expr.right, vars))
        is PmExpr.Mul -> evalComplex(expr.left, vars).multiply(evalComplex(expr.right, vars))
        is PmExpr.Div -> evalComplex(expr.num, vars).divide(evalComplex(expr.den, vars))
        is PmExpr.Pow -> evalComplex(expr.base, vars).pow(evalComplex(expr.exp, vars))
        is PmExpr.Root -> {
            val z = evalComplex(expr.radicand, vars)
            if (expr.index == null) z.sqrt() else z.pow(Complex.ONE.divide(evalComplex(expr.index, vars)))
        }
        is PmExpr.Abs -> Complex(evalComplex(expr.inner, vars).abs(), 0.0)
        is PmExpr.Func -> if (expr.args.size == 1) {
            val z = evalComplex(expr.args[0], vars)
            when (expr.name) {
                "sin" -> z.sin()
                "cos" -> z.cos()
                "tan" -> z.tan()
                "exp" -> z.exp()
                "ln" -> z.log()
                "log", "log10" -> z.log().divide(FastMath.log(10.0))
                else -> Complex.NaN
            }
        } else Complex.NaN
        else -> Complex.NaN
    }

    fun evalExactRational(expr: PmExpr): BigRat? = when (expr) {
        is PmExpr.Num -> expr.rat
        is PmExpr.Neg -> evalExactRational(expr.inner)?.unaryMinus()
        is PmExpr.Add -> {
            val a = evalExactRational(expr.left)
            val b = evalExactRational(expr.right)
            if (a != null && b != null) a + b else null
        }
        is PmExpr.Sub -> {
            val a = evalExactRational(expr.left)
            val b = evalExactRational(expr.right)
            if (a != null && b != null) a - b else null
        }
        is PmExpr.Mul -> {
            val a = evalExactRational(expr.left)
            val b = evalExactRational(expr.right)
            if (a != null && b != null) a * b else null
        }
        is PmExpr.Div -> {
            val a = evalExactRational(expr.num)
            val b = evalExactRational(expr.den)
            if (a != null && b != null && !b.isZero) a / b else null
        }
        is PmExpr.Pow -> {
            val a = evalExactRational(expr.base)
            val b = evalExactRational(expr.exp)
            if (a != null && b != null && b.isInt) {
                val e = b.num.toInt()
                if (e in -16..16 && !(a.isZero && e < 0)) a.pow(e) else null
            } else null
        }
        is PmExpr.Root -> {
            if (expr.index != null) null
            else {
                val r = evalExactRational(expr.radicand)
                if (r != null && !r.isNegative) {
                    val sn = ExactMath.simplifySqrt(r.num)
                    val sd = ExactMath.simplifySqrt(r.den)
                    if (sn.isExactInt && sd.isExactInt) BigRat.of(sn.outside, sd.outside) else null
                } else null
            }
        }
        is PmExpr.Abs -> evalExactRational(expr.inner)?.abs()
        is PmExpr.Func -> when {
            (expr.name == "factorial" || expr.name == "perm") && expr.args.size == 1 -> {
                val a = evalExactRational(expr.args[0])
                if (a != null && a.isInt && a.num >= BigInteger.ZERO && a.num <= BigInteger.valueOf(60L)) {
                    BigRat.of(ExactMath.factorial(a.num.toInt()))
                } else null
            }
            expr.name == "comb" && expr.args.size == 2 -> {
                val n = evalExactRational(expr.args[0]); val k = evalExactRational(expr.args[1])
                if (n != null && k != null && n.isInt && k.isInt && n.num >= BigInteger.ZERO && k.num >= BigInteger.ZERO && k.num <= n.num && n.num <= BigInteger.valueOf(100L)) {
                    BigRat.of(ExactMath.comb(n.num.toInt(), k.num.toInt()))
                } else null
            }
            expr.name == "var" && expr.args.size == 2 -> {
                val n = evalExactRational(expr.args[0]); val k = evalExactRational(expr.args[1])
                if (n != null && k != null && n.isInt && k.isInt && n.num >= BigInteger.ZERO && k.num >= BigInteger.ZERO && k.num <= n.num && n.num <= BigInteger.valueOf(80L)) {
                    BigRat.of(ExactMath.variation(n.num.toInt(), k.num.toInt()))
                } else null
            }
            expr.name == "combrep" && expr.args.size == 2 -> {
                val n = evalExactRational(expr.args[0]); val k = evalExactRational(expr.args[1])
                if (n != null && k != null && n.isInt && k.isInt && n.num >= BigInteger.ONE && k.num >= BigInteger.ZERO && (n.num.toInt() + k.num.toInt()) <= 100) {
                    BigRat.of(ExactMath.comb(n.num.toInt() + k.num.toInt() - 1, k.num.toInt()))
                } else null
            }
            expr.name == "varrep" && expr.args.size == 2 -> {
                val n = evalExactRational(expr.args[0]); val k = evalExactRational(expr.args[1])
                if (n != null && k != null && n.isInt && k.isInt && n.num >= BigInteger.ZERO && k.num >= BigInteger.ZERO && k.num <= BigInteger.valueOf(40L)) {
                    BigRat.of(n.num.pow(k.num.toInt()))
                } else null
            }
            else -> null
        }
        else -> null
    }

    fun formatComplex(z: Complex): String {
        if (z.isNaN) return "Indefinido"
        val re = if (abs(z.real) < 1e-10) 0.0 else z.real
        val im = if (abs(z.imaginary) < 1e-10) 0.0 else z.imaginary
        if (im == 0.0) return formatDecimal(re)
        val imAbs = formatDecimal(abs(im))
        val imPart = if (imAbs == "1") "i" else "${imAbs}i"
        if (re == 0.0) return if (im < 0) "-$imPart" else imPart
        return "${formatDecimal(re)} ${if (im < 0) "-" else "+"} $imPart"
    }
}

object PmFormatter {
    fun format(expr: PmExpr, parentPrec: Int = 0): String = when (expr) {
        is PmExpr.Num -> expr.rat.toString()
        is PmExpr.Sym -> expr.name
        is PmExpr.Const -> when (expr.name) {
            "pi" -> "π"
            "inf" -> "∞"
            else -> expr.name
        }
        is PmExpr.Neg -> {
            val inner = format(expr.inner, 70)
            val s = if (expr.inner is PmExpr.Add || expr.inner is PmExpr.Sub) "-($inner)" else "-$inner"
            if (parentPrec > 70) "($s)" else s
        }
        is PmExpr.Add -> {
            val l = format(expr.left, 50)
            val r = format(expr.right, 50)
            val s = if (r.startsWith("-")) "$l - ${r.drop(1)}" else "$l + $r"
            if (50 < parentPrec) "($s)" else s
        }
        is PmExpr.Sub -> {
            val l = format(expr.left, 50)
            val r = format(expr.right, 51)
            val s = "$l - $r"
            if (50 < parentPrec) "($s)" else s
        }
        is PmExpr.Mul -> {
            val l = format(expr.left, 60)
            val r = format(expr.right, 60)
            val implicit = isImplicit(expr.left, expr.right)
            val s = if (implicit) "$l$r" else "$l·$r"
            if (60 < parentPrec) "($s)" else s
        }
        is PmExpr.Div -> {
            val l = format(expr.num, 61)
            val r = format(expr.den, 61)
            val s = "$l/$r"
            if (60 < parentPrec) "($s)" else s
        }
        is PmExpr.Pow -> {
            val b = format(expr.base, 81)
            val e = format(expr.exp, 80)
            val s = "$b^$e"
            if (80 < parentPrec) "($s)" else s
        }
        is PmExpr.Root -> {
            val rad = format(expr.radicand, 0)
            if (expr.index == null) {
                val simple = expr.radicand is PmExpr.Num || expr.radicand is PmExpr.Sym || expr.radicand is PmExpr.Const
                if (simple) "√$rad" else "√($rad)"
            } else {
                "nthrt(${format(expr.index, 0)}, $rad)"
            }
        }
        is PmExpr.Abs -> "|${format(expr.inner, 0)}|"
        is PmExpr.Func -> {
            if (expr.name == "factorial" && expr.args.size == 1) {
                val a = format(expr.args[0], 90)
                "$a!"
            } else if (expr.name == "log" && expr.args.size == 2) {
                "log_${format(expr.args[0], 90)}(${format(expr.args[1], 0)})"
            } else {
                val displayName = when (expr.name) {
                    "comb" -> "C"
                    "var" -> "V"
                    "perm" -> "P"
                    "combrep" -> "CR"
                    "varrep" -> "VR"
                    "log10" -> "log"
                    else -> expr.name
                }
                "$displayName(${expr.args.joinToString(", ") { format(it, 0) }})"
            }
        }
        is PmExpr.Deriv -> "d/d${expr.variable}(${format(expr.body, 0)})"
        is PmExpr.Integral -> {
            val bounds = if (expr.lower != null && expr.upper != null) "[${format(expr.lower, 0)}, ${format(expr.upper, 0)}]" else ""
            "∫$bounds(${format(expr.body, 0)}) d${expr.variable}"
        }
        is PmExpr.Limit -> "lim(${expr.variable}→${format(expr.target, 0)}) ${format(expr.body, 0)}"
        is PmExpr.Rel -> {
            val sym = when (expr.op) {
                "<=" -> "≤"
                ">=" -> "≥"
                else -> expr.op
            }
            "${format(expr.left, 0)} $sym ${format(expr.right, 0)}"
        }
        is PmExpr.System -> expr.items.joinToString(" ; ") { format(it, 0) }
    }

    private fun isImplicit(l: PmExpr, r: PmExpr): Boolean {
        val leftNum = l is PmExpr.Num || (l is PmExpr.Neg && l.inner is PmExpr.Num)
        val rightSym = r is PmExpr.Sym || r is PmExpr.Const || r is PmExpr.Root || r is PmExpr.Func ||
            (r is PmExpr.Pow && (r.base is PmExpr.Sym || r.base is PmExpr.Const))
        return leftNum && rightSym
    }
}
