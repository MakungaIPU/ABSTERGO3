package com.abstergo.app.labs.photomath

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abstergo.app.RedDot
import com.abstergo.app.labs.AbsLabCodec
import com.abstergo.app.labs.LabExercise
import com.abstergo.app.labs.MATH_LAB_SAMPLES
import com.abstergo.app.labs.PmHistoryEntry
import com.abstergo.app.labs.loadPmHistory
import com.abstergo.app.labs.savePmHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private enum class LabDockTab(val label: String, val icon: LabIconKind) {
    SCANNER("Escáner", LabIconKind.CAMERA),
    CALCULATOR("Calculadora", LabIconKind.CALCULATOR),
    PREU_LAB("Lab 10-12", LabIconKind.LAB_CUBE),
    HISTORY("Historial", LabIconKind.HISTORY)
}

/**
 * Matemática Labs: Clon completo de Photomath con estética de laboratorio Abstergo.
 * - Barra dock inferior intuitiva (Escáner · Calculadora · Lab 10-12 · Historial)
 * - Hoja de solución Photomath con múltiples métodos, Play paso a paso, subpasos "Explicar cómo"
 *   y gráfica 2D interactiva a 60 fps
 */
@Composable
fun PhotomathLabScreen(
    allExercises: List<LabExercise>,
    authorName: String,
    onBackToLabs: () -> Unit,
    onChangeExercises: (List<LabExercise>) -> Unit,
    onImportAbsLabClick: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val mathExercises = remember(allExercises) { allExercises.filter { it.subject == "m" } }

    var activeTab by remember { mutableStateOf(LabDockTab.CALCULATOR) }
    var showingSolution by remember { mutableStateOf(false) }
    var calcPrefill by remember { mutableStateOf("") }
    var activeInput by remember { mutableStateOf("") }
    var activeSolution by remember { mutableStateOf<PmSolution?>(null) }
    var solving by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf<List<PmHistoryEntry>>(emptyList()) }

    LaunchedEffect(Unit) {
        history = withContext(Dispatchers.IO) { loadPmHistory(ctx) }
    }

    fun solveAndOpen(exprText: String) {
        val clean = exprText.trim()
        if (clean.isEmpty()) return
        activeInput = clean
        showingSolution = true
        solving = true
        scope.launch {
            val sol = withContext(Dispatchers.Default) { PmSolver.solve(clean) }
            activeSolution = sol
            solving = false
            if (sol.ok) {
                val ans = sol.methods.firstOrNull()?.finalAnswer.orEmpty()
                val entry = PmHistoryEntry(
                    id = UUID.randomUUID().toString(),
                    expression = clean,
                    answer = ans,
                    category = sol.categoryTitle,
                    timestamp = System.currentTimeMillis()
                )
                val updated = (listOf(entry) + history.filterNot { it.expression == clean }).take(60)
                history = updated
                withContext(Dispatchers.IO) { savePmHistory(ctx, updated) }
            }
        }
    }

    if (showingSolution) {
        BackHandler {
            calcPrefill = activeInput
            showingSolution = false
        }
        PmSolutionScreen(
            inputText = activeInput,
            solution = activeSolution,
            loading = solving,
            onBack = {
                calcPrefill = activeInput
                showingSolution = false
            },
            onEditInCalc = {
                calcPrefill = activeInput
                showingSolution = false
                activeTab = LabDockTab.CALCULATOR
            },
            onOpenCamera = {
                showingSolution = false
                activeTab = LabDockTab.SCANNER
            },
            onSaveToLabs = { sol ->
                val ans = sol.methods.firstOrNull()?.finalAnswer.orEmpty()
                val ex = LabExercise(
                    id = UUID.randomUUID().toString(),
                    subject = "m",
                    title = sol.categoryTitle.ifBlank { activeInput.take(40) },
                    prompt = if (ans.isNotBlank()) "Resultado: $ans" else "",
                    expression = activeInput,
                    source = "photomath"
                )
                onChangeExercises(allExercises + ex)
                Toast.makeText(ctx, "Guardado en tus ejercicios de Matemática Labs", Toast.LENGTH_SHORT).show()
            }
        )
        return
    }

    val accent = labAccent()
    val onAccent = labOnAccent()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Contenido principal con transición suave
        AnimatedContent(
            targetState = activeTab,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            transitionSpec = { fadeIn(tween(180)) togetherWith fadeOut(tween(140)) },
            label = "lab_tab"
        ) { tab ->
            when (tab) {
                LabDockTab.SCANNER -> PmCameraScannerScreen(
                    onBackToLabs = onBackToLabs,
                    onOpenCalculator = { prefill ->
                        calcPrefill = prefill
                        activeTab = LabDockTab.CALCULATOR
                    },
                    onImportAbsLab = onImportAbsLabClick,
                    onSolvedFormula = { formula -> solveAndOpen(formula) }
                )

                LabDockTab.CALCULATOR -> {
                    BackHandler { onBackToLabs() }
                    PmCalculatorScreen(
                        initialInput = calcPrefill,
                        onBackToLabs = onBackToLabs,
                        onImportAbsLab = onImportAbsLabClick,
                        onSolve = { expr -> solveAndOpen(expr) }
                    )
                }

                LabDockTab.PREU_LAB -> {
                    PmPreuHubScreen(
                        onBack = { activeTab = LabDockTab.CALCULATOR },
                        onSolveInPhotomath = { expr -> solveAndOpen(expr) }
                    )
                }

                LabDockTab.HISTORY -> {
                    BackHandler { activeTab = LabDockTab.CALCULATOR }
                    PmHistoryAndPacksScreen(
                        history = history,
                        savedExercises = mathExercises,
                        authorName = authorName,
                        onBackToLabs = onBackToLabs,
                        onSolveExpression = { expr -> solveAndOpen(expr) },
                        onClearHistory = {
                            history = emptyList()
                            scope.launch(Dispatchers.IO) { savePmHistory(ctx, emptyList()) }
                        },
                        onToggleExerciseDone = { ex ->
                            onChangeExercises(allExercises.map { if (it.id == ex.id) it.copy(done = !it.done, isNew = false) else it })
                        },
                        onMarkExerciseSeen = { ex ->
                            if (ex.isNew) onChangeExercises(allExercises.map { if (it.id == ex.id) it.copy(isNew = false) else it })
                        },
                        onDeleteExercise = { ex ->
                            onChangeExercises(allExercises.filterNot { it.id == ex.id })
                        },
                        onImportAbsLab = onImportAbsLabClick
                    )
                }
            }
        }

        // Dock inferior unificado estilo Photomath × Abstergo Lab
        Row(
            Modifier.fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                .padding(horizontal = 10.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LabDockTab.entries.forEach { item ->
                val selected = activeTab == item
                Row(
                    Modifier.clip(RoundedCornerShape(14.dp))
                        .background(if (selected) accent else Color.Transparent)
                        .clickable { activeTab = item }
                        .padding(horizontal = if (selected) 14.dp else 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LabIcon(
                        kind = item.icon,
                        color = if (selected) onAccent else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(19.dp)
                    )
                    if (selected) {
                        Text(item.label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = onAccent, maxLines = 1)
                    }
                }
            }
        }
    }
}

// ==============================================================================
// HOJA DE SOLUCIÓN PHOTOMATH × ABSTERGO (MÉTODOS + PLAY + SUBPASOS + GRÁFICA)
// ==============================================================================
@Composable
private fun PmSolutionScreen(
    inputText: String,
    solution: PmSolution?,
    loading: Boolean,
    onBack: () -> Unit,
    onEditInCalc: () -> Unit,
    onOpenCamera: () -> Unit,
    onSaveToLabs: (PmSolution) -> Unit
) {
    val accent = labAccent()
    val onAccent = labOnAccent()
    var selectedMethodIdx by remember(solution) { mutableStateOf(0) }
    var stepsExpanded by remember(solution) { mutableStateOf(true) }
    var playMode by remember(solution, selectedMethodIdx) { mutableStateOf(false) }
    var isPlaying by remember(solution, selectedMethodIdx) { mutableStateOf(false) }
    var visibleCount by remember(solution, selectedMethodIdx) { mutableStateOf(1) }
    var expandedSubSteps by remember(solution, selectedMethodIdx) { mutableStateOf(setOf<Int>()) }
    var fullscreenGraph by remember { mutableStateOf(false) }

    val currentMethod = solution?.methods?.getOrNull(selectedMethodIdx.coerceIn(0, (solution.methods.lastIndex).coerceAtLeast(0)))
    val totalSteps = currentMethod?.steps?.size ?: 0

    LaunchedEffect(isPlaying, totalSteps) {
        if (!isPlaying || totalSteps == 0) return@LaunchedEffect
        if (visibleCount >= totalSteps) visibleCount = 1
        while (isPlaying && visibleCount < totalSteps) {
            delay(1300)
            visibleCount++
        }
        isPlaying = false
    }

    if (fullscreenGraph && solution?.plot != null) {
        BackHandler { fullscreenGraph = false }
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Gráfica interactiva", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                OutlinedButton({ fullscreenGraph = false }, shape = RoundedCornerShape(12.dp)) { Text("Cerrar") }
            }
            Spacer(Modifier.height(8.dp))
            PmInteractiveGraph(plot = solution.plot, modifier = Modifier.fillMaxWidth().weight(1f))
        }
        return
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Cabecera limpia con iconos vectoriales
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) { LabIcon(LabIconKind.BACK, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp)) }
            Spacer(Modifier.width(10.dp))
            Text("Solución paso a paso", fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
                    .clickable { onOpenCamera() },
                contentAlignment = Alignment.Center
            ) { LabIcon(LabIconKind.CAMERA, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp)) }
            if (solution != null && solution.ok) {
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(38.dp).clip(CircleShape).background(accent.copy(alpha = 0.16f))
                        .clickable { onSaveToLabs(solution) },
                    contentAlignment = Alignment.Center
                ) { LabIcon(LabIconKind.SAVE, accent, Modifier.size(18.dp)) }
            }
        }

        if (loading || solution == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = accent)
                    Spacer(Modifier.height(12.dp))
                    Text("Analizando en Matemática Labs…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            return
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1) Tarjeta del problema original en 2D con fondo blueprint sutil
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
            ) {
                LabBlueprintGrid(Modifier.matchParentSize())
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            solution.categoryTitle.uppercase().ifBlank { "PROBLEMA MATEMÁTICO" },
                            fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = accent
                        )
                        Spacer(Modifier.height(6.dp))
                        PmMathFormulaView(inputText, fontSize = 22.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Row(
                        Modifier.clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.85f))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .clickable { onEditInCalc() }
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LabIcon(LabIconKind.EDIT, MaterialTheme.colorScheme.onSurface, Modifier.size(14.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("Editar", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (!solution.ok || currentMethod == null) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.errorContainer).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("No se pudo interpretar el problema", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                    Text(solution.error ?: "Revisa la sintaxis de tu expresión.", color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 14.sp)
                    Button(onEditInCalc, shape = RoundedCornerShape(12.dp)) { Text("Corregir en Calculadora") }
                }
                return@Column
            }

            // 2) Tarjeta Hero de Solución estilo Photomath × Abstergo
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.5.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("SOLUCIÓN", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp, color = accent)
                PmMathFormulaView(
                    text = currentMethod.finalAnswer,
                    fontSize = 25.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (currentMethod.altForms.isNotEmpty()) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    currentMethod.altForms.forEach { (label, value) ->
                        Column {
                            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            PmMathFormulaView(value, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }

                if (currentMethod.intervals.isNotEmpty()) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Text("Recta numérica", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    InequalityNumberLine(currentMethod.intervals)
                }

                // Botón principal Photomath + botón Play paso a paso
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            stepsExpanded = !stepsExpanded
                            if (stepsExpanded) { playMode = false; isPlaying = false }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = accent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Text(
                            if (stepsExpanded) "Ocultar pasos" else "Mostrar pasos (${currentMethod.steps.size})",
                            fontWeight = FontWeight.Bold, color = onAccent
                        )
                    }
                    if (totalSteps > 1) {
                        OutlinedButton(
                            onClick = {
                                stepsExpanded = true
                                playMode = true
                                visibleCount = 1
                                isPlaying = true
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            LabIcon(LabIconKind.PLAY, accent, Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Play", fontWeight = FontWeight.Bold, color = accent)
                        }
                    }
                }
            }

            // 3) Selector de métodos estilo Photomath
            if (solution.methods.size > 1) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Método de resolución", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        solution.methods.forEachIndexed { idx, m ->
                            val sel = idx == selectedMethodIdx
                            Box(
                                Modifier.clip(RoundedCornerShape(12.dp))
                                    .background(if (sel) accent else MaterialTheme.colorScheme.surface)
                                    .border(1.dp, if (sel) accent else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                                    .clickable { selectedMethodIdx = idx; playMode = false; isPlaying = false }
                                    .padding(horizontal = 14.dp, vertical = 9.dp)
                            ) {
                                Text(
                                    m.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (sel) onAccent else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // 4) Pasos de la solución (modo completo Photomath o modo Play animado)
            AnimatedVisibility(visible = stepsExpanded) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (playMode && totalSteps > 1) {
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                .background(accent.copy(alpha = 0.12f)).padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                enabled = visibleCount > 1,
                                onClick = { isPlaying = false; visibleCount = (visibleCount - 1).coerceAtLeast(1) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) { Text("◀") }
                            Button(
                                onClick = { isPlaying = !isPlaying },
                                colors = ButtonDefaults.buttonColors(containerColor = accent),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                LabIcon(if (isPlaying) LabIconKind.PAUSE else LabIconKind.PLAY, onAccent, Modifier.size(14.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Paso $visibleCount de $totalSteps", color = onAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            OutlinedButton(
                                enabled = visibleCount < totalSteps,
                                onClick = { isPlaying = false; visibleCount = (visibleCount + 1).coerceAtMost(totalSteps) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) { Text("▶") }
                            TextButton({ playMode = false; isPlaying = false }) { Text("Todos", fontSize = 12.sp) }
                        }
                    } else {
                        Text("Pasos · ${currentMethod.name}", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }

                    val stepsToRender = if (playMode) currentMethod.steps.take(visibleCount) else currentMethod.steps
                    stepsToRender.forEach { step ->
                        val showSubs = step.index in expandedSubSteps
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(
                                    width = if (playMode && step.index == visibleCount) 1.5.dp else 1.dp,
                                    color = if (playMode && step.index == visibleCount) accent else MaterialTheme.colorScheme.outlineVariant,
                                    shape = RoundedCornerShape(18.dp)
                                )
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(26.dp).clip(CircleShape).background(accent),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("${step.index}", color = onAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(step.actionTitle, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            }

                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                PmMathFormulaView(
                                    text = step.mathText,
                                    fontSize = 20.sp,
                                    highlightSegment = step.highlightSegment
                                )
                            }

                            if (step.detail.isNotBlank()) {
                                Text(step.detail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 19.sp)
                            }

                            if (step.subSteps.isNotEmpty()) {
                                Row(
                                    Modifier.clip(RoundedCornerShape(10.dp))
                                        .background(accent.copy(alpha = 0.12f))
                                        .clickable {
                                            expandedSubSteps = if (showSubs) expandedSubSteps - step.index else expandedSubSteps + step.index
                                        }
                                        .padding(horizontal = 12.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        if (showSubs) "Ocultar explicación ▲" else "Explicar cómo ▼",
                                        fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent
                                    )
                                }
                                AnimatedVisibility(visible = showSubs) {
                                    Column(
                                        Modifier.fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.background)
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        step.subSteps.forEach { sub ->
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Text(sub.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent)
                                                PmMathFormulaView(sub.mathText, fontSize = 16.sp)
                                                if (sub.note.isNotBlank()) {
                                                    Text(sub.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5) Gráfica interactiva 2D a 60 fps
            val plot = solution.plot
            if (plot != null && plot.curves.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Gráfica interactiva", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("Toca para medir (x, y)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    PmInteractiveGraph(
                        plot = plot,
                        modifier = Modifier.fillMaxWidth().height(310.dp),
                        onExpandFullscreen = { fullscreenGraph = true }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

// ==============================================================================
// HISTORIAL + GUÍAS .abslab
// ==============================================================================
@Composable
private fun PmHistoryAndPacksScreen(
    history: List<PmHistoryEntry>,
    savedExercises: List<LabExercise>,
    authorName: String,
    onBackToLabs: () -> Unit,
    onSolveExpression: (String) -> Unit,
    onClearHistory: () -> Unit,
    onToggleExerciseDone: (LabExercise) -> Unit,
    onMarkExerciseSeen: (LabExercise) -> Unit,
    onDeleteExercise: (LabExercise) -> Unit,
    onImportAbsLab: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val accent = labAccent()
    var tab by remember { mutableStateOf(0) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val toExport = if (savedExercises.isEmpty()) MATH_LAB_SAMPLES else savedExercises
                    val json = AbsLabCodec.encode("Matemática Labs", "m", authorName, toExport)
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (_: Exception) { false }
            }
            Toast.makeText(ctx, if (ok) "Paquete .abslab exportado." else "Error al exportar.", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
                    .clickable { onBackToLabs() },
                contentAlignment = Alignment.Center
            ) { LabIcon(LabIconKind.BACK, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp)) }
            Spacer(Modifier.width(10.dp))
            Text("Historial y Guías", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Historial (${history.size})") }, modifier = Modifier.weight(1f))
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Guías .abslab (${savedExercises.size})") }, modifier = Modifier.weight(1f))
        }

        if (tab == 0) {
            if (history.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Aún no has resuelto problemas.\nEscanea una ecuación o escríbela en la Calculadora 2D.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item(key = "__clear_hist__") {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClearHistory) { Text("Limpiar historial", fontSize = 12.sp) }
                        }
                    }
                    items(history, key = { it.id }) { h ->
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .clickable { onSolveExpression(h.expression) }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(h.category, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = accent)
                            PmMathFormulaView(h.expression, fontSize = 18.sp, scrollable = false)
                            if (h.answer.isNotBlank()) {
                                Text("= ${h.answer}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item(key = "__abslab_btns__") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onImportAbsLab, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Importar .abslab", fontSize = 12.sp) }
                        OutlinedButton({ exportLauncher.launch("matematica_labs.abslab") }, Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("Exportar .abslab", fontSize = 12.sp) }
                    }
                }
                val listToShow = if (savedExercises.isEmpty()) MATH_LAB_SAMPLES else savedExercises
                items(listToShow, key = { it.id }) { ex ->
                    val isReal = savedExercises.any { it.id == ex.id }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .clickable {
                                if (isReal) onMarkExerciseSeen(ex)
                                onSolveExpression(ex.expression.ifBlank { ex.title })
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isReal) {
                            Box(
                                Modifier.size(28.dp).clip(CircleShape)
                                    .background(if (ex.done) accent else Color.Transparent)
                                    .border(2.dp, accent, CircleShape)
                                    .clickable { onToggleExerciseDone(ex) },
                                contentAlignment = Alignment.Center
                            ) { if (ex.done) Text("✓", color = labOnAccent(), fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.width(10.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(
                                ex.title, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                                textDecoration = if (ex.done) TextDecoration.LineThrough else null,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(ex.expression, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (ex.prompt.isNotBlank()) Text(ex.prompt, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        if (ex.isNew) { Spacer(Modifier.width(8.dp)); RedDot() }
                        if (isReal) {
                            Text("✕", Modifier.clickable { onDeleteExercise(ex) }.padding(8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
