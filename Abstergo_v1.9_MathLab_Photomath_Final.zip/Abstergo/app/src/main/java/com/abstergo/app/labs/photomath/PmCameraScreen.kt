package com.abstergo.app.labs.photomath

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.RectF
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.abstergo.app.labs.ocr.MathOcrEngine
import com.abstergo.app.labs.ocr.OcrModelStatus
import com.abstergo.app.labs.ocr.OcrResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Escáner de cámara Photomath × Abstergo Labs:
 * - Visor redimensionable arrastrando el dedo para 1 línea o sistema completo
 * - Esquinas y haz láser en verde menta Abstergo (#86FF8E)
 * - Iconos vectoriales limpios (linterna, galería, disparador) sin emojis
 */
@Composable
fun PmCameraScannerScreen(
    onBackToLabs: () -> Unit,
    onOpenCalculator: (prefill: String) -> Unit,
    onImportAbsLab: () -> Unit,
    onSolvedFormula: (String) -> Unit
) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val ocrStatus = remember { MathOcrEngine.checkStatus(ctx) }
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val reqPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) reqPerm.launch(Manifest.permission.CAMERA) }

    DisposableEffect(Unit) {
        onDispose { MathOcrEngine.releaseAsync() }
    }

    var boxWidthFrac by remember { mutableStateOf(0.84f) }
    var boxHeightFrac by remember { mutableStateOf(0.22f) }
    var screenSize by remember { mutableStateOf(IntSize(1080, 1920)) }

    var camera by remember { mutableStateOf<Camera?>(null) }
    var torchOn by remember { mutableStateOf(false) }
    var scanning by remember { mutableStateOf(false) }
    var ocrReview by remember { mutableStateOf<OcrResult?>(null) }
    var editableText by remember { mutableStateOf("") }

    BackHandler {
        if (ocrReview != null) ocrReview = null else onBackToLabs()
    }

    fun currentCropRect(): RectF {
        val hw = boxWidthFrac / 2f
        val hh = boxHeightFrac / 2f
        val cy = 0.45f
        return RectF(
            (0.5f - hw).coerceIn(0.05f, 0.44f),
            (cy - hh).coerceIn(0.12f, 0.42f),
            (0.5f + hw).coerceIn(0.56f, 0.95f),
            (cy + hh).coerceIn(0.48f, 0.76f)
        )
    }

    fun runOcr(file: File, applyCrop: Boolean) {
        scanning = true
        scope.launch {
            val res = MathOcrEngine.recognizeFile(ctx, file, if (applyCrop) currentCropRect() else null)
            withContext(Dispatchers.IO) { file.delete() }
            scanning = false
            ocrReview = res
            editableText = if (res.ok) res.normalizedMath else ""
        }
    }

    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scanning = true
        scope.launch {
            val tmp = withContext(Dispatchers.IO) {
                try {
                    val f = File(ctx.cacheDir, "pm_pick_${System.currentTimeMillis()}.jpg")
                    ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    f
                } catch (_: Exception) { null }
            }
            if (tmp != null && tmp.exists()) runOcr(tmp, applyCrop = false)
            else {
                scanning = false
                Toast.makeText(ctx, "No se pudo leer la foto.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val neonMint = Color(0xFF86FF8E)
    val accent = labAccent()
    val onAccent = labOnAccent()

    if (!granted) {
        Box(Modifier.fillMaxSize().background(Color(0xFF0B0F12))) {
            LabBlueprintGrid(Modifier.fillMaxSize())
            Column(
                Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)).background(neonMint.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    LabIcon(LabIconKind.CAMERA, neonMint, Modifier.size(38.dp))
                }
                Spacer(Modifier.height(18.dp))
                Text("Escáner de Matemática Labs", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Permite acceso a la cámara para escanear ecuaciones impresas o manuscritas 100% offline.",
                    color = Color(0xFFB6C2CE), textAlign = TextAlign.Center, lineHeight = 21.sp, fontSize = 14.sp
                )
                Spacer(Modifier.height(22.dp))
                Button(
                    onClick = { reqPerm.launch(Manifest.permission.CAMERA) },
                    colors = ButtonDefaults.buttonColors(containerColor = neonMint),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) { Text("Activar cámara", fontWeight = FontWeight.Bold, color = Color(0xFF07210D)) }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onOpenCalculator("") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text("Ir a Calculadora 2D", color = Color.White) }
            }
        }
        return
    }

    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val selector = remember {
        ResolutionSelector.Builder()
            .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
            .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
            .build()
    }
    val capture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setResolutionSelector(selector)
            .build()
    }

    DisposableEffect(owner) {
        val future = ProcessCameraProvider.getInstance(ctx)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val preview = Preview.Builder().setResolutionSelector(selector).build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                p.unbindAll()
                camera = p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            } catch (_: Exception) {
                Toast.makeText(ctx, "No se pudo iniciar la cámara.", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { provider?.unbindAll() }
    }

    LaunchedEffect(torchOn, camera) {
        camera?.cameraControl?.enableTorch(torchOn)
    }

    fun takePhoto() {
        if (scanning) return
        if (ocrStatus is OcrModelStatus.MissingFiles) {
            Toast.makeText(ctx, "Modelo OCR offline no encontrado; usa la Calculadora 2D.", Toast.LENGTH_SHORT).show()
            onOpenCalculator("")
            return
        }
        scanning = true
        val f = File(ctx.cacheDir, "pm_scan_${System.currentTimeMillis()}.jpg")
        capture.takePicture(
            ImageCapture.OutputFileOptions.Builder(f).build(),
            ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) { runOcr(f, applyCrop = true) }
                override fun onError(e: ImageCaptureException) {
                    scanning = false
                    Toast.makeText(ctx, "Error al capturar foto.", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    val scanTransition = rememberInfiniteTransition(label = "scan")
    val scanProgress by scanTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(850, easing = LinearEasing), RepeatMode.Reverse),
        label = "laser"
    )

    Box(Modifier.fillMaxSize().background(Color.Black).onSizeChanged { screenSize = it }) {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { previewView })

        // Enfoque táctil + redimensionar visor arrastrando
        Box(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { pos ->
                        val c = camera ?: return@detectTapGestures
                        val pt = previewView.meteringPointFactory.createPoint(pos.x, pos.y)
                        c.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures { _, drag ->
                        val w = screenSize.width.toFloat().coerceAtLeast(1f)
                        val h = screenSize.height.toFloat().coerceAtLeast(1f)
                        boxWidthFrac = (boxWidthFrac + (drag.x / w) * 1.4f).coerceIn(0.36f, 0.90f)
                        boxHeightFrac = (boxHeightFrac + (drag.y / h) * 1.4f).coerceIn(0.11f, 0.42f)
                    }
                }
        )

        // Visor Photomath con estética menta Abstergo
        Canvas(Modifier.fillMaxSize()) {
            val crop = currentCropRect()
            val l = size.width * crop.left
            val t = size.height * crop.top
            val r = size.width * crop.right
            val b = size.height * crop.bottom
            val dim = Color(0x9C070A0D)

            drawRect(dim, Offset(0f, 0f), Size(size.width, t))
            drawRect(dim, Offset(0f, b), Size(size.width, size.height - b))
            drawRect(dim, Offset(0f, t), Size(l, b - t))
            drawRect(dim, Offset(r, t), Size(size.width - r, b - t))

            val corner = 26.dp.toPx()
            val stroke = 4.dp.toPx()
            val cCol = if (scanning) neonMint else Color.White
            // 4 esquinas
            drawLine(cCol, Offset(l, t), Offset(l + corner, t), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(l, t), Offset(l, t + corner), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(r, t), Offset(r - corner, t), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(r, t), Offset(r, t + corner), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(l, b), Offset(l + corner, b), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(l, b), Offset(l, b - corner), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(r, b), Offset(r - corner, b), stroke, StrokeCap.Round)
            drawLine(cCol, Offset(r, b), Offset(r, b - corner), stroke, StrokeCap.Round)

            // Mira central
            val cx = (l + r) / 2f; val cy = (t + b) / 2f
            drawLine(neonMint.copy(alpha = 0.6f), Offset(cx - 12f, cy), Offset(cx + 12f, cy), 2f)
            drawLine(neonMint.copy(alpha = 0.6f), Offset(cx, cy - 12f), Offset(cx, cy + 12f), 2f)

            if (scanning) {
                val ly = t + (b - t) * scanProgress
                drawLine(neonMint.copy(alpha = 0.35f), Offset(l + 8f, ly), Offset(r - 8f, ly), 12f, StrokeCap.Round)
                drawLine(neonMint, Offset(l + 8f, ly), Offset(r - 8f, ly), 3.5f, StrokeCap.Round)
            }
        }

        // Barra superior flotante
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color(0x880B1015)).clickable { onBackToLabs() },
                contentAlignment = Alignment.Center
            ) { LabIcon(LabIconKind.BACK, Color.White, Modifier.size(18.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Escáner · Matemática Labs", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (ocrStatus is OcrModelStatus.Ready) "OCR Offline listo · Arrastra para ajustar el marco"
                    else "Arrastra para ajustar · Usa Calculadora 2D debajo",
                    color = neonMint.copy(alpha = 0.9f), fontSize = 11.sp
                )
            }
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0x880B1015))
                    .clickable { onImportAbsLab() }.padding(horizontal = 10.dp, vertical = 7.dp)
            ) { Text(".abslab", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
        }

        // Controles de disparo estilo Photomath sobre el dock inferior
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 18.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Color(0x990B1015)).padding(horizontal = 14.dp, vertical = 5.dp)
            ) {
                Text(
                    if (scanning) "Reconociendo ecuación offline…" else "Encuadra el ejercicio dentro del marco",
                    color = Color.White, fontSize = 12.sp
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Galería
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Color(0x990B1015))
                        .clickable { galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    contentAlignment = Alignment.Center
                ) { LabIcon(LabIconKind.GALLERY, Color.White, Modifier.size(22.dp)) }

                // Disparador central estilo Photomath con anillo Abstergo menta
                Box(
                    Modifier.size(74.dp).clip(CircleShape)
                        .border(4.dp, Color.White, CircleShape)
                        .padding(6.dp).clip(CircleShape)
                        .background(if (scanning) Color.Gray else neonMint)
                        .clickable(enabled = !scanning) { takePhoto() },
                    contentAlignment = Alignment.Center
                ) {
                    if (scanning) CircularProgressIndicator(Modifier.size(26.dp), color = Color(0xFF07210D), strokeWidth = 3.dp)
                    else LabIcon(LabIconKind.CAMERA, Color(0xFF07210D), Modifier.size(28.dp))
                }

                // Linterna
                Box(
                    Modifier.size(48.dp).clip(CircleShape)
                        .background(if (torchOn) neonMint else Color(0x990B1015))
                        .clickable { torchOn = !torchOn },
                    contentAlignment = Alignment.Center
                ) { LabIcon(LabIconKind.FLASH, if (torchOn) Color(0xFF07210D) else Color.White, Modifier.size(22.dp)) }
            }
        }
    }

    // Revisión rápida del resultado OCR
    ocrReview?.let { res ->
        AlertDialog(
            onDismissRequest = { ocrReview = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text(if (res.ok) "Ecuación escaneada (${res.elapsedMs} ms)" else "No se leyó con claridad") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (res.ok) {
                        if (editableText.isNotBlank()) {
                            Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp)
                            ) { PmMathFormulaView(editableText, fontSize = 20.sp) }
                        }
                        OutlinedTextField(
                            value = editableText,
                            onValueChange = { editableText = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Editar expresión") },
                            singleLine = true
                        )
                    } else {
                        Text(res.error ?: "Acércate un poco más con buena luz o escríbela en la Calculadora 2D.")
                    }
                }
            },
            confirmButton = {
                if (res.ok) {
                    Button(
                        onClick = {
                            val expr = editableText.trim()
                            ocrReview = null
                            if (expr.isNotEmpty()) onSolvedFormula(expr)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = accent),
                        shape = RoundedCornerShape(10.dp)
                    ) { Text("Resolver", fontWeight = FontWeight.Bold, color = onAccent) }
                } else {
                    TextButton({ ocrReview = null; onOpenCalculator("") }) { Text("Ir a Calculadora", fontWeight = FontWeight.Bold, color = accent) }
                }
            },
            dismissButton = {
                TextButton({
                    val cur = editableText.trim()
                    ocrReview = null
                    if (res.ok && cur.isNotEmpty()) onOpenCalculator(cur)
                }) { Text(if (res.ok) "Abrir en teclado" else "Reintentar") }
            }
        )
    }
}
