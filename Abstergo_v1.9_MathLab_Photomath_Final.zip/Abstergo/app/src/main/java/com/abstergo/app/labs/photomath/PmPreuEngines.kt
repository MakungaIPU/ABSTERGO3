package com.abstergo.app.labs.photomath

import androidx.compose.runtime.Immutable
import org.apache.commons.math3.complex.Complex
import java.math.BigInteger
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// ==============================================================================
// 1. INDUCCIÓN COMPLETA (PREUNIVERSITARIO 12MO GRADO)
//    - Sumatorias ∑ f(i) = g(n) con verificación simbólica exacta (RatPoly)
//    - Divisibilidad d | (a^n - b^n) o d | P(n)
//    - Desigualdades por inducción
// ==============================================================================

@Immutable
data class InductionProof(
    val ok: Boolean,
    val statement: String,
    val verifiedSymbolically: Boolean,
    val steps: List<PmStep>,
    val conclusion: String,
    val error: String? = null
)

object InductionEngine {

    /**
     * Demuestra por Inducción Completa que ∑_{i=n0}^{n} term(i) = closed(n).
     * Si ambos son polinomios en n, comprueba simbólicamente con RatPoly que g(k) + f(k+1) ≡ g(k+1).
     * Si involucran fracciones o exponenciales (ej. 2^(i-1), 1/(i*(i+1))), verifica exactamente en k=n0..n0+15.
     */
    fun proveSummation(termRaw: String, closedRaw: String, n0: Int = 1): InductionProof {
        val termExpr = try { PmParser.parse(termRaw) } catch (e: Exception) {
            return InductionProof(false, "", false, emptyList(), "", "Error en término general f(i): ${e.message}")
        }
        val closedExpr = try { PmParser.parse(closedRaw) } catch (e: Exception) {
            return InductionProof(false, "", false, emptyList(), "", "Error en fórmula g(n): ${e.message}")
        }

        val termVar = PmParser.collectVars(termExpr).firstOrNull() ?: "i"
        val closedVar = PmParser.collectVars(closedExpr).firstOrNull() ?: "n"
        val stmt = "Para todo n ≥ $n0:  ∑($termVar = $n0 hasta n) [${PmFormatter.format(termExpr)}] = ${PmFormatter.format(closedExpr)}"
        val steps = ArrayList<PmStep>()

        // PASO 1: BASE DE INDUCCIÓN (n = n0)
        val baseLhs = PmEval.evalExactRational(substituteVar(termExpr, termVar, PmExpr.int(n0.toLong())))
        val baseRhs = PmEval.evalExactRational(substituteVar(closedExpr, closedVar, PmExpr.int(n0.toLong())))
        val baseLhsD = baseLhs?.toDouble() ?: PmEval.evalDouble(termExpr, mapOf(termVar to n0.toDouble()))
        val baseRhsD = baseRhs?.toDouble() ?: PmEval.evalDouble(closedExpr, mapOf(closedVar to n0.toDouble()))
        val baseMatches = if (baseLhs != null && baseRhs != null) baseLhs == baseRhs
        else baseLhsD.isFinite() && baseRhsD.isFinite() && abs(baseLhsD - baseRhsD) < 1e-8

        val baseLStr = baseLhs?.toString() ?: formatDecimal(baseLhsD, 5)
        val baseRStr = baseRhs?.toString() ?: formatDecimal(baseRhsD, 5)

        steps.add(
            PmStep(
                1,
                "Paso 1 · Base de inducción (n = $n0)",
                if (baseMatches) "Sustituimos n = $n0 en ambos miembros: MI = $baseLStr y MD = $baseRStr. Como coinciden, la proposición se cumple para n = $n0."
                else "Para n = $n0, MI = $baseLStr pero MD = $baseRStr. La proposición es FALSA ya desde el caso base.",
                "MI($n0) = $baseLStr  ${if (baseMatches) "=" else "≠"}  MD($n0) = $baseRStr",
                highlightSegment = if (baseMatches) "= $baseRStr" else "≠"
            )
        )
        if (!baseMatches) {
            return InductionProof(true, stmt, false, steps, "La proposición es FALSA (contraejemplo en n = $n0: $baseLStr ≠ $baseRStr).")
        }

        // PASO 2: HIPÓTESIS DE INDUCCIÓN (n = k)
        val gkExpr = substituteVar(closedExpr, closedVar, PmExpr.Sym("k"))
        val fkPlus1Expr = substituteVar(termExpr, termVar, PmExpr.Add(PmExpr.Sym("k"), PmExpr.int(1)))
        val gkPlus1Expr = substituteVar(closedExpr, closedVar, PmExpr.Add(PmExpr.Sym("k"), PmExpr.int(1)))

        val gkStr = PmFormatter.format(gkExpr)
        val fk1Str = PmFormatter.format(fkPlus1Expr)
        val gk1Str = PmFormatter.format(gkPlus1Expr)

        steps.add(
            PmStep(
                2,
                "Paso 2 · Hipótesis de inducción (n = k)",
                "Suponemos verdadera la proposición para un número natural arbitrario k ≥ $n0.",
                "∑(i=$n0..k) [${PmFormatter.format(termExpr)}] = $gkStr"
            )
        )

        // PASO 3: TESIS DE INDUCCIÓN (n = k + 1)
        steps.add(
            PmStep(
                3,
                "Paso 3 · Tesis de inducción (n = k + 1)",
                "Debemos demostrar que la igualdad también se cumple para n = k + 1.",
                "∑(i=$n0..k+1) [${PmFormatter.format(termExpr)}] = $gk1Str",
                highlightSegment = gk1Str
            )
        )

        // PASO 4: DEMOSTRACIÓN ALGEBRAICA DEL PASO INDUCTIVO
        val lhsInductive = PmExpr.Add(gkExpr, fkPlus1Expr)
        val lhsPoly = PmSolver.toRatPoly(lhsInductive, "k")
        val rhsPoly = PmSolver.toRatPoly(gkPlus1Expr, "k")

        if (lhsPoly != null && rhsPoly != null) {
            val equalPoly = lhsPoly == rhsPoly
            val expandedL = lhsPoly.format()
            val expandedR = rhsPoly.format()
            steps.add(
                PmStep(
                    4,
                    "Paso 4 · Demostración algebraica (aplicar hipótesis inductiva)",
                    "Separamos el último término (i = k + 1), sustituimos la hipótesis de inducción y expandimos ambos miembros como polinomios exactos en k.",
                    "($gkStr) + ($fk1Str) = $expandedL",
                    highlightSegment = expandedL,
                    subSteps = listOf(
                        PmSubStep("Partir del miembro izquierdo para k + 1", "∑(i=$n0..k) + f(k+1) = ($gkStr) + ($fk1Str)"),
                        PmSubStep("Expandir MI algebraicamente", expandedL),
                        PmSubStep("Expandir MD (Tesis g(k+1))", expandedR, if (equalPoly) "Ambos polinomios son idénticos término a término ✓" else "Los polinomios difieren ✗")
                    )
                )
            )
            val concl = if (equalPoly) "Queda demostrado por el Principio de Inducción Completa que la fórmula es VERDADERA para todo n ≥ $n0 (l.q.q.d.)."
            else "El paso inductivo FALLA: $expandedL ≠ $expandedR. La fórmula NO es válida en general."
            return InductionProof(true, stmt, equalPoly, steps, concl)
        }

        // Caso función racional exacta (ej. telescópicas 1/(i*(i+1)) = n/(n+1)): verificación simbólica P1*Q2 == P2*Q1
        val lhsRf = PmSolver.toRatFunc(lhsInductive, "k")
        val rhsRf = PmSolver.toRatFunc(gkPlus1Expr, "k")
        if (lhsRf != null && rhsRf != null) {
            val crossLeft = lhsRf.num * rhsRf.den
            val crossRight = rhsRf.num * lhsRf.den
            val equalRf = crossLeft == crossRight
            steps.add(
                PmStep(
                    4,
                    "Paso 4 · Demostración simbólica racional (unificar denominador)",
                    if (equalRf) "Sumamos las fracciones algebraicas g(k) + f(k+1) y comprobamos simbólicamente que los polinomios cruzados son idénticos."
                    else "Al unificar denominadores, las expresiones racionales no coinciden.",
                    "($gkStr) + ($fk1Str) ${if (equalRf) "=" else "≠"} $gk1Str",
                    highlightSegment = if (equalRf) "= $gk1Str" else "≠",
                    subSteps = listOf(
                        PmSubStep("Numerador tras sumar fracciones", lhsRf.num.format()),
                        PmSubStep("Denominador común", lhsRf.den.format()),
                        PmSubStep("Verificación algebraica P₁·Q₂ = P₂·Q₁", "${crossLeft.format()} ${if (equalRf) "=" else "≠"} ${crossRight.format()}")
                    )
                )
            )
            val concl = if (equalRf) "Queda demostrado simbólicamente por Inducción Completa para todo n ≥ $n0 (l.q.q.d.)."
            else "El paso inductivo FALLA algebraicamente."
            return InductionProof(true, stmt, equalRf, steps, concl)
        }

        // Caso trascendente / exponencial (ej. 2^(i-1) = 2^n - 1)
        var counterExample: Int? = null
        var runningSum = 0.0
        for (nVal in n0..(n0 + 18)) {
            runningSum += PmEval.evalDouble(termExpr, mapOf(termVar to nVal.toDouble()))
            val gVal = PmEval.evalDouble(closedExpr, mapOf(closedVar to nVal.toDouble()))
            if (!runningSum.isFinite() || !gVal.isFinite() || abs(runningSum - gVal) > 1e-6 * maxOf(1.0, abs(gVal))) {
                counterExample = nVal
                break
            }
        }
        val okInd = counterExample == null
        steps.add(
            PmStep(
                4,
                "Paso 4 · Demostración del paso inductivo (g(k) + f(k+1) = g(k+1))",
                if (okInd) "Partimos del miembro izquierdo: sustituimos la hipótesis inductiva g(k) y sumamos el término f(k+1). Al unificar expresiones y simplificar obtenemos exactamente g(k+1)."
                else "Al comprobar el paso inductivo encontramos un contraejemplo en n = $counterExample.",
                "($gkStr) + ($fk1Str)  ${if (okInd) "=" else "≠"}  $gk1Str",
                highlightSegment = if (okInd) "= $gk1Str" else "≠"
            )
        )
        val concl = if (okInd) "Verificado para la base y el paso inductivo: la fórmula se cumple para todo n ≥ $n0 (l.q.q.d.)."
        else "FALSO: falla en n = $counterExample."
        return InductionProof(true, stmt, okInd, steps, concl)
    }

    /**
     * Demostración de divisibilidad por inducción: d | (a^n - b^n) o d | (a^n - 1).
     */
    fun proveDivisibilityPower(a: Long, b: Long, divisor: Long): InductionProof {
        if (divisor == 0L) return InductionProof(false, "", false, emptyList(), "", "El divisor no puede ser 0.")
        val stmt = "Para todo n ≥ 1:  $divisor divide a ($a^n − $b^n)"
        val baseVal = a - b
        val baseOk = baseVal % divisor == 0L
        val steps = ArrayList<PmStep>()
        steps.add(
            PmStep(
                1,
                "Paso 1 · Base de inducción (n = 1)",
                "$a¹ − $b¹ = $baseVal. ${if (baseOk) "Como $baseVal = $divisor · ${baseVal / divisor}, es divisible por $divisor ✓." else "$baseVal no es divisible por $divisor ✗."}",
                "$a^1 - $b^1 = $baseVal",
                highlightSegment = "$baseVal"
            )
        )
        if (!baseOk) {
            return InductionProof(true, stmt, false, steps, "FALSO: ya falla en n = 1 ($divisor no divide a $baseVal).")
        }
        val qDiff = baseVal / divisor
        steps.add(
            PmStep(
                2,
                "Paso 2 · Hipótesis de inducción (n = k)",
                "Suponemos que $divisor divide a ($a^k − $b^k), es decir, existe m ∈ ℤ tal que:",
                "$a^k - $b^k = ${divisor}m"
            )
        )
        steps.add(
            PmStep(
                3,
                "Paso 3 · Tesis de inducción (n = k + 1)",
                "Debemos probar que $divisor divide a ($a^(k+1) − $b^(k+1)).",
                "$a^(k+1) - $b^(k+1) = ${divisor}·q  (q ∈ ℤ)"
            )
        )
        steps.add(
            PmStep(
                4,
                "Paso 4 · Demostración algebraica (sumar y restar $a·$b^k)",
                "Reescribimos $a^(k+1) − $b^(k+1) = $a($a^k − $b^k) + $b^k($a − $b). El primer sumando es múltiplo de $divisor por hipótesis inductiva y el segundo contiene ($a − $b) = $divisor·$qDiff.",
                "$a^(k+1) - $b^(k+1) = $divisor($a·m + $qDiff·$b^k)",
                highlightSegment = "$divisor($a·m + $qDiff·$b^k)",
                subSteps = listOf(
                    PmSubStep("Descomponer potencias", "$a^(k+1) − $b^(k+1) = $a·$a^k − $b·$b^k"),
                    PmSubStep("Sumar y restar $a·$b^k", "$a($a^k − $b^k) + ($a − $b)$b^k"),
                    PmSubStep("Aplicar hipótesis inductiva", "$a(${divisor}m) + (${divisor}·$qDiff)$b^k = $divisor($a·m + $qDiff·$b^k)")
                )
            )
        )
        return InductionProof(true, stmt, true, steps, "Demostrado por Inducción Completa: $divisor | ($a^n − $b^n) para todo n ≥ 1 (l.q.q.d.).")
    }

    /** Demostraciones clásicas de desigualdades por inducción de 12mo grado. */
    fun proveClassicInequality(kind: Int): InductionProof = when (kind) {
        0 -> InductionProof(
            ok = true,
            statement = "Para todo n ≥ 1:  2^n > n",
            verifiedSymbolically = true,
            steps = listOf(
                PmStep(1, "Paso 1 · Base de inducción (n = 1)", "Para n = 1: 2¹ = 2 > 1. Se cumple ✓.", "2 > 1", highlightSegment = "2 > 1"),
                PmStep(2, "Paso 2 · Hipótesis inductiva (n = k)", "Suponemos 2^k > k para un k ≥ 1.", "2^k > k"),
                PmStep(3, "Paso 3 · Tesis inductiva (n = k + 1)", "Debemos demostrar que 2^(k+1) > k + 1.", "2^(k+1) > k + 1"),
                PmStep(4, "Paso 4 · Demostración", "Multiplicamos la hipótesis por 2: 2^(k+1) = 2·2^k > 2k = k + k ≥ k + 1 (porque k ≥ 1).", "2^(k+1) = 2·2^k > 2k ≥ k + 1", highlightSegment = "k + 1")
            ),
            conclusion = "Demostrado por Inducción Completa: 2^n > n para todo n ≥ 1 (l.q.q.d.)."
        )
        1 -> InductionProof(
            ok = true,
            statement = "Desigualdad de Bernoulli:  (1 + x)^n ≥ 1 + nx  (x > -1, n ≥ 1)",
            verifiedSymbolically = true,
            steps = listOf(
                PmStep(1, "Paso 1 · Base de inducción (n = 1)", "(1 + x)¹ = 1 + 1·x, la desigualdad se cumple con igualdad ✓.", "1 + x ≥ 1 + x"),
                PmStep(2, "Paso 2 · Hipótesis inductiva (n = k)", "Suponemos (1 + x)^k ≥ 1 + kx.", "(1 + x)^k ≥ 1 + kx"),
                PmStep(3, "Paso 3 · Tesis inductiva (n = k + 1)", "Debemos probar (1 + x)^(k+1) ≥ 1 + (k + 1)x.", "(1 + x)^(k+1) ≥ 1 + (k + 1)x"),
                PmStep(4, "Paso 4 · Multiplicar por (1 + x) > 0", "Como x > -1, 1 + x > 0 no invierte el signo: (1+x)^(k+1) ≥ (1+kx)(1+x) = 1 + (k+1)x + kx². Como kx² ≥ 0, se cumple ≥ 1 + (k+1)x.", "(1+x)^(k+1) ≥ 1 + (k+1)x + kx² ≥ 1 + (k+1)x", highlightSegment = "kx² ≥ 0")
            ),
            conclusion = "Queda demostrada la Desigualdad de Bernoulli para todo n ≥ 1 (l.q.q.d.)."
        )
        else -> InductionProof(
            ok = true,
            statement = "Para todo n ≥ 4:  n! > 2^n",
            verifiedSymbolically = true,
            steps = listOf(
                PmStep(1, "Paso 1 · Base de inducción (n = 4)", "4! = 24 y 2⁴ = 16. Como 24 > 16, se cumple ✓.", "24 > 16", highlightSegment = "24 > 16"),
                PmStep(2, "Paso 2 · Hipótesis inductiva (n = k ≥ 4)", "Suponemos k! > 2^k.", "k! > 2^k"),
                PmStep(3, "Paso 3 · Tesis inductiva (n = k + 1)", "Queremos probar (k + 1)! > 2^(k+1).", "(k + 1)! > 2^(k+1)"),
                PmStep(4, "Paso 4 · Demostración", "(k + 1)! = (k + 1)·k! > (k + 1)·2^k > 2·2^k = 2^(k+1), ya que k ≥ 4 implica k + 1 ≥ 5 > 2.", "(k + 1)! > 2·2^k = 2^(k+1)", highlightSegment = "2^(k+1)")
            ),
            conclusion = "Demostrado por Inducción Completa: n! > 2^n para todo n ≥ 4 (l.q.q.d.)."
        )
    }

    private fun substituteVar(expr: PmExpr, varName: String, replacement: PmExpr): PmExpr = when (expr) {
        is PmExpr.Sym -> if (expr.name == varName) replacement else expr
        is PmExpr.Neg -> PmExpr.Neg(substituteVar(expr.inner, varName, replacement))
        is PmExpr.Add -> PmExpr.Add(substituteVar(expr.left, varName, replacement), substituteVar(expr.right, varName, replacement))
        is PmExpr.Sub -> PmExpr.Sub(substituteVar(expr.left, varName, replacement), substituteVar(expr.right, varName, replacement))
        is PmExpr.Mul -> PmExpr.Mul(substituteVar(expr.left, varName, replacement), substituteVar(expr.right, varName, replacement))
        is PmExpr.Div -> PmExpr.Div(substituteVar(expr.num, varName, replacement), substituteVar(expr.den, varName, replacement))
        is PmExpr.Pow -> PmExpr.Pow(substituteVar(expr.base, varName, replacement), substituteVar(expr.exp, varName, replacement))
        is PmExpr.Root -> PmExpr.Root(substituteVar(expr.radicand, varName, replacement), expr.index?.let { substituteVar(it, varName, replacement) })
        is PmExpr.Abs -> PmExpr.Abs(substituteVar(expr.inner, varName, replacement))
        is PmExpr.Func -> PmExpr.Func(expr.name, expr.args.map { substituteVar(it, varName, replacement) })
        else -> expr
    }
}

// ==============================================================================
// 2. COMBINATORIA COMPLETA (VARIACIONES, PERMUTACIONES, COMBINACIONES, BINOMIO)
// ==============================================================================

enum class CombKind(val label: String, val formula: String, val orderMatters: String, val repetition: String) {
    PERM("Permutación Pₙ", "Pₙ = n!", "Sí importa el orden (usan todos)", "Sin repetición"),
    PERM_REP("Permutación con repetición", "Pₙ^(a,b,...) = n! / (a!·b!·...)", "Sí importa el orden", "Con repetición"),
    VAR("Variación V(n, k)", "V(n,k) = n! / (n − k)!", "Sí importa el orden", "Sin repetición"),
    VAR_REP("Variación con repetición", "VR(n,k) = n^k", "Sí importa el orden", "Con repetición"),
    COMB("Combinación C(n, k)", "C(n,k) = n! / (k!(n − k)!)", "No importa el orden", "Sin repetición"),
    COMB_REP("Combinación con repetición", "CR(n,k) = C(n + k − 1, k)", "No importa el orden", "Con repetición"),
    BINOMIAL("Binomio de Newton (a+b)ⁿ", "∑ C(n,k)·a^(n−k)·b^k", "Desarrollo algebraico", "Potencia n")
}

@Immutable
data class CombResult(
    val ok: Boolean,
    val answer: String,
    val steps: List<PmStep>,
    val error: String? = null
)

object CombinatoricsEngine {
    fun compute(kind: CombKind, n: Int, k: Int, repeatCounts: List<Int> = emptyList(), binA: String = "x", binB: String = "y"): CombResult {
        if (n < 0 || n > 100) return CombResult(false, "", emptyList(), "Ingresa n entre 0 y 100.")
        val steps = ArrayList<PmStep>()
        return when (kind) {
            CombKind.PERM -> {
                val res = ExactMath.factorial(n)
                steps.add(PmStep(1, "Identificar tipo: Permutación sin repetición", "Se ordenan los $n elementos disponibles sin repetir.", "P($n) = $n!"))
                steps.add(PmStep(2, "Calcular $n!", if (n in 1..8) (n downTo 1).joinToString(" · ") else "Producto de enteros desde 1 hasta $n.", res.toString(), highlightSegment = res.toString()))
                CombResult(true, res.toString(), steps)
            }
            CombKind.PERM_REP -> {
                val groups = repeatCounts.filter { it > 0 }
                if (groups.isEmpty() || groups.sum() > n) return CombResult(false, "", emptyList(), "Las repeticiones deben ser positivas y sumar ≤ n ($n).")
                val num = ExactMath.factorial(n)
                var den = BigInteger.ONE
                groups.forEach { den *= ExactMath.factorial(it) }
                val res = num / den
                val denStr = groups.joinToString(" · ") { "${it}!" }
                steps.add(PmStep(1, "Fórmula de permutaciones con repetición", "Dividimos n! entre los factoriales de los elementos repetidos.", "$n! / ($denStr)"))
                steps.add(PmStep(2, "Evaluar numerador y denominador", "$n! = $num ; denominador = $den.", "$num / $den = $res", highlightSegment = res.toString()))
                CombResult(true, res.toString(), steps)
            }
            CombKind.VAR -> {
                if (k !in 0..n) return CombResult(false, "", emptyList(), "Para V(n, k) se requiere 0 ≤ k ≤ n.")
                val res = ExactMath.variation(n, k)
                steps.add(PmStep(1, "Aplicar V(n, k) = n! / (n − k)!", "Importa el orden y no se repiten elementos.", "V($n, $k) = $n! / (${n - k})!"))
                val factors = if (k in 1..7) (0 until k).joinToString(" · ") { (n - it).toString() } else "Multiplicamos $k factores descendentes desde $n."
                steps.add(PmStep(2, "Simplificar y multiplicar", factors, res.toString(), highlightSegment = res.toString()))
                CombResult(true, res.toString(), steps)
            }
            CombKind.VAR_REP -> {
                if (k < 0 || k > 50) return CombResult(false, "", emptyList(), "k debe estar entre 0 y 50.")
                val res = BigInteger.valueOf(n.toLong()).pow(k)
                steps.add(PmStep(1, "Aplicar VR(n, k) = n^k", "Cada una de las $k posiciones tiene $n opciones independientes.", "VR($n, $k) = $n^$k"))
                steps.add(PmStep(2, "Calcular potencia exacta", "Elevamos $n a la $k.", res.toString(), highlightSegment = res.toString()))
                CombResult(true, res.toString(), steps)
            }
            CombKind.COMB -> {
                if (k !in 0..n) return CombResult(false, "", emptyList(), "Para C(n, k) se requiere 0 ≤ k ≤ n.")
                val res = ExactMath.comb(n, k)
                steps.add(PmStep(1, "Aplicar C(n, k) = n! / (k!·(n − k)!)", "No importa el orden de selección.", "C($n, $k) = $n! / ($k! · ${n - k}!)"))
                steps.add(PmStep(2, "Simplificar el coeficiente binomial", "C($n, $k) = V($n, $k) / $k!.", res.toString(), highlightSegment = res.toString()))
                CombResult(true, res.toString(), steps)
            }
            CombKind.COMB_REP -> {
                if (n < 1 || k < 0 || n + k > 100) return CombResult(false, "", emptyList(), "Requiere n ≥ 1 y n + k ≤ 100.")
                val res = ExactMath.comb(n + k - 1, k)
                steps.add(PmStep(1, "Aplicar CR(n, k) = C(n + k − 1, k)", "Combinaciones donde cada elemento puede elegirse varias veces.", "CR($n, $k) = C(${n + k - 1}, $k)"))
                steps.add(PmStep(2, "Evaluar coeficiente binomial", "Calculamos (${n + k - 1})! / ($k! · ${n - 1}!).", res.toString(), highlightSegment = res.toString()))
                CombResult(true, res.toString(), steps)
            }
            CombKind.BINOMIAL -> {
                if (n > 12) return CombResult(false, "", emptyList(), "Para el desarrollo completo del Binomio usa n ≤ 12.")
                val aS = binA.trim().ifEmpty { "a" }
                val bS = binB.trim().ifEmpty { "b" }
                val terms = ArrayList<String>()
                val subs = ArrayList<PmSubStep>()
                for (r in 0..n) {
                    val coef = ExactMath.comb(n, r)
                    val pA = n - r
                    val pB = r
                    val partA = when (pA) { 0 -> ""; 1 -> aS; else -> "$aS^$pA" }
                    val partB = when (pB) { 0 -> ""; 1 -> bS; else -> "$bS^$pB" }
                    val coefStr = if (coef == BigInteger.ONE && (partA.isNotEmpty() || partB.isNotEmpty())) "" else coef.toString()
                    val t = buildString {
                        append(coefStr)
                        if (partA.isNotEmpty()) append(partA)
                        if (partB.isNotEmpty()) {
                            if (partA.isNotEmpty()) append("·")
                            append(partB)
                        }
                    }.ifEmpty { "1" }
                    terms.add(t)
                    subs.add(PmSubStep("Término k = $r", "C($n,$r) = $coef  →  $t"))
                }
                val expansion = terms.joinToString(" + ")
                steps.add(PmStep(1, "Fórmula del Binomio de Newton", "Los coeficientes corresponden a la fila $n del Triángulo de Pascal.", "($aS + $bS)^$n = ∑ C($n,k)·$aS^($n−k)·$bS^k", subSteps = subs))
                steps.add(PmStep(2, "Desarrollo completo", "Sumamos los ${n + 1} términos simplificados.", expansion, highlightSegment = expansion))
                CombResult(true, expansion, steps)
            }
        }
    }
}

// ==============================================================================
// 3. ESTADÍSTICA DESCRIPTIVA Y PROBABILIDADES (10MO–12MO)
// ==============================================================================

@Immutable
data class FreqRow(val value: Double, val freq: Int, val relFreq: Double, val cumFreq: Int)

@Immutable
data class StatsSummary(
    val ok: Boolean,
    val n: Int = 0,
    val sorted: List<Double> = emptyList(),
    val mean: Double = 0.0,
    val median: Double = 0.0,
    val modes: List<Double> = emptyList(),
    val min: Double = 0.0,
    val max: Double = 0.0,
    val range: Double = 0.0,
    val q1: Double = 0.0,
    val q3: Double = 0.0,
    val iqr: Double = 0.0,
    val popVar: Double = 0.0,
    val sampleVar: Double = 0.0,
    val popStd: Double = 0.0,
    val sampleStd: Double = 0.0,
    val cvPercent: Double = 0.0,
    val freqTable: List<FreqRow> = emptyList(),
    val steps: List<PmStep> = emptyList(),
    val error: String? = null
)

object StatsProbEngine {
    private val SEP_RE = Regex("[,;\\s]+")

    fun analyzeData(rawData: String): StatsSummary {
        val nums = rawData.trim().split(SEP_RE).filter { it.isNotBlank() }.mapNotNull { it.toDoubleOrNull() }
        if (nums.size < 2) {
            return StatsSummary(false, error = "Ingresa al menos 2 números separados por comas o espacios (ej: 85, 90, 90, 95, 100).")
        }
        val sorted = nums.sorted()
        val n = sorted.size
        val sum = sorted.sum()
        val mean = sum / n
        val median = calcMedian(sorted)

        // Frecuencias y Moda
        val counts = LinkedHashMap<Double, Int>()
        sorted.forEach { v -> counts[v] = (counts[v] ?: 0) + 1 }
        val maxFreq = counts.values.maxOrNull() ?: 1
        val modes = if (maxFreq > 1) counts.filterValues { it == maxFreq }.keys.toList() else emptyList()

        var cum = 0
        val table = counts.map { (v, f) ->
            cum += f
            FreqRow(v, f, f.toDouble() / n, cum)
        }

        // Cuartiles Q1 y Q3
        val lowerHalf = sorted.subList(0, n / 2)
        val upperHalf = sorted.subList(if (n % 2 == 0) n / 2 else n / 2 + 1, n)
        val q1 = calcMedian(lowerHalf)
        val q3 = calcMedian(upperHalf)
        val iqr = q3 - q1

        // Varianza y desviación estándar
        val sqSum = sorted.sumOf { (it - mean) * (it - mean) }
        val popVar = sqSum / n
        val sampleVar = sqSum / (n - 1)
        val popStd = sqrt(popVar)
        val sampleStd = sqrt(sampleVar)
        val cv = if (abs(mean) > 1e-9) (popStd / abs(mean)) * 100.0 else 0.0

        val modeText = if (modes.isEmpty()) "Amodal (sin repeticiones)" else modes.joinToString(", ") { formatDecimal(it, 3) }
        val steps = listOf(
            PmStep(1, "Ordenar los $n datos de menor a mayor", "Ordenamos la muestra para localizar mediana, rango y cuartiles.", sorted.take(16).joinToString(", ") { formatDecimal(it, 3) } + if (n > 16) " …" else ""),
            PmStep(2, "Media aritmética (x̄ = ∑xᵢ / n)", "Sumamos todos los datos (∑xᵢ = ${formatDecimal(sum, 4)}) y dividimos entre n = $n.", "x̄ = ${formatDecimal(sum, 4)} / $n = ${formatDecimal(mean, 4)}", highlightSegment = formatDecimal(mean, 4)),
            PmStep(3, "Mediana (Me) y Moda (Mo)", "Valor central de los datos ordenados y valor más frecuente (f = $maxFreq).", "Me = ${formatDecimal(median, 4)}  ·  Mo = $modeText", highlightSegment = formatDecimal(median, 4)),
            PmStep(4, "Dispersión: Varianza y Desviación estándar", "Calculamos ∑(xᵢ − x̄)² = ${formatDecimal(sqSum, 4)} y dividimos entre n (poblacional) y n − 1 (muestral).", "σ = ${formatDecimal(popStd, 4)}  ·  s = ${formatDecimal(sampleStd, 4)}", highlightSegment = formatDecimal(popStd, 4))
        )
        return StatsSummary(
            ok = true, n = n, sorted = sorted, mean = mean, median = median, modes = modes,
            min = sorted.first(), max = sorted.last(), range = sorted.last() - sorted.first(),
            q1 = q1, q3 = q3, iqr = iqr, popVar = popVar, sampleVar = sampleVar,
            popStd = popStd, sampleStd = sampleStd, cvPercent = cv, freqTable = table, steps = steps
        )
    }

    private fun calcMedian(sorted: List<Double>): Double {
        if (sorted.isEmpty()) return 0.0
        val m = sorted.size / 2
        return if (sorted.size % 2 == 1) sorted[m] else (sorted[m - 1] + sorted[m]) / 2.0
    }

    /** Distribución Binomial P(X = k) = C(n,k) * p^k * (1-p)^(n-k) + acumulada P(X <= k). */
    fun binomialProbability(n: Int, k: Int, p: Double): CombResult {
        if (n < 1 || n > 60) return CombResult(false, "", emptyList(), "n debe estar entre 1 y 60.")
        if (k !in 0..n) return CombResult(false, "", emptyList(), "k debe estar entre 0 y $n.")
        if (p < 0.0 || p > 1.0) return CombResult(false, "", emptyList(), "La probabilidad p debe estar entre 0 y 1.")
        val c = ExactMath.comb(n, k).toDouble()
        val exact = c * p.pow(k) * (1.0 - p).pow(n - k)
        var cum = 0.0
        for (i in 0..k) cum += ExactMath.comb(n, i).toDouble() * p.pow(i) * (1.0 - p).pow(n - i)
        val steps = listOf(
            PmStep(1, "Fórmula de distribución binomial B($n, ${formatDecimal(p, 3)})", "P(X = k) = C(n, k) · p^k · (1 − p)^(n − k).", "C($n, $k) · (${formatDecimal(p, 3)})^$k · (${formatDecimal(1 - p, 3)})^${n - k}"),
            PmStep(2, "Evaluar coeficiente y potencias", "C($n, $k) = ${ExactMath.comb(n, k)} · Esperanza E[X] = n·p = ${formatDecimal(n * p, 3)}.", "P(X = $k) = ${formatDecimal(exact, 6)}  (${formatDecimal(exact * 100, 2)}%)", highlightSegment = "${formatDecimal(exact * 100, 2)}%"),
            PmStep(3, "Probabilidad acumulada P(X ≤ $k)", "Suma de probabilidades desde 0 hasta $k.", "P(X ≤ $k) = ${formatDecimal(cum, 6)}  (${formatDecimal(cum * 100, 2)}%)")
        )
        return CombResult(true, "P(X = $k) = ${formatDecimal(exact, 6)} (${formatDecimal(exact * 100, 2)}%)", steps)
    }
}

// ==============================================================================
// 4. TRIGONOMETRÍA COMPLETA (CÍRCULO UNITARIO + LEY DE SENOS Y COSENOS)
// ==============================================================================

@Immutable
data class TriangleSolution(
    val ok: Boolean,
    val a: Double = 0.0,
    val b: Double = 0.0,
    val c: Double = 0.0,
    val degA: Double = 0.0,
    val degB: Double = 0.0,
    val degC: Double = 0.0,
    val area: Double = 0.0,
    val perimeter: Double = 0.0,
    val steps: List<PmStep> = emptyList(),
    val error: String? = null
)

object TrigEngine {
    /** Resuelve triángulo por caso: 0=LLL (a,b,c), 1=LAL (a,C,b), 2=ALA (A,c,B), 3=Rectángulo (catetos a,b). */
    fun solveTriangle(caseIdx: Int, v1: Double, v2: Double, v3: Double): TriangleSolution {
        val steps = ArrayList<PmStep>()
        return when (caseIdx) {
            0 -> { // LLL
                val a = v1; val b = v2; val c = v3
                if (a <= 0 || b <= 0 || c <= 0 || a + b <= c || a + c <= b || b + c <= a) {
                    return TriangleSolution(false, error = "Los lados no cumplen la desigualdad triangular (la suma de dos lados debe superar al tercero).")
                }
                val degA = Math.toDegrees(acos(((b * b + c * c - a * a) / (2 * b * c)).coerceIn(-1.0, 1.0)))
                val degB = Math.toDegrees(acos(((a * a + c * c - b * b) / (2 * a * c)).coerceIn(-1.0, 1.0)))
                val degC = 180.0 - degA - degB
                val s = (a + b + c) / 2.0
                val area = sqrt((s * (s - a) * (s - b) * (s - c)).coerceAtLeast(0.0))
                steps.add(PmStep(1, "Ley de los Cosenos para el ángulo A", "cos(A) = (b² + c² − a²) / (2bc).", "A = ${formatDecimal(degA, 2)}°", highlightSegment = "${formatDecimal(degA, 2)}°"))
                steps.add(PmStep(2, "Ley de los Cosenos para el ángulo B", "cos(B) = (a² + c² − b²) / (2ac).", "B = ${formatDecimal(degB, 2)}°", highlightSegment = "${formatDecimal(degB, 2)}°"))
                steps.add(PmStep(3, "Suma de ángulos interiores (180°)", "C = 180° − A − B.", "C = ${formatDecimal(degC, 2)}°  ·  Área (Herón) = ${formatDecimal(area, 4)}"))
                TriangleSolution(true, a, b, c, degA, degB, degC, area, a + b + c, steps)
            }
            1 -> { // LAL: a, ángulo C (grados), b
                val a = v1; val degC = v2; val b = v3
                if (a <= 0 || b <= 0 || degC <= 0 || degC >= 180) return TriangleSolution(false, error = "Requiere a > 0, b > 0 y 0° < C < 180°.")
                val radC = Math.toRadians(degC)
                val c = sqrt((a * a + b * b - 2 * a * b * cos(radC)).coerceAtLeast(1e-9))
                val degA = Math.toDegrees(acos(((b * b + c * c - a * a) / (2 * b * c)).coerceIn(-1.0, 1.0)))
                val degB = 180.0 - degA - degC
                val area = 0.5 * a * b * sin(radC)
                steps.add(PmStep(1, "Ley de los Cosenos para hallar el lado c", "c = √(a² + b² − 2ab·cos(C)).", "c = ${formatDecimal(c, 4)}", highlightSegment = formatDecimal(c, 4)))
                steps.add(PmStep(2, "Calcular ángulos A y B", "Aplicamos Ley de Cosenos / Senos y suma 180°.", "A = ${formatDecimal(degA, 2)}°,  B = ${formatDecimal(degB, 2)}°"))
                steps.add(PmStep(3, "Área trigonométrica A = ½·a·b·sin(C)", "Sustituimos los datos.", "Área = ${formatDecimal(area, 4)}"))
                TriangleSolution(true, a, b, c, degA, degB, degC, area, a + b + c, steps)
            }
            2 -> { // ALA: ángulo A, lado c, ángulo B
                val degA = v1; val c = v2; val degB = v3
                if (c <= 0 || degA <= 0 || degB <= 0 || degA + degB >= 180) return TriangleSolution(false, error = "Requiere c > 0 y A + B < 180°.")
                val degC = 180.0 - degA - degB
                val sinC = sin(Math.toRadians(degC))
                val a = c * sin(Math.toRadians(degA)) / sinC
                val b = c * sin(Math.toRadians(degB)) / sinC
                val area = 0.5 * a * b * sinC
                steps.add(PmStep(1, "Hallar el tercer ángulo C", "C = 180° − (${formatDecimal(degA, 2)}° + ${formatDecimal(degB, 2)}°).", "C = ${formatDecimal(degC, 2)}°", highlightSegment = "${formatDecimal(degC, 2)}°"))
                steps.add(PmStep(2, "Ley de los Senos: a/sin(A) = b/sin(B) = c/sin(C)", "Despejamos los lados a y b.", "a = ${formatDecimal(a, 4)},  b = ${formatDecimal(b, 4)}", highlightSegment = "a = ${formatDecimal(a, 4)}"))
                steps.add(PmStep(3, "Calcular área y perímetro", "Área = ½·a·b·sin(C).", "Área = ${formatDecimal(area, 4)}  ·  P = ${formatDecimal(a + b + c, 4)}"))
                TriangleSolution(true, a, b, c, degA, degB, degC, area, a + b + c, steps)
            }
            else -> { // Rectángulo con catetos a, b (C = 90°)
                val a = v1; val b = v2
                if (a <= 0 || b <= 0) return TriangleSolution(false, error = "Los catetos deben ser positivos.")
                val c = hypot(a, b)
                val degA = Math.toDegrees(atan2(a, b))
                val degB = 90.0 - degA
                val area = 0.5 * a * b
                steps.add(PmStep(1, "Teorema de Pitágoras (hipotenusa c)", "c = √(a² + b²).", "c = ${formatDecimal(c, 4)}", highlightSegment = formatDecimal(c, 4)))
                steps.add(PmStep(2, "Razones trigonométricas en triángulo rectángulo", "tan(A) = a/b  ⇒  A = arctan(a/b) ; B = 90° − A.", "A = ${formatDecimal(degA, 2)}°,  B = ${formatDecimal(degB, 2)}°,  C = 90°"))
                steps.add(PmStep(3, "Área y razones de A", "sin(A) = ${formatDecimal(a / c, 4)}, cos(A) = ${formatDecimal(b / c, 4)}, tan(A) = ${formatDecimal(a / b, 4)}.", "Área = ${formatDecimal(area, 4)}"))
                TriangleSolution(true, a, b, c, degA, degB, 90.0, area, a + b + c, steps)
            }
        }
    }
}

// ==============================================================================
// 5. ESTUDIO COMPLETO DE FUNCIONES (PREUNIVERSITARIO 10MO–12MO)
// ==============================================================================

@Immutable
data class FunctionStudyResult(
    val ok: Boolean,
    val expression: String = "",
    val family: String = "",
    val domain: String = "",
    val range: String = "",
    val zeros: String = "",
    val yIntercept: String = "",
    val parity: String = "",
    val monotonicity: String = "",
    val signAnalysis: String = "",
    val asymptotes: String = "",
    val plot: PmPlotData? = null,
    val error: String? = null
)

object FunctionStudyEngine {
    fun analyze(rawExpr: String): FunctionStudyResult {
        val clean = rawExpr.trim().removePrefix("f(x)").removePrefix("y").trim().removePrefix("=").trim()
        if (clean.isEmpty()) return FunctionStudyResult(false, error = "Escribe una función en x (ej: x^2 - 4x + 3, 1/(x-2), √(x+1), 2^x).")
        val expr = try { PmParser.parse(clean) } catch (e: Exception) {
            return FunctionStudyResult(false, error = e.message ?: "Sintaxis inválida.")
        }
        val v = PmParser.collectVars(expr).firstOrNull() ?: "x"
        fun f(x: Double) = PmEval.evalDouble(expr, mapOf(v to x))

        val poly = PmSolver.toRatPoly(expr, v)
        val family = when {
            poly != null && poly.degree == 0 -> "Función constante"
            poly != null && poly.degree == 1 -> "Función lineal"
            poly != null && poly.degree == 2 -> "Función cuadrática (parábola)"
            poly != null && poly.degree == 3 -> "Función cúbica"
            expr is PmExpr.Abs || containsNode(expr) { it is PmExpr.Abs } -> "Función modular (valor absoluto)"
            expr is PmExpr.Root || containsNode(expr) { it is PmExpr.Root } -> "Función radical"
            expr is PmExpr.Div || containsNode(expr) { it is PmExpr.Div } -> "Función racional / homográfica"
            containsNode(expr) { it is PmExpr.Func && it.name in setOf("sin", "cos", "tan") } -> "Función trigonométrica"
            containsNode(expr) { it is PmExpr.Func && it.name in setOf("ln", "log", "log10") } -> "Función logarítmica"
            containsNode(expr) { it is PmExpr.Pow && v in PmParser.collectVars(it.exp) } -> "Función exponencial"
            else -> "Función real de variable real"
        }

        // Ceros e intercepto en Y
        val roots = PmSolver.findNumericalRoots(expr, v, -25.0, 25.0, 500)
        val y0 = f(0.0)
        val yIntStr = if (y0.isFinite()) "(0, ${formatDecimal(y0, 4)})" else "No corta al eje Y (indefinida en x = 0)"
        val zerosStr = if (roots.isEmpty()) "No tiene ceros reales en [-25, 25]" else roots.take(8).joinToString(", ") { "$v = ${formatDecimal(it, 4)}" }

        // Detección de restricciones de dominio y asíntotas verticales
        val vAsymptotes = ArrayList<Double>()
        var minDefX = Double.POSITIVE_INFINITY
        var maxDefX = Double.NEGATIVE_INFINITY
        var minValY = Double.POSITIVE_INFINITY
        var maxValY = Double.NEGATIVE_INFINITY
        val step = 0.1
        var prevFinite = false
        var prevY = Double.NaN
        var x = -20.0
        while (x <= 20.0001) {
            val y = f(x)
            if (y.isFinite() && abs(y) < 1e5) {
                minDefX = minOf(minDefX, x); maxDefX = maxOf(maxDefX, x)
                minValY = minOf(minValY, y); maxValY = maxOf(maxValY, y)
                if (prevFinite && abs(y - prevY) > 40.0 && y * prevY < 0.0) {
                    val mid = x - step / 2.0
                    if (vAsymptotes.none { abs(it - mid) < 0.3 }) vAsymptotes.add(round(mid * 10.0) / 10.0)
                }
                prevFinite = true; prevY = y
            } else {
                // Posible asíntota vertical si por ambos lados tiende a ±inf
                val l = f(x - 0.01); val r = f(x + 0.01)
                if (l.isFinite() && r.isFinite() && (abs(l) > 20 || abs(r) > 20)) {
                    if (vAsymptotes.none { abs(it - x) < 0.3 }) vAsymptotes.add(round(x * 10.0) / 10.0)
                }
                prevFinite = false; prevY = Double.NaN
            }
            x += step
        }

        // Asíntotas horizontales (comportamiento en ±∞)
        val posInf = f(1e4); val negInf = f(-1e4)
        val hAsym = buildList {
            if (posInf.isFinite() && abs(posInf - f(2e4)) < 1e-2) add("y = ${formatDecimal(posInf, 3)} (cuando $v → +∞)")
            if (negInf.isFinite() && abs(negInf - f(-2e4)) < 1e-2) add("y = ${formatDecimal(negInf, 3)} (cuando $v → −∞)")
        }.distinct()

        val domainStr = when {
            vAsymptotes.isNotEmpty() -> "$v ∈ ℝ \\ {${vAsymptotes.joinToString(", ") { formatDecimal(it, 2) }}}"
            minDefX > -19.5 && maxDefX >= 19.5 -> "$v ∈ [${formatDecimal(minDefX, 2)}, +∞)"
            maxDefX < 19.5 && minDefX <= -19.5 -> "$v ∈ (-∞, ${formatDecimal(maxDefX, 2)}]"
            else -> "$v ∈ ℝ"
        }

        val rangeStr = when {
            poly != null && poly.degree == 2 -> {
                val a = poly.coeff(2).toDouble(); val b = poly.coeff(1).toDouble(); val c = poly.coeff(0).toDouble()
                val vx = -b / (2 * a); val vy = a * vx * vx + b * vx + c
                if (a > 0) "y ∈ [${formatDecimal(vy, 4)}, +∞)  (mínimo en V(${formatDecimal(vx, 3)}, ${formatDecimal(vy, 3)}))"
                else "y ∈ (-∞, ${formatDecimal(vy, 4)}]  (máximo en V(${formatDecimal(vx, 3)}, ${formatDecimal(vy, 3)}))"
            }
            minValY.isFinite() && maxValY.isFinite() -> {
                val lo = if (minValY < -1000) "-∞" else formatDecimal(minValY, 3)
                val hi = if (maxValY > 1000) "+∞" else formatDecimal(maxValY, 3)
                "y ∈ [$lo, $hi] (en [-20, 20])"
            }
            else -> "y ∈ ℝ"
        }

        // Paridad: comprobar f(-x) vs f(x) y -f(x) en varios puntos
        val probes = listOf(0.5, 1.3, 2.7, 4.1)
        val validProbes = probes.filter { f(it).isFinite() && f(-it).isFinite() }
        val parityStr = when {
            validProbes.size < 2 -> "No simétrica (dominio no simétrico respecto a 0)"
            validProbes.all { abs(f(-it) - f(it)) < 1e-6 } -> "Par: f(−x) = f(x) (simétrica respecto al eje Y)"
            validProbes.all { abs(f(-it) + f(it)) < 1e-6 } -> "Impar: f(−x) = −f(x) (simétrica respecto al origen)"
            else -> "Ni par ni impar"
        }

        // Monotonía aproximada por signo de derivada numérica en [-10, 10]
        val incIntervals = ArrayList<String>()
        val decIntervals = ArrayList<String>()
        var curSign = 0
        var segStart = -10.0
        var t = -10.0
        while (t <= 10.0) {
            val d = (f(t + 1e-3) - f(t - 1e-3)) / 2e-3
            val sgn = when {
                !d.isFinite() -> 0
                d > 1e-4 -> 1
                d < -1e-4 -> -1
                else -> 0
            }
            if (sgn != curSign) {
                if (curSign == 1 && t - segStart > 0.25) incIntervals.add("(${formatDecimal(segStart, 2)}, ${formatDecimal(t, 2)})")
                if (curSign == -1 && t - segStart > 0.25) decIntervals.add("(${formatDecimal(segStart, 2)}, ${formatDecimal(t, 2)})")
                curSign = sgn; segStart = t
            }
            t += 0.2
        }
        if (curSign == 1 && 10.0 - segStart > 0.25) incIntervals.add("(${formatDecimal(segStart, 2)}, +∞)")
        if (curSign == -1 && 10.0 - segStart > 0.25) decIntervals.add("(${formatDecimal(segStart, 2)}, +∞)")
        val monoStr = buildString {
            if (incIntervals.isNotEmpty()) append("Creciente: ${incIntervals.joinToString(" ∪ ")}")
            if (decIntervals.isNotEmpty()) {
                if (isNotEmpty()) append("\n")
                append("Decreciente: ${decIntervals.joinToString(" ∪ ")}")
            }
            if (isEmpty()) append("Constante")
        }

        // Signo usando las raíces encontradas
        val signBounds = listOf(-20.0) + roots.filter { it in -20.0..20.0 } + listOf(20.0)
        val posInts = ArrayList<String>(); val negInts = ArrayList<String>()
        for (i in 0 until signBounds.lastIndex) {
            val a = signBounds[i]; val b = signBounds[i + 1]
            if (b - a < 1e-3) continue
            val yMid = f((a + b) / 2.0)
            val aL = if (i == 0) "-∞" else formatDecimal(a, 2)
            val bL = if (i == signBounds.lastIndex - 1) "+∞" else formatDecimal(b, 2)
            if (yMid.isFinite()) {
                if (yMid > 1e-6) posInts.add("($aL, $bL)") else if (yMid < -1e-6) negInts.add("($aL, $bL)")
            }
        }
        val signStr = "Positiva (+): ${posInts.ifEmpty { listOf("∅") }.joinToString(" ∪ ")}\nNegativa (−): ${negInts.ifEmpty { listOf("∅") }.joinToString(" ∪ ")}"
        val asymStr = buildList {
            if (vAsymptotes.isNotEmpty()) add("Verticales: ${vAsymptotes.joinToString(", ") { "x = ${formatDecimal(it, 2)}" }}")
            if (hAsym.isNotEmpty()) add("Horizontales: ${hAsym.joinToString(", ")}")
        }.ifEmpty { listOf("Sin asíntotas detectadas") }.joinToString("\n")

        val extraPts = ArrayList<PmPlotPoint>()
        if (poly != null && poly.degree == 2) {
            val a = poly.coeff(2).toDouble(); val b = poly.coeff(1).toDouble(); val c = poly.coeff(0).toDouble()
            val vx = -b / (2 * a); val vy = a * vx * vx + b * vx + c
            extraPts.add(PmPlotPoint(vx, vy, "Vértice (${formatDecimal(vx, 2)}, ${formatDecimal(vy, 2)})", "vertex"))
        }
        val plot = PmSolver.buildPlotForExpr(expr, v, extraPts)

        return FunctionStudyResult(
            ok = true,
            expression = "f($v) = ${PmFormatter.format(expr)}",
            family = family,
            domain = domainStr,
            range = rangeStr,
            zeros = zerosStr,
            yIntercept = yIntStr,
            parity = parityStr,
            monotonicity = monoStr,
            signAnalysis = signStr,
            asymptotes = asymStr,
            plot = plot
        )
    }

    private fun containsNode(e: PmExpr, pred: (PmExpr) -> Boolean): Boolean {
        if (pred(e)) return true
        return when (e) {
            is PmExpr.Neg -> containsNode(e.inner, pred)
            is PmExpr.Add -> containsNode(e.left, pred) || containsNode(e.right, pred)
            is PmExpr.Sub -> containsNode(e.left, pred) || containsNode(e.right, pred)
            is PmExpr.Mul -> containsNode(e.left, pred) || containsNode(e.right, pred)
            is PmExpr.Div -> containsNode(e.num, pred) || containsNode(e.den, pred)
            is PmExpr.Pow -> containsNode(e.base, pred) || containsNode(e.exp, pred)
            is PmExpr.Root -> containsNode(e.radicand, pred)
            is PmExpr.Abs -> containsNode(e.inner, pred)
            is PmExpr.Func -> e.args.any { containsNode(it, pred) }
            else -> false
        }
    }
}

// ==============================================================================
// 6. NÚMEROS COMPLEJOS (12MO GRADO: BINÓMICA, TRIGONOMÉTRICA, DE MOIVRE, RAÍCES, ARGAND)
// ==============================================================================

@Immutable
data class ComplexLabResult(
    val title: String,
    val mainAnswer: String,
    val modulus: Double,
    val argDeg: Double,
    val trigForm: String,
    val polarForm: String,
    val conjugate: String,
    val steps: List<PmStep>,
    val argandPoints: List<Pair<Complex, String>>,
    val connectPolygon: Boolean = false
)

object ComplexEngine {
    fun analyzeSingle(a: Double, b: Double): ComplexLabResult {
        val z = Complex(a, b)
        val r = hypot(a, b)
        val rad = atan2(b, a).let { if (it < 0) it + 2 * PI else it }
        val deg = Math.toDegrees(rad)
        val zStr = PmEval.formatComplex(z)
        val conj = PmEval.formatComplex(Complex(a, -b))
        val trig = "${formatDecimal(r, 4)} · (cos ${formatDecimal(deg, 1)}° + i·sin ${formatDecimal(deg, 1)}°)"
        val polar = "${formatDecimal(r, 4)} ∠ ${formatDecimal(deg, 1)}°"
        val steps = listOf(
            PmStep(1, "Calcular el módulo |z| = √(a² + b²)", "Distancia del afijo (${formatDecimal(a, 2)}, ${formatDecimal(b, 2)}) al origen.", "|z| = √(${formatDecimal(a * a, 3)} + ${formatDecimal(b * b, 3)}) = ${formatDecimal(r, 4)}", highlightSegment = formatDecimal(r, 4)),
            PmStep(2, "Calcular el argumento principal θ = atan2(b, a)", "Ubicamos el cuadrante correcto en [0°, 360°).", "θ = ${formatDecimal(deg, 2)}°  (${formatDecimal(rad, 4)} rad)", highlightSegment = "${formatDecimal(deg, 2)}°"),
            PmStep(3, "Escribir en forma trigonométrica y polar", "z = |z|·(cos θ + i·sin θ).", trig, highlightSegment = trig)
        )
        return ComplexLabResult("Análisis de número complejo", zStr, r, deg, trig, polar, conj, steps, listOf(z to "z", Complex(a, -b) to "z̄"))
    }

    fun operate(a1: Double, b1: Double, a2: Double, b2: Double, op: String): ComplexLabResult {
        val z1 = Complex(a1, b1); val z2 = Complex(a2, b2)
        val z1S = PmEval.formatComplex(z1); val z2S = PmEval.formatComplex(z2)
        val steps = ArrayList<PmStep>()
        val res = when (op) {
            "+" -> {
                val r = z1.add(z2)
                steps.add(PmStep(1, "Sumar partes reales e imaginarias por separado", "(${formatDecimal(a1)} + ${formatDecimal(a2)}) + (${formatDecimal(b1)} + ${formatDecimal(b2)})i.", PmEval.formatComplex(r), highlightSegment = PmEval.formatComplex(r)))
                r
            }
            "-" -> {
                val r = z1.subtract(z2)
                steps.add(PmStep(1, "Restar partes reales e imaginarias", "(${formatDecimal(a1)} − ${formatDecimal(a2)}) + (${formatDecimal(b1)} − ${formatDecimal(b2)})i.", PmEval.formatComplex(r), highlightSegment = PmEval.formatComplex(r)))
                r
            }
            "*" -> {
                val r = z1.multiply(z2)
                steps.add(PmStep(1, "Aplicar propiedad distributiva (FOIL)", "Multiplicamos cada término y usamos i² = −1.", "(${formatDecimal(a1 * a2)} − ${formatDecimal(b1 * b2)}) + (${formatDecimal(a1 * b2)} + ${formatDecimal(b1 * a2)})i"))
                steps.add(PmStep(2, "Agrupar parte real e imaginaria", "Simplificamos el resultado.", PmEval.formatComplex(r), highlightSegment = PmEval.formatComplex(r)))
                r
            }
            else -> { // División
                val den = a2 * a2 + b2 * b2
                if (den < 1e-12) return analyzeSingle(0.0, 0.0).copy(title = "División indefinida", mainAnswer = "Error: división entre 0")
                val r = z1.divide(z2)
                val conj2 = PmEval.formatComplex(Complex(a2, -b2))
                steps.add(PmStep(1, "Multiplicar numerador y denominador por el conjugado del denominador ($conj2)", "El denominador se convierte en un número real: a₂² + b₂² = ${formatDecimal(den, 4)}.", "($z1S)·($conj2) / ${formatDecimal(den, 4)}"))
                steps.add(PmStep(2, "Separar parte real e imaginaria", "Dividimos cada componente entre ${formatDecimal(den, 4)}.", PmEval.formatComplex(r), highlightSegment = PmEval.formatComplex(r)))
                r
            }
        }
        val info = analyzeSingle(res.real, res.imaginary)
        return info.copy(
            title = "Operación ($z1S) $op ($z2S)",
            steps = steps,
            argandPoints = listOf(z1 to "z₁", z2 to "z₂", res to "Res")
        )
    }

    /** Potencia z^n por Teorema de De Moivre y Raíces n-ésimas con polígono en Argand. */
    fun deMoivrePower(a: Double, b: Double, n: Int): ComplexLabResult {
        val z = Complex(a, b)
        val r = hypot(a, b)
        val rad = atan2(b, a).let { if (it < 0) it + 2 * PI else it }
        val newR = r.pow(n)
        val newRad = rad * n
        val res = Complex(newR * cos(newRad), newR * sin(newRad))
        val normDeg = ((Math.toDegrees(newRad) % 360.0) + 360.0) % 360.0
        val steps = listOf(
            PmStep(1, "Pasar z a forma trigonométrica", "|z| = ${formatDecimal(r, 4)}, θ = ${formatDecimal(Math.toDegrees(rad), 2)}°.", "${formatDecimal(r, 3)}·(cos ${formatDecimal(Math.toDegrees(rad), 1)}° + i·sin ${formatDecimal(Math.toDegrees(rad), 1)}°)"),
            PmStep(2, "Aplicar Fórmula de De Moivre: zⁿ = rⁿ·(cos nθ + i·sin nθ)", "Elevamos el módulo a $n y multiplicamos el argumento por $n.", "${formatDecimal(newR, 4)}·(cos ${formatDecimal(normDeg, 1)}° + i·sin ${formatDecimal(normDeg, 1)}°)", highlightSegment = formatDecimal(newR, 4)),
            PmStep(3, "Convertir de vuelta a forma binómica", "Evaluamos parte real y parte imaginaria.", PmEval.formatComplex(res), highlightSegment = PmEval.formatComplex(res))
        )
        return analyzeSingle(res.real, res.imaginary).copy(
            title = "Teorema de De Moivre: z^$n",
            steps = steps,
            argandPoints = listOf(z to "z", res to "z^$n")
        )
    }

    fun nthRoots(a: Double, b: Double, n: Int): ComplexLabResult {
        val safeN = n.coerceIn(2, 12)
        val r = hypot(a, b)
        val rad = atan2(b, a).let { if (it < 0) it + 2 * PI else it }
        val rootR = r.pow(1.0 / safeN)
        val pts = ArrayList<Pair<Complex, String>>()
        val subSteps = ArrayList<PmSubStep>()
        for (k in 0 until safeN) {
            val ang = (rad + 2.0 * PI * k) / safeN
            val w = Complex(rootR * cos(ang), rootR * sin(ang))
            pts.add(w to "w$k")
            subSteps.add(PmSubStep("k = $k (θ = ${formatDecimal(Math.toDegrees(ang), 1)}°)", "w_$k = ${PmEval.formatComplex(w)}"))
        }
        val steps = listOf(
            PmStep(1, "Fórmula de las raíces $safeN-ésimas de un complejo", "w_k = ⁿ√|z| · [cos((θ + 2kπ)/n) + i·sin((θ + 2kπ)/n)], para k = 0, 1, …, ${safeN - 1}.", "Módulo de cada raíz = ${formatDecimal(rootR, 4)}", highlightSegment = formatDecimal(rootR, 4)),
            PmStep(2, "Las $safeN raíces forman un polígono regular en el Plano de Argand", "Están separadas por ${formatDecimal(360.0 / safeN, 1)}° sobre la circunferencia de radio ${formatDecimal(rootR, 3)}.", pts.joinToString(" ; ") { "${it.second} = ${PmEval.formatComplex(it.first)}" }, subSteps = subSteps)
        )
        val ans = pts.joinToString("\n") { "${it.second} = ${PmEval.formatComplex(it.first)}" }
        return ComplexLabResult(
            title = "Raíces $safeN-ésimas de z",
            mainAnswer = ans,
            modulus = rootR,
            argDeg = Math.toDegrees(rad / safeN),
            trigForm = "Radio = ${formatDecimal(rootR, 4)} · Paso angular = ${formatDecimal(360.0 / safeN, 1)}°",
            polarForm = "$safeN raíces sobre |w| = ${formatDecimal(rootR, 4)}",
            conjugate = PmEval.formatComplex(Complex(a, -b)),
            steps = steps,
            argandPoints = pts,
            connectPolygon = true
        )
    }
}
