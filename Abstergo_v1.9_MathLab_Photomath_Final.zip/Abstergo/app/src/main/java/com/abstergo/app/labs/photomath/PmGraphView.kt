package com.abstergo.app.labs.photomath

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

/**
 * Graficador 2D nativo a 60 fps estilo Photomath (cero WebView, 100% offline):
 * - Zoom con dos dedos y arrastre fluido con 1 dedo
 * - Rejilla adaptativa automática (1, 2, 5 × 10^n)
 * - Detección de discontinuidades/asíntotas (sin trazos verticales falsos)
 * - Tocar cualquier punto traza una mira interactiva mostrando (x, y) exacto
 * - Puntos notables marcados (raíces, corte en Y, vértice, intersección)
 */
@Composable
fun PmInteractiveGraph(
    plot: PmPlotData,
    modifier: Modifier = Modifier,
    onExpandFullscreen: (() -> Unit)? = null
) {
    var xMin by remember(plot) { mutableStateOf(plot.xMin) }
    var xMax by remember(plot) { mutableStateOf(plot.xMax) }
    var yMin by remember(plot) { mutableStateOf(plot.yMin) }
    var yMax by remember(plot) { mutableStateOf(plot.yMax) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var traceX by remember(plot) { mutableStateOf<Double?>(null) }

    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bgColor = if (dark) Color(0xFF14171D) else Color(0xFFFFFFFF)
    val gridColor = if (dark) Color(0xFF262B35) else Color(0xFFE7EAF0)
    val axisColor = if (dark) Color(0xFF9AA4B2) else Color(0xFF374151)
    val labelArgb = (if (dark) Color(0xFFCBD5E1) else Color(0xFF4B5563)).toArgb()

    val labelPaint = remember(labelArgb) {
        Paint().apply {
            isAntiAlias = true
            color = labelArgb
            textSize = 27f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
    }

    fun resetBounds() {
        xMin = plot.xMin; xMax = plot.xMax; yMin = plot.yMin; yMax = plot.yMax
        traceX = null
    }

    fun zoomBy(factor: Double) {
        val cx = (xMin + xMax) / 2.0
        val cy = (yMin + yMax) / 2.0
        val hx = ((xMax - xMin) / 2.0 * factor).coerceIn(0.2, 5000.0)
        val hy = ((yMax - yMin) / 2.0 * factor).coerceIn(0.2, 5000.0)
        xMin = cx - hx; xMax = cx + hx; yMin = cy - hy; yMax = cy + hy
    }

    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(bgColor)
                .onSizeChanged { canvasSize = it }
                .pointerInput(plot) {
                    detectTransformGestures { centroid, pan, zoom, _ ->
                        val w = canvasSize.width.toDouble().coerceAtLeast(1.0)
                        val h = canvasSize.height.toDouble().coerceAtLeast(1.0)
                        val curSpanX = xMax - xMin
                        val curSpanY = yMax - yMin

                        // Desplazamiento proporcional
                        val dxWorld = -pan.x / w * curSpanX
                        val dyWorld = pan.y / h * curSpanY
                        var nxMin = xMin + dxWorld
                        var nxMax = xMax + dxWorld
                        var nyMin = yMin + dyWorld
                        var nyMax = yMax + dyWorld

                        // Zoom centrado en el pellizco
                        if (zoom != 1f && zoom.isFinite() && zoom > 0.01f) {
                            val z = zoom.toDouble()
                            val focusX = nxMin + (centroid.x / w) * (nxMax - nxMin)
                            val focusY = nyMax - (centroid.y / h) * (nyMax - nyMin)
                            val newSpanX = ((nxMax - nxMin) / z).coerceIn(0.4, 10000.0)
                            val newSpanY = ((nyMax - nyMin) / z).coerceIn(0.4, 10000.0)
                            val rx = (focusX - nxMin) / (nxMax - nxMin)
                            val ry = (nyMax - focusY) / (nyMax - nyMin)
                            nxMin = focusX - rx * newSpanX
                            nxMax = nxMin + newSpanX
                            nyMax = focusY + ry * newSpanY
                            nyMin = nyMax - newSpanY
                        }
                        xMin = nxMin; xMax = nxMax; yMin = nyMin; yMax = nyMax
                    }
                }
                .pointerInput(plot) {
                    detectTapGestures(
                        onTap = { pos ->
                            val w = canvasSize.width.toDouble().coerceAtLeast(1.0)
                            traceX = xMin + (pos.x / w) * (xMax - xMin)
                        },
                        onDoubleTap = { resetBounds() }
                    )
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                if (w <= 1f || h <= 1f) return@Canvas
                val spanX = (xMax - xMin).coerceAtLeast(1e-6)
                val spanY = (yMax - yMin).coerceAtLeast(1e-6)

                fun wx(x: Double): Float = (((x - xMin) / spanX) * w).toFloat()
                fun wy(y: Double): Float = (((yMax - y) / spanY) * h).toFloat()

                // 1) Rejilla adaptativa
                val stepX = niceGridStep(spanX / 6.0)
                val stepY = niceGridStep(spanY / 6.0)

                val firstX = ceil(xMin / stepX) * stepX
                var gx = firstX
                var guard = 0
                while (gx <= xMax && guard < 120) {
                    val px = wx(gx)
                    drawLine(gridColor, Offset(px, 0f), Offset(px, h), strokeWidth = 1.5f)
                    gx += stepX; guard++
                }

                val firstY = ceil(yMin / stepY) * stepY
                var gy = firstY
                guard = 0
                while (gy <= yMax && guard < 120) {
                    val py = wy(gy)
                    drawLine(gridColor, Offset(0f, py), Offset(w, py), strokeWidth = 1.5f)
                    gy += stepY; guard++
                }

                // 2) Ejes X e Y
                val axisXPos = wy(0.0).coerceIn(18f, h - 24f)
                val axisYPos = wx(0.0).coerceIn(24f, w - 18f)
                if (0.0 in yMin..yMax) {
                    drawLine(axisColor, Offset(0f, wy(0.0)), Offset(w, wy(0.0)), strokeWidth = 3f)
                }
                if (0.0 in xMin..xMax) {
                    drawLine(axisColor, Offset(wx(0.0), 0f), Offset(wx(0.0), h), strokeWidth = 3f)
                }

                // Etiquetas de ejes
                drawContext.canvas.nativeCanvas.apply {
                    gx = firstX; guard = 0
                    while (gx <= xMax && guard < 60) {
                        if (abs(gx) > stepX * 0.2) {
                            val px = wx(gx)
                            if (px in 28f..(w - 28f)) {
                                drawText(formatTick(gx), px - 10f, axisXPos + 28f, labelPaint)
                            }
                        }
                        gx += stepX; guard++
                    }
                    gy = firstY; guard = 0
                    while (gy <= yMax && guard < 60) {
                        if (abs(gy) > stepY * 0.2) {
                            val py = wy(gy)
                            if (py in 28f..(h - 28f)) {
                                drawText(formatTick(gy), axisYPos + 8f, py + 8f, labelPaint)
                            }
                        }
                        gy += stepY; guard++
                    }
                }

                // 3) Curvas suaves con corte automático en discontinuidades/asíntotas
                val samples = (w / 2.2f).toInt().coerceIn(160, 420)
                val yJumpLimit = spanY * 2.2
                plot.curves.forEach { curve ->
                    val path = Path()
                    var penDown = false
                    var lastY = Double.NaN
                    for (s in 0..samples) {
                        val x = xMin + (s.toDouble() / samples) * spanX
                        val y = PmEval.evalDouble(curve.expr, mapOf(curve.variable to x))
                        if (!y.isFinite() || y < yMin - spanY * 3 || y > yMax + spanY * 3) {
                            penDown = false
                            lastY = Double.NaN
                            continue
                        }
                        if (penDown && lastY.isFinite() && abs(y - lastY) > yJumpLimit) {
                            penDown = false
                        }
                        val px = wx(x)
                        val py = wy(y)
                        if (!penDown) {
                            path.moveTo(px, py)
                            penDown = true
                        } else {
                            path.lineTo(px, py)
                        }
                        lastY = y
                    }
                    drawPath(
                        path = path,
                        color = Color(curve.colorHex),
                        style = Stroke(width = 5.5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }

                // 4) Puntos notables (raíces, vértice, corte Y, intersección)
                plot.points.forEach { pt ->
                    if (pt.x in xMin..xMax && pt.y in yMin..yMax) {
                        val c = Offset(wx(pt.x), wy(pt.y))
                        val dotColor = pointColorFor(pt.kind)
                        drawCircle(bgColor, radius = 11f, center = c)
                        drawCircle(dotColor, radius = 8f, center = c)
                    }
                }

                // 5) Mira interactiva al tocar la gráfica
                val tx = traceX
                if (tx != null && tx in xMin..xMax && plot.curves.isNotEmpty()) {
                    val mainCurve = plot.curves[0]
                    val ty = PmEval.evalDouble(mainCurve.expr, mapOf(mainCurve.variable to tx))
                    val px = wx(tx)
                    drawLine(axisColor.copy(alpha = 0.55f), Offset(px, 0f), Offset(px, h), strokeWidth = 2f)
                    if (ty.isFinite() && ty in yMin..yMax) {
                        val py = wy(ty)
                        drawLine(axisColor.copy(alpha = 0.4f), Offset(0f, py), Offset(w, py), strokeWidth = 2f)
                        drawCircle(Color(mainCurve.colorHex), radius = 12f, center = Offset(px, py), style = Stroke(width = 4f))
                        drawCircle(bgColor, radius = 6f, center = Offset(px, py))
                    }
                }
            }

            // Burbuja flotante con coordenadas exactas al tocar
            val tx = traceX
            if (tx != null && plot.curves.isNotEmpty()) {
                val ty = PmEval.evalDouble(plot.curves[0].expr, mapOf(plot.curves[0].variable to tx))
                val label = if (ty.isFinite()) "x = ${formatDecimal(tx, 3)},  y = ${formatDecimal(ty, 3)}"
                else "x = ${formatDecimal(tx, 3)} (indefinido)"
                Box(
                    Modifier.align(Alignment.TopStart).padding(10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.inverseSurface.copy(alpha = 0.9f))
                        .clickable { traceX = null }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(label, color = MaterialTheme.colorScheme.inverseOnSurface, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Controles flotantes (+, -, Centrar, Pantalla completa)
            Row(
                Modifier.align(Alignment.BottomEnd).padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                GraphHudButton("+") { zoomBy(0.72) }
                GraphHudButton("−") { zoomBy(1.38) }
                GraphHudButton("◎") { resetBounds() }
                if (onExpandFullscreen != null) {
                    GraphHudButton("⤢") { onExpandFullscreen() }
                }
            }
        }

        // Leyenda de puntos notables
        if (plot.points.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                plot.points.forEach { pt ->
                    Row(
                        Modifier.clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { traceX = pt.x }
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(pointColorFor(pt.kind)))
                        Spacer(Modifier.width(6.dp))
                        Text(pt.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun GraphHudButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
    }
}

private fun pointColorFor(kind: String): Color = when (kind) {
    "root" -> Color(0xFF00C853)
    "yintercept" -> Color(0xFF2563EB)
    "vertex" -> Color(0xFFF59E0B)
    "intersection" -> Color(0xFF8B5CF6)
    else -> Color(0xFF10B981)
}

private fun niceGridStep(rough: Double): Double {
    val safe = rough.coerceAtLeast(1e-6)
    val exp = floor(log10(safe))
    val base = 10.0.pow(exp)
    val frac = safe / base
    return when {
        frac < 1.5 -> 1.0 * base
        frac < 3.5 -> 2.0 * base
        frac < 7.5 -> 5.0 * base
        else -> 10.0 * base
    }
}

private fun formatTick(v: Double): String {
    val clean = if (abs(v) < 1e-9) 0.0 else v
    val r = kotlin.math.round(clean)
    return if (abs(clean - r) < 1e-6) r.toLong().toString() else formatDecimal(clean, 2)
}
