package com.abstergo.app.labs

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abstergo.app.LineSymbol
import com.abstergo.app.RedDot
import com.abstergo.app.labs.photomath.PhotomathLabScreen

/**
 * Pestaña principal Labs:
 * muestra el catálogo de Laboratorios por asignatura y abre el clon de Photomath en Matemática Labs.
 */
@Composable
fun LabsTab(
    labExercises: List<LabExercise>,
    authorName: String,
    openSubject: String?,
    onOpenSubject: (String?) -> Unit,
    onChangeExercises: (List<LabExercise>) -> Unit,
    onImportAbsLabClick: () -> Unit
) {
    if (openSubject == "m") {
        PhotomathLabScreen(
            allExercises = labExercises,
            authorName = authorName,
            onBackToLabs = { onOpenSubject(null) },
            onChangeExercises = onChangeExercises,
            onImportAbsLabClick = onImportAbsLabClick
        )
    } else {
        LabsGalleryScreen(
            labExercises = labExercises,
            onSelectLab = { key -> onOpenSubject(key) },
            onImportAbsLabClick = onImportAbsLabClick
        )
    }
}

@Composable
private fun LabsGalleryScreen(
    labExercises: List<LabExercise>,
    onSelectLab: (String) -> Unit,
    onImportAbsLabClick: () -> Unit
) {
    val ctx = LocalContext.current
    val bySubject = remember(labExercises) { labExercises.groupBy { it.subject } }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Labs", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton(onImportAbsLabClick, shape = RoundedCornerShape(14.dp)) {
                Text("Importar .abslab")
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Laboratorios interactivos offline por asignatura",
            Modifier.padding(horizontal = 20.dp),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        LazyColumn(
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(LAB_CATALOG, key = { it.key }) { lab ->
                val list = bySubject[lab.key].orEmpty()
                val done = list.count { it.done }
                val hasNew = list.any { it.isNew }
                Row(
                    Modifier.fillMaxWidth()
                        .alpha(if (lab.active) 1f else 0.62f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable {
                            if (lab.active) onSelectLab(lab.key)
                            else Toast.makeText(ctx, "${lab.title} llega en una próxima versión.", Toast.LENGTH_SHORT).show()
                        }
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (lab.active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        LineSymbol(
                            lab.symbol, 1f,
                            if (lab.active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                            Modifier.size(32.dp), 4.5f
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(lab.title, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f, fill = false))
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier.clip(RoundedCornerShape(50))
                                    .background(if (lab.active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    if (lab.active) "ACTIVO" else "PRONTO",
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                    color = if (lab.active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (hasNew) {
                                Spacer(Modifier.width(8.dp))
                                RedDot()
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(lab.subtitle, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
                        if (lab.active && list.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text("${list.size} ejercicios guardados · $done completados", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { done.toFloat() / list.size.coerceAtLeast(1) },
                                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(4.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}
