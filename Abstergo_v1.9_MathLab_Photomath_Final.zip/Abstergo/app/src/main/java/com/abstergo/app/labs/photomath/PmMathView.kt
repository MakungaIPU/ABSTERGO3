package com.abstergo.app.labs.photomath

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Renderizador matemático 2D nativo en Jetpack Compose (cero WebView, 60 fps, 100% offline):
 * dibuja fracciones apiladas, raíces con barra superior, exponentes elevados,
 * barras de valor absoluto, derivadas, integrales y sistemas con llave.
 */
@Composable
fun PmMathFormulaView(
    text: String,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 20.sp,
    color: Color = MaterialTheme.colorScheme.onBackground,
    highlightSegment: String = "",
    scrollable: Boolean = true
) {
    val parsed = remember(text) {
        try {
            if (text.contains("±") || text.contains("≈") || text.contains("∈") ||
                text.contains("Caso ") || text.contains("Ec.") || text.contains("Δ =") ||
                text.contains("∪") || text.contains(" rad") || text.contains("°") || text.contains("  o  ")
            ) {
                null
            } else {
                PmParser.parse(text)
            }
        } catch (_: Exception) {
            null
        }
    }
    val hlColor = labAccent()
    val containerMod = if (scrollable) modifier.horizontalScroll(rememberScrollState()) else modifier

    Box(modifier = containerMod, contentAlignment = Alignment.CenterStart) {
        if (parsed != null && highlightSegment.isBlank()) {
            PmExprNodeView(expr = parsed, fontSize = fontSize, color = color)
        } else if (parsed != null && text.trim() == highlightSegment.trim()) {
            PmExprNodeView(expr = parsed, fontSize = fontSize, color = hlColor)
        } else {
            PmHighlightedMathText(
                text = text,
                highlightSegment = highlightSegment,
                fontSize = fontSize,
                color = color,
                highlightColor = hlColor
            )
        }
    }
}

/** Renderiza directamente un AST PmExpr en notación 2D de libro de texto. */
@Composable
fun PmExprNodeView(
    expr: PmExpr,
    fontSize: TextUnit = 20.sp,
    color: Color = MaterialTheme.colorScheme.onBackground,
    parentPrec: Int = 0
) {
    val smallSize = (fontSize.value * 0.72f).coerceAtLeast(11f).sp
    val tinySize = (fontSize.value * 0.58f).coerceAtLeast(10f).sp

    when (expr) {
        is PmExpr.Num -> {
            if (expr.rat.isInt) {
                Text(expr.rat.num.toString(), fontSize = fontSize, fontWeight = FontWeight.SemiBold, color = color)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (expr.rat.isNegative) {
                        Text("−", fontSize = fontSize, fontWeight = FontWeight.SemiBold, color = color, modifier = Modifier.padding(end = 2.dp))
                    }
                    StackedFraction(
                        top = { Text(expr.rat.num.abs().toString(), fontSize = smallSize, fontWeight = FontWeight.SemiBold, color = color) },
                        bottom = { Text(expr.rat.den.toString(), fontSize = smallSize, fontWeight = FontWeight.SemiBold, color = color) },
                        barColor = color
                    )
                }
            }
        }

        is PmExpr.Sym -> {
            Text(expr.name, fontSize = fontSize, fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, color = color)
        }

        is PmExpr.Const -> {
            val label = when (expr.name) {
                "pi" -> "π"
                "inf" -> "∞"
                else -> expr.name
            }
            Text(
                label,
                fontSize = fontSize,
                fontStyle = if (expr.name == "i" || expr.name == "e") FontStyle.Italic else FontStyle.Normal,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }

        is PmExpr.Neg -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("−", fontSize = fontSize, fontWeight = FontWeight.SemiBold, color = color)
                val needsP = expr.inner is PmExpr.Add || expr.inner is PmExpr.Sub
                if (needsP) Text("(", fontSize = fontSize, color = color)
                PmExprNodeView(expr.inner, fontSize, color, 70)
                if (needsP) Text(")", fontSize = fontSize, color = color)
            }
        }

        is PmExpr.Add -> {
            val wrap = 50 < parentPrec
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (wrap) Text("(", fontSize = fontSize, color = color)
                PmExprNodeView(expr.left, fontSize, color, 50)
                Text(" + ", fontSize = fontSize, color = color)
                PmExprNodeView(expr.right, fontSize, color, 50)
                if (wrap) Text(")", fontSize = fontSize, color = color)
            }
        }

        is PmExpr.Sub -> {
            val wrap = 50 < parentPrec
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (wrap) Text("(", fontSize = fontSize, color = color)
                PmExprNodeView(expr.left, fontSize, color, 50)
                Text(" − ", fontSize = fontSize, color = color)
                PmExprNodeView(expr.right, fontSize, color, 51)
                if (wrap) Text(")", fontSize = fontSize, color = color)
            }
        }

        is PmExpr.Mul -> {
            val wrap = 60 < parentPrec
            val leftNum = expr.left is PmExpr.Num || (expr.left is PmExpr.Neg && expr.left.inner is PmExpr.Num)
            val rightSym = expr.right is PmExpr.Sym || expr.right is PmExpr.Const || expr.right is PmExpr.Root ||
                expr.right is PmExpr.Func || (expr.right is PmExpr.Pow && (expr.right.base is PmExpr.Sym || expr.right.base is PmExpr.Const))
            val implicit = leftNum && rightSym
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (wrap) Text("(", fontSize = fontSize, color = color)
                PmExprNodeView(expr.left, fontSize, color, 60)
                if (!implicit) Text(" · ", fontSize = fontSize, color = color)
                PmExprNodeView(expr.right, fontSize, color, 60)
                if (wrap) Text(")", fontSize = fontSize, color = color)
            }
        }

        is PmExpr.Div -> {
            StackedFraction(
                top = { PmExprNodeView(expr.num, smallSize, color, 0) },
                bottom = { PmExprNodeView(expr.den, smallSize, color, 0) },
                barColor = color
            )
        }

        is PmExpr.Pow -> {
            Row(verticalAlignment = Alignment.Top) {
                val wrapBase = expr.base is PmExpr.Add || expr.base is PmExpr.Sub || expr.base is PmExpr.Div || expr.base is PmExpr.Neg
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                    if (wrapBase) Text("(", fontSize = fontSize, color = color)
                    PmExprNodeView(expr.base, fontSize, color, 81)
                    if (wrapBase) Text(")", fontSize = fontSize, color = color)
                }
                Box(Modifier.padding(start = 1.dp)) {
                    PmExprNodeView(expr.exp, smallSize, color, 0)
                }
            }
        }

        is PmExpr.Root -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (expr.index != null) {
                    Box(Modifier.align(Alignment.Top).padding(end = 1.dp)) {
                        PmExprNodeView(expr.index, tinySize, color, 0)
                    }
                }
                Box(
                    modifier = Modifier
                        .drawBehind {
                            val strokeW = (fontSize.value * 0.08f).coerceIn(1.5f, 3.2f)
                            val lead = 12.dp.toPx()
                            val topY = 2.dp.toPx()
                            val p = Path().apply {
                                moveTo(0f, size.height * 0.58f)
                                lineTo(lead * 0.32f, size.height * 0.52f)
                                lineTo(lead * 0.62f, size.height * 0.90f)
                                lineTo(lead, topY)
                                lineTo(size.width, topY)
                            }
                            drawPath(p, color = color, style = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                        .padding(start = 14.dp, top = 4.dp, end = 4.dp, bottom = 2.dp)
                ) {
                    PmExprNodeView(expr.radicand, fontSize, color, 0)
                }
            }
        }

        is PmExpr.Abs -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("|", fontSize = fontSize, fontWeight = FontWeight.Normal, color = color)
                Box(Modifier.padding(horizontal = 2.dp)) {
                    PmExprNodeView(expr.inner, fontSize, color, 0)
                }
                Text("|", fontSize = fontSize, fontWeight = FontWeight.Normal, color = color)
            }
        }

        is PmExpr.Func -> {
            if (expr.name == "factorial" && expr.args.size == 1) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PmExprNodeView(expr.args[0], fontSize, color, 90)
                    Text("!", fontSize = fontSize, fontWeight = FontWeight.Bold, color = color)
                }
            } else if (expr.name == "log" && expr.args.size == 2) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("log", fontSize = fontSize, fontWeight = FontWeight.Medium, color = color)
                    Box(Modifier.align(Alignment.Bottom).padding(end = 1.dp)) {
                        PmExprNodeView(expr.args[0], tinySize, color, 0)
                    }
                    Text("(", fontSize = fontSize, color = color)
                    PmExprNodeView(expr.args[1], fontSize, color, 0)
                    Text(")", fontSize = fontSize, color = color)
                }
            } else {
                val displayName = when (expr.name) {
                    "comb" -> "C"
                    "var" -> "V"
                    "perm" -> "P"
                    "combrep" -> "CR"
                    "varrep" -> "VR"
                    "log10" -> "log"
                    else -> expr.name
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(displayName, fontSize = fontSize, fontWeight = FontWeight.Bold, color = color)
                    Text("(", fontSize = fontSize, color = color)
                    expr.args.forEachIndexed { idx, arg ->
                        if (idx > 0) Text(", ", fontSize = fontSize, color = color)
                        PmExprNodeView(arg, fontSize, color, 0)
                    }
                    Text(")", fontSize = fontSize, color = color)
                }
            }
        }

        is PmExpr.Deriv -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StackedFraction(
                    top = { Text("d", fontSize = smallSize, fontStyle = FontStyle.Italic, color = color) },
                    bottom = { Text("d${expr.variable}", fontSize = smallSize, fontStyle = FontStyle.Italic, color = color) },
                    barColor = color
                )
                Text(" (", fontSize = fontSize, color = color)
                PmExprNodeView(expr.body, fontSize, color, 0)
                Text(")", fontSize = fontSize, color = color)
            }
        }

        is PmExpr.Integral -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("∫", fontSize = (fontSize.value * 1.45f).sp, fontWeight = FontWeight.Normal, color = color)
                if (expr.lower != null && expr.upper != null) {
                    Column(Modifier.padding(end = 4.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        PmExprNodeView(expr.upper, tinySize, color, 0)
                        PmExprNodeView(expr.lower, tinySize, color, 0)
                    }
                }
                PmExprNodeView(expr.body, fontSize, color, 0)
                Text(" d${expr.variable}", fontSize = fontSize, fontStyle = FontStyle.Italic, color = color)
            }
        }

        is PmExpr.Limit -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(end = 6.dp)) {
                    Text("lim", fontSize = fontSize, fontWeight = FontWeight.Medium, color = color)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${expr.variable}→", fontSize = tinySize, fontStyle = FontStyle.Italic, color = color)
                        PmExprNodeView(expr.target, tinySize, color, 0)
                    }
                }
                PmExprNodeView(expr.body, fontSize, color, 0)
            }
        }

        is PmExpr.Rel -> {
            val opSym = when (expr.op) {
                "<=" -> " ≤ "
                ">=" -> " ≥ "
                else -> " ${expr.op} "
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                PmExprNodeView(expr.left, fontSize, color, 0)
                Text(opSym, fontSize = fontSize, fontWeight = FontWeight.Bold, color = color)
                PmExprNodeView(expr.right, fontSize, color, 0)
            }
        }

        is PmExpr.System -> {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("{", fontSize = (fontSize.value * (1.25f + expr.items.size * 0.45f)).coerceAtMost(56f).sp, fontWeight = FontWeight.Light, color = color)
                Spacer(Modifier.width(4.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    expr.items.forEach { eq ->
                        PmExprNodeView(eq, (fontSize.value * 0.9f).sp, color, 0)
                    }
                }
            }
        }
    }
}

@Composable
private fun StackedFraction(
    top: @Composable () -> Unit,
    bottom: @Composable () -> Unit,
    barColor: Color
) {
    Column(
        modifier = Modifier.width(IntrinsicSize.Max).padding(horizontal = 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.padding(horizontal = 4.dp), contentAlignment = Alignment.Center) { top() }
        Box(Modifier.fillMaxWidth().padding(vertical = 2.dp).height(1.6.dp).background(barColor))
        Box(Modifier.padding(horizontal = 4.dp), contentAlignment = Alignment.Center) { bottom() }
    }
}

@Composable
private fun PmHighlightedMathText(
    text: String,
    highlightSegment: String,
    fontSize: TextUnit,
    color: Color,
    highlightColor: Color
) {
    val prettified = remember(text) { prettifyInlineMath(text) }
    val prettifiedHl = remember(highlightSegment) { prettifyInlineMath(highlightSegment) }
    val annotated = remember(prettified, prettifiedHl, color, highlightColor) {
        buildAnnotatedString {
            if (prettifiedHl.isNotBlank()) {
                val idx = prettified.indexOf(prettifiedHl)
                if (idx >= 0) {
                    withStyle(SpanStyle(color = color)) { append(prettified.substring(0, idx)) }
                    withStyle(SpanStyle(color = highlightColor, fontWeight = FontWeight.ExtraBold)) {
                        append(prettified.substring(idx, idx + prettifiedHl.length))
                    }
                    withStyle(SpanStyle(color = color)) { append(prettified.substring(idx + prettifiedHl.length)) }
                } else {
                    withStyle(SpanStyle(color = color)) { append(prettified) }
                }
            } else {
                withStyle(SpanStyle(color = color)) { append(prettified) }
            }
        }
    }
    Text(annotated, fontSize = fontSize, fontWeight = FontWeight.SemiBold, lineHeight = (fontSize.value * 1.35f).sp)
}

private fun prettifyInlineMath(s: String): String = s
    .replace("^2", "²")
    .replace("^3", "³")
    .replace("^4", "⁴")
    .replace("<=", "≤")
    .replace(">=", "≥")
    .replace("*", "·")

/**
 * Recta numérica interactiva con etiquetas numéricas exactas en cada punto crítico,
 * círculos abiertos/cerrados y rayos en esmeralda Abstergo.
 */
@Composable
fun InequalityNumberLine(
    intervals: List<NumberLineInterval>,
    modifier: Modifier = Modifier
) {
    val accent = labAccent()
    val axisColor = MaterialTheme.colorScheme.onSurfaceVariant
    val bgColor = MaterialTheme.colorScheme.surface
    val labelArgb = MaterialTheme.colorScheme.onSurface.toArgb()
    val subArgb = axisColor.toArgb()

    val pointPaint = remember(labelArgb) {
        Paint().apply {
            isAntiAlias = true
            color = labelArgb
            textSize = 27f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }
    val zeroPaint = remember(subArgb) {
        Paint().apply {
            isAntiAlias = true
            color = subArgb
            textSize = 23f
            textAlign = Paint.Align.CENTER
        }
    }

    val bounds = remember(intervals) {
        val pts = intervals.flatMap { listOfNotNull(it.from, it.to) }
        if (pts.isEmpty()) -5.0 to 5.0
        else {
            val lo = pts.min()
            val hi = pts.max()
            val pad = maxOf(3.0, (hi - lo) * 0.55)
            (lo - pad) to (hi + pad)
        }
    }

    Canvas(modifier = modifier.fillMaxWidth().height(84.dp)) {
        val w = size.width
        val h = size.height
        val y = h * 0.42f
        val leftX = 24.dp.toPx()
        val rightX = w - 24.dp.toPx()
        val span = (bounds.second - bounds.first).coerceAtLeast(1e-6)
        fun toX(v: Double): Float = leftX + (((v - bounds.first) / span).toFloat().coerceIn(0f, 1f)) * (rightX - leftX)

        // Eje con flechas
        drawLine(axisColor, Offset(leftX, y), Offset(rightX, y), strokeWidth = 2.5f)
        drawLine(axisColor, Offset(leftX, y), Offset(leftX + 10f, y - 6f), strokeWidth = 2.5f)
        drawLine(axisColor, Offset(leftX, y), Offset(leftX + 10f, y + 6f), strokeWidth = 2.5f)
        drawLine(axisColor, Offset(rightX, y), Offset(rightX - 10f, y - 6f), strokeWidth = 2.5f)
        drawLine(axisColor, Offset(rightX, y), Offset(rightX - 10f, y + 6f), strokeWidth = 2.5f)

        // Etiquetas -∞ y +∞
        drawContext.canvas.nativeCanvas.apply {
            drawText("−∞", leftX, y + 36f, zeroPaint)
            drawText("+∞", rightX, y + 36f, zeroPaint)
        }

        // Marca de referencia 0 si no coincide con un extremo
        val boundaryVals = intervals.flatMap { listOfNotNull(it.from, it.to) }
        if (0.0 in bounds.first..bounds.second && boundaryVals.none { kotlin.math.abs(it) < 0.08 * span }) {
            val x0 = toX(0.0)
            drawLine(axisColor, Offset(x0, y - 7f), Offset(x0, y + 7f), strokeWidth = 2f)
            drawContext.canvas.nativeCanvas.drawText("0", x0, y + 34f, zeroPaint)
        }

        // Intervalos en esmeralda Abstergo + etiquetas exactas debajo de cada punto crítico
        val drawnLabels = ArrayList<Float>()
        intervals.forEach { iv ->
            val sx = if (iv.from == null) leftX else toX(iv.from)
            val ex = if (iv.to == null) rightX else toX(iv.to)
            drawLine(accent.copy(alpha = 0.25f), Offset(sx, y), Offset(ex, y), strokeWidth = 16f, cap = StrokeCap.Round)
            drawLine(accent, Offset(sx, y), Offset(ex, y), strokeWidth = 7f, cap = StrokeCap.Round)

            fun drawEndPoint(v: Double, inc: Boolean) {
                val cx = toX(v)
                drawCircle(if (inc) accent else bgColor, radius = 9.5f, center = Offset(cx, y))
                drawCircle(accent, radius = 9.5f, center = Offset(cx, y), style = Stroke(width = 3.5f))
                if (drawnLabels.none { kotlin.math.abs(it - cx) < 32f }) {
                    drawnLabels.add(cx)
                    drawContext.canvas.nativeCanvas.drawText(formatDecimal(v, 2), cx, y + 38f, pointPaint)
                }
            }
            iv.from?.let { drawEndPoint(it, iv.includeFrom) }
            iv.to?.let { drawEndPoint(it, iv.includeTo) }
        }
    }
}
