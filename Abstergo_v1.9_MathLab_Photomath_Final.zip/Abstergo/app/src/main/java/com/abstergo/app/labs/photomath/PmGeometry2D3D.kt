package com.abstergo.app.labs.photomath

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

// ==============================================================================
// MOTOR DE GEOMETRÍA 3D LIGERO (PROYECCIÓN PERSPECTIVA + ROTACIÓN TÁCTIL 60 FPS)
// ==============================================================================

data class Vec3(val x: Double, val y: Double, val z: Double) {
    operator fun plus(o: Vec3) = Vec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vec3) = Vec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Double) = Vec3(x * s, y * s, z * s)
    fun dot(o: Vec3): Double = x * o.x + y * o.y + z * o.z
    fun cross(o: Vec3): Vec3 = Vec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun length(): Double = sqrt(x * x + y * y + z * z)
    fun normalized(): Vec3 {
        val len = length()
        return if (len < 1e-9) Vec3(0.0, 0.0, 1.0) else Vec3(x / len, y / len, z / len)
    }
}

private data class Face3D(val indices: List<Int>, val color: Color)
private data class Edge3D(val a: Int, val b: Int, val dashed: Boolean = false)
private data class Mesh3D(
    val vertices: List<Vec3>,
    val faces: List<Face3D>,
    val edges: List<Edge3D>,
    val labels: List<Pair<Vec3, String>> = emptyList()
)

private fun rotatePoint(v: Vec3, yawRad: Double, pitchRad: Double): Vec3 {
    // Rotación alrededor del eje Y (yaw / azimut) y luego eje X (pitch / elevación)
    val cy = cos(yawRad); val sy = sin(yawRad)
    val x1 = v.x * cy + v.z * sy
    val z1 = -v.x * sy + v.z * cy
    val cp = cos(pitchRad); val sp = sin(pitchRad)
    val y2 = v.y * cp - z1 * sp
    val z2 = v.y * sp + z1 * cp
    return Vec3(x1, y2, z2)
}

private fun projectPoint(v: Vec3, yaw: Double, pitch: Double, cx: Float, cy: Float, scale: Float): Triple<Float, Float, Double> {
    val r = rotatePoint(v, yaw, pitch)
    val camDist = 6.2
    val denom = (camDist - r.z).coerceAtLeast(0.8)
    val persp = (camDist / denom).toFloat()
    val sx = cx + (r.x * scale * persp).toFloat()
    val sy = cy - (r.y * scale * persp).toFloat()
    return Triple(sx, sy, r.z)
}

private fun buildBoxMesh(a: Double, b: Double, h: Double, baseColor: Color): Mesh3D {
    val m = maxOf(a, b, h, 1e-3)
    val hx = (a / m) * 1.15
    val hz = (b / m) * 1.15
    val hy = (h / m) * 1.15
    val verts = listOf(
        Vec3(-hx, -hy, -hz), Vec3(hx, -hy, -hz), Vec3(hx, -hy, hz), Vec3(-hx, -hy, hz),
        Vec3(-hx, hy, -hz), Vec3(hx, hy, -hz), Vec3(hx, hy, hz), Vec3(-hx, hy, hz)
    )
    val faces = listOf(
        Face3D(listOf(0, 1, 2, 3), baseColor.copy(alpha = 0.28f)),
        Face3D(listOf(4, 5, 6, 7), baseColor.copy(alpha = 0.42f)),
        Face3D(listOf(0, 1, 5, 4), baseColor.copy(alpha = 0.34f)),
        Face3D(listOf(2, 3, 7, 6), baseColor.copy(alpha = 0.34f)),
        Face3D(listOf(1, 2, 6, 5), baseColor.copy(alpha = 0.25f)),
        Face3D(listOf(3, 0, 4, 7), baseColor.copy(alpha = 0.25f))
    )
    val edges = listOf(
        Edge3D(0, 1), Edge3D(1, 2), Edge3D(2, 3), Edge3D(3, 0),
        Edge3D(4, 5), Edge3D(5, 6), Edge3D(6, 7), Edge3D(7, 4),
        Edge3D(0, 4), Edge3D(1, 5), Edge3D(2, 6), Edge3D(3, 7),
        Edge3D(0, 6, dashed = true) // Diagonal espacial
    )
    val labels = listOf(
        Vec3(0.0, -hy - 0.18, hz) to "a=${formatDecimal(a, 2)}",
        Vec3(hx + 0.18, -hy, 0.0) to "b=${formatDecimal(b, 2)}",
        Vec3(hx + 0.18, 0.0, hz) to "h=${formatDecimal(h, 2)}"
    )
    return Mesh3D(verts, faces, edges, labels)
}

private fun buildPyramidMesh(a: Double, h: Double, baseColor: Color): Mesh3D {
    val m = maxOf(a, h, 1e-3)
    val half = (a / m) * 1.15
    val topY = (h / m) * 1.35
    val botY = -topY * 0.45
    val verts = listOf(
        Vec3(-half, botY, -half), Vec3(half, botY, -half),
        Vec3(half, botY, half), Vec3(-half, botY, half),
        Vec3(0.0, topY, 0.0),
        Vec3(0.0, botY, 0.0), // Centro base (para altura)
        Vec3(0.0, botY, half) // Punto medio lado (para apotema)
    )
    val faces = listOf(
        Face3D(listOf(0, 1, 2, 3), baseColor.copy(alpha = 0.30f)),
        Face3D(listOf(0, 1, 4), baseColor.copy(alpha = 0.36f)),
        Face3D(listOf(1, 2, 4), baseColor.copy(alpha = 0.28f)),
        Face3D(listOf(2, 3, 4), baseColor.copy(alpha = 0.42f)),
        Face3D(listOf(3, 0, 4), baseColor.copy(alpha = 0.24f))
    )
    val edges = listOf(
        Edge3D(0, 1), Edge3D(1, 2), Edge3D(2, 3), Edge3D(3, 0),
        Edge3D(0, 4), Edge3D(1, 4), Edge3D(2, 4), Edge3D(3, 4),
        Edge3D(4, 5, dashed = true), // Altura h
        Edge3D(4, 6, dashed = true)  // Apotema lateral
    )
    val labels = listOf(
        Vec3(0.0, botY - 0.2, half) to "a=${formatDecimal(a, 2)}",
        Vec3(0.14, (topY + botY) * 0.5, 0.0) to "h=${formatDecimal(h, 2)}"
    )
    return Mesh3D(verts, faces, edges, labels)
}

private fun buildCylinderMesh(r: Double, h: Double, baseColor: Color): Mesh3D {
    val m = maxOf(r * 2.0, h, 1e-3)
    val rad = (r / m) * 1.25
    val hy = (h / m) * 1.15
    val segs = 24
    val verts = ArrayList<Vec3>(segs * 2 + 2)
    for (i in 0 until segs) {
        val ang = 2.0 * PI * i / segs
        verts.add(Vec3(rad * cos(ang), -hy, rad * sin(ang)))
    }
    for (i in 0 until segs) {
        val ang = 2.0 * PI * i / segs
        verts.add(Vec3(rad * cos(ang), hy, rad * sin(ang)))
    }
    verts.add(Vec3(0.0, -hy, 0.0)) // centro inf
    verts.add(Vec3(0.0, hy, 0.0))  // centro sup

    val faces = ArrayList<Face3D>()
    faces.add(Face3D((0 until segs).toList(), baseColor.copy(alpha = 0.25f)))
    faces.add(Face3D((segs until 2 * segs).toList(), baseColor.copy(alpha = 0.40f)))
    for (i in 0 until segs) {
        val ni = (i + 1) % segs
        faces.add(Face3D(listOf(i, ni, segs + ni, segs + i), baseColor.copy(alpha = 0.22f)))
    }
    val edges = ArrayList<Edge3D>()
    for (i in 0 until segs) {
        val ni = (i + 1) % segs
        edges.add(Edge3D(i, ni))
        edges.add(Edge3D(segs + i, segs + ni))
        if (i % 6 == 0) edges.add(Edge3D(i, segs + i))
    }
    edges.add(Edge3D(2 * segs, 2 * segs + 1, dashed = true)) // eje h
    edges.add(Edge3D(2 * segs + 1, segs, dashed = true))     // radio r
    val labels = listOf(
        Vec3(rad * 0.5, hy + 0.16, 0.0) to "r=${formatDecimal(r, 2)}",
        Vec3(0.14, 0.0, 0.0) to "h=${formatDecimal(h, 2)}"
    )
    return Mesh3D(verts, faces, edges, labels)
}

private fun buildConeMesh(r: Double, h: Double, baseColor: Color): Mesh3D {
    val m = maxOf(r * 2.0, h, 1e-3)
    val rad = (r / m) * 1.25
    val topY = (h / m) * 1.35
    val botY = -topY * 0.45
    val segs = 24
    val verts = ArrayList<Vec3>(segs + 2)
    for (i in 0 until segs) {
        val ang = 2.0 * PI * i / segs
        verts.add(Vec3(rad * cos(ang), botY, rad * sin(ang)))
    }
    val apexIdx = segs
    val centerIdx = segs + 1
    verts.add(Vec3(0.0, topY, 0.0))
    verts.add(Vec3(0.0, botY, 0.0))

    val faces = ArrayList<Face3D>()
    faces.add(Face3D((0 until segs).toList(), baseColor.copy(alpha = 0.28f)))
    for (i in 0 until segs) {
        val ni = (i + 1) % segs
        faces.add(Face3D(listOf(i, ni, apexIdx), baseColor.copy(alpha = 0.24f)))
    }
    val edges = ArrayList<Edge3D>()
    for (i in 0 until segs) {
        val ni = (i + 1) % segs
        edges.add(Edge3D(i, ni))
        if (i % 6 == 0) edges.add(Edge3D(i, apexIdx))
    }
    edges.add(Edge3D(centerIdx, apexIdx, dashed = true))
    edges.add(Edge3D(centerIdx, 0, dashed = true))
    val labels = listOf(
        Vec3(rad * 0.55, botY - 0.18, 0.0) to "r=${formatDecimal(r, 2)}",
        Vec3(0.14, (topY + botY) * 0.5, 0.0) to "h=${formatDecimal(h, 2)}"
    )
    return Mesh3D(verts, faces, edges, labels)
}

private fun buildSphereMesh(r: Double, baseColor: Color): Mesh3D {
    val rad = 1.25
    val rings = 8
    val segs = 20
    val verts = ArrayList<Vec3>()
    for (lat in 0..rings) {
        val phi = -PI / 2.0 + PI * lat / rings
        val y = rad * sin(phi)
        val rr = rad * cos(phi)
        for (lon in 0 until segs) {
            val theta = 2.0 * PI * lon / segs
            verts.add(Vec3(rr * cos(theta), y, rr * sin(theta)))
        }
    }
    val centerIdx = verts.size
    verts.add(Vec3(0.0, 0.0, 0.0))
    val edges = ArrayList<Edge3D>()
    // Paralelos y meridianos clave
    for (lat in 1 until rings) {
        for (lon in 0 until segs) {
            val cur = lat * segs + lon
            val nxt = lat * segs + (lon + 1) % segs
            if (lat == rings / 2 || lat % 2 == 0) edges.add(Edge3D(cur, nxt))
        }
    }
    for (lon in 0 until segs step 4) {
        for (lat in 0 until rings) {
            edges.add(Edge3D(lat * segs + lon, (lat + 1) * segs + lon))
        }
    }
    val eqPointIdx = (rings / 2) * segs
    edges.add(Edge3D(centerIdx, eqPointIdx, dashed = true))
    val faces = ArrayList<Face3D>()
    for (lat in 0 until rings) {
        for (lon in 0 until segs) {
            val a = lat * segs + lon
            val b = lat * segs + (lon + 1) % segs
            val c = (lat + 1) * segs + (lon + 1) % segs
            val d = (lat + 1) * segs + lon
            faces.add(Face3D(listOf(a, b, c, d), baseColor.copy(alpha = 0.16f)))
        }
    }
    return Mesh3D(verts, faces, edges, listOf(Vec3(rad * 0.55, 0.14, 0.0) to "r=${formatDecimal(r, 2)}"))
}

// ==============================================================================
// PANTALLA INTERACTIVA: VISOR DE GEOMETRÍA 2D Y 3D (PREUNIVERSITARIO 10-12)
// ==============================================================================

@Composable
fun PmGeometryScreen(onBack: () -> Unit) {
    var mode3D by remember { mutableStateOf(false) }
    val red = photomathRed()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val onAcc = labOnAccent()
        // Barra superior limpia
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) { LabIcon(LabIconKind.BACK, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Geometría 2D y 3D", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("VISOR ANALÍTICO Y ESTEREOMETRÍA", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = red)
            }
        }

        // Selector 2D / 3D con contraste perfecto en modo claro y oscuro
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(false to "Geometría 2D", true to "Geometría 3D (360°)").forEach { (is3d, label) ->
                val sel = mode3D == is3d
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                        .background(if (sel) red else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (sel) red else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                        .clickable { mode3D = is3d }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (sel) onAcc else MaterialTheme.colorScheme.onSurface)
                }
            }
        }

        if (mode3D) Geometry3DPane() else Geometry2DPane()
    }
}

// ==============================================================================
// PANEL 2D: TRIÁNGULO, RECTA, CIRCUNFERENCIA, ELIPSE Y VECTORES R²
// ==============================================================================
@Composable
private fun Geometry2DPane() {
    var fig by remember { mutableStateOf(0) } // 0=Triángulo, 1=Recta 2 pts, 2=Circunferencia, 3=Elipse, 4=Vectores R2
    val red = photomathRed()

    // Parámetros editables
    var ax by remember { mutableStateOf("-3") }; var ay by remember { mutableStateOf("-1") }
    var bx by remember { mutableStateOf("4") }; var by by remember { mutableStateOf("-1") }
    var cx by remember { mutableStateOf("1") }; var cy by remember { mutableStateOf("4") }
    var showMedians by remember { mutableStateOf(true) }
    var showCircum by remember { mutableStateOf(false) }

    var ch by remember { mutableStateOf("1") }; var ck by remember { mutableStateOf("-1") }
    var radA by remember { mutableStateOf("4") }; var radB by remember { mutableStateOf("2.5") }

    var zoom by remember { mutableStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }

    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bgColor = if (dark) Color(0xFF14171D) else Color.White
    val gridColor = if (dark) Color(0xFF262B35) else Color(0xFFE7EAF0)
    val axisColor = if (dark) Color(0xFF9AA4B2) else Color(0xFF374151)
    val lblArgb = (if (dark) Color(0xFFE2E8F0) else Color(0xFF1F2937)).toArgb()
    val paint = remember(lblArgb) {
        Paint().apply { isAntiAlias = true; color = lblArgb; textSize = 28f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
    }

    val pAx = ax.toDoubleOrNull() ?: 0.0; val pAy = ay.toDoubleOrNull() ?: 0.0
    val pBx = bx.toDoubleOrNull() ?: 3.0; val pBy = by.toDoubleOrNull() ?: 0.0
    val pCx = cx.toDoubleOrNull() ?: 1.0; val pCy = cy.toDoubleOrNull() ?: 3.0
    val hVal = ch.toDoubleOrNull() ?: 0.0; val kVal = ck.toDoubleOrNull() ?: 0.0
    val rA = (radA.toDoubleOrNull() ?: 3.0).coerceAtLeast(0.2)
    val rB = (radB.toDoubleOrNull() ?: 2.0).coerceAtLeast(0.2)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Triángulo", "Recta (2 pts)", "Circunferencia", "Elipse", "Vectores ℝ²").forEachIndexed { idx, label ->
                FilterChip(selected = fig == idx, onClick = { fig = idx; zoom = 1f; pan = Offset.Zero }, label = { Text(label, fontSize = 12.sp) })
            }
        }

        // Lienzo 2D interactivo
        Box(
            Modifier.fillMaxWidth().height(290.dp).clip(RoundedCornerShape(18.dp))
                .background(bgColor).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                .pointerInput(fig) {
                    detectTransformGestures { _, dPan, dZoom, _ ->
                        zoom = (zoom * dZoom).coerceIn(0.4f, 4f)
                        pan += dPan
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width; val h = size.height
                val baseScale = minOf(w, h) / 14f * zoom
                val originX = w / 2f + pan.x
                val originY = h / 2f + pan.y
                fun sx(x: Double) = originX + (x * baseScale).toFloat()
                fun sy(y: Double) = originY - (y * baseScale).toFloat()

                // Rejilla
                for (i in -20..20) {
                    val x = sx(i.toDouble()); val y = sy(i.toDouble())
                    if (x in 0f..w) drawLine(gridColor, Offset(x, 0f), Offset(x, h), 1.5f)
                    if (y in 0f..h) drawLine(gridColor, Offset(0f, y), Offset(w, y), 1.5f)
                }
                drawLine(axisColor, Offset(0f, originY), Offset(w, originY), 2.8f)
                drawLine(axisColor, Offset(originX, 0f), Offset(originX, h), 2.8f)

                when (fig) {
                    0 -> { // Triángulo ABC
                        val oA = Offset(sx(pAx), sy(pAy))
                        val oB = Offset(sx(pBx), sy(pBy))
                        val oC = Offset(sx(pCx), sy(pCy))
                        val poly = Path().apply { moveTo(oA.x, oA.y); lineTo(oB.x, oB.y); lineTo(oC.x, oC.y); close() }
                        drawPath(poly, red.copy(alpha = 0.14f))
                        drawPath(poly, red, style = Stroke(4.5f, join = StrokeJoin.Round))

                        if (showMedians) {
                            val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
                            drawLine(Color(0xFF1E88E5), oA, Offset((oB.x + oC.x) / 2f, (oB.y + oC.y) / 2f), 2.5f, pathEffect = dash)
                            drawLine(Color(0xFF1E88E5), oB, Offset((oA.x + oC.x) / 2f, (oA.y + oC.y) / 2f), 2.5f, pathEffect = dash)
                            drawLine(Color(0xFF1E88E5), oC, Offset((oA.x + oB.x) / 2f, (oA.y + oB.y) / 2f), 2.5f, pathEffect = dash)
                            val g = Offset((oA.x + oB.x + oC.x) / 3f, (oA.y + oB.y + oC.y) / 3f)
                            drawCircle(Color(0xFF1E88E5), 8f, g)
                            drawContext.canvas.nativeCanvas.drawText("G", g.x + 10f, g.y - 8f, paint)
                        }
                        if (showCircum) {
                            val d = 2.0 * (pAx * (pBy - pCy) + pBx * (pCy - pAy) + pCx * (pAy - pBy))
                            if (abs(d) > 1e-6) {
                                val ux = ((pAx * pAx + pAy * pAy) * (pBy - pCy) + (pBx * pBx + pBy * pBy) * (pCy - pAy) + (pCx * pCx + pCy * pCy) * (pAy - pBy)) / d
                                val uy = ((pAx * pAx + pAy * pAy) * (pCx - pBx) + (pBx * pBx + pBy * pBy) * (pAx - pCx) + (pCx * pCx + pCy * pCy) * (pBx - pAx)) / d
                                val r = hypot(pAx - ux, pAy - uy)
                                drawCircle(Color(0xFF2E7D32), (r * baseScale).toFloat(), Offset(sx(ux), sy(uy)), style = Stroke(3f))
                                drawCircle(Color(0xFF2E7D32), 7f, Offset(sx(ux), sy(uy)))
                            }
                        }
                        listOf(oA to "A", oB to "B", oC to "C").forEach { (pt, lbl) ->
                            drawCircle(bgColor, 10f, pt)
                            drawCircle(red, 7f, pt)
                            drawContext.canvas.nativeCanvas.drawText(lbl, pt.x + 10f, pt.y - 10f, paint)
                        }
                    }
                    1 -> { // Recta por A y B
                        val dx = pBx - pAx; val dy = pBy - pAy
                        if (hypot(dx, dy) > 1e-6) {
                            val p1 = Offset(sx(pAx - dx * 10), sy(pAy - dy * 10))
                            val p2 = Offset(sx(pBx + dx * 10), sy(pBy + dy * 10))
                            drawLine(Color(0xFF1E88E5).copy(alpha = 0.45f), p1, p2, 3f)
                        }
                        val oA = Offset(sx(pAx), sy(pAy)); val oB = Offset(sx(pBx), sy(pBy))
                        val oM = Offset((oA.x + oB.x) / 2f, (oA.y + oB.y) / 2f)
                        drawLine(red, oA, oB, 5f, StrokeCap.Round)
                        drawCircle(red, 8f, oA); drawCircle(red, 8f, oB)
                        drawCircle(Color(0xFF2E7D32), 8f, oM)
                        drawContext.canvas.nativeCanvas.apply {
                            drawText("A", oA.x + 10f, oA.y - 10f, paint)
                            drawText("B", oB.x + 10f, oB.y - 10f, paint)
                            drawText("M", oM.x + 10f, oM.y - 10f, paint)
                        }
                    }
                    2 -> { // Circunferencia
                        val c = Offset(sx(hVal), sy(kVal))
                        val rp = (rA * baseScale).toFloat()
                        drawCircle(red.copy(alpha = 0.12f), rp, c)
                        drawCircle(red, rp, c, style = Stroke(4.5f))
                        drawLine(Color(0xFF1E88E5), c, Offset(c.x + rp, c.y), 3.5f)
                        drawCircle(red, 8f, c)
                        drawContext.canvas.nativeCanvas.drawText("C(${formatDecimal(hVal, 1)}, ${formatDecimal(kVal, 1)})", c.x + 10f, c.y - 10f, paint)
                    }
                    3 -> { // Elipse
                        val path = Path()
                        for (i in 0..120) {
                            val t = 2.0 * PI * i / 120
                            val px = sx(hVal + rA * cos(t))
                            val py = sy(kVal + rB * sin(t))
                            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }
                        path.close()
                        drawPath(path, red.copy(alpha = 0.12f))
                        drawPath(path, red, style = Stroke(4.5f))
                        val cFocus = sqrt(abs(rA * rA - rB * rB))
                        val f1 = if (rA >= rB) Offset(sx(hVal - cFocus), sy(kVal)) else Offset(sx(hVal), sy(kVal - cFocus))
                        val f2 = if (rA >= rB) Offset(sx(hVal + cFocus), sy(kVal)) else Offset(sx(hVal), sy(kVal + cFocus))
                        drawCircle(Color(0xFF1E88E5), 8f, f1); drawCircle(Color(0xFF1E88E5), 8f, f2)
                        drawContext.canvas.nativeCanvas.apply {
                            drawText("F₁", f1.x + 8f, f1.y - 8f, paint)
                            drawText("F₂", f2.x + 8f, f2.y - 8f, paint)
                        }
                    }
                    4 -> { // Vectores u=(pAx, pAy), v=(pBx, pBy) y suma u+v
                        val o = Offset(sx(0.0), sy(0.0))
                        val u = Offset(sx(pAx), sy(pAy))
                        val v = Offset(sx(pBx), sy(pBy))
                        val sum = Offset(sx(pAx + pBx), sy(pAy + pBy))
                        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                        drawLine(axisColor.copy(alpha = 0.5f), u, sum, 2f, pathEffect = dash)
                        drawLine(axisColor.copy(alpha = 0.5f), v, sum, 2f, pathEffect = dash)
                        drawArrow2D(o, u, Color(0xFF1E88E5), 5f)
                        drawArrow2D(o, v, Color(0xFF2E7D32), 5f)
                        drawArrow2D(o, sum, red, 6f)
                        drawContext.canvas.nativeCanvas.apply {
                            drawText("u", u.x + 8f, u.y - 8f, paint)
                            drawText("v", v.x + 8f, v.y - 8f, paint)
                            drawText("u+v", sum.x + 8f, sum.y - 8f, paint)
                        }
                    }
                }
            }
            TextButton(
                { zoom = 1f; pan = Offset.Zero },
                modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)
            ) { Text("Centrar", fontSize = 11.sp) }
        }

        // Controles numéricos según la figura
        when (fig) {
            0 -> {
                CoordRow("A", ax, ay, { ax = it }, { ay = it })
                CoordRow("B", bx, by, { bx = it }, { by = it })
                CoordRow("C", cx, cy, { cx = it }, { cy = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = showMedians, onClick = { showMedians = !showMedians }, label = { Text("Medianas y Baricentro") })
                    FilterChip(selected = showCircum, onClick = { showCircum = !showCircum }, label = { Text("Circunscrita") })
                }
                val aSide = hypot(pBx - pCx, pBy - pCy)
                val bSide = hypot(pAx - pCx, pAy - pCy)
                val cSide = hypot(pAx - pBx, pAy - pBy)
                val perim = aSide + bSide + cSide
                val area = 0.5 * abs(pAx * (pBy - pCy) + pBx * (pCy - pAy) + pCx * (pAy - pBy))
                val angA = if (bSide * cSide > 1e-9) Math.toDegrees(acos(((bSide * bSide + cSide * cSide - aSide * aSide) / (2 * bSide * cSide)).coerceIn(-1.0, 1.0))) else 0.0
                val angB = if (aSide * cSide > 1e-9) Math.toDegrees(acos(((aSide * aSide + cSide * cSide - bSide * bSide) / (2 * aSide * cSide)).coerceIn(-1.0, 1.0))) else 0.0
                val angC = (180.0 - angA - angB).coerceAtLeast(0.0)
                GeomResultCard(
                    "Propiedades del Triángulo ABC",
                    listOf(
                        "Lados" to "a = ${formatDecimal(aSide, 3)},  b = ${formatDecimal(bSide, 3)},  c = ${formatDecimal(cSide, 3)}",
                        "Ángulos interiores" to "A = ${formatDecimal(angA, 2)}°,  B = ${formatDecimal(angB, 2)}°,  C = ${formatDecimal(angC, 2)}°",
                        "Perímetro (P)" to formatDecimal(perim, 4),
                        "Área (Determinante / Herón)" to formatDecimal(area, 4),
                        "Baricentro G" to "(${formatDecimal((pAx + pBx + pCx) / 3.0, 3)}, ${formatDecimal((pAy + pBy + pCy) / 3.0, 3)})"
                    )
                )
            }
            1 -> {
                CoordRow("A", ax, ay, { ax = it }, { ay = it })
                CoordRow("B", bx, by, { bx = it }, { by = it })
                val dist = hypot(pBx - pAx, pBy - pAy)
                val mx = (pAx + pBx) / 2.0; val my = (pAy + pBy) / 2.0
                val dx = pBx - pAx; val dy = pBy - pAy
                val eqStr = if (abs(dx) < 1e-9) "x = ${formatDecimal(pAx, 3)} (vertical)"
                else {
                    val m = dy / dx; val n = pAy - m * pAx
                    "y = ${formatDecimal(m, 3)}x ${if (n >= 0) "+ ${formatDecimal(n, 3)}" else "- ${formatDecimal(-n, 3)}"}"
                }
                val slopeStr = if (abs(dx) < 1e-9) "Indefinida (90°)" else "${formatDecimal(dy / dx, 4)} (θ = ${formatDecimal(Math.toDegrees(atan2(dy, dx)), 2)}°)"
                GeomResultCard(
                    "Geometría Analítica de la Recta AB",
                    listOf(
                        "Distancia d(A, B)" to "${formatDecimal(dist, 4)}  (√${formatDecimal(dx * dx + dy * dy, 2)})",
                        "Punto medio M" to "(${formatDecimal(mx, 3)}, ${formatDecimal(my, 3)})",
                        "Pendiente m" to slopeStr,
                        "Ecuación explícita" to eqStr,
                        "Vector director" to "(${formatDecimal(dx, 2)}, ${formatDecimal(dy, 2)})"
                    )
                )
            }
            2 -> {
                CoordRow("Centro (h, k)", ch, ck, { ch = it }, { ck = it })
                OutlinedTextField(radA, { radA = it }, Modifier.fillMaxWidth(), label = { Text("Radio r") }, singleLine = true)
                GeomResultCard(
                    "Circunferencia",
                    listOf(
                        "Ecuación canónica" to "(x − ${formatDecimal(hVal, 2)})² + (y − ${formatDecimal(kVal, 2)})² = ${formatDecimal(rA * rA, 3)}",
                        "Diámetro (D = 2r)" to formatDecimal(2 * rA, 4),
                        "Longitud (L = 2πr)" to "${formatDecimal(2 * rA, 3)}π  ≈  ${formatDecimal(2 * PI * rA, 4)}",
                        "Área (A = πr²)" to "${formatDecimal(rA * rA, 3)}π  ≈  ${formatDecimal(PI * rA * rA, 4)}"
                    )
                )
            }
            3 -> {
                CoordRow("Centro (h, k)", ch, ck, { ch = it }, { ck = it })
                CoordRow("Semiejes (a, b)", radA, radB, { radA = it }, { radB = it })
                val cF = sqrt(abs(rA * rA - rB * rB))
                val major = max(rA, rB)
                val ecc = cF / major
                GeomResultCard(
                    "Cónica · Elipse",
                    listOf(
                        "Ecuación canónica" to "(x−${formatDecimal(hVal, 1)})²/${formatDecimal(rA * rA, 2)} + (y−${formatDecimal(kVal, 1)})²/${formatDecimal(rB * rB, 2)} = 1",
                        "Distancia focal c" to formatDecimal(cF, 4),
                        "Excentricidad e = c/a" to formatDecimal(ecc, 4),
                        "Área (π·a·b)" to "${formatDecimal(rA * rB, 3)}π  ≈  ${formatDecimal(PI * rA * rB, 4)}"
                    )
                )
            }
            4 -> {
                CoordRow("Vector u", ax, ay, { ax = it }, { ay = it })
                CoordRow("Vector v", bx, by, { bx = it }, { by = it })
                val mu = hypot(pAx, pAy); val mv = hypot(pBx, pBy)
                val dot = pAx * pBx + pAy * pBy
                val ang = if (mu * mv > 1e-9) Math.toDegrees(acos((dot / (mu * mv)).coerceIn(-1.0, 1.0))) else 0.0
                GeomResultCard(
                    "Álgebra Vectorial en ℝ²",
                    listOf(
                        "Suma u + v" to "(${formatDecimal(pAx + pBx, 3)}, ${formatDecimal(pAy + pBy, 3)})",
                        "Resta u − v" to "(${formatDecimal(pAx - pBx, 3)}, ${formatDecimal(pAy - pBy, 3)})",
                        "Módulos |u|, |v|" to "|u| = ${formatDecimal(mu, 4)},  |v| = ${formatDecimal(mv, 4)}",
                        "Producto escalar u · v" to formatDecimal(dot, 4),
                        "Ángulo entre u y v" to "${formatDecimal(ang, 2)}°"
                    )
                )
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArrow2D(from: Offset, to: Offset, color: Color, width: Float) {
    drawLine(color, from, to, strokeWidth = width, cap = StrokeCap.Round)
    val ang = atan2((to.y - from.y).toDouble(), (to.x - from.x).toDouble())
    val head = 18.0
    val p1 = Offset((to.x - head * cos(ang - 0.45)).toFloat(), (to.y - head * sin(ang - 0.45)).toFloat())
    val p2 = Offset((to.x - head * cos(ang + 0.45)).toFloat(), (to.y - head * sin(ang + 0.45)).toFloat())
    drawLine(color, to, p1, strokeWidth = width, cap = StrokeCap.Round)
    drawLine(color, to, p2, strokeWidth = width, cap = StrokeCap.Round)
}

// ==============================================================================
// PANEL 3D: ESTEREOMETRÍA (CUBO, PRISMA, PIRÁMIDE, CILINDRO, CONO, ESFERA, VECTORES ℝ³)
// ==============================================================================
@Composable
private fun Geometry3DPane() {
    var solid by remember { mutableStateOf(0) } // 0=Cubo, 1=Prisma, 2=Pirámide, 3=Cilindro, 4=Cono, 5=Esfera, 6=Vectores 3D
    var yaw by remember { mutableStateOf(0.65) }
    var pitch by remember { mutableStateOf(0.45) }
    var zoom3D by remember { mutableStateOf(1f) }

    var p1 by remember { mutableStateOf("4") }
    var p2 by remember { mutableStateOf("3") }
    var p3 by remember { mutableStateOf("5") }
    // Vectores R3
    var u1 by remember { mutableStateOf("2") }; var u2 by remember { mutableStateOf("1") }; var u3 by remember { mutableStateOf("0") }
    var v1 by remember { mutableStateOf("0") }; var v2 by remember { mutableStateOf("2") }; var v3 by remember { mutableStateOf("3") }

    val a = (p1.toDoubleOrNull() ?: 4.0).coerceAtLeast(0.1)
    val b = (p2.toDoubleOrNull() ?: 3.0).coerceAtLeast(0.1)
    val h = (p3.toDoubleOrNull() ?: 5.0).coerceAtLeast(0.1)

    val red = photomathRed()
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bgColor = if (dark) Color(0xFF101319) else Color(0xFFF9FAFB)
    val edgeColor = if (dark) Color(0xFFF1F5F9) else Color(0xFF1E293B)
    val lblArgb = (if (dark) Color(0xFFF1F5F9) else Color(0xFF111827)).toArgb()
    val paint = remember(lblArgb) {
        Paint().apply { isAntiAlias = true; color = lblArgb; textSize = 27f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) }
    }

    val mesh = remember(solid, a, b, h, red) {
        when (solid) {
            0 -> buildBoxMesh(a, a, a, red)
            1 -> buildBoxMesh(a, b, h, Color(0xFF1E88E5))
            2 -> buildPyramidMesh(a, h, Color(0xFFFB8C00))
            3 -> buildCylinderMesh(a, h, Color(0xFF2E7D32))
            4 -> buildConeMesh(a, h, Color(0xFF8E24AA))
            5 -> buildSphereMesh(a, red)
            else -> null
        }
    }

    val vu = Vec3(u1.toDoubleOrNull() ?: 1.0, u2.toDoubleOrNull() ?: 0.0, u3.toDoubleOrNull() ?: 0.0)
    val vv = Vec3(v1.toDoubleOrNull() ?: 0.0, v2.toDoubleOrNull() ?: 1.0, v3.toDoubleOrNull() ?: 0.0)
    val vCross = vu.cross(vv)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Cubo", "Prisma", "Pirámide", "Cilindro", "Cono", "Esfera", "Vectores ℝ³").forEachIndexed { idx, label ->
                FilterChip(selected = solid == idx, onClick = { solid = idx }, label = { Text(label, fontSize = 12.sp) })
            }
        }

        // Visor 3D rotable con un dedo
        Box(
            Modifier.fillMaxWidth().height(300.dp).clip(RoundedCornerShape(18.dp))
                .background(bgColor).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                .pointerInput(Unit) {
                    detectDragGestures { _, drag ->
                        yaw += drag.x * 0.012
                        pitch = (pitch + drag.y * 0.012).coerceIn(-1.4, 1.4)
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val cx = size.width / 2f; val cy = size.height / 2f
                val sc = minOf(size.width, size.height) * 0.27f * zoom3D

                // Ejes de referencia 3D sutiles
                val o = projectPoint(Vec3(0.0, 0.0, 0.0), yaw, pitch, cx, cy, sc)
                listOf(
                    Triple(Vec3(1.8, 0.0, 0.0), Color(0xFFE53935), "X"),
                    Triple(Vec3(0.0, 1.8, 0.0), Color(0xFF43A047), "Y"),
                    Triple(Vec3(0.0, 0.0, 1.8), Color(0xFF1E88E5), "Z")
                ).forEach { (axisPt, col, lbl) ->
                    val p = projectPoint(axisPt, yaw, pitch, cx, cy, sc)
                    drawLine(col.copy(alpha = 0.45f), Offset(o.first, o.second), Offset(p.first, p.second), 2.5f)
                    drawContext.canvas.nativeCanvas.drawText(lbl, p.first + 6f, p.second, paint)
                }

                if (mesh != null) {
                    val proj = mesh.vertices.map { projectPoint(it, yaw, pitch, cx, cy, sc) }
                    // Painter's algorithm: ordenar caras por profundidad Z media
                    val sortedFaces = mesh.faces.sortedBy { f -> f.indices.map { proj[it].third }.average() }
                    sortedFaces.forEach { face ->
                        val p = Path()
                        face.indices.forEachIndexed { idx, vi ->
                            val pt = proj[vi]
                            if (idx == 0) p.moveTo(pt.first, pt.second) else p.lineTo(pt.first, pt.second)
                        }
                        p.close()
                        drawPath(p, face.color)
                    }
                    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f))
                    mesh.edges.forEach { e ->
                        val pA = proj[e.a]; val pB = proj[e.b]
                        drawLine(
                            color = if (e.dashed) red else edgeColor,
                            start = Offset(pA.first, pA.second),
                            end = Offset(pB.first, pB.second),
                            strokeWidth = if (e.dashed) 3.2f else 3f,
                            pathEffect = if (e.dashed) dashEffect else null,
                            cap = StrokeCap.Round
                        )
                    }
                    mesh.labels.forEach { (pt, txt) ->
                        val pr = projectPoint(pt, yaw, pitch, cx, cy, sc)
                        drawContext.canvas.nativeCanvas.drawText(txt, pr.first, pr.second, paint)
                    }
                } else {
                    // Dibujar vectores u, v y producto cruz u × v en ℝ³
                    val maxLen = maxOf(vu.length(), vv.length(), vCross.length(), 1.0)
                    val normScale = 1.6 / maxLen
                    listOf(
                        Triple(vu * normScale, Color(0xFF1E88E5), "u"),
                        Triple(vv * normScale, Color(0xFF2E7D32), "v"),
                        Triple(vCross * normScale, red, "u×v")
                    ).forEach { (vec, col, lbl) ->
                        val p = projectPoint(vec, yaw, pitch, cx, cy, sc)
                        drawArrow2D(Offset(o.first, o.second), Offset(p.first, p.second), col, 5.5f)
                        drawContext.canvas.nativeCanvas.drawText(lbl, p.first + 8f, p.second - 6f, paint)
                    }
                }
            }

            Text(
                "Arrastra con 1 dedo para rotar 360°",
                Modifier.align(Alignment.TopStart).padding(10.dp),
                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(Modifier.align(Alignment.BottomEnd).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Small3DBtn("+") { zoom3D = (zoom3D * 1.18f).coerceAtMost(2.2f) }
                Small3DBtn("−") { zoom3D = (zoom3D * 0.85f).coerceAtLeast(0.5f) }
                Small3DBtn("↺") { yaw = 0.65; pitch = 0.45; zoom3D = 1f }
            }
        }

        // Inputs y fórmulas paso a paso
        when (solid) {
            0 -> {
                OutlinedTextField(p1, { p1 = it }, Modifier.fillMaxWidth(), label = { Text("Arista a") }, singleLine = true)
                GeomResultCard(
                    "Cubo (Hexaedro regular)",
                    listOf(
                        "Diagonal de una cara (a√2)" to "${formatDecimal(a, 2)}√2  ≈  ${formatDecimal(a * sqrt(2.0), 4)}",
                        "Diagonal espacial (a√3)" to "${formatDecimal(a, 2)}√3  ≈  ${formatDecimal(a * sqrt(3.0), 4)}",
                        "Área lateral (A_L = 4a²)" to formatDecimal(4 * a * a, 4),
                        "Área total (A_T = 6a²)" to formatDecimal(6 * a * a, 4),
                        "Volumen (V = a³)" to formatDecimal(a * a * a, 4)
                    )
                )
            }
            1 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(p1, { p1 = it }, Modifier.weight(1f), label = { Text("Largo a") }, singleLine = true)
                    OutlinedTextField(p2, { p2 = it }, Modifier.weight(1f), label = { Text("Ancho b") }, singleLine = true)
                    OutlinedTextField(p3, { p3 = it }, Modifier.weight(1f), label = { Text("Altura h") }, singleLine = true)
                }
                val diag = sqrt(a * a + b * b + h * h)
                val al = 2 * (a + b) * h
                val at = al + 2 * a * b
                val vol = a * b * h
                GeomResultCard(
                    "Prisma Recto Rectangular (Ortoedro)",
                    listOf(
                        "Área de la base (A_B = a·b)" to formatDecimal(a * b, 4),
                        "Área lateral (A_L = 2(a+b)h)" to formatDecimal(al, 4),
                        "Área total (A_T = A_L + 2A_B)" to formatDecimal(at, 4),
                        "Volumen (V = a·b·h)" to formatDecimal(vol, 4),
                        "Diagonal espacial (√(a²+b²+h²))" to formatDecimal(diag, 4)
                    )
                )
            }
            2 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(p1, { p1 = it }, Modifier.weight(1f), label = { Text("Lado base a") }, singleLine = true)
                    OutlinedTextField(p3, { p3 = it }, Modifier.weight(1f), label = { Text("Altura h") }, singleLine = true)
                }
                val ap = sqrt(h * h + (a / 2.0) * (a / 2.0))
                val edgeLat = sqrt(h * h + (a * a) / 2.0)
                val ab = a * a
                val al = 2 * a * ap
                val at = ab + al
                val vol = ab * h / 3.0
                GeomResultCard(
                    "Pirámide Cuadrangular Regular",
                    listOf(
                        "Apotema lateral (√(h²+(a/2)²))" to formatDecimal(ap, 4),
                        "Arista lateral" to formatDecimal(edgeLat, 4),
                        "Área base (A_B = a²)" to formatDecimal(ab, 4),
                        "Área lateral (A_L = 2a·ap)" to formatDecimal(al, 4),
                        "Área total (A_T = A_B + A_L)" to formatDecimal(at, 4),
                        "Volumen (V = A_B·h / 3)" to formatDecimal(vol, 4)
                    )
                )
            }
            3 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(p1, { p1 = it }, Modifier.weight(1f), label = { Text("Radio r") }, singleLine = true)
                    OutlinedTextField(p3, { p3 = it }, Modifier.weight(1f), label = { Text("Altura h") }, singleLine = true)
                }
                GeomResultCard(
                    "Cilindro Circular Recto",
                    listOf(
                        "Área base (πr²)" to "${formatDecimal(a * a, 3)}π  ≈  ${formatDecimal(PI * a * a, 4)}",
                        "Área lateral (2πrh)" to "${formatDecimal(2 * a * h, 3)}π  ≈  ${formatDecimal(2 * PI * a * h, 4)}",
                        "Área total (2πr(r+h))" to "${formatDecimal(2 * a * (a + h), 3)}π  ≈  ${formatDecimal(2 * PI * a * (a + h), 4)}",
                        "Volumen (πr²h)" to "${formatDecimal(a * a * h, 3)}π  ≈  ${formatDecimal(PI * a * a * h, 4)}"
                    )
                )
            }
            4 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(p1, { p1 = it }, Modifier.weight(1f), label = { Text("Radio r") }, singleLine = true)
                    OutlinedTextField(p3, { p3 = it }, Modifier.weight(1f), label = { Text("Altura h") }, singleLine = true)
                }
                val g = sqrt(a * a + h * h)
                GeomResultCard(
                    "Cono Circular Recto",
                    listOf(
                        "Generatriz g = √(r²+h²)" to formatDecimal(g, 4),
                        "Área lateral (πrg)" to "${formatDecimal(a * g, 3)}π  ≈  ${formatDecimal(PI * a * g, 4)}",
                        "Área total (πr(r+g))" to "${formatDecimal(a * (a + g), 3)}π  ≈  ${formatDecimal(PI * a * (a + g), 4)}",
                        "Volumen (πr²h / 3)" to "${formatDecimal(a * a * h / 3.0, 3)}π  ≈  ${formatDecimal(PI * a * a * h / 3.0, 4)}"
                    )
                )
            }
            5 -> {
                OutlinedTextField(p1, { p1 = it }, Modifier.fillMaxWidth(), label = { Text("Radio r") }, singleLine = true)
                GeomResultCard(
                    "Esfera",
                    listOf(
                        "Diámetro (2r)" to formatDecimal(2 * a, 4),
                        "Área superficial (4πr²)" to "${formatDecimal(4 * a * a, 3)}π  ≈  ${formatDecimal(4 * PI * a * a, 4)}",
                        "Volumen (4/3 · πr³)" to "${formatDecimal(4.0 * a * a * a / 3.0, 3)}π  ≈  ${formatDecimal(4.0 * PI * a * a * a / 3.0, 4)}"
                    )
                )
            }
            6 -> {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(u1, { u1 = it }, Modifier.weight(1f), label = { Text("uₓ") }, singleLine = true)
                    OutlinedTextField(u2, { u2 = it }, Modifier.weight(1f), label = { Text("uᵧ") }, singleLine = true)
                    OutlinedTextField(u3, { u3 = it }, Modifier.weight(1f), label = { Text("u_z") }, singleLine = true)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(v1, { v1 = it }, Modifier.weight(1f), label = { Text("vₓ") }, singleLine = true)
                    OutlinedTextField(v2, { v2 = it }, Modifier.weight(1f), label = { Text("vᵧ") }, singleLine = true)
                    OutlinedTextField(v3, { v3 = it }, Modifier.weight(1f), label = { Text("v_z") }, singleLine = true)
                }
                val dot = vu.dot(vv)
                val mu = vu.length(); val mv = vv.length()
                val ang = if (mu * mv > 1e-9) Math.toDegrees(acos((dot / (mu * mv)).coerceIn(-1.0, 1.0))) else 0.0
                GeomResultCard(
                    "Vectores en el Espacio ℝ³",
                    listOf(
                        "Módulos" to "|u| = ${formatDecimal(mu, 4)},  |v| = ${formatDecimal(mv, 4)}",
                        "Producto escalar u · v" to formatDecimal(dot, 4),
                        "Producto vectorial u × v" to "(${formatDecimal(vCross.x, 3)}, ${formatDecimal(vCross.y, 3)}, ${formatDecimal(vCross.z, 3)})",
                        "Área del paralelogramo |u × v|" to formatDecimal(vCross.length(), 4),
                        "Ángulo entre u y v" to "${formatDecimal(ang, 2)}°"
                    )
                )
            }
        }
    }
}

@Composable
private fun Small3DBtn(txt: String, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(txt, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
private fun CoordRow(title: String, x: String, y: String, onX: (String) -> Unit, onY: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(64.dp))
        OutlinedTextField(x, onX, Modifier.weight(1f), label = { Text("x") }, singleLine = true)
        OutlinedTextField(y, onY, Modifier.weight(1f), label = { Text("y") }, singleLine = true)
    }
}

@Composable
private fun GeomResultCard(title: String, rows: List<Pair<String, String>>) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = photomathRed())
        rows.forEach { (k, v) ->
            Column {
                Text(k, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(v, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
