package com.abstergo.app.labs.photomath

import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.tan

// ==============================================================================
// MESA DE LABORATORIO PREUNIVERSITARIO (10mo, 11no y 12mo) — DISEÑO 2 COLUMNAS
// ==============================================================================

enum class PreuTopic(
    val title: String,
    val grade: String,
    val grades: Set<String>,
    val desc: String,
    val icon: LabIconKind
) {
    GEOMETRY("Geometría 2D y 3D", "10mo–12mo", setOf("10mo", "11no", "12mo"), "Planos 2D, cónicas, vectores y sólidos 3D rotables", LabIconKind.GEOM_2D3D),
    FUNCTIONS("Funciones", "10mo–12mo", setOf("10mo", "11no", "12mo"), "Dominio, imagen, ceros, monotonía, paridad y asíntotas", LabIconKind.FUNCTIONS),
    INEQUALITIES("Inecuaciones", "10mo–11no", setOf("10mo", "11no"), "Lineales, cuadráticas, racionales y |x| + recta real", LabIconKind.INEQUALITIES),
    TRIGONOMETRY("Trigonometría", "10mo–11no", setOf("10mo", "11no"), "Círculo unitario, Ley de Senos/Cosenos y ecuaciones", LabIconKind.TRIG),
    COMPLEX("Complejos", "12mo", setOf("12mo"), "Binómica, polar, De Moivre, raíces ⁿ√z y Argand", LabIconKind.COMPLEX),
    COMBINATORICS("Combinatoria", "12mo", setOf("12mo"), "Variaciones, permutaciones, combinaciones y Binomio", LabIconKind.COMBINATORICS),
    INDUCTION("Inducción", "12mo", setOf("12mo"), "Base, hipótesis, tesis y prueba simbólica exacta", LabIconKind.INDUCTION),
    STATISTICS("Estadística", "10mo–12mo", setOf("10mo", "11no", "12mo"), "Media, mediana, cuartiles, σ, histograma y Binomial", LabIconKind.STATS)
}

@Composable
fun PmPreuHubScreen(
    onBack: () -> Unit,
    onSolveInPhotomath: (String) -> Unit
) {
    var openTopic by remember { mutableStateOf<PreuTopic?>(null) }
    var gradeFilter by remember { mutableStateOf("Todos") }

    BackHandler {
        if (openTopic != null) openTopic = null else onBack()
    }

    when (openTopic) {
        PreuTopic.GEOMETRY -> PmGeometryScreen(onBack = { openTopic = null })
        PreuTopic.FUNCTIONS -> PmFunctionStudyScreen(onBack = { openTopic = null })
        PreuTopic.INEQUALITIES -> PmInequalitiesScreen(onBack = { openTopic = null }, onOpenFullSolution = onSolveInPhotomath)
        PreuTopic.TRIGONOMETRY -> PmTrigonometryScreen(onBack = { openTopic = null }, onSolveEquation = onSolveInPhotomath)
        PreuTopic.COMPLEX -> PmComplexScreen(onBack = { openTopic = null })
        PreuTopic.COMBINATORICS -> PmCombinatoricsScreen(onBack = { openTopic = null })
        PreuTopic.INDUCTION -> PmInductionScreen(onBack = { openTopic = null })
        PreuTopic.STATISTICS -> PmStatsProbScreen(onBack = { openTopic = null })
        null -> {
            val accent = labAccent()
            val onAcc = labOnAccent()
            val shown = remember(gradeFilter) {
                if (gradeFilter == "Todos") PreuTopic.entries
                else PreuTopic.entries.filter { gradeFilter in it.grades }
            }

            Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                // Encabezado estilo Laboratorio Abstergo
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                ) {
                    LabBlueprintGrid(Modifier.matchParentSize())
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("ABSTERGO · LAB PREUNIVERSITARIO", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.4.sp, color = accent)
                        Text("Módulos de 10mo a 12mo", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Herramientas interactivas paso a paso, 100% offline.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // Filtro por grado (Todos · 10mo · 11no · 12mo)
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Todos", "10mo", "11no", "12mo").forEach { g ->
                        val sel = gradeFilter == g
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                .background(if (sel) accent else MaterialTheme.colorScheme.surface)
                                .border(1.dp, if (sel) accent else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                                .clickable { gradeFilter = g }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(g, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) onAcc else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Rejilla visual 2 columnas de módulos del laboratorio
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(shown, key = { it.name }) { topic ->
                        Column(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                                .clickable { openTopic = topic }
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                                        .background(accent.copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    LabIcon(topic.icon, accent, Modifier.size(24.dp))
                                }
                                Spacer(Modifier.weight(1f))
                                Box(
                                    Modifier.clip(RoundedCornerShape(50))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(horizontal = 7.dp, vertical = 2.dp)
                                ) {
                                    Text(topic.grade, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Text(topic.title, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(topic.desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// COMPONENTE COMPARTIDO DE CABECERA Y TARJETAS DE PASOS PHOTOMATH
// ==============================================================================
@Composable
private fun PreuTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface)
                .clickable { onBack() },
            contentAlignment = Alignment.Center
        ) { LabIcon(LabIconKind.BACK, MaterialTheme.colorScheme.onSurface, Modifier.size(18.dp)) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("MATEMÁTICA LABS · 10MO–12MO", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = labAccent())
        }
    }
}

@Composable
private fun PreuStepsList(steps: List<PmStep>) {
    val red = photomathRed()
    var expanded by remember(steps) { mutableStateOf(setOf<Int>()) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        steps.forEach { step ->
            val open = step.index in expanded
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).clip(CircleShape).background(red), contentAlignment = Alignment.Center) {
                        Text("${step.index}", color = labOnAccent(), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(step.actionTitle, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                }
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    PmMathFormulaView(step.mathText, fontSize = 18.sp, highlightSegment = step.highlightSegment)
                }
                if (step.detail.isNotBlank()) {
                    Text(step.detail, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 18.sp)
                }
                if (step.subSteps.isNotEmpty()) {
                    Text(
                        if (open) "Ocultar detalle ▲" else "Explicar cómo ▼",
                        color = red, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { expanded = if (open) expanded - step.index else expanded + step.index }.padding(vertical = 4.dp)
                    )
                    AnimatedVisibility(open) {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.background).padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            step.subSteps.forEach { sub ->
                                Text(sub.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = red)
                                Text(sub.mathText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                if (sub.note.isNotBlank()) Text(sub.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 1. ESTUDIO COMPLETO DE FUNCIONES (10mo–12mo)
// ==============================================================================
@Composable
private fun PmFunctionStudyScreen(onBack: () -> Unit) {
    var input by remember { mutableStateOf("x^2 - 4x + 3") }
    val presets = listOf("2x - 4", "x^2 - 4x + 3", "x^3 - 3x", "|x - 2| - 1", "√(x + 2)", "1/(x - 2)", "2^x - 1", "ln(x + 1)", "sin(x)")
    val result = remember(input) { FunctionStudyEngine.analyze(input) }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Estudio de Funciones", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                presets.forEach { p -> FilterChip(selected = input == p, onClick = { input = p }, label = { Text(p, fontSize = 12.sp) }) }
            }
            OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("Función f(x)") }, singleLine = true, shape = RoundedCornerShape(14.dp))

            if (!result.ok) {
                Text(result.error.orEmpty(), color = MaterialTheme.colorScheme.error)
            } else {
                result.plot?.let { plot ->
                    PmInteractiveGraph(plot = plot, modifier = Modifier.fillMaxWidth().height(290.dp))
                }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(result.family, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = photomathRed())
                    PmMathFormulaView(result.expression, fontSize = 22.sp)
                    HorizontalDivider()
                    StudyRow("Dominio", result.domain)
                    StudyRow("Imagen / Recorrido", result.range)
                    StudyRow("Ceros (cortes con eje X)", result.zeros)
                    StudyRow("Intercepto con eje Y", result.yIntercept)
                    StudyRow("Paridad (Simetría)", result.parity)
                    StudyRow("Monotonía", result.monotonicity)
                    StudyRow("Signo de la función", result.signAnalysis)
                    StudyRow("Asíntotas", result.asymptotes)
                }
            }
        }
    }
}

@Composable
private fun StudyRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp)
    }
}

// ==============================================================================
// 2. INECUACIONES (LINEALES, CUADRÁTICAS, RACIONALES Y VALOR ABSOLUTO)
// ==============================================================================
@Composable
private fun PmInequalitiesScreen(onBack: () -> Unit, onOpenFullSolution: (String) -> Unit) {
    var input by remember { mutableStateOf("(x - 2)/(x + 3) >= 0") }
    val presets = listOf(
        "-2x + 4 <= 10",
        "x^2 - 5x + 6 > 0",
        "x^2 - 4 <= 0",
        "(x - 2)/(x + 3) >= 0",
        "(x^2 - 1)/(x - 2) < 0",
        "|2x - 1| <= 5",
        "|x + 3| > 4"
    )
    val sol = remember(input) { PmSolver.solve(input) }
    val red = photomathRed()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Inecuaciones", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                presets.forEach { p -> FilterChip(selected = input == p, onClick = { input = p }, label = { Text(p, fontSize = 12.sp) }) }
            }
            OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("Inecuación (<, <=, >, >=)") }, singleLine = true, shape = RoundedCornerShape(14.dp))

            if (!sol.ok || sol.methods.isEmpty()) {
                Text(sol.error ?: "Escribe una inecuación válida.", color = MaterialTheme.colorScheme.error)
            } else {
                val m = sol.methods.first()
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.5.dp, red.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(sol.categoryTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = red)
                    PmMathFormulaView(m.finalAnswer, fontSize = 22.sp)
                    m.altForms.forEach { (k, v) ->
                        Text("$k: $v", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (m.intervals.isNotEmpty()) {
                        Text("Recta numérica", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        InequalityNumberLine(m.intervals)
                    }
                }
                PreuStepsList(m.steps)
                OutlinedButton({ onOpenFullSolution(input) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Text("Abrir en hoja completa de Photomath")
                }
            }
        }
    }
}

// ==============================================================================
// 3. TRIGONOMETRÍA (CÍRCULO UNITARIO INTERACTIVO + TRIÁNGULOS + ECUACIONES)
// ==============================================================================
@Composable
private fun PmTrigonometryScreen(onBack: () -> Unit, onSolveEquation: (String) -> Unit) {
    var tab by remember { mutableStateOf(0) } // 0=Círculo unitario, 1=Triángulos, 2=Ecuaciones trig
    var angleDeg by remember { mutableStateOf(30f) }

    // Triángulo
    var triCase by remember { mutableStateOf(0) } // 0=LLL, 1=LAL, 2=ALA, 3=Rectángulo
    var t1 by remember { mutableStateOf("5") }
    var t2 by remember { mutableStateOf("6") }
    var t3 by remember { mutableStateOf("7") }

    // Ecuación trigonométrica
    var trigEq by remember { mutableStateOf("sin(x) = 1/2") }

    val red = photomathRed()
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bg = if (dark) Color(0xFF14171D) else Color.White
    val axisColor = if (dark) Color(0xFF9AA4B2) else Color(0xFF374151)

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Trigonometría", onBack)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Círculo unitario", "Triángulos", "Ecuaciones").forEachIndexed { i, lbl ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(lbl, fontSize = 12.sp) }, modifier = Modifier.weight(1f))
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (tab) {
                0 -> {
                    val rad = Math.toRadians(angleDeg.toDouble())
                    val sVal = sin(rad); val cVal = cos(rad)
                    val tVal = if (abs(cVal) < 1e-6) Double.NaN else tan(rad)
                    val quad = when {
                        angleDeg % 360f == 0f || angleDeg % 90f == 0f -> "Eje coordenado"
                        angleDeg < 90f -> "I Cuadrante (+, +)"
                        angleDeg < 180f -> "II Cuadrante (−, +)"
                        angleDeg < 270f -> "III Cuadrante (−, −)"
                        else -> "IV Cuadrante (+, −)"
                    }
                    // Círculo trigonométrico interactivo 2D
                    Box(
                        Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(18.dp))
                            .background(bg).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                    ) {
                        Canvas(Modifier.fillMaxSize()) {
                            val cx = size.width / 2f; val cy = size.height / 2f
                            val r = minOf(size.width, size.height) * 0.38f
                            drawLine(axisColor, Offset(cx - r * 1.25f, cy), Offset(cx + r * 1.25f, cy), 2f)
                            drawLine(axisColor, Offset(cx, cy - r * 1.25f), Offset(cx, cy + r * 1.25f), 2f)
                            drawCircle(axisColor.copy(alpha = 0.5f), r, Offset(cx, cy), style = Stroke(3f))

                            val px = cx + (r * cVal).toFloat()
                            val py = cy - (r * sVal).toFloat()
                            // cos (azul), sin (rojo), radio (negro/blanco)
                            drawLine(Color(0xFF1E88E5), Offset(cx, cy), Offset(px, cy), 6f, StrokeCap.Round)
                            drawLine(red, Offset(px, cy), Offset(px, py), 6f, StrokeCap.Round)
                            drawLine(axisColor, Offset(cx, cy), Offset(px, py), 4f, StrokeCap.Round)
                            drawCircle(red, 9f, Offset(px, py))
                        }
                    }

                    Text("Ángulo θ = ${angleDeg.toInt()}°  (${formatDecimal(rad / PI, 3)}π rad)  ·  $quad", fontWeight = FontWeight.Bold)
                    Slider(value = angleDeg, onValueChange = { angleDeg = it }, valueRange = 0f..360f)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(0, 30, 45, 60, 90, 120, 135, 150, 180, 210, 225, 240, 270, 300, 315, 330).forEach { d ->
                            FilterChip(selected = angleDeg.toInt() == d, onClick = { angleDeg = d.toFloat() }, label = { Text("${d}°", fontSize = 11.sp) })
                        }
                    }

                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("sin(${angleDeg.toInt()}°) = ${formatDecimal(sVal, 5)}", color = red, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("cos(${angleDeg.toInt()}°) = ${formatDecimal(cVal, 5)}", color = Color(0xFF1E88E5), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("tan(${angleDeg.toInt()}°) = ${if (tVal.isFinite()) formatDecimal(tVal, 5) else "Indefinida (asíntota)"}", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Identidad pitagórica: sin²θ + cos²θ = ${formatDecimal(sVal * sVal + cVal * cVal, 4)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                1 -> {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LLL (a,b,c)", "LAL (a,C°,b)", "ALA (A°,c,B°)", "Rectángulo (a,b)").forEachIndexed { idx, lbl ->
                            FilterChip(selected = triCase == idx, onClick = { triCase = idx }, label = { Text(lbl, fontSize = 12.sp) })
                        }
                    }
                    val labels = when (triCase) {
                        0 -> Triple("Lado a", "Lado b", "Lado c")
                        1 -> Triple("Lado a", "Ángulo C (°)", "Lado b")
                        2 -> Triple("Ángulo A (°)", "Lado c", "Ángulo B (°)")
                        else -> Triple("Cateto a", "Cateto b", "")
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(t1, { t1 = it }, Modifier.weight(1f), label = { Text(labels.first) }, singleLine = true)
                        OutlinedTextField(t2, { t2 = it }, Modifier.weight(1f), label = { Text(labels.second) }, singleLine = true)
                        if (triCase != 3) OutlinedTextField(t3, { t3 = it }, Modifier.weight(1f), label = { Text(labels.third) }, singleLine = true)
                    }
                    val res = remember(triCase, t1, t2, t3) {
                        TrigEngine.solveTriangle(triCase, t1.toDoubleOrNull() ?: 0.0, t2.toDoubleOrNull() ?: 0.0, t3.toDoubleOrNull() ?: 0.0)
                    }
                    if (!res.ok) {
                        Text(res.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                    } else {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Solución del triángulo", fontWeight = FontWeight.Bold, color = red)
                            Text("Lados: a = ${formatDecimal(res.a, 3)},  b = ${formatDecimal(res.b, 3)},  c = ${formatDecimal(res.c, 3)}", fontWeight = FontWeight.SemiBold)
                            Text("Ángulos: A = ${formatDecimal(res.degA, 2)}°,  B = ${formatDecimal(res.degB, 2)}°,  C = ${formatDecimal(res.degC, 2)}°", fontWeight = FontWeight.SemiBold)
                            Text("Perímetro = ${formatDecimal(res.perimeter, 4)}  ·  Área = ${formatDecimal(res.area, 4)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        PreuStepsList(res.steps)
                    }
                }
                else -> {
                    val eqPresets = listOf("sin(x) = 1/2", "cos(x) = -1/2", "tan(x) = 1", "sin(2x) = 0", "cos(2x - 1) = 0.5")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        eqPresets.forEach { p -> FilterChip(selected = trigEq == p, onClick = { trigEq = p }, label = { Text(p, fontSize = 12.sp) }) }
                    }
                    OutlinedTextField(trigEq, { trigEq = it }, Modifier.fillMaxWidth(), label = { Text("Ecuación trigonométrica") }, singleLine = true)
                    val sol = remember(trigEq) { PmSolver.solve(trigEq) }
                    if (sol.ok && sol.methods.isNotEmpty()) {
                        val m = sol.methods.first()
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Soluciones en [0, 2π]", fontSize = 12.sp, color = red, fontWeight = FontWeight.Bold)
                            Text(m.finalAnswer, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            m.altForms.forEach { (k, v) -> Text("$k: $v", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                        PreuStepsList(m.steps)
                        Button({ onSolveEquation(trigEq) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Text("Ver gráfica y solución completa")
                        }
                    } else {
                        Text(sol.error ?: "Introduce una ecuación trigonométrica.", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 4. NÚMEROS COMPLEJOS + PLANO DE ARGAND 2D (12MO GRADO)
// ==============================================================================
@Composable
private fun PmComplexScreen(onBack: () -> Unit) {
    var mode by remember { mutableStateOf(0) } // 0=Analizar, 1=Operar, 2=De Moivre z^n, 3=Raíces n-ésimas, 4=Potencias de i
    var a1 by remember { mutableStateOf("3") }; var b1 by remember { mutableStateOf("4") }
    var a2 by remember { mutableStateOf("1") }; var b2 by remember { mutableStateOf("-2") }
    var op by remember { mutableStateOf("/") }
    var nExp by remember { mutableStateOf("4") }

    val va1 = a1.toDoubleOrNull() ?: 0.0; val vb1 = b1.toDoubleOrNull() ?: 0.0
    val va2 = a2.toDoubleOrNull() ?: 1.0; val vb2 = b2.toDoubleOrNull() ?: 0.0
    val nVal = (nExp.toIntOrNull() ?: 3).coerceIn(1, 1000)

    val res: ComplexLabResult? = remember(mode, va1, vb1, va2, vb2, op, nVal) {
        when (mode) {
            0 -> ComplexEngine.analyzeSingle(va1, vb1)
            1 -> ComplexEngine.operate(va1, vb1, va2, vb2, op)
            2 -> ComplexEngine.deMoivrePower(va1, vb1, nVal.coerceIn(1, 20))
            3 -> ComplexEngine.nthRoots(va1, vb1, nVal.coerceIn(2, 12))
            else -> null
        }
    }

    val red = photomathRed()
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val bg = if (dark) Color(0xFF14171D) else Color.White
    val axisColor = if (dark) Color(0xFF9AA4B2) else Color(0xFF374151)
    val lblArgb = (if (dark) Color(0xFFE2E8F0) else Color(0xFF1F2937)).toArgb()
    val paint = remember(lblArgb) { Paint().apply { isAntiAlias = true; color = lblArgb; textSize = 26f; typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) } }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Números Complejos", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Analizar z", "Operar z₁, z₂", "De Moivre zⁿ", "Raíces ⁿ√z", "Potencias iⁿ").forEachIndexed { idx, lbl ->
                    FilterChip(selected = mode == idx, onClick = { mode = idx }, label = { Text(lbl, fontSize = 12.sp) })
                }
            }

            if (mode == 4) {
                OutlinedTextField(nExp, { nExp = it }, Modifier.fillMaxWidth(), label = { Text("Exponente entero n para iⁿ") }, singleLine = true)
                val rem = ((nVal % 4) + 4) % 4
                val ansI = when (rem) { 0 -> "1"; 1 -> "i"; 2 -> "-1"; else -> "-i" }
                PreuStepsList(
                    listOf(
                        PmStep(1, "Dividir el exponente entre 4 (ciclo i¹=i, i²=−1, i³=−i, i⁴=1)", "$nVal = 4 · ${nVal / 4} + $rem (resto = $rem).", "i^$nVal = i^$rem"),
                        PmStep(2, "Evaluar el resto", "Resultado exacto de la potencia imaginaria.", "i^$nVal = $ansI", highlightSegment = ansI)
                    )
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(a1, { a1 = it }, Modifier.weight(1f), label = { Text("Re(z₁)") }, singleLine = true)
                    OutlinedTextField(b1, { b1 = it }, Modifier.weight(1f), label = { Text("Im(z₁)") }, singleLine = true)
                }
                if (mode == 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("+", "-", "*", "/").forEach { o -> FilterChip(selected = op == o, onClick = { op = o }, label = { Text(o, fontWeight = FontWeight.Bold) }) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(a2, { a2 = it }, Modifier.weight(1f), label = { Text("Re(z₂)") }, singleLine = true)
                        OutlinedTextField(b2, { b2 = it }, Modifier.weight(1f), label = { Text("Im(z₂)") }, singleLine = true)
                    }
                }
                if (mode == 2 || mode == 3) {
                    OutlinedTextField(nExp, { nExp = it }, Modifier.fillMaxWidth(), label = { Text(if (mode == 2) "Exponente n" else "Índice de raíz n (2..12)") }, singleLine = true)
                }

                if (res != null) {
                    // Plano de Argand 2D interactivo
                    Box(
                        Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(18.dp))
                            .background(bg).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(18.dp))
                    ) {
                        Canvas(Modifier.fillMaxSize()) {
                            val cx = size.width / 2f; val cy = size.height / 2f
                            val maxR = res.argandPoints.maxOfOrNull { hypot(it.first.real, it.first.imaginary) }?.coerceAtLeast(1.0) ?: 1.0
                            val sc = (minOf(size.width, size.height) * 0.37f) / maxR.toFloat()
                            drawLine(axisColor, Offset(12f, cy), Offset(size.width - 12f, cy), 2f)
                            drawLine(axisColor, Offset(cx, 12f), Offset(cx, size.height - 12f), 2f)
                            drawContext.canvas.nativeCanvas.apply {
                                drawText("Re", size.width - 42f, cy - 8f, paint)
                                drawText("Im", cx + 8f, 28f, paint)
                            }
                            if (res.connectPolygon && res.argandPoints.size >= 2) {
                                drawCircle(axisColor.copy(alpha = 0.35f), (res.modulus * sc).toFloat(), Offset(cx, cy), style = Stroke(2f))
                                val poly = Path()
                                res.argandPoints.forEachIndexed { idx, (c, _) ->
                                    val px = cx + (c.real * sc).toFloat(); val py = cy - (c.imaginary * sc).toFloat()
                                    if (idx == 0) poly.moveTo(px, py) else poly.lineTo(px, py)
                                }
                                poly.close()
                                drawPath(poly, red.copy(alpha = 0.14f))
                                drawPath(poly, red, style = Stroke(3.5f))
                            }
                            val cols = listOf(red, Color(0xFF1E88E5), Color(0xFF2E7D32), Color(0xFF8E24AA))
                            res.argandPoints.forEachIndexed { idx, (c, lbl) ->
                                val px = cx + (c.real * sc).toFloat(); val py = cy - (c.imaginary * sc).toFloat()
                                val col = cols[idx % cols.size]
                                drawLine(col, Offset(cx, cy), Offset(px, py), 4f, StrokeCap.Round)
                                drawCircle(col, 8f, Offset(px, py))
                                drawContext.canvas.nativeCanvas.drawText(lbl, px + 8f, py - 8f, paint)
                            }
                        }
                    }

                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(res.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = red)
                        Text(res.mainAnswer, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Forma trigonométrica: ${res.trigForm}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Forma polar: ${res.polarForm}  ·  Conjugado: ${res.conjugate}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    PreuStepsList(res.steps)
                }
            }
        }
    }
}

// ==============================================================================
// 5. COMBINATORIA Y BINOMIO DE NEWTON (12MO GRADO)
// ==============================================================================
@Composable
private fun PmCombinatoricsScreen(onBack: () -> Unit) {
    var kind by remember { mutableStateOf(CombKind.COMB) }
    var nText by remember { mutableStateOf("8") }
    var kText by remember { mutableStateOf("3") }
    var repText by remember { mutableStateOf("2, 2, 1") }
    var binA by remember { mutableStateOf("x") }
    var binB by remember { mutableStateOf("2") }

    val n = nText.toIntOrNull() ?: 0
    val k = kText.toIntOrNull() ?: 0
    val reps = remember(repText) { repText.split(",", " ", ";").mapNotNull { it.trim().toIntOrNull() } }
    val res = remember(kind, n, k, reps, binA, binB) { CombinatoricsEngine.compute(kind, n, k, reps, binA, binB) }
    val red = photomathRed()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Combinatoria y Binomio", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CombKind.entries.forEach { ck ->
                    FilterChip(selected = kind == ck, onClick = { kind = ck }, label = { Text(ck.label, fontSize = 12.sp) })
                }
            }
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(kind.formula, fontWeight = FontWeight.Bold, color = red, fontSize = 15.sp)
                Text("${kind.orderMatters}  ·  ${kind.repetition}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nText, { nText = it }, Modifier.weight(1f), label = { Text("Total n") }, singleLine = true)
                if (kind in listOf(CombKind.VAR, CombKind.VAR_REP, CombKind.COMB, CombKind.COMB_REP)) {
                    OutlinedTextField(kText, { kText = it }, Modifier.weight(1f), label = { Text("Tomados de k") }, singleLine = true)
                }
            }
            if (kind == CombKind.PERM_REP) {
                OutlinedTextField(repText, { repText = it }, Modifier.fillMaxWidth(), label = { Text("Repeticiones (ej: 2, 3, 2)") }, singleLine = true)
            }
            if (kind == CombKind.BINOMIAL) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(binA, { binA = it }, Modifier.weight(1f), label = { Text("Término a") }, singleLine = true)
                    OutlinedTextField(binB, { binB = it }, Modifier.weight(1f), label = { Text("Término b") }, singleLine = true)
                }
            }

            if (!res.ok) {
                Text(res.error.orEmpty(), color = MaterialTheme.colorScheme.error)
            } else {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.5.dp, red.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                        .padding(16.dp)
                ) {
                    Text("Resultado exacto", fontSize = 12.sp, color = red, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    PmMathFormulaView(res.answer, fontSize = 22.sp)
                }
                PreuStepsList(res.steps)
            }
        }
    }
}

// ==============================================================================
// 6. INDUCCIÓN COMPLETA (12MO GRADO — DEMOSTRADOR FORMAL DE 4 PASOS)
// ==============================================================================
@Composable
private fun PmInductionScreen(onBack: () -> Unit) {
    var mode by remember { mutableStateOf(0) } // 0=Sumatorias, 1=Divisibilidad, 2=Desigualdades
    var term by remember { mutableStateOf("2i - 1") }
    var closed by remember { mutableStateOf("n^2") }
    var n0Str by remember { mutableStateOf("1") }

    var divA by remember { mutableStateOf("7") }
    var divB by remember { mutableStateOf("1") }
    var divD by remember { mutableStateOf("6") }
    var ineqKind by remember { mutableStateOf(0) }

    val sumPresets = listOf(
        Triple("i", "n*(n+1)/2", "Suma naturales"),
        Triple("2i - 1", "n^2", "Suma impares"),
        Triple("2i", "n*(n+1)", "Suma pares"),
        Triple("i^2", "n*(n+1)*(2n+1)/6", "Suma cuadrados"),
        Triple("i^3", "(n*(n+1)/2)^2", "Suma cubos"),
        Triple("2^(i-1)", "2^n - 1", "Geométrica 2^i"),
        Triple("1/(i*(i+1))", "n/(n+1)", "Telescópica")
    )

    val proof = remember(mode, term, closed, n0Str, divA, divB, divD, ineqKind) {
        when (mode) {
            0 -> InductionEngine.proveSummation(term, closed, (n0Str.toIntOrNull() ?: 1).coerceIn(0, 10))
            1 -> InductionEngine.proveDivisibilityPower(divA.toLongOrNull() ?: 7L, divB.toLongOrNull() ?: 1L, divD.toLongOrNull() ?: 6L)
            else -> InductionEngine.proveClassicInequality(ineqKind)
        }
    }
    val red = photomathRed()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Inducción Completa", onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Sumatorias ∑", "Divisibilidad", "Desigualdades").forEachIndexed { idx, lbl ->
                    FilterChip(selected = mode == idx, onClick = { mode = idx }, label = { Text(lbl, fontSize = 12.sp) }, modifier = Modifier.weight(1f))
                }
            }

            when (mode) {
                0 -> {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        sumPresets.forEach { (t, c, name) ->
                            FilterChip(selected = term == t && closed == c, onClick = { term = t; closed = c; n0Str = "1" }, label = { Text(name, fontSize = 11.sp) })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(term, { term = it }, Modifier.weight(1f), label = { Text("Término f(i)") }, singleLine = true)
                        OutlinedTextField(n0Str, { n0Str = it }, Modifier.width(80.dp), label = { Text("n₀") }, singleLine = true)
                    }
                    OutlinedTextField(closed, { closed = it }, Modifier.fillMaxWidth(), label = { Text("Fórmula cerrada g(n)") }, singleLine = true)
                }
                1 -> {
                    Text("Demostrar que d divide a (aⁿ − bⁿ) para todo n ≥ 1:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(divA, { divA = it }, Modifier.weight(1f), label = { Text("Base a") }, singleLine = true)
                        OutlinedTextField(divB, { divB = it }, Modifier.weight(1f), label = { Text("Base b") }, singleLine = true)
                        OutlinedTextField(divD, { divD = it }, Modifier.weight(1f), label = { Text("Divisor d") }, singleLine = true)
                    }
                }
                else -> {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("2ⁿ > n", "Bernoulli (1+x)ⁿ ≥ 1+nx", "n! > 2ⁿ (n≥4)").forEachIndexed { i, lbl ->
                            FilterChip(selected = ineqKind == i, onClick = { ineqKind = i }, label = { Text(lbl, fontSize = 12.sp) })
                        }
                    }
                }
            }

            if (!proof.ok) {
                Text(proof.error.orEmpty(), color = MaterialTheme.colorScheme.error)
            } else {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(if (proof.verifiedSymbolically) Color(0xFF2E7D32).copy(alpha = 0.14f) else red.copy(alpha = 0.14f))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        if (proof.verifiedSymbolically) "✓ Proposición demostrada" else "✗ Contraejemplo detectado",
                        fontWeight = FontWeight.Bold,
                        color = if (proof.verifiedSymbolically) Color(0xFF2E7D32) else red
                    )
                    Text(proof.statement, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(proof.conclusion, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                PreuStepsList(proof.steps)
            }
        }
    }
}

// ==============================================================================
// 7. ESTADÍSTICA DESCRIPTIVA (CON HISTOGRAMA NATIVO) Y PROBABILIDAD BINOMIAL
// ==============================================================================
@Composable
private fun PmStatsProbScreen(onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) } // 0=Estadística descriptiva, 1=Probabilidad y Binomial
    var dataText by remember { mutableStateOf("82, 85, 90, 90, 92, 95, 95, 95, 98, 100") }

    // Probabilidad
    var fav by remember { mutableStateOf("3") }
    var tot by remember { mutableStateOf("10") }
    var binN by remember { mutableStateOf("10") }
    var binK by remember { mutableStateOf("4") }
    var binP by remember { mutableStateOf("0.5") }

    val stats = remember(dataText) { StatsProbEngine.analyzeData(dataText) }
    val red = photomathRed()

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        PreuTopBar("Estadística y Probabilidad", onBack)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Descriptiva + Gráfico") }, modifier = Modifier.weight(1f))
            FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Probabilidad / Binomial") }, modifier = Modifier.weight(1f))
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (tab == 0) {
                OutlinedTextField(
                    dataText, { dataText = it }, Modifier.fillMaxWidth(),
                    label = { Text("Datos separados por comas o espacios") }, minLines = 2, shape = RoundedCornerShape(14.dp)
                )
                if (!stats.ok) {
                    Text(stats.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                } else {
                    // Gráfico de barras de frecuencias (Canvas nativo 60 fps)
                    val maxF = stats.freqTable.maxOfOrNull { it.freq }?.coerceAtLeast(1) ?: 1
                    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
                    val lblArgb = (if (dark) Color(0xFFE2E8F0) else Color(0xFF374151)).toArgb()
                    val paint = remember(lblArgb) { Paint().apply { isAntiAlias = true; color = lblArgb; textSize = 24f; textAlign = Paint.Align.CENTER } }

                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Gráfico de frecuencias (n = ${stats.n})", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = red)
                        Canvas(Modifier.fillMaxWidth().height(160.dp)) {
                            val bars = stats.freqTable.take(12)
                            if (bars.isEmpty()) return@Canvas
                            val slotW = size.width / bars.size
                            val barW = slotW * 0.62f
                            val topPad = 24f
                            val botPad = 32f
                            val availH = (size.height - topPad - botPad).coerceAtLeast(20f)
                            bars.forEachIndexed { idx, row ->
                                val bh = (row.freq.toFloat() / maxF) * availH
                                val left = idx * slotW + (slotW - barW) / 2f
                                val top = topPad + (availH - bh)
                                drawRect(red, Offset(left, top), Size(barW, bh))
                                drawContext.canvas.nativeCanvas.apply {
                                    drawText("${row.freq}", left + barW / 2f, top - 6f, paint)
                                    drawText(formatDecimal(row.value, 1), left + barW / 2f, size.height - 6f, paint)
                                }
                            }
                        }
                    }

                    // Tarjeta de medidas estadísticas
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Medidas de tendencia central y dispersión", fontWeight = FontWeight.Bold, color = red)
                        StudyRow("Media (x̄) · Mediana (Me)", "x̄ = ${formatDecimal(stats.mean, 4)}   ·   Me = ${formatDecimal(stats.median, 4)}")
                        StudyRow("Moda (Mo) · Rango (R)", "Mo = ${if (stats.modes.isEmpty()) "Amodal" else stats.modes.joinToString(", ") { formatDecimal(it, 2) }}   ·   R = ${formatDecimal(stats.range, 4)}")
                        StudyRow("Cuartiles y Rango Intercuartílico", "Q₁ = ${formatDecimal(stats.q1, 3)}  ·  Q₂ = ${formatDecimal(stats.median, 3)}  ·  Q₃ = ${formatDecimal(stats.q3, 3)}  ·  IQR = ${formatDecimal(stats.iqr, 3)}")
                        StudyRow("Varianza (σ² / s²)", "Poblacional σ² = ${formatDecimal(stats.popVar, 4)}   ·   Muestral s² = ${formatDecimal(stats.sampleVar, 4)}")
                        StudyRow("Desviación estándar (σ / s) y CV", "σ = ${formatDecimal(stats.popStd, 4)}   ·   s = ${formatDecimal(stats.sampleStd, 4)}   ·   CV = ${formatDecimal(stats.cvPercent, 2)}%")
                    }

                    // Tabla de frecuencias
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Tabla de frecuencias", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row(Modifier.fillMaxWidth()) {
                            Text("xᵢ", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("fᵢ", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("hᵢ (%)", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Fᵢ", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        HorizontalDivider()
                        stats.freqTable.forEach { row ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                Text(formatDecimal(row.value, 2), Modifier.weight(1f), fontSize = 13.sp)
                                Text("${row.freq}", Modifier.weight(1f), fontSize = 13.sp)
                                Text("${formatDecimal(row.relFreq * 100, 1)}%", Modifier.weight(1f), fontSize = 13.sp)
                                Text("${row.cumFreq}", Modifier.weight(1f), fontSize = 13.sp)
                            }
                        }
                    }

                    PreuStepsList(stats.steps)
                }
            } else {
                // Regla de Laplace
                val fV = fav.toDoubleOrNull() ?: 0.0
                val tV = tot.toDoubleOrNull() ?: 1.0
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Regla de Laplace · P(A) = Casos favorables / Casos posibles", fontWeight = FontWeight.Bold, color = red, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(fav, { fav = it }, Modifier.weight(1f), label = { Text("Favorables") }, singleLine = true)
                        OutlinedTextField(tot, { tot = it }, Modifier.weight(1f), label = { Text("Posibles") }, singleLine = true)
                    }
                    if (tV > 0 && fV in 0.0..tV) {
                        val p = fV / tV
                        Text("P(A) = ${formatDecimal(p, 5)}  (${formatDecimal(p * 100, 2)}%)  ·  P(Ā) = ${formatDecimal(1 - p, 5)}", fontWeight = FontWeight.Bold)
                    }
                }

                // Distribución Binomial
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Distribución Binomial B(n, p)", fontWeight = FontWeight.Bold, color = red, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(binN, { binN = it }, Modifier.weight(1f), label = { Text("Ensayos n") }, singleLine = true)
                        OutlinedTextField(binK, { binK = it }, Modifier.weight(1f), label = { Text("Éxitos k") }, singleLine = true)
                        OutlinedTextField(binP, { binP = it }, Modifier.weight(1f), label = { Text("Prob. p") }, singleLine = true)
                    }
                    val binRes = remember(binN, binK, binP) {
                        StatsProbEngine.binomialProbability(binN.toIntOrNull() ?: 0, binK.toIntOrNull() ?: 0, binP.toDoubleOrNull() ?: 0.5)
                    }
                    if (binRes.ok) {
                        Text(binRes.answer, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        PreuStepsList(binRes.steps)
                    } else {
                        Text(binRes.error.orEmpty(), color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}
