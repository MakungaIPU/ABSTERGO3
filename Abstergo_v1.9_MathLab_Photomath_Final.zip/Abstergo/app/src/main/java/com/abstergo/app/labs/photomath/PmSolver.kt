package com.abstergo.app.labs.photomath

import androidx.compose.runtime.Immutable
import org.apache.commons.math3.analysis.UnivariateFunction
import org.apache.commons.math3.analysis.integration.SimpsonIntegrator
import org.apache.commons.math3.analysis.solvers.BrentSolver
import java.math.BigInteger
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

// ==============================================================================
// MODELOS DE SOLUCIÓN PHOTOMATH (MÚLTIPLES MÉTODOS + SUBPASOS EXPANDIBLES + GRÁFICA)
// ==============================================================================

@Immutable
data class PmSubStep(
    val title: String,
    val mathText: String,
    val note: String = ""
)

@Immutable
data class PmStep(
    val index: Int,
    val actionTitle: String,
    val detail: String,
    val mathText: String,
    val highlightSegment: String = "",
    val subSteps: List<PmSubStep> = emptyList()
)

@Immutable
data class NumberLineInterval(
    val from: Double?, // null = -infinito
    val to: Double?,   // null = +infinito
    val includeFrom: Boolean = false,
    val includeTo: Boolean = false
)

@Immutable
data class PmMethod(
    val id: String,
    val name: String,
    val summary: String,
    val finalAnswer: String,
    val altForms: List<Pair<String, String>> = emptyList(),
    val steps: List<PmStep> = emptyList(),
    val intervals: List<NumberLineInterval> = emptyList()
)

@Immutable
data class PmPlotPoint(
    val x: Double,
    val y: Double,
    val label: String,
    val kind: String // "root", "yintercept", "vertex", "intersection"
)

@Immutable
data class PmCurve(
    val label: String,
    val expr: PmExpr,
    val variable: String,
    val colorHex: Long
)

@Immutable
data class PmPlotData(
    val curves: List<PmCurve>,
    val points: List<PmPlotPoint>,
    val xMin: Double = -8.0,
    val xMax: Double = 8.0,
    val yMin: Double = -8.0,
    val yMax: Double = 8.0,
    val domainText: String = "x ∈ ℝ"
)

@Immutable
data class PmSolution(
    val ok: Boolean,
    val rawInput: String,
    val normalizedInput: String,
    val parsedExpr: PmExpr? = null,
    val categoryTitle: String = "",
    val methods: List<PmMethod> = emptyList(),
    val plot: PmPlotData? = null,
    val error: String? = null
)

// ==============================================================================
// POLINOMIOS EXACTOS SOBRE BigRat (SIN ERRORES DE PUNTO FLOTANTE)
// ==============================================================================

data class RatPoly(val variable: String, val coeffs: List<BigRat>) {
    val degree: Int
        get() {
            var d = coeffs.lastIndex
            while (d > 0 && coeffs[d].isZero) d--
            return d
        }

    fun coeff(k: Int): BigRat = if (k in coeffs.indices) coeffs[k] else BigRat.ZERO

    operator fun plus(o: RatPoly): RatPoly {
        val n = maxOf(coeffs.size, o.coeffs.size)
        return RatPoly(variable, List(n) { i -> coeff(i) + o.coeff(i) })
    }

    operator fun minus(o: RatPoly): RatPoly {
        val n = maxOf(coeffs.size, o.coeffs.size)
        return RatPoly(variable, List(n) { i -> coeff(i) - o.coeff(i) })
    }

    operator fun times(o: RatPoly): RatPoly {
        val out = MutableList(degree + o.degree + 1) { BigRat.ZERO }
        for (i in 0..degree) {
            for (j in 0..o.degree) {
                out[i + j] = out[i + j] + coeff(i) * o.coeff(j)
            }
        }
        return RatPoly(variable, out)
    }

    fun scale(f: BigRat): RatPoly = RatPoly(variable, coeffs.map { it * f })

    fun eval(x: BigRat): BigRat {
        var acc = BigRat.ZERO
        for (k in degree downTo 0) acc = acc * x + coeff(k)
        return acc
    }

    fun toExpr(): PmExpr {
        var acc: PmExpr? = null
        for (k in degree downTo 0) {
            val c = coeff(k)
            if (c.isZero) continue
            val term = makeTerm(c.abs(), variable, k)
            acc = if (acc == null) {
                if (c.isNegative) PmExpr.Neg(term) else term
            } else {
                if (c.isNegative) PmExpr.Sub(acc, term) else PmExpr.Add(acc, term)
            }
        }
        return acc ?: PmExpr.Num(BigRat.ZERO)
    }

    private fun makeTerm(absC: BigRat, v: String, p: Int): PmExpr {
        if (p == 0) return PmExpr.Num(absC)
        val vp: PmExpr = if (p == 1) PmExpr.Sym(v) else PmExpr.Pow(PmExpr.Sym(v), PmExpr.int(p.toLong()))
        return if (absC.isOne) vp else PmExpr.Mul(PmExpr.Num(absC), vp)
    }

    fun format(): String = PmFormatter.format(toExpr())
}

data class RatLinearForm(val coeffs: List<BigRat>, val constant: BigRat)

/** Función racional exacta P(x) / Q(x) sobre polinomios exactos RatPoly. */
data class RatFunc(val num: RatPoly, val den: RatPoly) {
    operator fun plus(o: RatFunc): RatFunc = RatFunc(num * o.den + o.num * den, den * o.den)
    operator fun minus(o: RatFunc): RatFunc = RatFunc(num * o.den - o.num * den, den * o.den)
    operator fun times(o: RatFunc): RatFunc = RatFunc(num * o.num, den * o.den)
    operator fun div(o: RatFunc): RatFunc = RatFunc(num * o.den, den * o.num)
    fun negate(): RatFunc = RatFunc(num.scale(BigRat.NEG_ONE), den)
}

// ==============================================================================
// MOTOR DE CÁLCULO SIMBÓLICO PHOTOMATH (PmSolver)
// ==============================================================================

object PmSolver {

    private val CURVE_COLORS = listOf(0xFF00B862L, 0xFF2563EBL, 0xFFF59E0BL, 0xFF8B5CF6L)

    fun solve(rawInput: String): PmSolution {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return PmSolution(false, rawInput, "", error = "Escribe o escanea una expresión matemática.")
        }
        val normalized = PmLatexNormalizer.normalize(trimmed)
        return try {
            val expr = PmParser.parse(normalized)
            val vars = PmParser.collectVars(expr)
            when (expr) {
                is PmExpr.System -> solveSystem(trimmed, normalized, expr, vars)
                is PmExpr.Deriv -> solveDerivative(trimmed, normalized, expr.body, expr.variable)
                is PmExpr.Integral -> solveIntegral(trimmed, normalized, expr)
                is PmExpr.Limit -> solveLimit(trimmed, normalized, expr)
                is PmExpr.Rel -> {
                    if (expr.op == "=") solveEquation(trimmed, normalized, expr, vars)
                    else solveInequality(trimmed, normalized, expr, vars)
                }
                else -> {
                    if (vars.isEmpty()) solveArithmetic(trimmed, normalized, expr)
                    else solveAlgebraicExpression(trimmed, normalized, expr, vars)
                }
            }
        } catch (e: PmParseException) {
            PmSolution(false, rawInput, normalized, error = e.userMsg)
        } catch (e: Exception) {
            PmSolution(false, rawInput, normalized, error = e.message ?: "No se pudo resolver esta expresión.")
        }
    }

    /** Vista previa rápida de respuesta para la calculadora en vivo (sin generar gráficas). */
    fun quickPreview(rawInput: String): String? {
        if (rawInput.isBlank()) return null
        return try {
            val sol = solve(rawInput)
            if (sol.ok) sol.methods.firstOrNull()?.finalAnswer else null
        } catch (_: Exception) {
            null
        }
    }

    // ==========================================================================
    // 1. ARITMÉTICA, FRACCIONES, RADICALES Y TRIGONOMETRÍA EXACTA
    // ==========================================================================
    private fun solveArithmetic(raw: String, norm: String, expr: PmExpr): PmSolution {
        val steps = ArrayList<PmStep>()
        val originalStr = PmFormatter.format(expr)
        val hasI = containsImaginary(expr)

        // Caso especial: Combinatoria directa C(n,k), V(n,k), P(n), CR(n,k), VR(n,k)
        if (expr is PmExpr.Func && expr.name in setOf("comb", "var", "perm", "combrep", "varrep")) {
            val combSol = solveDirectCombinatorics(raw, norm, expr)
            if (combSol != null) return combSol
        }

        // Caso especial: suma/resta de dos fracciones a/b ± c/d -> mostrar mcm explícito
        if ((expr is PmExpr.Add || expr is PmExpr.Sub)) {
            val leftR = PmEval.evalExactRational(if (expr is PmExpr.Add) expr.left else (expr as PmExpr.Sub).left)
            val rightR = PmEval.evalExactRational(if (expr is PmExpr.Add) expr.right else (expr as PmExpr.Sub).right)
            if (leftR != null && rightR != null && (!leftR.isInt || !rightR.isInt)) {
                val isAdd = expr is PmExpr.Add
                val lcm = ExactMath.lcm(leftR.den, rightR.den)
                val n1 = leftR.num * (lcm / leftR.den)
                val n2 = rightR.num * (lcm / rightR.den)
                val opSym = if (isAdd) "+" else "-"
                val combinedNum = if (isAdd) n1 + n2 else n1 - n2
                val finalRat = BigRat.of(combinedNum, lcm)

                steps.add(
                    PmStep(
                        1,
                        "Escribir las fracciones sobre el mínimo común denominador",
                        "El mínimo común múltiplo de ${leftR.den} y ${rightR.den} es $lcm.",
                        "($n1 $opSym $n2)/$lcm",
                        highlightSegment = "$lcm",
                        subSteps = listOf(
                            PmSubStep("Amplificar primera fracción", "${leftR} = $n1/$lcm", "Multiplicamos numerador y denominador por ${lcm / leftR.den}."),
                            PmSubStep("Amplificar segunda fracción", "${rightR} = $n2/$lcm", "Multiplicamos numerador y denominador por ${lcm / rightR.den}.")
                        )
                    )
                )
                steps.add(
                    PmStep(
                        2,
                        if (isAdd) "Sumar los numeradores" else "Restar los numeradores",
                        "Operamos los numeradores manteniendo el denominador común $lcm.",
                        "$combinedNum/$lcm",
                        highlightSegment = "$combinedNum"
                    )
                )
                if (finalRat.den != lcm || finalRat.isInt) {
                    steps.add(
                        PmStep(
                            3,
                            "Simplificar la fracción",
                            "Dividimos numerador y denominador entre su máximo común divisor.",
                            finalRat.toString(),
                            highlightSegment = finalRat.toString()
                        )
                    )
                }
                val alts = buildRatAltForms(finalRat)
                val m = PmMethod("arith_frac", "Evaluar fracciones", "Cálculo exacto con mínimo común denominador", finalRat.toString(), alts, steps)
                return PmSolution(true, raw, norm, expr, "Aritmética de fracciones", listOf(m))
            }
        }

        // Caso especial: raíz cuadrada exacta o simplificable √n
        if (expr is PmExpr.Root && expr.index == null) {
            val radRat = PmEval.evalExactRational(expr.radicand)
            if (radRat != null && radRat.isInt && radRat.isPositive) {
                val sim = ExactMath.simplifySqrt(radRat.num)
                val outStr = sim.format()
                val dec = formatDecimal(sqrt(radRat.toDouble()))
                steps.add(
                    PmStep(
                        1,
                        "Factorizar el radicando buscando cuadrados perfectos",
                        if (sim.isExactInt) "${radRat.num} es un cuadrado perfecto (${sim.outside}² = ${radRat.num})."
                        else "Descomponemos ${radRat.num} = ${sim.outside}² · ${sim.inside} para extraer el factor cuadrado.",
                        if (sim.isExactInt) "√(${sim.outside}^2)" else "√(${sim.outside}^2·${sim.inside})",
                        highlightSegment = "${sim.outside}"
                    )
                )
                steps.add(
                    PmStep(
                        2,
                        "Extraer la raíz cuadrada",
                        "La raíz de un cuadrado perfecto sale fuera del radical.",
                        outStr,
                        highlightSegment = outStr
                    )
                )
                val alts = if (!sim.isExactInt) listOf("Forma decimal" to "≈ $dec") else emptyList()
                val m = PmMethod("arith_sqrt", "Simplificar radical", "Extracción exacta de factores cuadrados", outStr, alts, steps)
                return PmSolution(true, raw, norm, expr, "Simplificación de radical", listOf(m))
            }
        }

        // Evaluación trigonométrica exacta para ángulos notables (sin(π/6), cos(π/3), tan(π/4), etc.)
        val exactTrig = evalExactTrig(expr)
        if (exactTrig != null) {
            val numVal = PmEval.evalDouble(expr)
            steps.add(
                PmStep(
                    1,
                    "Identificar ángulo notable en la circunferencia unitaria",
                    "Aplicamos la tabla de valores trigonométricos exactos.",
                    "$originalStr = $exactTrig",
                    highlightSegment = exactTrig
                )
            )
            val alts = if (numVal.isFinite()) listOf("Forma decimal" to "≈ ${formatDecimal(numVal)}") else emptyList()
            val m = PmMethod("arith_trig", "Valor trigonométrico exacto", "Ángulo notable en radianes", exactTrig, alts, steps)
            return PmSolution(true, raw, norm, expr, "Trigonometría exacta", listOf(m))
        }

        // Números complejos
        if (hasI) {
            val z = PmEval.evalComplex(expr)
            val ans = PmEval.formatComplex(z)
            steps.add(PmStep(1, "Evaluar en el plano complejo", "Separamos parte real e imaginaria usando i² = -1.", originalStr))
            steps.add(PmStep(2, "Resultado complejo", "Expresamos el resultado en forma binómica a + bi.", ans, highlightSegment = ans))
            val m = PmMethod("arith_complex", "Evaluar en complejos", "Aritmética en ℂ", ans, listOf("Módulo |z|" to formatDecimal(z.abs())), steps)
            return PmSolution(true, raw, norm, expr, "Números complejos", listOf(m))
        }

        // Evaluación racional exacta paso a paso
        val exactRat = PmEval.evalExactRational(expr)
        if (exactRat != null) {
            var cur = expr
            var stepNum = 1
            repeat(8) {
                val (next, ruleTitle, ruleDetail, hl) = reduceOneArithmeticStep(cur)
                if (next == cur) return@repeat
                steps.add(PmStep(stepNum++, ruleTitle, ruleDetail, PmFormatter.format(next), highlightSegment = hl))
                cur = next
            }
            val finalStr = exactRat.toString()
            if (steps.isEmpty() || steps.last().mathText != finalStr) {
                steps.add(PmStep(stepNum, "Resultado exacto", "Simplificamos al máximo el resultado numérico.", finalStr, highlightSegment = finalStr))
            }
            val m = PmMethod("arith_exact", "Evaluar expresión", "Jerarquía de operaciones exacta", finalStr, buildRatAltForms(exactRat), steps)
            return PmSolution(true, raw, norm, expr, "Cálculo aritmético", listOf(m))
        }

        // Evaluación decimal de precisión
        val numVal = PmEval.evalDouble(expr)
        if (!numVal.isFinite()) {
            return PmSolution(false, raw, norm, expr, error = "Expresión indefinida en los reales (división entre cero o dominio inválido).")
        }
        val decStr = formatDecimal(numVal, 6)
        steps.add(PmStep(1, "Aplicar jerarquía de operaciones", "Evaluamos funciones, potencias, productos y sumas en orden.", originalStr))
        steps.add(PmStep(2, "Calcular valor numérico", "Obtenemos el resultado aproximado.", decStr, highlightSegment = decStr))
        val m = PmMethod("arith_num", "Evaluar", "Cálculo numérico de alta precisión", decStr, emptyList(), steps)
        return PmSolution(true, raw, norm, expr, "Cálculo numérico", listOf(m))
    }

    private data class StepReduction(val expr: PmExpr, val title: String, val detail: String, val highlight: String)

    private fun reduceOneArithmeticStep(e: PmExpr): StepReduction = when (e) {
        is PmExpr.Num, is PmExpr.Sym, is PmExpr.Const -> StepReduction(e, "", "", "")
        is PmExpr.Neg -> {
            if (e.inner is PmExpr.Num) {
                val r = -e.inner.rat
                StepReduction(PmExpr.Num(r), "Aplicar signo negativo", "Negamos el valor numérico.", r.toString())
            } else {
                val sub = reduceOneArithmeticStep(e.inner)
                StepReduction(PmExpr.Neg(sub.expr), sub.title, sub.detail, sub.highlight)
            }
        }
        is PmExpr.Abs -> {
            val r = PmEval.evalExactRational(e.inner)
            if (r != null) {
                val a = r.abs()
                StepReduction(PmExpr.Num(a), "Calcular valor absoluto", "El valor absoluto de $r es su distancia al cero: $a.", a.toString())
            } else {
                val sub = reduceOneArithmeticStep(e.inner)
                StepReduction(PmExpr.Abs(sub.expr), sub.title, sub.detail, sub.highlight)
            }
        }
        is PmExpr.Pow -> {
            if (e.base is PmExpr.Num && e.exp is PmExpr.Num && e.exp.rat.isInt) {
                val res = e.base.rat.pow(e.exp.rat.num.toInt())
                StepReduction(PmExpr.Num(res), "Evaluar la potencia", "Calculamos ${e.base.rat}^${e.exp.rat} = $res.", res.toString())
            } else {
                val l = reduceOneArithmeticStep(e.base)
                if (l.expr != e.base) StepReduction(PmExpr.Pow(l.expr, e.exp), l.title, l.detail, l.highlight)
                else {
                    val r = reduceOneArithmeticStep(e.exp)
                    StepReduction(PmExpr.Pow(e.base, r.expr), r.title, r.detail, r.highlight)
                }
            }
        }
        is PmExpr.Mul -> {
            if (e.left is PmExpr.Num && e.right is PmExpr.Num) {
                val res = e.left.rat * e.right.rat
                StepReduction(PmExpr.Num(res), "Multiplicar los números", "${e.left.rat} · ${e.right.rat} = $res.", res.toString())
            } else {
                val l = reduceOneArithmeticStep(e.left)
                if (l.expr != e.left) StepReduction(PmExpr.Mul(l.expr, e.right), l.title, l.detail, l.highlight)
                else {
                    val r = reduceOneArithmeticStep(e.right)
                    StepReduction(PmExpr.Mul(e.left, r.expr), r.title, r.detail, r.highlight)
                }
            }
        }
        is PmExpr.Div -> {
            if (e.num is PmExpr.Num && e.den is PmExpr.Num && !e.den.rat.isZero) {
                val res = e.num.rat / e.den.rat
                StepReduction(PmExpr.Num(res), "Dividir / simplificar fracción", "${e.num.rat} / ${e.den.rat} = $res.", res.toString())
            } else {
                val l = reduceOneArithmeticStep(e.num)
                if (l.expr != e.num) StepReduction(PmExpr.Div(l.expr, e.den), l.title, l.detail, l.highlight)
                else {
                    val r = reduceOneArithmeticStep(e.den)
                    StepReduction(PmExpr.Div(e.num, r.expr), r.title, r.detail, r.highlight)
                }
            }
        }
        is PmExpr.Add -> {
            if (e.left is PmExpr.Num && e.right is PmExpr.Num) {
                val res = e.left.rat + e.right.rat
                StepReduction(PmExpr.Num(res), "Sumar los números", "${e.left.rat} + ${e.right.rat} = $res.", res.toString())
            } else {
                val l = reduceOneArithmeticStep(e.left)
                if (l.expr != e.left) StepReduction(PmExpr.Add(l.expr, e.right), l.title, l.detail, l.highlight)
                else {
                    val r = reduceOneArithmeticStep(e.right)
                    StepReduction(PmExpr.Add(e.left, r.expr), r.title, r.detail, r.highlight)
                }
            }
        }
        is PmExpr.Sub -> {
            if (e.left is PmExpr.Num && e.right is PmExpr.Num) {
                val res = e.left.rat - e.right.rat
                StepReduction(PmExpr.Num(res), "Restar los números", "${e.left.rat} - ${e.right.rat} = $res.", res.toString())
            } else {
                val l = reduceOneArithmeticStep(e.left)
                if (l.expr != e.left) StepReduction(PmExpr.Sub(l.expr, e.right), l.title, l.detail, l.highlight)
                else {
                    val r = reduceOneArithmeticStep(e.right)
                    StepReduction(PmExpr.Sub(e.left, r.expr), r.title, r.detail, r.highlight)
                }
            }
        }
        else -> {
            val r = PmEval.evalExactRational(e)
            if (r != null) StepReduction(PmExpr.Num(r), "Evaluar operación", "Simplificamos la subexpresión a $r.", r.toString())
            else StepReduction(e, "", "", "")
        }
    }

    private fun evalExactTrig(expr: PmExpr): String? {
        if (expr !is PmExpr.Func || expr.args.size != 1) return null
        if (expr.name !in setOf("sin", "cos", "tan")) return null
        val angleRad = PmEval.evalDouble(expr.args[0])
        if (!angleRad.isFinite()) return null
        // Verificar si es múltiplo exacto de π/12
        val kFloat = angleRad / (Math.PI / 6.0)
        val kPi4 = angleRad / (Math.PI / 4.0)
        val k6 = kotlin.math.round(kFloat).toInt()
        val k4 = kotlin.math.round(kPi4).toInt()
        if (abs(kFloat - k6) < 1e-9) {
            val mod = ((k6 % 12) + 12) % 12
            return when (expr.name) {
                "sin" -> mapOf(
                    0 to "0", 1 to "1/2", 2 to "√3/2", 3 to "1", 4 to "√3/2", 5 to "1/2",
                    6 to "0", 7 to "-1/2", 8 to "-√3/2", 9 to "-1", 10 to "-√3/2", 11 to "-1/2"
                )[mod]
                "cos" -> mapOf(
                    0 to "1", 1 to "√3/2", 2 to "1/2", 3 to "0", 4 to "-1/2", 5 to "-√3/2",
                    6 to "-1", 7 to "-√3/2", 8 to "-1/2", 9 to "0", 10 to "1/2", 11 to "√3/2"
                )[mod]
                "tan" -> mapOf(
                    0 to "0", 1 to "√3/3", 2 to "√3", 4 to "-√3", 5 to "-√3/3",
                    6 to "0", 7 to "√3/3", 8 to "√3", 10 to "-√3", 11 to "-√3/3"
                )[mod]
                else -> null
            }
        }
        if (abs(kPi4 - k4) < 1e-9) {
            val mod = ((k4 % 8) + 8) % 8
            return when (expr.name) {
                "sin" -> mapOf(1 to "√2/2", 3 to "√2/2", 5 to "-√2/2", 7 to "-√2/2")[mod]
                "cos" -> mapOf(1 to "√2/2", 3 to "-√2/2", 5 to "-√2/2", 7 to "√2/2")[mod]
                "tan" -> mapOf(1 to "1", 3 to "-1", 5 to "1", 7 to "-1")[mod]
                else -> null
            }
        }
        return null
    }

    // ==========================================================================
    // 2. EXPRESIONES ALGEBRAICAS (SIMPLIFICAR + FACTORIZAR + DERIVAR + GRAFICAR)
    // ==========================================================================
    private fun solveAlgebraicExpression(raw: String, norm: String, expr: PmExpr, vars: List<String>): PmSolution {
        val methods = ArrayList<PmMethod>()
        val v = vars[0]
        val poly = if (vars.size == 1) toRatPoly(expr, v) else null
        val simplified = poly?.toExpr() ?: simplifySymbolic(expr)
        val simpText = PmFormatter.format(simplified)

        // Método 1: Simplificar / Expandir
        val simpSteps = ArrayList<PmStep>()
        simpSteps.add(PmStep(1, "Expresión original", "Identificamos paréntesis, potencias y términos semejantes.", PmFormatter.format(expr)))
        if (simpText != PmFormatter.format(expr)) {
            simpSteps.add(
                PmStep(
                    2,
                    "Expandir y agrupar términos semejantes",
                    "Aplicamos la propiedad distributiva y sumamos los coeficientes de potencias iguales de $v.",
                    simpText,
                    highlightSegment = simpText
                )
            )
        } else {
            simpSteps.add(PmStep(2, "La expresión ya está simplificada", "No existen más términos semejantes por reducir.", simpText))
        }
        val alts = ArrayList<Pair<String, String>>()
        val factored = poly?.let { factorRatPoly(it) }
        if (factored != null && factored != simpText) alts.add("Forma factorizada" to factored)
        methods.add(PmMethod("expr_simplify", "Simplificar", "Forma polinómica reducida", simpText, alts, simpSteps))

        // Método 2: Factorizar (si es polinomio factorizable)
        if (poly != null && factored != null && factored != simpText) {
            val fSteps = buildFactoringSteps(poly, factored)
            methods.add(PmMethod("expr_factor", "Factorizar", "Descomposición en factores primos", factored, listOf("Forma expandida" to simpText), fSteps))
        }

        // Método 3: Hallar raíces f(x) = 0 si es función de 1 variable
        if (vars.size == 1 && poly != null && poly.degree in 1..3) {
            val eqSol = solveEquation(raw, norm, PmExpr.Rel("=", expr, PmExpr.int(0)), vars)
            eqSol.methods.firstOrNull()?.let { rootMethod ->
                methods.add(rootMethod.copy(id = "expr_roots", name = "Hallar raíces (f($v) = 0)"))
            }
        }

        // Método 4: Derivada simbólica d/dx
        if (vars.size == 1) {
            val derivSol = solveDerivative(raw, norm, expr, v)
            derivSol.methods.firstOrNull()?.let { dm ->
                methods.add(dm.copy(id = "expr_deriv", name = "Derivar (d/d$v)"))
            }
        }

        val plot = if (vars.size == 1) buildPlotForExpr(simplified, v) else null
        return PmSolution(true, raw, norm, expr, if (vars.size == 1) "Expresión algebraica en $v" else "Expresión multivariable", methods, plot)
    }

    // ==========================================================================
    // 3. ECUACIONES (LINEALES, CUADRÁTICAS 3 MÉTODOS, CÚBICAS, |x|, √x, EXP/LOG)
    // ==========================================================================
    private fun solveEquation(raw: String, norm: String, eq: PmExpr.Rel, vars: List<String>): PmSolution {
        val left = eq.left
        val right = eq.right

        // Caso función y = f(x) -> analizar función y graficar
        if (left is PmExpr.Sym && left.name.equals("y", true) && vars.any { !it.equals("y", true) }) {
            val xVars = vars.filterNot { it.equals("y", true) }
            val exprSol = solveAlgebraicExpression(raw, norm, right, xVars)
            return exprSol.copy(categoryTitle = "Función y = f(${xVars.firstOrNull() ?: "x"})")
        }

        // Sin variables: comprobación de identidad numérica
        if (vars.isEmpty()) {
            val l = PmEval.evalDouble(left)
            val r = PmEval.evalDouble(right)
            val ok = l.isFinite() && r.isFinite() && abs(l - r) < 1e-9
            val step = PmStep(1, "Evaluar ambos miembros", if (ok) "La igualdad es verdadera." else "La igualdad es falsa.", "${formatDecimal(l)} = ${formatDecimal(r)}")
            val ans = if (ok) "Verdadero" else "Falso"
            return PmSolution(true, raw, norm, eq, "Comprobación de igualdad", listOf(PmMethod("eq_check", "Comprobar igualdad", "", ans, emptyList(), listOf(step))))
        }

        val v = vars[0]

        // A) Ecuación con valor absoluto (soporta |A| = B, a|A| + b = c, |A| - c = 0)
        if (vars.size == 1) {
            val isoAbs = isolateSpecial(left, right) { it is PmExpr.Abs }
            if (isoAbs != null) {
                val absInner = (isoAbs.first as PmExpr.Abs).inner
                val cRat = PmEval.evalExactRational(isoAbs.second)
                if (cRat != null) return solveAbsEquation(raw, norm, eq, absInner, cRat, v)
            }
        }

        // B) Ecuación con radical √(A) = B (también soporta a√(A) + b = c)
        if (vars.size == 1) {
            val isoRad = isolateSpecial(left, right) { it is PmExpr.Root && it.index == null }
            if (isoRad != null) {
                val radInner = (isoRad.first as PmExpr.Root).radicand
                val other = isoRad.second
                if (toRatPoly(radInner, v) != null && toRatPoly(other, v) != null) {
                    return solveRadicalEquation(raw, norm, eq, radInner, other, v)
                }
            }
        }

        // C) Ecuación exponencial a^(bx+c) = d (también soporta k·a^(bx+c) + m = d)
        if (vars.size == 1) {
            val isoExp = isolateSpecial(left, right) { it is PmExpr.Pow && PmParser.collectVars(it.base).isEmpty() && v in PmParser.collectVars(it.exp) }
            if (isoExp != null) {
                val expSol = trySolveExponential(raw, norm, eq, isoExp.first as PmExpr.Pow, isoExp.second, v)
                if (expSol != null) return expSol
            }
        }

        // C2) Ecuación trigonométrica sin/cos/tan (también soporta 2sin(x) - 1 = 0)
        if (vars.size == 1) {
            val isoTrig = isolateSpecial(left, right) { it is PmExpr.Func && it.name in setOf("sin", "cos", "tan") }
            if (isoTrig != null) {
                val trigSol = trySolveTrigEquation(raw, norm, eq, isoTrig.first as PmExpr.Func, isoTrig.second, v)
                if (trigSol != null) return trigSol
            }
        }

        // C3) Ecuación logarítmica ln(A) = c o log(A) = c (también soporta a·ln(A) + b = c)
        if (vars.size == 1) {
            val isoLog = isolateSpecial(left, right) { it is PmExpr.Func && it.name in setOf("ln", "log", "log10") }
            if (isoLog != null) {
                val logSol = trySolveLogarithmic(raw, norm, eq, isoLog.first as PmExpr.Func, isoLog.second, v)
                if (logSol != null) return logSol
            }
        }

        // D) Ecuación fraccionaria / racional general (ej. 1/x + 1/(x+1) = 3/2)
        if (vars.size == 1 && (hasDivisionByVar(left, v) || hasDivisionByVar(right, v))) {
            val fracSol = trySolveFractionalEquation(raw, norm, eq, left, right, v)
            if (fracSol != null) return fracSol
        }

        // E) Ecuación polinómica exacta sobre BigRat
        if (vars.size == 1) {
            val lp = toRatPoly(left, v)
            val rp = toRatPoly(right, v)
            if (lp != null && rp != null) {
                val diff = lp - rp
                return when (diff.degree) {
                    0 -> {
                        val c = diff.coeff(0)
                        val ans = if (c.isZero) "$v ∈ ℝ (infinitas soluciones)" else "Sin solución ($v ∈ ∅)"
                        val steps = listOf(
                            PmStep(1, "Simplificar ambos lados", "Los términos con $v se cancelan por completo.", "$c = 0"),
                            PmStep(2, "Conclusión", if (c.isZero) "La igualdad se cumple para todo valor real de $v." else "Contradicción matemática: ningún valor real cumple la ecuación.", ans, highlightSegment = ans)
                        )
                        PmSolution(true, raw, norm, eq, "Ecuación degenerada", listOf(PmMethod("eq_deg", "Resolver para $v", "", ans, emptyList(), steps)))
                    }
                    1 -> solveLinearEquation(raw, norm, eq, lp, rp, diff, v)
                    2 -> solveQuadraticEquation(raw, norm, eq, lp, rp, diff, v)
                    in 3..5 -> solveHigherPolyEquation(raw, norm, eq, diff, v)
                    else -> solveNumericalEquation(raw, norm, eq, PmExpr.Sub(left, right), v)
                }
            }
        }

        // F) Respaldo numérico robusto (Brent) + gráfica interactiva
        return solveNumericalEquation(raw, norm, eq, PmExpr.Sub(left, right), v)
    }

    // ---------- 3.1 Ecuación lineal ax + b = cx + d ----------
    private fun solveLinearEquation(
        raw: String, norm: String, eq: PmExpr.Rel,
        lp: RatPoly, rp: RatPoly, diff: RatPoly, v: String
    ): PmSolution {
        val steps = ArrayList<PmStep>()
        var idx = 1
        val origL = PmFormatter.format(eq.left)
        val origR = PmFormatter.format(eq.right)
        val simpL = lp.format()
        val simpR = rp.format()

        if (origL != simpL || origR != simpR) {
            steps.add(
                PmStep(
                    idx++,
                    "Expandir y simplificar cada miembro",
                    "Quitamos paréntesis y agrupamos términos semejantes en ambos lados de la igualdad.",
                    "$simpL = $simpR",
                    subSteps = listOf(
                        PmSubStep("Miembro izquierdo", "$origL → $simpL"),
                        PmSubStep("Miembro derecho", "$origR → $simpR")
                    )
                )
            )
        }

        val a = diff.coeff(1)
        val b = diff.coeff(0)
        val rhs = -b

        // Paso de transposición
        val movedExpr = "${formatCoeffVar(a, v)} = $rhs"
        val subTrans = ArrayList<PmSubStep>()
        if (!rp.coeff(1).isZero) subTrans.add(PmSubStep("Mover término con $v a la izquierda", "Restamos ${formatCoeffVar(rp.coeff(1), v)} en ambos lados."))
        if (!lp.coeff(0).isZero) subTrans.add(PmSubStep("Mover constante a la derecha", "Restamos ${lp.coeff(0)} en ambos lados."))

        if (!rp.coeff(1).isZero || !lp.coeff(0).isZero) {
            steps.add(
                PmStep(
                    idx++,
                    "Agrupar términos con $v a la izquierda y constantes a la derecha",
                    "Al cambiar un término de miembro, cambia su signo.",
                    movedExpr,
                    highlightSegment = "$rhs",
                    subSteps = subTrans
                )
            )
        }

        val root = rhs / a
        if (!a.isOne) {
            val divDetail = if (a.isNegOne) "Multiplicamos ambos lados por -1 para cambiar el signo."
            else "Dividimos ambos miembros entre $a para despejar $v."
            steps.add(
                PmStep(
                    idx++,
                    if (a.isNegOne) "Cambiar el signo en ambos miembros" else "Dividir ambos lados entre $a",
                    divDetail,
                    "$v = $root",
                    highlightSegment = root.toString(),
                    subSteps = listOf(
                        PmSubStep("Operación", "$v = ($rhs) / ($a) = $root", "Reducimos la fracción al máximo.")
                    )
                )
            )
        }

        val ans = "$v = $root"
        val alts = buildList {
            if (!root.isInt) add("Forma decimal" to "$v ≈ ${root.toDecimalString()}")
        }
        val plot = buildPlotForExpr(diff.toExpr(), v, listOf(PmPlotPoint(root.toDouble(), 0.0, "Raíz ($root, 0)", "root")))
        val method = PmMethod("lin_std", "Resolver para $v", "Despeje algebraico exacto", ans, alts, steps)
        return PmSolution(true, raw, norm, eq, "Ecuación lineal", listOf(method), plot)
    }

    // ---------- 3.2 Ecuación cuadrática ax² + bx + c = 0 (3 MÉTODOS PHOTOMATH) ----------
    private fun solveQuadraticEquation(
        raw: String, norm: String, eq: PmExpr.Rel,
        lp: RatPoly, rp: RatPoly, rawDiff: RatPoly, v: String
    ): PmSolution {
        // Normalizar para que el coeficiente principal a sea positivo (más limpio)
        val poly = if (rawDiff.coeff(2).isNegative) rawDiff.scale(BigRat.NEG_ONE) else rawDiff
        val a = poly.coeff(2)
        val b = poly.coeff(1)
        val c = poly.coeff(0)
        val disc = b * b - BigRat.of(4) * a * c
        val twoA = BigRat.TWO * a

        // Calcular representación exacta de las raíces (racionales, radicales exactos o complejos)
        val (exactSummary, altDecimals, plotRoots) = formatExactQuadraticRoots(a, b, c, disc, v)

        val methods = ArrayList<PmMethod>()

        // ----- MÉTODO 1: FÓRMULA CUADRÁTICA -----
        val fSteps = ArrayList<PmStep>()
        var si = 1
        fSteps.add(
            PmStep(
                si++,
                "Escribir en forma estándar a$v² + b$v + c = 0",
                "Identificamos los coeficientes: a = $a, b = $b, c = $c.",
                "${poly.format()} = 0",
                highlightSegment = "a = $a, b = $b, c = $c"
            )
        )
        fSteps.add(
            PmStep(
                si++,
                "Aplicar la fórmula cuadrática",
                "Sustituimos a = $a, b = $b y c = $c en $v = (-b ± √(b² - 4ac)) / (2a).",
                "$v = (${-b} ± √(($b)^2 - 4·($a)·($c))) / (2·$a)",
                subSteps = listOf(
                    PmSubStep("Calcular b²", "($b)² = ${b * b}"),
                    PmSubStep("Calcular -4ac", "-4 · ($a) · ($c) = ${BigRat.of(-4) * a * c}"),
                    PmSubStep("Calcular denominador 2a", "2 · ($a) = $twoA")
                )
            )
        )
        val discNote = when {
            disc.isPositive -> "Como el discriminante Δ = $disc > 0, existen dos soluciones reales distintas."
            disc.isZero -> "Como el discriminante Δ = 0, existe una única solución real (raíz doble)."
            else -> "Como el discriminante Δ = $disc < 0, no hay raíces reales; las soluciones son complejas conjugadas."
        }
        fSteps.add(
            PmStep(
                si++,
                "Evaluar el discriminante Δ = b² - 4ac",
                discNote,
                "$v = (${-b} ± √($disc)) / $twoA",
                highlightSegment = disc.toString()
            )
        )
        fSteps.add(
            PmStep(
                si,
                "Simplificar para obtener las soluciones",
                "Separamos los signos + y − y simplificamos fracciones y radicales.",
                exactSummary,
                highlightSegment = exactSummary
            )
        )
        methods.add(PmMethod("quad_formula", "Fórmula cuadrática", "Funciona para cualquier ecuación de 2º grado", exactSummary, altDecimals, fSteps))

        // ----- MÉTODO 2: FACTORIZACIÓN (cuando las raíces son racionales exactas) -----
        val factored = factorRatPoly(poly)
        if (factored != null && !disc.isNegative) {
            val facSteps = ArrayList<PmStep>()
            facSteps.add(PmStep(1, "Escribir en forma estándar", "Agrupamos todos los términos en el miembro izquierdo.", "${poly.format()} = 0"))
            facSteps.add(
                PmStep(
                    2,
                    "Factorizar la expresión cuadrática",
                    "Descomponemos el trinomio en producto de factores lineales.",
                    "$factored = 0",
                    highlightSegment = factored
                )
            )
            facSteps.add(
                PmStep(
                    3,
                    "Igualar cada factor a cero (propiedad del producto nulo)",
                    "Si un producto es cero, al menos uno de los factores debe ser cero.",
                    exactSummary,
                    highlightSegment = exactSummary
                )
            )
            methods.add(PmMethod("quad_factor", "Factorización", "Descomposición en factores lineales", exactSummary, altDecimals, facSteps))
        }

        // ----- MÉTODO 3: COMPLETANDO EL CUADRADO -----
        val compSteps = ArrayList<PmStep>()
        var ci = 1
        val bDivA = b / a
        val cDivA = c / a
        if (!a.isOne) {
            compSteps.add(PmStep(ci++, "Dividir toda la ecuación entre $a", "Hacemos que el coeficiente de $v² sea 1.", "$v^2 + (${bDivA})$v + (${cDivA}) = 0"))
        }
        compSteps.add(PmStep(ci++, "Mover el término independiente a la derecha", "Aislamos los términos que contienen $v.", "$v^2 + (${bDivA})$v = ${-cDivA}", highlightSegment = "${-cDivA}"))
        val halfB = bDivA / BigRat.TWO
        val sqHalf = halfB * halfB
        val rhsComp = -cDivA + sqHalf
        compSteps.add(
            PmStep(
                ci++,
                "Sumar (${halfB})² = $sqHalf en ambos lados",
                "Completamos un trinomio cuadrado perfecto sumando la mitad del coeficiente lineal al cuadrado.",
                "($v + $halfB)^2 = $rhsComp",
                highlightSegment = "$sqHalf",
                subSteps = listOf(
                    PmSubStep("Lado izquierdo", "$v² + (${bDivA})$v + $sqHalf = ($v + $halfB)²"),
                    PmSubStep("Lado derecho", "${-cDivA} + $sqHalf = $rhsComp")
                )
            )
        )
        compSteps.add(PmStep(ci, "Extraer raíz cuadrada en ambos lados y despejar $v", "Consideramos tanto la raíz positiva como la negativa (±).", exactSummary, highlightSegment = exactSummary))
        methods.add(PmMethod("quad_complete", "Completando el cuadrado", "Transformación a binomio al cuadrado", exactSummary, altDecimals, compSteps))

        // Puntos notables para la gráfica (vértice + raíces reales)
        val vx = (-b / twoA).toDouble()
        val vy = (a * ((-b / twoA).pow(2)) + b * (-b / twoA) + c).toDouble()
        val pts = ArrayList<PmPlotPoint>()
        pts.add(PmPlotPoint(vx, vy, "Vértice (${formatDecimal(vx, 3)}, ${formatDecimal(vy, 3)})", "vertex"))
        pts.addAll(plotRoots)
        val plot = buildPlotForExpr(poly.toExpr(), v, pts)

        return PmSolution(true, raw, norm, eq, "Ecuación cuadrática", methods, plot)
    }

    private fun formatExactQuadraticRoots(
        a: BigRat, b: BigRat, c: BigRat, disc: BigRat, v: String
    ): Triple<String, List<Pair<String, String>>, List<PmPlotPoint>> {
        val twoA = BigRat.TWO * a
        if (disc.isZero) {
            val r = -b / twoA
            val ans = "$v = $r"
            val alts = if (!r.isInt) listOf("Forma decimal" to "$v ≈ ${r.toDecimalString()}") else emptyList()
            return Triple(ans, alts, listOf(PmPlotPoint(r.toDouble(), 0.0, "Raíz doble ($r, 0)", "root")))
        }
        // Reescribir a, b, c multiplicados por mcm de denominadores para raíces enteras exactas
        val lcmD = ExactMath.lcm(ExactMath.lcm(a.den, b.den), c.den)
        val ai = a.num * (lcmD / a.den)
        val bi = b.num * (lcmD / b.den)
        val ci = c.num * (lcmD / c.den)
        val di = bi * bi - BigInteger.valueOf(4L) * ai * ci
        val denomI = BigInteger.valueOf(2L) * ai

        if (di > BigInteger.ZERO) {
            val sim = ExactMath.simplifySqrt(di)
            if (sim.isExactInt) {
                val r1 = BigRat.of(-bi - sim.outside, denomI)
                val r2 = BigRat.of(-bi + sim.outside, denomI)
                val sorted = listOf(r1, r2).sorted()
                val ans = "${v}₁ = ${sorted[0]},  ${v}₂ = ${sorted[1]}"
                val alts = if (!sorted[0].isInt || !sorted[1].isInt) {
                    listOf("Forma decimal" to "${v}₁ ≈ ${sorted[0].toDecimalString()}, ${v}₂ ≈ ${sorted[1].toDecimalString()}")
                } else emptyList()
                val pts = listOf(
                    PmPlotPoint(sorted[0].toDouble(), 0.0, "${v}₁ (${sorted[0]}, 0)", "root"),
                    PmPlotPoint(sorted[1].toDouble(), 0.0, "${v}₂ (${sorted[1]}, 0)", "root")
                )
                return Triple(ans, alts, pts)
            } else {
                // Raíces irracionales exactas reducidas por MCD: (-bi ± outside*√inside) / (2*ai)
                val g = ExactMath.gcd(ExactMath.gcd(bi.abs(), sim.outside), denomI.abs())
                val p = -bi / g
                val q = sim.outside / g
                val d = denomI / g
                val radPart = if (q == BigInteger.ONE) "√${sim.inside}" else "${q}√${sim.inside}"
                val exactExpr = when {
                    d == BigInteger.ONE && p == BigInteger.ZERO -> "±$radPart"
                    d == BigInteger.ONE -> "$p ± $radPart"
                    p == BigInteger.ZERO -> "±$radPart/$d"
                    else -> "($p ± $radPart)/$d"
                }
                val x1 = (-b.toDouble() - sqrt(disc.toDouble())) / twoA.toDouble()
                val x2 = (-b.toDouble() + sqrt(disc.toDouble())) / twoA.toDouble()
                val lo = minOf(x1, x2); val hi = maxOf(x1, x2)
                val alts = listOf("Forma decimal" to "${v}₁ ≈ ${formatDecimal(lo)}, ${v}₂ ≈ ${formatDecimal(hi)}")
                val pts = listOf(
                    PmPlotPoint(lo, 0.0, "${v}₁ (${formatDecimal(lo, 3)}, 0)", "root"),
                    PmPlotPoint(hi, 0.0, "${v}₂ (${formatDecimal(hi, 3)}, 0)", "root")
                )
                return Triple("$v = $exactExpr", alts, pts)
            }
        } else {
            // Raíces complejas exactas
            val sim = ExactMath.simplifySqrt(di.abs())
            val g = ExactMath.gcd(ExactMath.gcd(bi.abs(), sim.outside), denomI.abs())
            val p = -bi / g
            val q = sim.outside / g
            val d = denomI / g
            val imCore = when {
                sim.isExactInt && q == BigInteger.ONE -> "i"
                sim.isExactInt -> "${q}i"
                q == BigInteger.ONE -> "√${sim.inside}·i"
                else -> "${q}√${sim.inside}·i"
            }
            val exactExpr = when {
                d == BigInteger.ONE && p == BigInteger.ZERO -> "±$imCore"
                d == BigInteger.ONE -> "$p ± $imCore"
                p == BigInteger.ZERO -> "±$imCore/$d"
                else -> "($p ± $imCore)/$d"
            }
            val reD = (-b / twoA).toDouble()
            val imD = sqrt(abs(disc.toDouble())) / abs(twoA.toDouble())
            val alts = listOf("Forma decimal compleja" to "$v ≈ ${formatDecimal(reD)} ± ${formatDecimal(imD)}i")
            return Triple("$v = $exactExpr  (∉ ℝ)", alts, emptyList())
        }
    }

    // ---------- 3.3 Polinomios grado 3–5 (Teorema de Raíces Racionales + Ruffini) ----------
    private fun solveHigherPolyEquation(raw: String, norm: String, eq: PmExpr.Rel, poly: RatPoly, v: String): PmSolution {
        val steps = ArrayList<PmStep>()
        var idx = 1
        steps.add(PmStep(idx++, "Forma estándar del polinomio", "Agrupamos los términos en orden decreciente de exponente.", "${poly.format()} = 0"))

        var current = poly
        val exactRoots = ArrayList<BigRat>()

        // Extraer x = 0 si el término independiente es cero
        while (current.degree >= 1 && current.coeff(0).isZero) {
            exactRoots.add(BigRat.ZERO)
            current = RatPoly(v, current.coeffs.drop(1))
            steps.add(PmStep(idx++, "Extraer factor común $v", "Como no hay término independiente, $v = 0 es raíz.", "$v · (${current.format()}) = 0", highlightSegment = "$v = 0"))
        }

        // Buscar raíces racionales p/q por Ruffini
        while (current.degree >= 3) {
            val found = findRationalRoot(current) ?: break
            exactRoots.add(found)
            current = divideByLinear(current, found)
            steps.add(
                PmStep(
                    idx++,
                    "División sintética (Regla de Ruffini) con $v = $found",
                    "Al evaluar el polinomio en $v = $found el resto es 0, por lo tanto ($v - ($found)) es un factor.",
                    "($v ${if (found.isNegative) "+ ${found.abs()}" else "- $found"})(${current.format()}) = 0",
                    highlightSegment = "$v = $found"
                )
            )
        }

        val allLabels = exactRoots.map { it.toString() }.toMutableList()
        val plotPts = exactRoots.distinct().map { PmPlotPoint(it.toDouble(), 0.0, "Raíz ($it, 0)", "root") }.toMutableList()

        if (current.degree == 1) {
            val r = -current.coeff(0) / current.coeff(1)
            exactRoots.add(r)
            allLabels.add(r.toString())
            plotPts.add(PmPlotPoint(r.toDouble(), 0.0, "Raíz ($r, 0)", "root"))
            steps.add(PmStep(idx++, "Resolver el factor lineal restante", "Despejamos $v del factor ${current.format()} = 0.", "$v = $r", highlightSegment = "$r"))
        } else if (current.degree == 2) {
            val a = current.coeff(2); val b = current.coeff(1); val c = current.coeff(0)
            val disc = b * b - BigRat.of(4) * a * c
            val (qAns, _, qPts) = formatExactQuadraticRoots(a, b, c, disc, v)
            allLabels.add(qAns)
            plotPts.addAll(qPts)
            steps.add(PmStep(idx++, "Resolver el factor cuadrático restante", "Aplicamos la fórmula cuadrática a ${current.format()} = 0.", qAns, highlightSegment = qAns))
        } else if (current.degree >= 3) {
            val numRoots = findNumericalRoots(current.toExpr(), v)
            numRoots.forEach { r ->
                allLabels.add("≈ ${formatDecimal(r, 4)}")
                plotPts.add(PmPlotPoint(r, 0.0, "Raíz (${formatDecimal(r, 3)}, 0)", "root"))
            }
            steps.add(PmStep(idx++, "Localizar raíces restantes (método numérico de Brent)", "El factor ${current.format()} no tiene raíces racionales simples; hallamos sus raíces reales con precisión 10⁻¹⁰.", allLabels.joinToString(", ")))
        }

        val finalAns = if (exactRoots.isNotEmpty() && current.degree <= 1) {
            exactRoots.distinct().sorted().mapIndexed { i, r -> "${v}${subscript(i + 1)} = $r" }.joinToString(",  ")
        } else {
            allLabels.distinct().joinToString(" ; ")
        }
        val plot = buildPlotForExpr(poly.toExpr(), v, plotPts.distinctBy { formatDecimal(it.x, 3) })
        val m = PmMethod("poly_ruffini", "Factorización / Ruffini", "Reducción exacta de grado paso a paso", finalAns, emptyList(), steps)
        return PmSolution(true, raw, norm, eq, "Ecuación polinómica de grado ${poly.degree}", listOf(m), plot)
    }

    // ---------- 3.4 Ecuaciones con valor absoluto |A| = c ----------
    private fun solveAbsEquation(raw: String, norm: String, eq: PmExpr.Rel, inner: PmExpr, c: BigRat, v: String): PmSolution {
        val steps = ArrayList<PmStep>()
        val innerStr = PmFormatter.format(inner)
        if (c.isNegative) {
            steps.add(PmStep(1, "Analizar el valor absoluto", "Un valor absoluto nunca puede ser negativo (|$innerStr| ≥ 0 para todo $v ∈ ℝ).", "|$innerStr| = $c → Sin solución", highlightSegment = "Sin solución"))
            return PmSolution(true, raw, norm, eq, "Ecuación con valor absoluto", listOf(PmMethod("abs_none", "Resolver para $v", "", "Sin solución ($v ∈ ∅)", emptyList(), steps)))
        }
        if (c.isZero) {
            val subSol = solveEquation(raw, norm, PmExpr.Rel("=", inner, PmExpr.int(0)), listOf(v))
            val ans = subSol.methods.firstOrNull()?.finalAnswer ?: "0"
            steps.add(PmStep(1, "Eliminar el valor absoluto", "El único número con valor absoluto 0 es el propio 0.", "$innerStr = 0"))
            subSol.methods.firstOrNull()?.steps?.forEachIndexed { i, s -> steps.add(s.copy(index = i + 2)) }
            return PmSolution(true, raw, norm, eq, "Ecuación con valor absoluto", listOf(PmMethod("abs_zero", "Resolver para $v", "", ans, emptyList(), steps)), subSol.plot)
        }
        steps.add(
            PmStep(
                1,
                "Dividir en dos casos por definición de valor absoluto",
                "Si |$innerStr| = $c, entonces $innerStr = $c o $innerStr = ${-c}.",
                "Caso 1: $innerStr = $c   |   Caso 2: $innerStr = ${-c}",
                highlightSegment = "±$c"
            )
        )
        val sol1 = solveEquation(raw, norm, PmExpr.Rel("=", inner, PmExpr.Num(c)), listOf(v))
        val sol2 = solveEquation(raw, norm, PmExpr.Rel("=", inner, PmExpr.Num(-c)), listOf(v))
        val a1 = sol1.methods.firstOrNull()?.finalAnswer ?: ""
        val a2 = sol2.methods.firstOrNull()?.finalAnswer ?: ""
        steps.add(PmStep(2, "Resolver Caso 1 ($innerStr = $c)", "Despejamos $v en la primera rama.", a1, highlightSegment = a1, subSteps = sol1.methods.firstOrNull()?.steps?.map { PmSubStep(it.actionTitle, it.mathText, it.detail) }.orEmpty()))
        steps.add(PmStep(3, "Resolver Caso 2 ($innerStr = ${-c})", "Despejamos $v en la segunda rama.", a2, highlightSegment = a2, subSteps = sol2.methods.firstOrNull()?.steps?.map { PmSubStep(it.actionTitle, it.mathText, it.detail) }.orEmpty()))
        val finalAns = "$a1  ;  $a2"
        val plot = buildPlotForExpr(PmExpr.Sub(PmExpr.Abs(inner), PmExpr.Num(c)), v)
        return PmSolution(true, raw, norm, eq, "Ecuación con valor absoluto", listOf(PmMethod("abs_two", "Dos casos", "Definición de |u| = c", finalAns, emptyList(), steps)), plot)
    }

    // ---------- 3.5 Ecuaciones con radical √(A) = B ----------
    private fun solveRadicalEquation(raw: String, norm: String, eq: PmExpr.Rel, radInner: PmExpr, other: PmExpr, v: String): PmSolution {
        val steps = ArrayList<PmStep>()
        steps.add(PmStep(1, "Aislar el radical", "La raíz cuadrada ya está despejada en un miembro.", "√(${PmFormatter.format(radInner)}) = ${PmFormatter.format(other)}"))
        val squaredEq = PmExpr.Rel("=", radInner, PmExpr.Pow(other, PmExpr.int(2)))
        steps.add(PmStep(2, "Elevar ambos miembros al cuadrado", "Eliminamos la raíz cuadrada elevando al cuadrado ambos lados.", "${PmFormatter.format(radInner)} = (${PmFormatter.format(other)})^2", highlightSegment = "^2"))
        val sub = solveEquation(raw, norm, squaredEq, listOf(v))
        val sqPoly = (toRatPoly(radInner, v)!! - (toRatPoly(other, v)!! * toRatPoly(other, v)!!))
        val candidates = when (sqPoly.degree) {
            1 -> listOf((-sqPoly.coeff(0) / sqPoly.coeff(1)).toDouble())
            2 -> {
                val a = sqPoly.coeff(2).toDouble(); val b = sqPoly.coeff(1).toDouble(); val c = sqPoly.coeff(0).toDouble()
                val d = b * b - 4.0 * a * c
                if (d < -1e-9) emptyList()
                else if (abs(d) <= 1e-9) listOf(-b / (2.0 * a))
                else listOf((-b - sqrt(d)) / (2.0 * a), (-b + sqrt(d)) / (2.0 * a)).sorted()
            }
            else -> sub.plot?.points?.filter { it.kind == "root" }?.map { it.x }.orEmpty()
        }
        val valid = ArrayList<Double>()
        val rejected = ArrayList<Double>()
        for (cand in candidates) {
            val lhsV = PmEval.evalDouble(PmExpr.Root(radInner), mapOf(v to cand))
            val rhsV = PmEval.evalDouble(other, mapOf(v to cand))
            if (lhsV.isFinite() && rhsV.isFinite() && abs(lhsV - rhsV) < 1e-6) valid.add(cand)
            else rejected.add(cand)
        }
        val subAns = sub.methods.firstOrNull()?.finalAnswer ?: ""
        steps.add(PmStep(3, "Resolver la ecuación polinómica resultante", "Resolvemos la ecuación sin radicales.", subAns))
        val checkMsg = buildString {
            if (valid.isNotEmpty()) append("Válidas: ${valid.joinToString(", ") { "$v = ${formatDecimal(it, 4)}" }}. ")
            if (rejected.isNotEmpty()) append("Descartadas (extrañas): ${rejected.joinToString(", ") { formatDecimal(it, 4) }}.")
            if (valid.isEmpty()) append("Ninguna solución candidata satisface la ecuación original.")
        }
        val finalAns = if (valid.isEmpty()) "Sin solución real" else valid.joinToString(",  ") { "$v = ${formatDecimal(it, 4)}" }
        steps.add(PmStep(4, "Comprobar soluciones extrañas", checkMsg, finalAns, highlightSegment = finalAns))
        val pts = valid.map { PmPlotPoint(it, 0.0, "Solución (${formatDecimal(it, 3)}, 0)", "root") }
        val plot = buildPlotForExpr(PmExpr.Sub(PmExpr.Root(radInner), other), v, pts)
        return PmSolution(true, raw, norm, eq, "Ecuación con radical", listOf(PmMethod("rad_eq", "Elevar al cuadrado y verificar", "Verificación de soluciones extrañas", finalAns, emptyList(), steps)), plot)
    }

    // ---------- 3.6 Ecuaciones exponenciales y logarítmicas ----------
    private fun trySolveExponential(raw: String, norm: String, eq: PmExpr.Rel, pow: PmExpr.Pow, other: PmExpr, v: String): PmSolution? {
        if (PmParser.collectVars(pow.base).isNotEmpty()) return null
        val baseVal = PmEval.evalDouble(pow.base)
        val rhsVal = PmEval.evalDouble(other)
        if (!baseVal.isFinite() || baseVal <= 0.0 || baseVal == 1.0 || !rhsVal.isFinite()) return null
        val expPoly = toRatPoly(pow.exp, v) ?: return null
        if (expPoly.degree != 1) return null

        val steps = ArrayList<PmStep>()
        if (rhsVal <= 0.0) {
            steps.add(PmStep(1, "Analizar el signo de la exponencial", "Una función exponencial de base positiva (${PmFormatter.format(pow.base)} > 0) siempre es estrictamente positiva.", "Sin solución real", highlightSegment = "Sin solución real"))
            return PmSolution(true, raw, norm, eq, "Ecuación exponencial", listOf(PmMethod("exp_none", "Resolver exponencial", "", "Sin solución real", emptyList(), steps)))
        }
        val logVal = ln(rhsVal) / ln(baseVal)
        val exactIntExp = kotlin.math.round(logVal).takeIf { abs(it - logVal) < 1e-9 }?.toLong()
        val baseStr = PmFormatter.format(pow.base)
        val expStr = PmFormatter.format(pow.exp)

        if (exactIntExp != null) {
            steps.add(PmStep(1, "Igualar las bases", "Reescribimos ${PmFormatter.format(other)} como potencia de $baseStr: $baseStr^$exactIntExp.", "$baseStr^($expStr) = $baseStr^$exactIntExp", highlightSegment = "$exactIntExp"))
            steps.add(PmStep(2, "Igualar los exponentes", "Como las bases son iguales, los exponentes deben coincidir.", "$expStr = $exactIntExp"))
            val a = expPoly.coeff(1); val b = expPoly.coeff(0)
            val root = (BigRat.of(exactIntExp) - b) / a
            steps.add(PmStep(3, "Despejar $v", "Resolvemos la ecuación lineal resultante.", "$v = $root", highlightSegment = root.toString()))
            val ans = "$v = $root"
            val plot = buildPlotForExpr(PmExpr.Sub(pow, other), v, listOf(PmPlotPoint(root.toDouble(), 0.0, "Raíz ($root, 0)", "root")))
            return PmSolution(true, raw, norm, eq, "Ecuación exponencial", listOf(PmMethod("exp_exact", "Igualar bases", "Solución exacta", ans, buildRatAltForms(root), steps)), plot)
        } else {
            val isEuler = pow.base is PmExpr.Const && pow.base.name == "e"
            steps.add(
                PmStep(
                    1,
                    if (isEuler) "Aplicar logaritmo natural (ln) a ambos lados" else "Aplicar logaritmo en base $baseStr",
                    "Usamos la operación inversa de la potenciación para bajar el exponente.",
                    if (isEuler) "$expStr = ln(${PmFormatter.format(other)})" else "$expStr = ln(${PmFormatter.format(other)}) / ln($baseStr)"
                )
            )
            val a = expPoly.coeff(1).toDouble(); val b = expPoly.coeff(0).toDouble()
            val xVal = (logVal - b) / a
            val ans = "$v ≈ ${formatDecimal(xVal, 5)}"
            steps.add(PmStep(2, "Despejar $v", "Calculamos el valor numérico final.", ans, highlightSegment = ans))
            val plot = buildPlotForExpr(PmExpr.Sub(pow, other), v, listOf(PmPlotPoint(xVal, 0.0, "Raíz (${formatDecimal(xVal, 3)}, 0)", "root")))
            return PmSolution(true, raw, norm, eq, "Ecuación exponencial", listOf(PmMethod("exp_log", "Usar logaritmos", "Despeje logarítmico", ans, emptyList(), steps)), plot)
        }
    }

    private fun trySolveLogarithmic(raw: String, norm: String, eq: PmExpr.Rel, fn: PmExpr.Func, other: PmExpr, v: String): PmSolution? {
        if (fn.name !in setOf("ln", "log", "log10")) return null
        val rhsVal = PmEval.evalDouble(other)
        if (!rhsVal.isFinite()) return null
        val (baseVal, baseLabel, argExpr) = when {
            fn.name == "ln" && fn.args.size == 1 -> Triple(Math.E, "e", fn.args[0])
            fn.name == "log10" && fn.args.size == 1 -> Triple(10.0, "10", fn.args[0])
            fn.name == "log" && fn.args.size == 2 -> Triple(PmEval.evalDouble(fn.args[0]), PmFormatter.format(fn.args[0]), fn.args[1])
            else -> return null
        }
        val argPoly = toRatPoly(argExpr, v) ?: return null
        if (argPoly.degree != 1) return null

        val steps = ArrayList<PmStep>()
        val powVal = baseVal.pow(rhsVal)
        steps.add(PmStep(1, "Convertir a forma exponencial", "Por definición de logaritmo, log_b(u) = c equivale a u = b^c.", "${PmFormatter.format(argExpr)} = $baseLabel^(${PmFormatter.format(other)})", highlightSegment = "$baseLabel^(${PmFormatter.format(other)})"))
        val a = argPoly.coeff(1).toDouble(); val b = argPoly.coeff(0).toDouble()
        val xVal = (powVal - b) / a
        val ans = "$v ≈ ${formatDecimal(xVal, 5)}"
        steps.add(PmStep(2, "Despejar $v y verificar dominio", "El argumento del logaritmo es positivo (${formatDecimal(powVal, 4)} > 0), así que la solución es válida.", ans, highlightSegment = ans))
        val plot = buildPlotForExpr(PmExpr.Sub(fn, other), v, listOf(PmPlotPoint(xVal, 0.0, "Raíz (${formatDecimal(xVal, 3)}, 0)", "root")))
        return PmSolution(true, raw, norm, eq, "Ecuación logarítmica", listOf(PmMethod("log_eq", "Forma exponencial", "Definición de logaritmo", ans, emptyList(), steps)), plot)
    }

    // ---------- 3.7 Ecuación general numérica (Brent) ----------
    private fun solveNumericalEquation(raw: String, norm: String, eq: PmExpr.Rel, diff: PmExpr, v: String): PmSolution {
        val roots = findNumericalRoots(diff, v)
        val steps = ArrayList<PmStep>()
        steps.add(PmStep(1, "Reescribir como f($v) = 0", "Restamos el segundo miembro al primero para localizar los cruces con el eje X.", "${PmFormatter.format(diff)} = 0"))
        val pts = roots.mapIndexed { i, r -> PmPlotPoint(r, 0.0, "${v}${subscript(i + 1)} (${formatDecimal(r, 3)}, 0)", "root") }
        val ans = if (roots.isEmpty()) "No se hallaron raíces reales en [-50, 50]"
        else roots.mapIndexed { i, r -> "${v}${subscript(i + 1)} ≈ ${formatDecimal(r, 5)}" }.joinToString(",  ")
        steps.add(PmStep(2, "Hallar raíces reales numéricamente", "Refinamos cada cruce de signo con el algoritmo de Brent (precisión 10⁻¹⁰).", ans, highlightSegment = ans))
        val plot = buildPlotForExpr(diff, v, pts)
        return PmSolution(true, raw, norm, eq, "Ecuación en $v", listOf(PmMethod("num_brent", "Resolución numérica", "Método de Brent de alta precisión", ans, emptyList(), steps)), plot)
    }

    // ==========================================================================
    // 4. INECUACIONES (<, <=, >, >=) CON RECTA NUMÉRICA Y NOTACIÓN DE INTERVALOS
    // ==========================================================================
    private fun solveInequality(raw: String, norm: String, rel: PmExpr.Rel, vars: List<String>): PmSolution {
        val v = vars.firstOrNull() ?: return solveEquation(raw, norm, rel, vars)

        // A) Inecuación con valor absoluto |ax+b| <, <=, >, >= c
        if (vars.size == 1 && (rel.left is PmExpr.Abs || rel.right is PmExpr.Abs)) {
            val absSol = trySolveAbsInequality(raw, norm, rel, v)
            if (absSol != null) return absSol
        }

        // B) Inecuación racional general (soporta P(x)/Q(x) y sumas de fracciones con x en denominador)
        if (vars.size == 1 && (hasDivisionByVar(rel.left, v) || hasDivisionByVar(rel.right, v))) {
            val ratSol = trySolveRationalInequality(raw, norm, rel, v)
            if (ratSol != null) return ratSol
        }

        val lp = toRatPoly(rel.left, v)
        val rp = toRatPoly(rel.right, v)
        if (lp == null || rp == null) {
            return PmSolution(false, raw, norm, rel, error = "Las inecuaciones admiten expresiones lineales, cuadráticas, racionales P(x)/Q(x) o con valor absoluto.")
        }
        val diff = lp - rp
        val sym = prettyRel(rel.op)
        val steps = ArrayList<PmStep>()

        // Inecuación lineal
        if (diff.degree == 1) {
            val a = diff.coeff(1)
            val rhs = -diff.coeff(0)
            steps.add(PmStep(1, "Agrupar términos con $v a la izquierda y constantes a la derecha", "Mantenemos el sentido de la desigualdad al sumar o restar términos.", "${formatCoeffVar(a, v)} $sym $rhs"))
            val flippedOp = if (a.isNegative) flipRel(rel.op) else rel.op
            val flippedSym = prettyRel(flippedOp)
            val bound = rhs / a
            steps.add(
                PmStep(
                    2,
                    if (a.isNegative) "Dividir entre $a e INVERTIR el signo" else "Dividir ambos lados entre $a",
                    if (a.isNegative) "Regla clave: al dividir una inecuación entre un número negativo ($a), el sentido de la desigualdad se invierte ($sym → $flippedSym)."
                    else "Como $a > 0, el sentido de la desigualdad se mantiene.",
                    "$v $flippedSym $bound",
                    highlightSegment = "$flippedSym $bound"
                )
            )
            val interval = when (flippedOp) {
                "<" -> NumberLineInterval(null, bound.toDouble(), false, false)
                "<=" -> NumberLineInterval(null, bound.toDouble(), false, true)
                ">" -> NumberLineInterval(bound.toDouble(), null, false, false)
                else -> NumberLineInterval(bound.toDouble(), null, true, false)
            }
            val intervalText = formatInterval(bound, flippedOp)
            val ans = "$v $flippedSym $bound"
            val m = PmMethod("ineq_lin", "Resolver inecuación", "Despeje con control de signo", ans, listOf("Notación de intervalo" to "$v ∈ $intervalText"), steps, listOf(interval))
            return PmSolution(true, raw, norm, rel, "Inecuación lineal", listOf(m))
        }

        // Inecuación cuadrática
        if (diff.degree == 2) {
            val a = diff.coeff(2); val b = diff.coeff(1); val c = diff.coeff(0)
            val disc = b * b - BigRat.of(4) * a * c
            val aPos = a.isPositive
            val wantPos = rel.op == ">" || rel.op == ">="
            val inclusive = rel.op == "<=" || rel.op == ">="
            steps.add(PmStep(1, "Pasar todos los términos al primer miembro", "Compararemos el signo de la parábola con cero.", "${diff.format()} $sym 0"))

            if (disc.isNegative) {
                val allTrue = (aPos && wantPos) || (!aPos && !wantPos)
                val ans = if (allTrue) "$v ∈ ℝ (todos los reales)" else "Sin solución ($v ∈ ∅)"
                steps.add(PmStep(2, "Analizar el discriminante (Δ < 0)", "La parábola nunca cruza el eje X; mantiene siempre el signo de a = $a.", ans, highlightSegment = ans))
                val ivs = if (allTrue) listOf(NumberLineInterval(null, null)) else emptyList()
                return PmSolution(true, raw, norm, rel, "Inecuación cuadrática", listOf(PmMethod("ineq_q", "Análisis de signo", "", ans, emptyList(), steps, ivs)), buildPlotForExpr(diff.toExpr(), v))
            }

            val r1d = (-b.toDouble() - sqrt(disc.toDouble())) / (2.0 * a.toDouble())
            val r2d = (-b.toDouble() + sqrt(disc.toDouble())) / (2.0 * a.toDouble())
            val lo = minOf(r1d, r2d); val hi = maxOf(r1d, r2d)
            val loS = formatDecimal(lo, 4); val hiS = formatDecimal(hi, 4)
            steps.add(PmStep(2, "Hallar puntos críticos (raíces de la ecuación asociada)", "Las raíces dividen la recta real en intervalos de signo constante.", "${v}₁ = $loS,  ${v}₂ = $hiS", highlightSegment = "$loS, $hiS"))

            val outer = (aPos && wantPos) || (!aPos && !wantPos)
            val ivs: List<NumberLineInterval>
            val ans: String
            val ivText: String
            if (outer) {
                ivs = listOf(NumberLineInterval(null, lo, false, inclusive), NumberLineInterval(hi, null, inclusive, false))
                val sL = if (inclusive) "≤" else "<"
                val sR = if (inclusive) "≥" else ">"
                ans = "$v $sL $loS  o  $v $sR $hiS"
                ivText = "(-∞, $loS${if (inclusive) "]" else ")"} ∪ ${if (inclusive) "[" else "("}$hiS, +∞)"
            } else {
                ivs = listOf(NumberLineInterval(lo, hi, inclusive, inclusive))
                val sC = if (inclusive) "≤" else "<"
                ans = "$loS $sC $v $sC $hiS"
                ivText = "${if (inclusive) "[" else "("}$loS, $hiS${if (inclusive) "]" else ")"}"
            }
            steps.add(PmStep(3, "Construir tabla de signos", "Evaluamos el signo en cada intervalo delimitado por $loS y $hiS.", ans, highlightSegment = ans))
            val pts = listOf(PmPlotPoint(lo, 0.0, "Crítico ($loS, 0)", "root"), PmPlotPoint(hi, 0.0, "Crítico ($hiS, 0)", "root"))
            val m = PmMethod("ineq_quad", "Tabla de signos", "Análisis de intervalos cuadráticos", ans, listOf("Notación de intervalo" to "$v ∈ $ivText"), steps, ivs)
            return PmSolution(true, raw, norm, rel, "Inecuación cuadrática", listOf(m), buildPlotForExpr(diff.toExpr(), v, pts))
        }

        return PmSolution(false, raw, norm, rel, error = "Inecuación de grado ${diff.degree} no soportada aún paso a paso.")
    }

    // ==========================================================================
    // 5. SISTEMAS DE ECUACIONES LINEALES (3 MÉTODOS PHOTOMATH: SUSTITUCIÓN, ELIMINACIÓN, CRAMER)
    // ==========================================================================
    private fun solveSystem(raw: String, norm: String, sys: PmExpr.System, vars: List<String>): PmSolution {
        val n = sys.items.size
        if (vars.size != n || n !in 2..3) {
            return PmSolution(false, raw, norm, sys, error = "El sistema tiene $n ecuaciones y ${vars.size} incógnitas (${vars.joinToString(", ")}). Ingresa 2 ecuaciones con 2 incógnitas o 3 con 3.")
        }

        val mat = Array(n) { Array(n) { BigRat.ZERO } }
        val rhs = Array(n) { BigRat.ZERO }
        for (i in 0 until n) {
            val item = sys.items[i]
            val diff = if (item is PmExpr.Rel && item.op == "=") PmExpr.Sub(item.left, item.right) else item
            val lf = toRatLinearForm(diff, vars)
                ?: return PmSolution(false, raw, norm, sys, error = "La ecuación ${i + 1} no es lineal. Los sistemas paso a paso resuelven ecuaciones lineales.")
            for (j in 0 until n) mat[i][j] = lf.coeffs[j]
            rhs[i] = -lf.constant
        }

        val det = exactDeterminant(mat)
        if (det.isZero) {
            val steps = listOf(
                PmStep(1, "Calcular el determinante del sistema", "El determinante de la matriz de coeficientes es Δ = 0.", "Δ = 0", highlightSegment = "0"),
                PmStep(2, "Clasificación del sistema", "Al ser Δ = 0, las ecuaciones son paralelas (sin solución) o coincidentes (infinitas soluciones).", "Sin solución única")
            )
            return PmSolution(true, raw, norm, sys, "Sistema lineal ${n}×${n}", listOf(PmMethod("sys_sing", "Análisis del sistema", "", "Sin solución única (Δ = 0)", emptyList(), steps)))
        }

        val sol = Array(n) { col ->
            val mod = Array(n) { r -> Array(n) { c -> if (c == col) rhs[r] else mat[r][c] } }
            exactDeterminant(mod) / det
        }
        val finalAns = (0 until n).joinToString(",  ") { i -> "${vars[i]} = ${sol[i]}" }
        val altDec = if (sol.any { !it.isInt }) {
            listOf("Forma decimal" to (0 until n).joinToString(", ") { i -> "${vars[i]} ≈ ${sol[i].toDecimalString()}" })
        } else emptyList()

        val methods = ArrayList<PmMethod>()

        if (n == 2) {
            val v1 = vars[0]; val v2 = vars[1]
            val a1 = mat[0][0]; val b1 = mat[0][1]; val c1 = rhs[0]
            val a2 = mat[1][0]; val b2 = mat[1][1]; val c2 = rhs[1]

            // ----- MÉTODO 1: SUSTITUCIÓN -----
            val sSteps = ArrayList<PmStep>()
            val isolateFirst = !a1.isZero
            if (isolateFirst) {
                val coef = -b1 / a1
                val cst = c1 / a1
                val isoStr = "$v1 = ${formatLinearRHS(cst, coef, v2)}"
                sSteps.add(PmStep(1, "Despejar $v1 en la primera ecuación", "Aislamos $v1 para sustituirlo en la segunda ecuación.", isoStr, highlightSegment = isoStr))
                val newB = a2 * coef + b2
                val newC = c2 - a2 * cst
                sSteps.add(PmStep(2, "Sustituir $v1 en la segunda ecuación", "Reemplazamos $v1 por ${formatLinearRHS(cst, coef, v2)}.", "${formatCoeffVar(newB, v2)} = $newC", highlightSegment = "$newC"))
                sSteps.add(PmStep(3, "Resolver para $v2", "Dividimos ambos miembros entre $newB.", "$v2 = ${sol[1]}", highlightSegment = "${sol[1]}"))
                sSteps.add(PmStep(4, "Sustituir $v2 = ${sol[1]} para hallar $v1", "Volvemos a la expresión despejada del paso 1.", "$v1 = ${sol[0]}", highlightSegment = "${sol[0]}"))
            } else {
                sSteps.add(PmStep(1, "Despejar $v2 en la primera ecuación", "Como el coeficiente de $v1 es 0, obtenemos $v2 directamente.", "$v2 = ${sol[1]}", highlightSegment = "${sol[1]}"))
                sSteps.add(PmStep(2, "Sustituir $v2 = ${sol[1]} en la segunda ecuación", "Despejamos $v1.", "$v1 = ${sol[0]}", highlightSegment = "${sol[0]}"))
            }
            methods.add(PmMethod("sys_sub", "Método de sustitución", "Despejar una incógnita y sustituir", finalAns, altDec, sSteps))

            // ----- MÉTODO 2: ELIMINACIÓN (REDUCCIÓN) -----
            val eSteps = ArrayList<PmStep>()
            val mult1 = b2
            val mult2 = -b1
            eSteps.add(
                PmStep(
                    1,
                    "Igualar coeficientes de $v2 con signos opuestos",
                    "Multiplicamos la Ec. 1 por ($mult1) y la Ec. 2 por ($mult2) para cancelar $v2 al sumar.",
                    "Ec.1 × ($mult1)  y  Ec.2 × ($mult2)",
                    highlightSegment = "$v2"
                )
            )
            val combA = a1 * mult1 + a2 * mult2
            val combC = c1 * mult1 + c2 * mult2
            eSteps.add(PmStep(2, "Sumar ambas ecuaciones", "Los términos con $v2 se anulan y queda una ecuación en $v1.", "${formatCoeffVar(combA, v1)} = $combC", highlightSegment = "$combC"))
            eSteps.add(PmStep(3, "Despejar $v1", "Dividimos entre $combA.", "$v1 = ${sol[0]}", highlightSegment = "${sol[0]}"))
            eSteps.add(PmStep(4, "Sustituir $v1 = ${sol[0]} para hallar $v2", "Reemplazamos en una de las ecuaciones originales.", "$v2 = ${sol[1]}", highlightSegment = "${sol[1]}"))
            methods.add(PmMethod("sys_elim", "Método de eliminación", "Cancelación directa de una variable", finalAns, altDec, eSteps))
        }

        // ----- MÉTODO 3: REGLA DE CRAMER / DETERMINANTES (2×2 y 3×3) -----
        val cSteps = ArrayList<PmStep>()
        cSteps.add(PmStep(1, "Determinante principal Δ", "Calculamos el determinante de la matriz de coeficientes.", "Δ = $det", highlightSegment = "$det"))
        for (i in 0 until n) {
            val mod = Array(n) { r -> Array(n) { c -> if (c == i) rhs[r] else mat[r][c] } }
            val di = exactDeterminant(mod)
            cSteps.add(PmStep(i + 2, "Hallar ${vars[i]} = Δ_${vars[i]} / Δ", "Sustituimos la columna de ${vars[i]} por los términos independientes: Δ_${vars[i]} = $di.", "${vars[i]} = $di / $det = ${sol[i]}", highlightSegment = "${sol[i]}"))
        }
        methods.add(PmMethod("sys_cramer", "Regla de Cramer", "Determinantes exactos paso a paso", finalAns, altDec, cSteps))

        // Gráfica 2D de ambas rectas y su punto de intersección
        val plot = if (n == 2) buildLinearSystemPlot(mat, rhs, sol) else null
        return PmSolution(true, raw, norm, sys, "Sistema de ecuaciones ${n}×${n}", methods, plot)
    }

    private fun buildLinearSystemPlot(mat: Array<Array<BigRat>>, rhs: Array<BigRat>, sol: Array<BigRat>): PmPlotData {
        val curves = ArrayList<PmCurve>()
        for (i in 0..1) {
            val a = mat[i][0]; val b = mat[i][1]; val c = rhs[i]
            if (!b.isZero) {
                // y = (c - a*x) / b
                val yExpr = PmExpr.Div(PmExpr.Sub(PmExpr.Num(c), PmExpr.Mul(PmExpr.Num(a), PmExpr.Sym("x"))), PmExpr.Num(b))
                curves.add(PmCurve("Ec. ${i + 1}: y = ${PmFormatter.format(simplifySymbolic(yExpr))}", yExpr, "x", CURVE_COLORS[i]))
            }
        }
        val ix = sol[0].toDouble(); val iy = sol[1].toDouble()
        val pad = maxOf(5.0, maxOf(abs(ix), abs(iy)) * 0.65 + 3.0)
        return PmPlotData(
            curves = curves,
            points = listOf(PmPlotPoint(ix, iy, "Solución (${sol[0]}, ${sol[1]})", "intersection")),
            xMin = ix - pad, xMax = ix + pad, yMin = iy - pad, yMax = iy + pad
        )
    }

    // ==========================================================================
    // 6. CÁLCULO: DERIVADAS, INTEGRALES Y LÍMITES
    // ==========================================================================
    private fun solveDerivative(raw: String, norm: String, body: PmExpr, v: String): PmSolution {
        val rules = LinkedHashSet<String>()
        val rawDeriv = differentiate(body, v, rules)
        val simp = toRatPoly(rawDeriv, v)?.toExpr() ?: simplifySymbolic(rawDeriv)
        val secondRaw = differentiate(simp, v, LinkedHashSet())
        val second = toRatPoly(secondRaw, v)?.toExpr() ?: simplifySymbolic(secondRaw)

        val steps = ArrayList<PmStep>()
        steps.add(PmStep(1, "Función a derivar respecto a $v", "Identificamos la estructura de f($v).", "d/d$v (${PmFormatter.format(body)})"))
        if (rules.isNotEmpty()) {
            steps.add(
                PmStep(
                    2,
                    "Aplicar reglas de derivación",
                    rules.joinToString("\n• ", prefix = "• "),
                    PmFormatter.format(rawDeriv),
                    subSteps = rules.map { PmSubStep("Regla aplicada", it) }
                )
            )
        }
        val ans = PmFormatter.format(simp)
        steps.add(PmStep(steps.size + 1, "Simplificar la derivada", "Agrupamos coeficientes y reducimos potencias.", "f'($v) = $ans", highlightSegment = ans))

        val m = PmMethod(
            "calc_deriv",
            "Primera derivada",
            "Derivación simbólica paso a paso",
            "f'($v) = $ans",
            listOf("Segunda derivada f''($v)" to PmFormatter.format(second)),
            steps
        )
        val plot = PmPlotData(
            curves = listOf(
                PmCurve("f($v) = ${PmFormatter.format(body)}", body, v, CURVE_COLORS[1]),
                PmCurve("f'($v) = $ans", simp, v, CURVE_COLORS[0])
            ),
            points = emptyList()
        )
        return PmSolution(true, raw, norm, PmExpr.Deriv(body, v), "Cálculo diferencial (Derivada)", listOf(m), plot)
    }

    private fun solveIntegral(raw: String, norm: String, integral: PmExpr.Integral): PmSolution {
        val v = integral.variable
        val body = integral.body
        val steps = ArrayList<PmStep>()
        val anti = integrateSymbolic(body, v)

        if (integral.lower != null && integral.upper != null) {
            val a = PmEval.evalDouble(integral.lower)
            val b = PmEval.evalDouble(integral.upper)
            if (anti != null) {
                val antiStr = PmFormatter.format(anti)
                steps.add(PmStep(1, "Hallar la primitiva F($v)", "Integramos término a término respecto a $v.", "F($v) = $antiStr", highlightSegment = antiStr))
                val fa = PmEval.evalDouble(anti, mapOf(v to a))
                val fb = PmEval.evalDouble(anti, mapOf(v to b))
                val res = fb - fa
                val resStr = formatDecimal(res, 6)
                steps.add(PmStep(2, "Aplicar la regla de Barrow: F(${PmFormatter.format(integral.upper)}) − F(${PmFormatter.format(integral.lower)})", "Evaluamos la primitiva en los límites superior e inferior.", "${formatDecimal(fb, 4)} - (${formatDecimal(fa, 4)}) = $resStr", highlightSegment = resStr))
                val m = PmMethod("int_def", "Integral definida", "Teorema fundamental del cálculo", resStr, listOf("Primitiva F($v)" to "$antiStr + C"), steps)
                return PmSolution(true, raw, norm, integral, "Integral definida", listOf(m), buildPlotForExpr(body, v))
            }
            // Respaldo numérico Simpson
            val numVal = numericalIntegral(body, v, a, b)
            val ans = formatDecimal(numVal, 6)
            steps.add(PmStep(1, "Integración numérica adaptativa (Simpson)", "Evaluamos el área bajo la curva en [${formatDecimal(a)}, ${formatDecimal(b)}].", ans, highlightSegment = ans))
            return PmSolution(true, raw, norm, integral, "Integral definida", listOf(PmMethod("int_num", "Integración numérica", "Método de Simpson", ans, emptyList(), steps)), buildPlotForExpr(body, v))
        }

        if (anti == null) {
            return PmSolution(false, raw, norm, integral, error = "Esta integral indefinida requiere métodos avanzados. Prueba con límites definidos: int(expr, $v, a, b).")
        }
        val antiStr = "${PmFormatter.format(anti)} + C"
        steps.add(PmStep(1, "Aplicar reglas básicas de integración", "Integramos cada término usando ∫xⁿ dx = xⁿ⁺¹/(n+1) y tablas elementales.", PmFormatter.format(anti)))
        steps.add(PmStep(2, "Añadir la constante de integración C", "Toda familia de primitivas difiere en una constante arbitraria C.", antiStr, highlightSegment = "+ C"))
        val m = PmMethod("int_indef", "Integral indefinida", "Antiderivada simbólica", antiStr, emptyList(), steps)
        return PmSolution(true, raw, norm, integral, "Cálculo integral", listOf(m), buildPlotForExpr(body, v))
    }

    private fun solveLimit(raw: String, norm: String, lim: PmExpr.Limit): PmSolution {
        val v = lim.variable
        val targetD = PmEval.evalDouble(lim.target)
        val steps = ArrayList<PmStep>()
        val targetStr = PmFormatter.format(lim.target)

        // 1) Sustitución directa
        val direct = PmEval.evalDouble(lim.body, mapOf(v to targetD))
        if (direct.isFinite()) {
            val ans = formatDecimal(direct, 6)
            steps.add(PmStep(1, "Sustitución directa ($v = $targetStr)", "La función es continua en $v = $targetStr, así que evaluamos directamente.", ans, highlightSegment = ans))
            return PmSolution(true, raw, norm, lim, "Límite de una función", listOf(PmMethod("lim_dir", "Sustitución directa", "", ans, emptyList(), steps)), buildPlotForExpr(lim.body, v))
        }

        // 2) Indeterminación 0/0 -> Regla de L'Hôpital simbólica
        if (lim.body is PmExpr.Div) {
            val num0 = PmEval.evalDouble(lim.body.num, mapOf(v to targetD))
            val den0 = PmEval.evalDouble(lim.body.den, mapOf(v to targetD))
            if (abs(num0) < 1e-8 && abs(den0) < 1e-8) {
                steps.add(PmStep(1, "Detectar forma indeterminada 0/0", "Al sustituir $v = $targetStr, tanto el numerador como el denominador se anulan.", "0/0 (indeterminación)", highlightSegment = "0/0"))
                val dNum = simplifySymbolic(differentiate(lim.body.num, v, LinkedHashSet()))
                val dDen = simplifySymbolic(differentiate(lim.body.den, v, LinkedHashSet()))
                steps.add(PmStep(2, "Aplicar la Regla de L'Hôpital", "Derivamos numerador y denominador por separado respecto a $v.", "(${PmFormatter.format(dNum)}) / (${PmFormatter.format(dDen)})"))
                val hopVal = PmEval.evalDouble(PmExpr.Div(dNum, dDen), mapOf(v to targetD))
                if (hopVal.isFinite()) {
                    val ans = formatDecimal(hopVal, 6)
                    steps.add(PmStep(3, "Evaluar el nuevo límite en $v = $targetStr", "La indeterminación desaparece.", ans, highlightSegment = ans))
                    return PmSolution(true, raw, norm, lim, "Límite (Regla de L'Hôpital)", listOf(PmMethod("lim_hop", "Regla de L'Hôpital", "Resolución de forma 0/0", ans, emptyList(), steps)), buildPlotForExpr(lim.body, v))
                }
            }
        }

        // 3) Aproximación bilateral numérica
        val eps = 1e-5
        val leftVal = if (targetD.isInfinite()) PmEval.evalDouble(lim.body, mapOf(v to 1e6)) else PmEval.evalDouble(lim.body, mapOf(v to targetD - eps))
        val rightVal = if (targetD.isInfinite()) PmEval.evalDouble(lim.body, mapOf(v to 1e7)) else PmEval.evalDouble(lim.body, mapOf(v to targetD + eps))
        val ans = when {
            leftVal.isFinite() && rightVal.isFinite() && abs(leftVal - rightVal) < 1e-2 -> formatDecimal((leftVal + rightVal) / 2.0, 5)
            else -> "No existe (límites laterales distintos o infinito)"
        }
        steps.add(PmStep(1, "Evaluar límites laterales", "Por izquierda: ${formatDecimal(leftVal, 4)} · Por derecha: ${formatDecimal(rightVal, 4)}.", ans, highlightSegment = ans))
        return PmSolution(true, raw, norm, lim, "Límite de una función", listOf(PmMethod("lim_num", "Límites laterales", "", ans, emptyList(), steps)), buildPlotForExpr(lim.body, v))
    }

    // ==========================================================================
    // UTILIDADES SIMBÓLICAS Y NUMÉRICAS INTERNAS
    // ==========================================================================

    internal fun toRatPoly(expr: PmExpr, v: String): RatPoly? {
        return when (expr) {
            is PmExpr.Num -> RatPoly(v, listOf(expr.rat))
            is PmExpr.Sym -> if (expr.name == v) RatPoly(v, listOf(BigRat.ZERO, BigRat.ONE)) else null
            is PmExpr.Neg -> toRatPoly(expr.inner, v)?.scale(BigRat.NEG_ONE)
            is PmExpr.Add -> {
                val l = toRatPoly(expr.left, v) ?: return null
                val r = toRatPoly(expr.right, v) ?: return null
                l + r
            }
            is PmExpr.Sub -> {
                val l = toRatPoly(expr.left, v) ?: return null
                val r = toRatPoly(expr.right, v) ?: return null
                l - r
            }
            is PmExpr.Mul -> {
                val l = toRatPoly(expr.left, v) ?: return null
                val r = toRatPoly(expr.right, v) ?: return null
                l * r
            }
            is PmExpr.Div -> {
                val l = toRatPoly(expr.num, v) ?: return null
                val r = toRatPoly(expr.den, v) ?: return null
                if (r.degree != 0 || r.coeff(0).isZero) null else l.scale(BigRat.ONE / r.coeff(0))
            }
            is PmExpr.Pow -> {
                val base = toRatPoly(expr.base, v) ?: return null
                val exp = toRatPoly(expr.exp, v) ?: return null
                if (exp.degree != 0 || !exp.coeff(0).isInt) return null
                val n = exp.coeff(0).num.toInt()
                if (n < 0 || n > 6) return null
                var acc = RatPoly(v, listOf(BigRat.ONE))
                repeat(n) { acc *= base }
                acc
            }
            else -> null
        }
    }

    private fun toRatLinearForm(expr: PmExpr, vars: List<String>): RatLinearForm? {
        val n = vars.size
        fun combine(a: RatLinearForm, b: RatLinearForm, sign: BigRat): RatLinearForm =
            RatLinearForm(List(n) { i -> a.coeffs[i] + sign * b.coeffs[i] }, a.constant + sign * b.constant)

        return when (expr) {
            is PmExpr.Num -> RatLinearForm(List(n) { BigRat.ZERO }, expr.rat)
            is PmExpr.Sym -> {
                val idx = vars.indexOf(expr.name)
                if (idx < 0) return null
                RatLinearForm(List(n) { if (it == idx) BigRat.ONE else BigRat.ZERO }, BigRat.ZERO)
            }
            is PmExpr.Neg -> {
                val inner = toRatLinearForm(expr.inner, vars) ?: return null
                RatLinearForm(inner.coeffs.map { -it }, -inner.constant)
            }
            is PmExpr.Add -> {
                val l = toRatLinearForm(expr.left, vars) ?: return null
                val r = toRatLinearForm(expr.right, vars) ?: return null
                combine(l, r, BigRat.ONE)
            }
            is PmExpr.Sub -> {
                val l = toRatLinearForm(expr.left, vars) ?: return null
                val r = toRatLinearForm(expr.right, vars) ?: return null
                combine(l, r, BigRat.NEG_ONE)
            }
            is PmExpr.Mul -> {
                val l = toRatLinearForm(expr.left, vars) ?: return null
                val r = toRatLinearForm(expr.right, vars) ?: return null
                val lConst = l.coeffs.all { it.isZero }
                val rConst = r.coeffs.all { it.isZero }
                when {
                    lConst -> RatLinearForm(r.coeffs.map { it * l.constant }, r.constant * l.constant)
                    rConst -> RatLinearForm(l.coeffs.map { it * r.constant }, l.constant * r.constant)
                    else -> null
                }
            }
            is PmExpr.Div -> {
                val l = toRatLinearForm(expr.num, vars) ?: return null
                val r = toRatLinearForm(expr.den, vars) ?: return null
                if (r.coeffs.all { it.isZero } && !r.constant.isZero) {
                    RatLinearForm(l.coeffs.map { it / r.constant }, l.constant / r.constant)
                } else null
            }
            else -> null
        }
    }

    private fun exactDeterminant(m: Array<Array<BigRat>>): BigRat {
        return when (m.size) {
            1 -> m[0][0]
            2 -> m[0][0] * m[1][1] - m[0][1] * m[1][0]
            3 -> {
                val a = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                val b = m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                val c = m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
                a - b + c
            }
            else -> BigRat.ZERO
        }
    }

    private fun factorRatPoly(poly: RatPoly): String? {
        val v = poly.variable
        if (poly.degree < 2) return null
        if (poly.degree == 2) {
            val a = poly.coeff(2); val b = poly.coeff(1); val c = poly.coeff(0)
            val disc = b * b - BigRat.of(4) * a * c
            if (disc.isNegative) return null
            val sn = ExactMath.simplifySqrt(disc.num)
            val sd = ExactMath.simplifySqrt(disc.den)
            if (!sn.isExactInt || !sd.isExactInt) return null
            val sq = BigRat.of(sn.outside, sd.outside)
            val r1 = (-b - sq) / (BigRat.TWO * a)
            val r2 = (-b + sq) / (BigRat.TWO * a)
            val lead = when {
                a.isOne -> ""
                a.isNegOne -> "-"
                else -> a.toString()
            }
            fun fac(r: BigRat): String = when {
                r.isZero -> v
                r.isPositive -> "($v - $r)"
                else -> "($v + ${r.abs()})"
            }
            return if (r1 == r2) {
                val f = fac(r1)
                if (f == v) "$lead$v^2" else "$lead$f^2"
            } else {
                "$lead${fac(r1)}${fac(r2)}"
            }
        }
        // Grado 3: factorización vía Ruffini si hay raíz racional
        if (poly.degree == 3) {
            val r = findRationalRoot(poly) ?: return null
            val q = divideByLinear(poly, r)
            val qFac = factorRatPoly(q) ?: "(${q.format()})"
            val linFac = when {
                r.isZero -> v
                r.isPositive -> "($v - $r)"
                else -> "($v + ${r.abs()})"
            }
            return "$linFac$qFac"
        }
        return null
    }

    private fun buildFactoringSteps(poly: RatPoly, factored: String): List<PmStep> {
        val v = poly.variable
        val steps = ArrayList<PmStep>()
        steps.add(PmStep(1, "Polinomio original", "Ordenamos por potencias descendentes de $v.", poly.format()))
        if (poly.degree == 2 && poly.coeff(1).isZero && poly.coeff(2).isPositive && poly.coeff(0).isNegative) {
            steps.add(PmStep(2, "Reconocer diferencia de cuadrados a² − b²", "Aplicamos la identidad a² − b² = (a − b)(a + b).", factored, highlightSegment = factored))
        } else {
            steps.add(PmStep(2, "Hallar factores lineales", "Descomponemos el polinomio en factores irreducibles sobre ℚ.", factored, highlightSegment = factored))
        }
        return steps
    }

    private fun findRationalRoot(poly: RatPoly): BigRat? {
        // Multiplicar por mcm de denominadores para obtener coeficientes enteros
        var lcm = BigInteger.ONE
        for (c in poly.coeffs) lcm = ExactMath.lcm(lcm, c.den)
        val intCoeffs = poly.coeffs.map { it.num * (lcm / it.den) }
        val c0 = intCoeffs.firstOrNull()?.abs() ?: return null
        val cn = intCoeffs[poly.degree].abs()
        if (c0 == BigInteger.ZERO) return BigRat.ZERO
        val pDivs = ExactMath.divisorsOf(c0, 32)
        val qDivs = ExactMath.divisorsOf(cn, 16)
        for (p in pDivs) {
            for (q in qDivs) {
                val candPos = BigRat.of(p, q)
                if (poly.eval(candPos).isZero) return candPos
                val candNeg = -candPos
                if (poly.eval(candNeg).isZero) return candNeg
            }
        }
        return null
    }

    private fun divideByLinear(poly: RatPoly, root: BigRat): RatPoly {
        val deg = poly.degree
        val out = MutableList(deg) { BigRat.ZERO }
        var carry = poly.coeff(deg)
        out[deg - 1] = carry
        for (k in (deg - 1) downTo 1) {
            carry = poly.coeff(k) + carry * root
            out[k - 1] = carry
        }
        return RatPoly(poly.variable, out)
    }

    internal fun simplifySymbolic(expr: PmExpr): PmExpr {
        var cur = expr
        repeat(5) {
            val next = simplifyStep(cur)
            if (next == cur) return next
            cur = next
        }
        return cur
    }

    private fun simplifyStep(e: PmExpr): PmExpr {
        return when (e) {
            is PmExpr.Num, is PmExpr.Sym, is PmExpr.Const -> e
            is PmExpr.Neg -> {
                val inner = simplifyStep(e.inner)
                when (inner) {
                    is PmExpr.Num -> PmExpr.Num(-inner.rat)
                    is PmExpr.Neg -> inner.inner
                    else -> PmExpr.Neg(inner)
                }
            }
            is PmExpr.Add -> {
                val l = simplifyStep(e.left); val r = simplifyStep(e.right)
                when {
                    l is PmExpr.Num && r is PmExpr.Num -> PmExpr.Num(l.rat + r.rat)
                    l is PmExpr.Num && l.rat.isZero -> r
                    r is PmExpr.Num && r.rat.isZero -> l
                    l == r -> PmExpr.Mul(PmExpr.int(2), l)
                    else -> PmExpr.Add(l, r)
                }
            }
            is PmExpr.Sub -> {
                val l = simplifyStep(e.left); val r = simplifyStep(e.right)
                when {
                    l is PmExpr.Num && r is PmExpr.Num -> PmExpr.Num(l.rat - r.rat)
                    r is PmExpr.Num && r.rat.isZero -> l
                    l is PmExpr.Num && l.rat.isZero -> simplifyStep(PmExpr.Neg(r))
                    l == r -> PmExpr.int(0)
                    else -> PmExpr.Sub(l, r)
                }
            }
            is PmExpr.Mul -> {
                val l = simplifyStep(e.left); val r = simplifyStep(e.right)
                when {
                    l is PmExpr.Num && r is PmExpr.Num -> PmExpr.Num(l.rat * r.rat)
                    (l is PmExpr.Num && l.rat.isZero) || (r is PmExpr.Num && r.rat.isZero) -> PmExpr.int(0)
                    l is PmExpr.Num && l.rat.isOne -> r
                    r is PmExpr.Num && r.rat.isOne -> l
                    l is PmExpr.Num && l.rat.isNegOne -> simplifyStep(PmExpr.Neg(r))
                    r is PmExpr.Num && r.rat.isNegOne -> simplifyStep(PmExpr.Neg(l))
                    r is PmExpr.Num && l !is PmExpr.Num -> PmExpr.Mul(r, l)
                    l is PmExpr.Num && r is PmExpr.Mul && r.left is PmExpr.Num ->
                        PmExpr.Mul(PmExpr.Num(l.rat * r.left.rat), r.right)
                    else -> PmExpr.Mul(l, r)
                }
            }
            is PmExpr.Div -> {
                val l = simplifyStep(e.num); val r = simplifyStep(e.den)
                when {
                    l is PmExpr.Num && r is PmExpr.Num && !r.rat.isZero -> PmExpr.Num(l.rat / r.rat)
                    l is PmExpr.Num && l.rat.isZero -> PmExpr.int(0)
                    r is PmExpr.Num && r.rat.isOne -> l
                    l == r -> PmExpr.int(1)
                    else -> PmExpr.Div(l, r)
                }
            }
            is PmExpr.Pow -> {
                val b = simplifyStep(e.base); val p = simplifyStep(e.exp)
                when {
                    p is PmExpr.Num && p.rat.isZero -> PmExpr.int(1)
                    p is PmExpr.Num && p.rat.isOne -> b
                    b is PmExpr.Num && b.rat.isZero -> PmExpr.int(0)
                    b is PmExpr.Num && b.rat.isOne -> PmExpr.int(1)
                    b is PmExpr.Num && p is PmExpr.Num && p.rat.isInt && p.rat.num.toInt() in -8..8 ->
                        PmExpr.Num(b.rat.pow(p.rat.num.toInt()))
                    else -> PmExpr.Pow(b, p)
                }
            }
            is PmExpr.Root -> PmExpr.Root(simplifyStep(e.radicand), e.index?.let(::simplifyStep))
            is PmExpr.Abs -> PmExpr.Abs(simplifyStep(e.inner))
            is PmExpr.Func -> PmExpr.Func(e.name, e.args.map(::simplifyStep))
            else -> e
        }
    }

    private fun differentiate(e: PmExpr, v: String, rules: MutableSet<String>): PmExpr {
        return when (e) {
            is PmExpr.Num, is PmExpr.Const -> { rules.add("Derivada de una constante: (c)' = 0"); PmExpr.int(0) }
            is PmExpr.Sym -> if (e.name == v) { rules.add("Derivada de $v: ($v)' = 1"); PmExpr.int(1) } else PmExpr.int(0)
            is PmExpr.Neg -> PmExpr.Neg(differentiate(e.inner, v, rules))
            is PmExpr.Add -> { rules.add("Regla de la suma: (u + w)' = u' + w'"); PmExpr.Add(differentiate(e.left, v, rules), differentiate(e.right, v, rules)) }
            is PmExpr.Sub -> { rules.add("Regla de la resta: (u − w)' = u' − w'"); PmExpr.Sub(differentiate(e.left, v, rules), differentiate(e.right, v, rules)) }
            is PmExpr.Mul -> {
                val lDep = v in PmParser.collectVars(e.left)
                val rDep = v in PmParser.collectVars(e.right)
                when {
                    !lDep -> { rules.add("Factor constante: (c·u)' = c·u'"); PmExpr.Mul(e.left, differentiate(e.right, v, rules)) }
                    !rDep -> { rules.add("Factor constante: (u·c)' = c·u'"); PmExpr.Mul(e.right, differentiate(e.left, v, rules)) }
                    else -> {
                        rules.add("Regla del producto: (u·w)' = u'·w + u·w'")
                        PmExpr.Add(PmExpr.Mul(differentiate(e.left, v, rules), e.right), PmExpr.Mul(e.left, differentiate(e.right, v, rules)))
                    }
                }
            }
            is PmExpr.Div -> {
                if (v !in PmParser.collectVars(e.den)) {
                    rules.add("División por constante: (u/c)' = u'/c")
                    PmExpr.Div(differentiate(e.num, v, rules), e.den)
                } else {
                    rules.add("Regla del cociente: (u/w)' = (u'·w − u·w') / w²")
                    PmExpr.Div(
                        PmExpr.Sub(PmExpr.Mul(differentiate(e.num, v, rules), e.den), PmExpr.Mul(e.num, differentiate(e.den, v, rules))),
                        PmExpr.Pow(e.den, PmExpr.int(2))
                    )
                }
            }
            is PmExpr.Pow -> {
                val bDep = v in PmParser.collectVars(e.base)
                val pDep = v in PmParser.collectVars(e.exp)
                when {
                    bDep && !pDep -> {
                        rules.add("Regla de la potencia y cadena: (uⁿ)' = n·uⁿ⁻¹·u'")
                        val nMinus1 = simplifySymbolic(PmExpr.Sub(e.exp, PmExpr.int(1)))
                        PmExpr.Mul(PmExpr.Mul(e.exp, PmExpr.Pow(e.base, nMinus1)), differentiate(e.base, v, rules))
                    }
                    !bDep && pDep -> {
                        rules.add("Derivada exponencial: (aᵘ)' = aᵘ·ln(a)·u'")
                        val lnA = if (e.base is PmExpr.Const && e.base.name == "e") PmExpr.int(1) else PmExpr.Func("ln", listOf(e.base))
                        PmExpr.Mul(PmExpr.Mul(e, lnA), differentiate(e.exp, v, rules))
                    }
                    else -> PmExpr.int(0)
                }
            }
            is PmExpr.Root -> {
                rules.add("Derivada de raíz cuadrada: (√u)' = u' / (2√u)")
                PmExpr.Div(differentiate(e.radicand, v, rules), PmExpr.Mul(PmExpr.int(2), PmExpr.Root(e.radicand)))
            }
            is PmExpr.Func -> if (e.args.size == 1) {
                val u = e.args[0]
                val du = differentiate(u, v, rules)
                val outer: PmExpr = when (e.name) {
                    "sin" -> { rules.add("(sin u)' = cos(u)·u'"); PmExpr.Func("cos", listOf(u)) }
                    "cos" -> { rules.add("(cos u)' = −sin(u)·u'"); PmExpr.Neg(PmExpr.Func("sin", listOf(u))) }
                    "tan" -> { rules.add("(tan u)' = u' / cos²(u)"); PmExpr.Div(PmExpr.int(1), PmExpr.Pow(PmExpr.Func("cos", listOf(u)), PmExpr.int(2))) }
                    "ln" -> { rules.add("(ln u)' = u' / u"); PmExpr.Div(PmExpr.int(1), u) }
                    "log10" -> { rules.add("(log₁₀ u)' = u' / (u·ln(10))"); PmExpr.Div(PmExpr.int(1), PmExpr.Mul(u, PmExpr.Func("ln", listOf(PmExpr.int(10))))) }
                    "exp" -> { rules.add("(eᵘ)' = eᵘ·u'"); PmExpr.Func("exp", listOf(u)) }
                    else -> PmExpr.int(0)
                }
                PmExpr.Mul(outer, du)
            } else PmExpr.int(0)
            else -> PmExpr.int(0)
        }
    }

    private fun integrateSymbolic(e: PmExpr, v: String): PmExpr? {
        // Caso polinomio exacto (cubre cualquier combinación lineal de potencias)
        val poly = toRatPoly(e, v)
        if (poly != null) {
            val outCoeffs = MutableList(poly.degree + 2) { BigRat.ZERO }
            for (k in 0..poly.degree) {
                val c = poly.coeff(k)
                if (!c.isZero) outCoeffs[k + 1] = c / BigRat.of((k + 1).toLong())
            }
            return RatPoly(v, outCoeffs).toExpr()
        }
        return when (e) {
            is PmExpr.Add -> {
                val l = integrateSymbolic(e.left, v) ?: return null
                val r = integrateSymbolic(e.right, v) ?: return null
                simplifySymbolic(PmExpr.Add(l, r))
            }
            is PmExpr.Sub -> {
                val l = integrateSymbolic(e.left, v) ?: return null
                val r = integrateSymbolic(e.right, v) ?: return null
                simplifySymbolic(PmExpr.Sub(l, r))
            }
            is PmExpr.Neg -> integrateSymbolic(e.inner, v)?.let { simplifySymbolic(PmExpr.Neg(it)) }
            is PmExpr.Mul -> {
                if (v !in PmParser.collectVars(e.left)) {
                    integrateSymbolic(e.right, v)?.let { simplifySymbolic(PmExpr.Mul(e.left, it)) }
                } else if (v !in PmParser.collectVars(e.right)) {
                    integrateSymbolic(e.left, v)?.let { simplifySymbolic(PmExpr.Mul(e.right, it)) }
                } else null
            }
            is PmExpr.Div -> {
                if (e.num is PmExpr.Num && e.den is PmExpr.Sym && e.den.name == v) {
                    simplifySymbolic(PmExpr.Mul(e.num, PmExpr.Func("ln", listOf(PmExpr.Abs(PmExpr.Sym(v))))))
                } else null
            }
            is PmExpr.Func -> if (e.args.size == 1 && e.args[0] is PmExpr.Sym && (e.args[0] as PmExpr.Sym).name == v) {
                when (e.name) {
                    "sin" -> PmExpr.Neg(PmExpr.Func("cos", listOf(PmExpr.Sym(v))))
                    "cos" -> PmExpr.Func("sin", listOf(PmExpr.Sym(v)))
                    "exp" -> PmExpr.Func("exp", listOf(PmExpr.Sym(v)))
                    else -> null
                }
            } else null
            is PmExpr.Pow -> {
                if (e.base is PmExpr.Const && e.base.name == "e" && e.exp is PmExpr.Sym && e.exp.name == v) e
                else null
            }
            else -> null
        }
    }

    private fun numericalIntegral(expr: PmExpr, v: String, a: Double, b: Double): Double {
        if (!a.isFinite() || !b.isFinite()) return Double.NaN
        if (abs(b - a) < 1e-12) return 0.0
        val sign = if (b < a) -1.0 else 1.0
        val lo = minOf(a, b); val hi = maxOf(a, b)
        val fn = UnivariateFunction { t -> PmEval.evalDouble(expr, mapOf(v to t)) }
        return try {
            sign * SimpsonIntegrator().integrate(2000, fn, lo, hi)
        } catch (_: Exception) {
            val n = 400; val h = (hi - lo) / n
            var sum = fn.value(lo) + fn.value(hi)
            for (i in 1 until n) {
                val y = fn.value(lo + i * h)
                if (!y.isFinite()) return Double.NaN
                sum += if (i % 2 == 0) 2.0 * y else 4.0 * y
            }
            sign * sum * h / 3.0
        }
    }

    internal fun findNumericalRoots(expr: PmExpr, v: String, minX: Double = -50.0, maxX: Double = 50.0, steps: Int = 500): List<Double> {
        val fn = UnivariateFunction { t -> PmEval.evalDouble(expr, mapOf(v to t)) }
        val solver = BrentSolver(1e-10, 1e-12)
        val roots = ArrayList<Double>()
        val dx = (maxX - minX) / steps
        var px = minX
        var py = fn.value(px)

        fun addUnique(r: Double) {
            if (!r.isFinite()) return
            val c = if (abs(r) < 1e-9) 0.0 else r
            if (roots.none { abs(it - c) < 1e-4 }) roots.add(c)
        }

        if (py.isFinite() && abs(py) < 1e-9) addUnique(px)
        for (i in 1..steps) {
            val cx = minX + i * dx
            val cy = fn.value(cx)
            if (py.isFinite() && cy.isFinite()) {
                if (abs(cy) < 1e-9) addUnique(cx)
                else if (py * cy < 0.0) {
                    try {
                        val root = solver.solve(100, fn, px, cx)
                        if (abs(fn.value(root)) < 1e-5) addUnique(root)
                    } catch (_: Exception) { }
                }
            }
            px = cx; py = cy
        }
        return roots.sorted()
    }

    internal fun buildPlotForExpr(expr: PmExpr, v: String, extraPoints: List<PmPlotPoint> = emptyList()): PmPlotData {
        val pts = ArrayList<PmPlotPoint>(extraPoints)
        val y0 = PmEval.evalDouble(expr, mapOf(v to 0.0))
        if (y0.isFinite() && pts.none { abs(it.x) < 1e-4 && abs(it.y - y0) < 1e-4 }) {
            pts.add(PmPlotPoint(0.0, y0, "Corte Y (0, ${formatDecimal(y0, 3)})", "yintercept"))
        }
        if (extraPoints.none { it.kind == "root" }) {
            findNumericalRoots(expr, v, -15.0, 15.0, 300).take(5).forEach { r ->
                pts.add(PmPlotPoint(r, 0.0, "Raíz (${formatDecimal(r, 3)}, 0)", "root"))
            }
        }
        var xMin = -8.0; var xMax = 8.0; var yMin = -8.0; var yMax = 8.0
        if (pts.isNotEmpty()) {
            val xs = pts.map { it.x }
            val ys = pts.map { it.y }
            val cx = (xs.min() + xs.max()) / 2.0
            val cy = (ys.min() + ys.max()) / 2.0
            val spanX = maxOf(10.0, (xs.max() - xs.min()) * 1.8 + 4.0)
            val spanY = maxOf(10.0, (ys.max() - ys.min()) * 1.8 + 4.0)
            xMin = cx - spanX / 2.0; xMax = cx + spanX / 2.0
            yMin = cy - spanY / 2.0; yMax = cy + spanY / 2.0
        }
        return PmPlotData(
            curves = listOf(PmCurve("f($v) = ${PmFormatter.format(expr)}", expr, v, CURVE_COLORS[0])),
            points = pts,
            xMin = xMin, xMax = xMax, yMin = yMin, yMax = yMax
        )
    }

    private fun containsImaginary(e: PmExpr): Boolean = when (e) {
        is PmExpr.Const -> e.name == "i"
        is PmExpr.Neg -> containsImaginary(e.inner)
        is PmExpr.Add -> containsImaginary(e.left) || containsImaginary(e.right)
        is PmExpr.Sub -> containsImaginary(e.left) || containsImaginary(e.right)
        is PmExpr.Mul -> containsImaginary(e.left) || containsImaginary(e.right)
        is PmExpr.Div -> containsImaginary(e.num) || containsImaginary(e.den)
        is PmExpr.Pow -> containsImaginary(e.base) || containsImaginary(e.exp)
        is PmExpr.Root -> containsImaginary(e.radicand)
        is PmExpr.Abs -> containsImaginary(e.inner)
        is PmExpr.Func -> e.args.any(::containsImaginary)
        else -> false
    }

    private fun buildRatAltForms(r: BigRat): List<Pair<String, String>> = buildList {
        if (!r.isInt) {
            add("Forma decimal" to "≈ ${r.toDecimalString()}")
            if (r.num.abs() > r.den) {
                val whole = r.num / r.den
                val rem = r.num.abs() % r.den
                if (rem != BigInteger.ZERO) add("Número mixto" to "$whole ${rem}/${r.den}")
            }
        }
    }

    private fun formatCoeffVar(c: BigRat, v: String): String = when {
        c.isOne -> v
        c.isNegOne -> "-$v"
        else -> "$c$v"
    }

    private fun formatLinearRHS(cst: BigRat, coef: BigRat, v: String): String = when {
        coef.isZero -> cst.toString()
        cst.isZero -> formatCoeffVar(coef, v)
        coef.isPositive -> "$cst + ${formatCoeffVar(coef, v)}"
        else -> "$cst - ${formatCoeffVar(coef.abs(), v)}"
    }

    private fun prettyRel(op: String): String = when (op) {
        "<=" -> "≤"
        ">=" -> "≥"
        else -> op
    }

    private fun flipRel(op: String): String = when (op) {
        "<" -> ">"
        "<=" -> ">="
        ">" -> "<"
        ">=" -> "<="
        else -> op
    }

    private fun formatInterval(bound: BigRat, op: String): String = when (op) {
        "<" -> "(-∞, $bound)"
        "<=" -> "(-∞, $bound]"
        ">" -> "($bound, +∞)"
        else -> "[$bound, +∞)"
    }

    private fun subscript(n: Int): String = when (n) {
        1 -> "₁"; 2 -> "₂"; 3 -> "₃"; 4 -> "₄"; 5 -> "₅"; else -> n.toString()
    }

    // ==========================================================================
    // EXTENSIONES PREUNIVERSITARIAS EN EL MOTOR PRINCIPAL:
    // Combinatoria directa, Ecuaciones fraccionarias/trigonométricas e Inecuaciones racionales/|x|
    // ==========================================================================

    private fun solveDirectCombinatorics(raw: String, norm: String, fn: PmExpr.Func): PmSolution? {
        val steps = ArrayList<PmStep>()
        when (fn.name) {
            "perm" -> {
                if (fn.args.size != 1) return null
                val nR = PmEval.evalExactRational(fn.args[0]) ?: return null
                if (!nR.isInt || nR.isNegative || nR.num > BigInteger.valueOf(60L)) return null
                val n = nR.num.toInt()
                val res = ExactMath.factorial(n)
                steps.add(PmStep(1, "Fórmula de permutaciones sin repetición", "Pₙ = n! cuenta todas las ordenaciones posibles de $n elementos distintos.", "P($n) = $n!"))
                steps.add(PmStep(2, "Calcular el factorial", if (n <= 7) (n downTo 1).joinToString(" · ") else "Multiplicamos los enteros desde 1 hasta $n.", res.toString(), highlightSegment = res.toString()))
                return PmSolution(true, raw, norm, fn, "Combinatoria · Permutaciones", listOf(PmMethod("comb_p", "Permutación P($n)", "", res.toString(), emptyList(), steps)))
            }
            "var" -> {
                if (fn.args.size != 2) return null
                val nR = PmEval.evalExactRational(fn.args[0]) ?: return null
                val kR = PmEval.evalExactRational(fn.args[1]) ?: return null
                if (!nR.isInt || !kR.isInt || kR.isNegative || kR.num > nR.num || nR.num > BigInteger.valueOf(80L)) return null
                val n = nR.num.toInt(); val k = kR.num.toInt()
                val res = ExactMath.variation(n, k)
                steps.add(PmStep(1, "Fórmula de variaciones sin repetición", "Importa el orden y no se repiten elementos: V(n,k) = n! / (n − k)!.", "V($n, $k) = $n! / (${n - k})!"))
                steps.add(PmStep(2, "Simplificar factoriales y multiplicar", "Quedan $k factores descendentes a partir de $n.", res.toString(), highlightSegment = res.toString()))
                return PmSolution(true, raw, norm, fn, "Combinatoria · Variaciones", listOf(PmMethod("comb_v", "Variación V($n,$k)", "", res.toString(), emptyList(), steps)))
            }
            "varrep" -> {
                if (fn.args.size != 2) return null
                val nR = PmEval.evalExactRational(fn.args[0]) ?: return null
                val kR = PmEval.evalExactRational(fn.args[1]) ?: return null
                if (!nR.isInt || !kR.isInt || nR.isNegative || kR.isNegative || kR.num > BigInteger.valueOf(40L)) return null
                val n = nR.num; val k = kR.num.toInt()
                val res = n.pow(k)
                steps.add(PmStep(1, "Fórmula de variaciones con repetición", "Importa el orden y se pueden repetir elementos: VR(n,k) = n^k.", "VR($n, $k) = $n^$k"))
                steps.add(PmStep(2, "Calcular la potencia", "Elevamos $n a la potencia $k.", res.toString(), highlightSegment = res.toString()))
                return PmSolution(true, raw, norm, fn, "Combinatoria · Variaciones con repetición", listOf(PmMethod("comb_vr", "Variación con repetición", "", res.toString(), emptyList(), steps)))
            }
            "comb" -> {
                if (fn.args.size != 2) return null
                val nR = PmEval.evalExactRational(fn.args[0]) ?: return null
                val kR = PmEval.evalExactRational(fn.args[1]) ?: return null
                if (!nR.isInt || !kR.isInt || kR.isNegative || kR.num > nR.num || nR.num > BigInteger.valueOf(100L)) return null
                val n = nR.num.toInt(); val k = kR.num.toInt()
                val res = ExactMath.comb(n, k)
                steps.add(PmStep(1, "Fórmula de combinaciones sin repetición", "No importa el orden: C(n,k) = n! / (k! · (n − k)!).", "C($n, $k) = $n! / ($k! · ${n - k}!)"))
                steps.add(PmStep(2, "Simplificar y calcular", "Dividimos V($n, $k) entre $k!.", res.toString(), highlightSegment = res.toString()))
                return PmSolution(true, raw, norm, fn, "Combinatoria · Combinaciones", listOf(PmMethod("comb_c", "Combinación C($n,$k)", "", res.toString(), emptyList(), steps)))
            }
            "combrep" -> {
                if (fn.args.size != 2) return null
                val nR = PmEval.evalExactRational(fn.args[0]) ?: return null
                val kR = PmEval.evalExactRational(fn.args[1]) ?: return null
                if (!nR.isInt || !kR.isInt || nR.num < BigInteger.ONE || kR.isNegative || (nR.num.toInt() + kR.num.toInt()) > 100) return null
                val n = nR.num.toInt(); val k = kR.num.toInt()
                val res = ExactMath.comb(n + k - 1, k)
                steps.add(PmStep(1, "Fórmula de combinaciones con repetición", "CR(n,k) = C(n + k − 1, k).", "CR($n, $k) = C(${n + k - 1}, $k)"))
                steps.add(PmStep(2, "Evaluar coeficiente binomial", "Calculamos (${n + k - 1})! / ($k! · ${n - 1}!).", res.toString(), highlightSegment = res.toString()))
                return PmSolution(true, raw, norm, fn, "Combinatoria · Combinaciones con repetición", listOf(PmMethod("comb_cr", "Combinación con repetición", "", res.toString(), emptyList(), steps)))
            }
            else -> return null
        }
    }

    private fun trySolveFractionalEquation(raw: String, norm: String, eq: PmExpr.Rel, left: PmExpr, right: PmExpr, v: String): PmSolution? {
        val rf1 = toRatFunc(left, v) ?: return null
        val rf2 = toRatFunc(right, v) ?: return null
        val p1 = rf1.num; val q1 = rf1.den
        val p2 = rf2.num; val q2 = rf2.den
        if (q1.degree == 0 && q2.degree == 0) return null

        val steps = ArrayList<PmStep>()
        val forbidden = ArrayList<Double>()
        if (q1.degree >= 1) forbidden.addAll(findNumericalRoots(q1.toExpr(), v, -50.0, 50.0, 300))
        if (q2.degree >= 1) forbidden.addAll(findNumericalRoots(q2.toExpr(), v, -50.0, 50.0, 300))
        val uniqueForbidden = forbidden.distinctBy { formatDecimal(it, 4) }

        steps.add(
            PmStep(
                1,
                "Determinar el dominio de definición (denominadores ≠ 0)",
                if (uniqueForbidden.isEmpty()) "Los denominadores nunca se anulan en ℝ."
                else "Excluimos los valores que anulan algún denominador: ${uniqueForbidden.joinToString(", ") { "$v ≠ ${formatDecimal(it, 4)}" }}.",
                if (uniqueForbidden.isEmpty()) "$v ∈ ℝ" else uniqueForbidden.joinToString(", ") { "$v ≠ ${formatDecimal(it, 4)}" }
            )
        )

        val crossPoly = (p1 * q2) - (p2 * q1)
        val crossEq = PmExpr.Rel("=", (p1 * q2).toExpr(), (p2 * q1).toExpr())
        steps.add(PmStep(2, "Multiplicar en cruz para eliminar denominadores", "Multiplicamos ambos miembros por el producto de los denominadores.", PmFormatter.format(crossEq)))

        val subSol = solveEquation(raw, norm, crossEq, listOf(v))
        val candRoots = subSol.plot?.points?.filter { it.kind == "root" }?.map { it.x }.orEmpty()
        val valid = candRoots.filter { r -> uniqueForbidden.none { f -> abs(r - f) < 1e-4 } }
        val rejected = candRoots.filter { r -> uniqueForbidden.any { f -> abs(r - f) < 1e-4 } }

        val finalAns = when {
            rejected.isEmpty() && subSol.methods.isNotEmpty() -> subSol.methods.first().finalAnswer
            valid.isEmpty() -> "Sin solución real (todas las candidatas anulan el denominador)"
            else -> valid.joinToString(",  ") { "$v = ${formatDecimal(it, 4)}" }
        }
        steps.add(
            PmStep(
                3,
                "Resolver y comprobar restricciones del dominio",
                if (rejected.isEmpty()) "Todas las soluciones pertenecen al dominio de la ecuación."
                else "Descartamos ${rejected.joinToString(", ") { formatDecimal(it, 4) }} por anular el denominador.",
                finalAns,
                highlightSegment = finalAns
            )
        )
        val plot = buildPlotForExpr(PmExpr.Sub(left, right), v, valid.map { PmPlotPoint(it, 0.0, "Raíz (${formatDecimal(it, 3)}, 0)", "root") })
        return PmSolution(true, raw, norm, eq, "Ecuación fraccionaria", listOf(PmMethod("eq_frac", "Eliminar denominadores y verificar dominio", "", finalAns, emptyList(), steps)), plot)
    }

    private fun trySolveTrigEquation(raw: String, norm: String, eq: PmExpr.Rel, fn: PmExpr.Func, other: PmExpr, v: String): PmSolution? {
        if (fn.args.size != 1) return null
        val rhs = PmEval.evalDouble(other)
        if (!rhs.isFinite()) return null
        val argPoly = toRatPoly(fn.args[0], v) ?: return null
        if (argPoly.degree != 1) return null

        val a = argPoly.coeff(1).toDouble()
        val b = argPoly.coeff(0).toDouble()
        val steps = ArrayList<PmStep>()
        val argStr = PmFormatter.format(fn.args[0])

        if ((fn.name == "sin" || fn.name == "cos") && abs(rhs) > 1.0 + 1e-9) {
            steps.add(PmStep(1, "Verificar el recorrido de ${fn.name}", "Como -1 ≤ ${fn.name}($argStr) ≤ 1 y ${formatDecimal(rhs)} está fuera de [-1, 1], no existen soluciones reales.", "Sin solución real ($v ∈ ∅)", highlightSegment = "Sin solución real"))
            return PmSolution(true, raw, norm, eq, "Ecuación trigonométrica", listOf(PmMethod("trig_none", "Análisis de recorrido", "", "Sin solución real", emptyList(), steps)))
        }

        val twoPi = 2.0 * Math.PI
        val (base1, base2, period, ruleDesc) = when (fn.name) {
            "sin" -> {
                val a1 = kotlin.math.asin(rhs.coerceIn(-1.0, 1.0))
                val a2 = Math.PI - a1
                Quadruple(a1, a2, twoPi, "sin(u) = c  ⇒  u = arcsin(c) + 2kπ  o  u = π − arcsin(c) + 2kπ")
            }
            "cos" -> {
                val a1 = kotlin.math.acos(rhs.coerceIn(-1.0, 1.0))
                val a2 = -a1
                Quadruple(a1, a2, twoPi, "cos(u) = c  ⇒  u = ±arccos(c) + 2kπ")
            }
            else -> {
                val a1 = kotlin.math.atan(rhs)
                Quadruple(a1, Double.NaN, Math.PI, "tan(u) = c  ⇒  u = arctan(c) + kπ")
            }
        }

        val x1 = (base1 - b) / a
        val stepP = abs(period / a)
        val deg1 = Math.toDegrees(x1)
        steps.add(PmStep(1, "Aplicar la función trigonométrica inversa", ruleDesc, "$argStr = ${formatDecimal(base1, 4)} rad (${formatDecimal(Math.toDegrees(base1), 1)}°)"))

        val inPeriod = ArrayList<Double>()
        fun collectIn0To2Pi(seed: Double) {
            if (!seed.isFinite()) return
            for (k in -6..6) {
                val cand = seed + k * stepP
                if (cand >= -1e-6 && cand <= twoPi + 1e-6) {
                    val normC = if (abs(cand) < 1e-6) 0.0 else cand
                    if (inPeriod.none { abs(it - normC) < 1e-4 }) inPeriod.add(normC)
                }
            }
        }
        collectIn0To2Pi(x1)
        if (base2.isFinite()) collectIn0To2Pi((base2 - b) / a)
        inPeriod.sort()

        val generalText = if (base2.isFinite() && abs(base1 - base2) > 1e-6) {
            val x2 = (base2 - b) / a
            "$v₁ = ${formatDecimal(x1, 4)} + ${formatDecimal(stepP, 4)}k ;  $v₂ = ${formatDecimal(x2, 4)} + ${formatDecimal(stepP, 4)}k  (k ∈ ℤ)"
        } else {
            "$v = ${formatDecimal(x1, 4)} + ${formatDecimal(stepP, 4)}k  (k ∈ ℤ)"
        }

        steps.add(PmStep(2, "Despejar $v (solución general)", "Dividimos entre el coeficiente de $v y conservamos el período k ∈ ℤ.", generalText, highlightSegment = formatDecimal(x1, 4)))
        val in02PiStr = inPeriod.joinToString(",  ") { "${formatDecimal(it, 3)} rad (${formatDecimal(Math.toDegrees(it), 1)}°)" }
        steps.add(PmStep(3, "Soluciones principales en [0, 2π]", "Evaluamos valores enteros de k dentro de una vuelta completa.", in02PiStr.ifBlank { generalText }, highlightSegment = in02PiStr))

        val ans = in02PiStr.ifBlank { "$v = ${formatDecimal(x1, 4)} rad (${formatDecimal(deg1, 1)}°)" }
        val pts = inPeriod.map { PmPlotPoint(it, 0.0, "(${formatDecimal(it, 2)}, 0)", "root") }
        val plot = buildPlotForExpr(PmExpr.Sub(fn, other), v, pts)
        val m = PmMethod("trig_eq", "Solución trigonométrica", "Solución general y en [0, 2π]", ans, listOf("Solución general" to generalText), steps)
        return PmSolution(true, raw, norm, eq, "Ecuación trigonométrica", listOf(m), plot)
    }

    private data class Quadruple(val a: Double, val b: Double, val c: Double, val d: String)

    private fun trySolveAbsInequality(raw: String, norm: String, rel: PmExpr.Rel, v: String): PmSolution? {
        val leftIsAbs = rel.left is PmExpr.Abs
        val inner = if (leftIsAbs) (rel.left as PmExpr.Abs).inner else (rel.right as PmExpr.Abs).inner
        val other = if (leftIsAbs) rel.right else rel.left
        val op = if (leftIsAbs) rel.op else flipRel(rel.op)
        val cRat = PmEval.evalExactRational(other) ?: return null
        val poly = toRatPoly(inner, v) ?: return null
        if (poly.degree != 1) return null

        val a = poly.coeff(1); val b = poly.coeff(0)
        val innerStr = PmFormatter.format(inner)
        val steps = ArrayList<PmStep>()
        val isLess = op == "<" || op == "<="
        val inc = op == "<=" || op == ">="

        if (cRat.isNegative) {
            val ans = if (isLess) "Sin solución ($v ∈ ∅)" else "$v ∈ ℝ (todos los reales)"
            steps.add(PmStep(1, "Comparar valor absoluto con número negativo", "Como |$innerStr| ≥ 0 siempre, la desigualdad |$innerStr| ${prettyRel(op)} $cRat es ${if (isLess) "imposible" else "siempre verdadera"}.", ans, highlightSegment = ans))
            val ivs = if (isLess) emptyList() else listOf(NumberLineInterval(null, null))
            return PmSolution(true, raw, norm, rel, "Inecuación con valor absoluto", listOf(PmMethod("abs_ineq_neg", "Análisis de signo", "", ans, emptyList(), steps, ivs)))
        }

        val r1 = (-cRat - b) / a
        val r2 = (cRat - b) / a
        val lo = minOf(r1, r2); val hi = maxOf(r1, r2)
        val sL = if (inc) "≤" else "<"
        val sG = if (inc) "≥" else ">"

        return if (isLess) {
            steps.add(PmStep(1, "Aplicar propiedad |u| $sL c  ⇔  −c $sL u $sL c", "El argumento debe estar acotado entre ${-cRat} y $cRat.", "${-cRat} $sL $innerStr $sL $cRat"))
            steps.add(PmStep(2, "Despejar $v en la doble desigualdad", "Restamos $b y dividimos entre $a.", "$lo $sL $v $sL $hi", highlightSegment = "$lo $sL $v $sL $hi"))
            val ivText = "${if (inc) "[" else "("}$lo, $hi${if (inc) "]" else ")"}"
            val ivs = listOf(NumberLineInterval(lo.toDouble(), hi.toDouble(), inc, inc))
            PmSolution(true, raw, norm, rel, "Inecuación con valor absoluto", listOf(PmMethod("abs_ineq_in", "Intervalo acotado", "", "$lo $sL $v $sL $hi", listOf("Intervalo" to "$v ∈ $ivText"), steps, ivs)))
        } else {
            steps.add(PmStep(1, "Aplicar propiedad |u| $sG c  ⇔  u $sL −c  o  u $sG c", "Separamos en dos ramas externas.", "$innerStr $sL ${-cRat}  o  $innerStr $sG $cRat"))
            steps.add(PmStep(2, "Despejar $v en ambas ramas", "Resolvemos cada inecuación lineal.", "$v $sL $lo  o  $v $sG $hi", highlightSegment = "$v $sL $lo  o  $v $sG $hi"))
            val ivText = "(-∞, $lo${if (inc) "]" else ")"} ∪ ${if (inc) "[" else "("}$hi, +∞)"
            val ivs = listOf(NumberLineInterval(null, lo.toDouble(), false, inc), NumberLineInterval(hi.toDouble(), null, inc, false))
            PmSolution(true, raw, norm, rel, "Inecuación con valor absoluto", listOf(PmMethod("abs_ineq_out", "Unión de intervalos", "", "$v $sL $lo  o  $v $sG $hi", listOf("Intervalo" to "$v ∈ $ivText"), steps, ivs)))
        }
    }

    private fun trySolveRationalInequality(raw: String, norm: String, rel: PmExpr.Rel, v: String): PmSolution? {
        // Llevar cualquier suma/resta de fracciones algebraicas a P(x)/Q(x) op 0
        val rf1 = toRatFunc(rel.left, v) ?: return null
        val rf2 = toRatFunc(rel.right, v) ?: return null
        val diffRf = rf1 - rf2
        val numPoly = diffRf.num
        val denPoly = diffRf.den
        if (denPoly.degree == 0) return null

        val inc = rel.op == "<=" || rel.op == ">="
        val wantPos = rel.op == ">" || rel.op == ">="
        val numRoots = findNumericalRoots(numPoly.toExpr(), v, -50.0, 50.0, 400)
        val denRoots = findNumericalRoots(denPoly.toExpr(), v, -50.0, 50.0, 400)
        val criticals = (numRoots + denRoots).distinctBy { formatDecimal(it, 4) }.sorted()

        val steps = ArrayList<PmStep>()
        steps.add(PmStep(1, "Llevar a una sola fracción comparada con 0", "Restamos el segundo miembro y unificamos denominador.", "(${numPoly.format()}) / (${denPoly.format()}) ${prettyRel(rel.op)} 0"))
        steps.add(
            PmStep(
                2,
                "Hallar ceros del numerador y restricciones del denominador",
                "Numerador = 0 en: ${if (numRoots.isEmpty()) "ninguno" else numRoots.joinToString(", ") { formatDecimal(it, 3) }}. " +
                    "Denominador = 0 (SIEMPRE excluidos): ${denRoots.joinToString(", ") { "$v ≠ ${formatDecimal(it, 3)}" }}.",
                "Puntos críticos: ${criticals.joinToString(", ") { formatDecimal(it, 3) }}",
                highlightSegment = criticals.joinToString(", ") { formatDecimal(it, 3) }
            )
        )

        // Evaluar signo en cada subintervalo entre puntos críticos
        val ivs = ArrayList<NumberLineInterval>()
        val intervalLabels = ArrayList<String>()
        val signNotes = ArrayList<PmSubStep>()

        fun isDenRoot(x: Double) = denRoots.any { abs(it - x) < 1e-3 }

        val boundaries = listOf<Double?>(null) + criticals + listOf<Double?>(null)
        for (i in 0 until boundaries.lastIndex) {
            val lo = boundaries[i]
            val hi = boundaries[i + 1]
            val sample = when {
                lo == null && hi == null -> 0.0
                lo == null && hi != null -> hi - 1.0
                lo != null && hi == null -> lo + 1.0
                else -> (lo!! + hi!!) / 2.0
            }
            val valNum = PmEval.evalDouble(numPoly.toExpr(), mapOf(v to sample))
            val valDen = PmEval.evalDouble(denPoly.toExpr(), mapOf(v to sample))
            val fracVal = valNum / valDen
            val okSign = if (wantPos) fracVal > 0.0 else fracVal < 0.0
            val loLabel = lo?.let { formatDecimal(it, 3) } ?: "-∞"
            val hiLabel = hi?.let { formatDecimal(it, 3) } ?: "+∞"
            signNotes.add(PmSubStep("Intervalo ($loLabel, $hiLabel)", "Prueba en $v = ${formatDecimal(sample, 2)} → signo ${if (fracVal > 0) "+" else "−"}", if (okSign) "Cumple la inecuación ✓" else "No cumple"))
            if (okSign) {
                val incLo = lo != null && inc && !isDenRoot(lo)
                val incHi = hi != null && inc && !isDenRoot(hi)
                ivs.add(NumberLineInterval(lo, hi, incLo, incHi))
                val lBr = if (incLo) "[" else "("
                val rBr = if (incHi) "]" else ")"
                intervalLabels.add("$lBr$loLabel, $hiLabel$rBr")
            }
        }

        val ivStr = if (intervalLabels.isEmpty()) "∅ (sin solución)" else intervalLabels.joinToString(" ∪ ")
        steps.add(PmStep(3, "Tabla de signos por intervalos", "Seleccionamos los intervalos cuyo signo cumple ${prettyRel(rel.op)} 0 (excluyendo siempre ceros del denominador).", "$v ∈ $ivStr", highlightSegment = ivStr, subSteps = signNotes))
        val m = PmMethod("ineq_rat", "Tabla de signos (racional)", "Puntos críticos de numerador y denominador", "$v ∈ $ivStr", emptyList(), steps, ivs)
        return PmSolution(true, raw, norm, rel, "Inecuación racional", listOf(m), buildPlotForExpr(PmExpr.Div(numPoly.toExpr(), denPoly.toExpr()), v))
    }


    /** Convierte cualquier combinación racional (+, -, *, /, ^) en fracción de polinomios P(x)/Q(x). */
    internal fun toRatFunc(expr: PmExpr, v: String): RatFunc? {
        val one = RatPoly(v, listOf(BigRat.ONE))
        return when (expr) {
            is PmExpr.Num -> RatFunc(RatPoly(v, listOf(expr.rat)), one)
            is PmExpr.Sym -> if (expr.name == v) RatFunc(RatPoly(v, listOf(BigRat.ZERO, BigRat.ONE)), one) else null
            is PmExpr.Neg -> toRatFunc(expr.inner, v)?.negate()
            is PmExpr.Add -> {
                val l = toRatFunc(expr.left, v) ?: return null
                val r = toRatFunc(expr.right, v) ?: return null
                l + r
            }
            is PmExpr.Sub -> {
                val l = toRatFunc(expr.left, v) ?: return null
                val r = toRatFunc(expr.right, v) ?: return null
                l - r
            }
            is PmExpr.Mul -> {
                val l = toRatFunc(expr.left, v) ?: return null
                val r = toRatFunc(expr.right, v) ?: return null
                l * r
            }
            is PmExpr.Div -> {
                val l = toRatFunc(expr.num, v) ?: return null
                val r = toRatFunc(expr.den, v) ?: return null
                if (r.num.degree == 0 && r.num.coeff(0).isZero) null else l / r
            }
            is PmExpr.Pow -> {
                val base = toRatFunc(expr.base, v) ?: return null
                val expRat = PmEval.evalExactRational(expr.exp) ?: return null
                if (!expRat.isInt) return null
                val n = expRat.num.toInt()
                if (n !in -4..5) return null
                if (n == 0) return RatFunc(one, one)
                val effective = if (n < 0) RatFunc(base.den, base.num) else base
                var acc = RatFunc(one, one)
                repeat(abs(n)) { acc *= effective }
                acc
            }
            else -> null
        }
    }

    private fun hasDivisionByVar(expr: PmExpr, v: String): Boolean = when (expr) {
        is PmExpr.Div -> v in PmParser.collectVars(expr.den) || hasDivisionByVar(expr.num, v) || hasDivisionByVar(expr.den, v)
        is PmExpr.Neg -> hasDivisionByVar(expr.inner, v)
        is PmExpr.Add -> hasDivisionByVar(expr.left, v) || hasDivisionByVar(expr.right, v)
        is PmExpr.Sub -> hasDivisionByVar(expr.left, v) || hasDivisionByVar(expr.right, v)
        is PmExpr.Mul -> hasDivisionByVar(expr.left, v) || hasDivisionByVar(expr.right, v)
        is PmExpr.Pow -> hasDivisionByVar(expr.base, v) || hasDivisionByVar(expr.exp, v)
        else -> false
    }

    /**
     * Aísla un término especial (|u|, √u, a^u, sin(u), ln(u)) si aparece en una combinación lineal
     * a·T + b = c en cualquiera de los dos miembros. Devuelve Pair(T, expresión_aislada).
     */
    private fun isolateSpecial(left: PmExpr, right: PmExpr, isTarget: (PmExpr) -> Boolean): Pair<PmExpr, PmExpr>? {
        fun tryFrom(sideWithTarget: PmExpr, otherSide: PmExpr): Pair<PmExpr, PmExpr>? {
            if (isTarget(sideWithTarget)) return sideWithTarget to otherSide
            return when (sideWithTarget) {
                is PmExpr.Neg -> if (isTarget(sideWithTarget.inner)) sideWithTarget.inner to simplifySymbolic(PmExpr.Neg(otherSide)) else null
                is PmExpr.Add -> when {
                    isTarget(sideWithTarget.left) && PmParser.collectVars(sideWithTarget.right).isEmpty() ->
                        sideWithTarget.left to simplifySymbolic(PmExpr.Sub(otherSide, sideWithTarget.right))
                    isTarget(sideWithTarget.right) && PmParser.collectVars(sideWithTarget.left).isEmpty() ->
                        sideWithTarget.right to simplifySymbolic(PmExpr.Sub(otherSide, sideWithTarget.left))
                    sideWithTarget.left is PmExpr.Mul && PmParser.collectVars(sideWithTarget.right).isEmpty() ->
                        tryFrom(sideWithTarget.left, simplifySymbolic(PmExpr.Sub(otherSide, sideWithTarget.right)))
                    sideWithTarget.right is PmExpr.Mul && PmParser.collectVars(sideWithTarget.left).isEmpty() ->
                        tryFrom(sideWithTarget.right, simplifySymbolic(PmExpr.Sub(otherSide, sideWithTarget.left)))
                    else -> null
                }
                is PmExpr.Sub -> when {
                    isTarget(sideWithTarget.left) && PmParser.collectVars(sideWithTarget.right).isEmpty() ->
                        sideWithTarget.left to simplifySymbolic(PmExpr.Add(otherSide, sideWithTarget.right))
                    isTarget(sideWithTarget.right) && PmParser.collectVars(sideWithTarget.left).isEmpty() ->
                        sideWithTarget.right to simplifySymbolic(PmExpr.Sub(sideWithTarget.left, otherSide))
                    sideWithTarget.left is PmExpr.Mul && PmParser.collectVars(sideWithTarget.right).isEmpty() ->
                        tryFrom(sideWithTarget.left, simplifySymbolic(PmExpr.Add(otherSide, sideWithTarget.right)))
                    else -> null
                }
                is PmExpr.Mul -> {
                    val lConst = PmEval.evalExactRational(sideWithTarget.left)
                    val rConst = PmEval.evalExactRational(sideWithTarget.right)
                    when {
                        lConst != null && !lConst.isZero && isTarget(sideWithTarget.right) ->
                            sideWithTarget.right to simplifySymbolic(PmExpr.Div(otherSide, PmExpr.Num(lConst)))
                        rConst != null && !rConst.isZero && isTarget(sideWithTarget.left) ->
                            sideWithTarget.left to simplifySymbolic(PmExpr.Div(otherSide, PmExpr.Num(rConst)))
                        else -> null
                    }
                }
                else -> null
            }
        }
        return tryFrom(left, right) ?: tryFrom(right, left)
    }

}
