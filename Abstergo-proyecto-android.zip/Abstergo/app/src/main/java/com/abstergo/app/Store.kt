package com.abstergo.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

// ---------- Ejercicios / entrenamientos ----------
data class Exercise(
    val id: String, val subject: String, val title: String, val text: String,
    val done: Boolean = false, val isNew: Boolean = false
)

private fun exFile(ctx: Context) = File(ctx.filesDir, "exercises.json")

fun subjectLabel(key: String): String = SUBJECTS[key] ?: "Otros"

fun loadExercises(ctx: Context): List<Exercise> = try {
    val a = JSONArray(exFile(ctx).readText())
    (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Exercise(o.getString("id"), o.getString("subject"), o.getString("title"), o.optString("text"), o.optBoolean("done"), o.optBoolean("new"))
    }
} catch (e: Exception) { emptyList() }

fun saveExercises(ctx: Context, list: List<Exercise>) {
    val a = JSONArray()
    list.forEach { e ->
        a.put(JSONObject().put("id", e.id).put("subject", e.subject).put("title", e.title)
            .put("text", e.text).put("done", e.done).put("new", e.isNew))
    }
    exFile(ctx).writeText(a.toString())
}

// ---------- Paquete que viaja por Wi-Fi Direct ----------
data class Dest(val kind: String, val label: String, val subject: String? = null)
data class Received(val sender: String, val dests: List<Dest>)

fun buildPayload(sender: String, schedules: List<Schedule>, exercises: List<Exercise>): String {
    val o = JSONObject().put("v", 1).put("sender", sender)
    val sa = JSONArray()
    schedules.forEach { s ->
        sa.put(JSONObject().put("date", s.date.toEpochDay()).put("group", s.group).put("slots", JSONObject(s.slots)))
    }
    val ea = JSONArray()
    exercises.forEach { e ->
        ea.put(JSONObject().put("id", e.id).put("subject", e.subject).put("title", e.title).put("text", e.text))
    }
    return o.put("schedules", sa).put("exercises", ea).toString()
}

/** Guarda lo recibido en su sección (horario o la asignatura de cada ejercicio) y lo marca como nuevo. */
fun applyPayload(ctx: Context, json: String): Received? {
    try {
        val o = JSONObject(json)
        if (o.optInt("v") != 1) return null
        val sender = o.optString("sender").take(60).ifBlank { "Otro dispositivo" }
        val dests = ArrayList<Dest>()

        var sched = loadSchedules(ctx)
        val sa = o.optJSONArray("schedules") ?: JSONArray()
        for (i in 0 until minOf(sa.length(), 60)) {
            val so = sa.getJSONObject(i)
            val day = so.getLong("date")
            if (day < 10957L || day > 47482L) continue // entre 2000 y 2100
            val date = LocalDate.ofEpochDay(day)
            val group = so.getString("group").take(20)
            val sl = so.getJSONObject("slots")
            val slots = HashMap<String, String>()
            sl.keys().forEach { k -> if (Regex("T?[1-6]").matches(k)) slots[k] = sl.getString(k).take(20) }
            if (slots.isEmpty()) continue
            sched = sched.filterNot { it.date == date && norm(it.group) == norm(group) } +
                Schedule(date, group, slots, System.currentTimeMillis(), true)
            dests.add(Dest("horario", "Horario · ${dateText(date)} (grupo $group)"))
        }
        saveSchedules(ctx, sched)

        var ex = loadExercises(ctx)
        val known = ex.map { it.id }.toHashSet()
        val ea = o.optJSONArray("exercises") ?: JSONArray()
        val counts = LinkedHashMap<String, Int>()
        for (i in 0 until minOf(ea.length(), 500)) {
            val eo = ea.getJSONObject(i)
            val id = eo.getString("id").take(60)
            if (id in known) continue
            val subj = eo.getString("subject").lowercase().let { if (it in SUBJECTS) it else "otros" }
            val title = eo.getString("title").take(200)
            if (title.isBlank()) continue
            ex = ex + Exercise(id, subj, title, eo.optString("text").take(5000), false, true)
            known.add(id)
            counts[subj] = (counts[subj] ?: 0) + 1
        }
        saveExercises(ctx, ex)
        counts.forEach { (k, n) ->
            dests.add(Dest("entrenar", "Entrenar · ${subjectLabel(k)} ($n ${if (n == 1) "ejercicio" else "ejercicios"})", k))
        }
        return if (dests.isEmpty()) null else Received(sender, dests)
    } catch (e: Exception) {
        return null
    }
}
