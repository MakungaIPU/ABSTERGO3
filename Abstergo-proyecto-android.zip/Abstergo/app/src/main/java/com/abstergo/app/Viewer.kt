package com.abstergo.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import android.graphics.Canvas
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Xml
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.util.zip.ZipFile

enum class Kind { PDF, DOCX, PPTX, HTML, TEXT, OTHER }

private val BINARY_EXT = setOf("mp4", "mkv", "3gp", "webm", "mov", "mp3", "m4a", "wav", "jpg", "jpeg", "png", "gif", "webp",
    "doc", "xls", "ppt", "epub", "mobi", "apk", "zip", "rar", "7z")
private val MONO_EXT = setOf("csv", "tsv", "json", "xml", "log", "ini", "yml", "yaml", "properties", "sh", "py", "js", "css", "java", "kt")

/** Detecta el tipo mirando el contenido del archivo (no solo la extensión). */
fun detectKind(f: File, ext: String): Kind {
    try {
        val head = ByteArray(2048)
        val n = f.inputStream().use { it.read(head) }.coerceAtLeast(0)
        if (n >= 4 && head[0] == 0x25.toByte() && head[1] == 0x50.toByte() && head[2] == 0x44.toByte() && head[3] == 0x46.toByte()) return Kind.PDF
        if (n >= 4 && head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()) {
            val z = ZipFile(f)
            try {
                if (z.getEntry("word/document.xml") != null) return Kind.DOCX
                if (z.getEntry("ppt/presentation.xml") != null) return Kind.PPTX
            } finally { z.close() }
            return Kind.OTHER
        }
        if (ext in BINARY_EXT) return Kind.OTHER
        val bytes = head.copyOf(n)
        if (bytes.any { it == 0.toByte() }) return Kind.OTHER
        val sample = String(bytes, Charsets.UTF_8).lowercase()
        if (ext in setOf("html", "htm", "xhtml") || sample.contains("<!doctype html") || sample.contains("<html")) return Kind.HTML
        return Kind.TEXT
    } catch (e: Exception) {
        return Kind.OTHER
    }
}

private fun readText(f: File, limit: Int = 3 * 1024 * 1024): String = f.inputStream().use { s ->
    val b = ByteArray(minOf(f.length(), limit.toLong()).toInt())
    var n = 0
    while (n < b.size) { val r = s.read(b, n, b.size - n); if (r < 0) break; n += r }
    String(b, 0, n, Charsets.UTF_8)
}

// ---------- Utilidades de Office (.docx / .pptx): relaciones e imágenes ----------
private fun resolveRel(baseDir: String, target: String): String {
    if (target.startsWith("/")) return target.drop(1)
    val parts = ArrayList<String>(baseDir.split('/').filter { it.isNotEmpty() })
    for (p in target.split('/')) {
        when (p) {
            "", "." -> {}
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
            else -> parts.add(p)
        }
    }
    return parts.joinToString("/")
}

/** Devuelve id de relación -> ruta de la imagen dentro del zip. */
private fun readRels(z: ZipFile, relsPath: String, baseDir: String): Map<String, String> {
    val e = z.getEntry(relsPath) ?: return emptyMap()
    val p = Xml.newPullParser(); p.setInput(z.getInputStream(e), "UTF-8")
    val m = HashMap<String, String>()
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        if (ev == XmlPullParser.START_TAG && p.name == "Relationship") {
            val type = p.getAttributeValue(null, "Type") ?: ""
            val id = p.getAttributeValue(null, "Id")
            val tg = p.getAttributeValue(null, "Target")
            if (id != null && tg != null && type.endsWith("/image") && p.getAttributeValue(null, "TargetMode") != "External") {
                m[id] = resolveRel(baseDir, tg)
            }
        }
        ev = p.next()
    }
    return m
}

fun decodeZipImage(f: File, entry: String, maxW: Int = 1080): ImageBitmap? {
    val z = ZipFile(f)
    try {
        val e = z.getEntry(entry) ?: return null
        val bytes = z.getInputStream(e).readBytes()
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        if (o.outWidth <= 0) return null
        var s = 1
        while (o.outWidth / (s * 2) >= maxW) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })?.asImageBitmap()
    } catch (e: Throwable) {
        return null
    } finally { z.close() }
}

// ---------- Word (.docx): texto, títulos, viñetas e imágenes ----------
data class DocPara(val text: String, val heading: Int, val image: String? = null)

fun readDocx(f: File): List<DocPara> {
    val z = ZipFile(f)
    try {
        val e = z.getEntry("word/document.xml") ?: return emptyList()
        val rels = readRels(z, "word/_rels/document.xml.rels", "word/")
        val p = Xml.newPullParser(); p.setInput(z.getInputStream(e), "UTF-8")
        val out = ArrayList<DocPara>(); val sb = StringBuilder(); val imgs = ArrayList<String>()
        var heading = 0; var bullet = false; var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && out.size < 20000) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "w:p" -> { sb.setLength(0); imgs.clear(); heading = 0; bullet = false }
                    "w:pStyle" -> {
                        val v = p.getAttributeValue(null, "w:val") ?: ""
                        if (v.startsWith("Heading") || v.startsWith("Ttulo") || v.startsWith("Title")) heading = v.filter { it.isDigit() }.toIntOrNull() ?: 1
                    }
                    "w:numPr" -> bullet = true
                    "w:t" -> inT = true
                    "w:tab" -> sb.append('\t')
                    "w:br" -> sb.append('\n')
                    "a:blip" -> rels[p.getAttributeValue(null, "r:embed") ?: ""]?.let { if (it !in imgs) imgs.add(it) }
                    "v:imagedata" -> rels[p.getAttributeValue(null, "r:id") ?: ""]?.let { if (it !in imgs) imgs.add(it) }
                }
            } else if (ev == XmlPullParser.TEXT) {
                if (inT) sb.append(p.text)
            } else if (ev == XmlPullParser.END_TAG) {
                if (p.name == "w:t") inT = false
                else if (p.name == "w:p") {
                    if (sb.isNotBlank()) out.add(DocPara((if (bullet) "• " else "") + sb.toString(), heading))
                    imgs.forEach { out.add(DocPara("", 0, it)) }
                    imgs.clear()
                }
            }
            ev = p.next()
        }
        return out
    } finally { z.close() }
}

// ---------- PowerPoint (.pptx): texto e imágenes de cada diapositiva ----------
data class Slide(val n: Int, val lines: List<String>, val images: List<String> = emptyList())

fun readPptx(f: File): List<Slide> {
    val z = ZipFile(f)
    try {
        val names = z.entries().asSequence().map { it.name }
            .filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
            .sortedBy { Regex("\\d+").find(it.substringAfterLast('/'))!!.value.toInt() }.toList()
        return names.mapIndexed { i, name ->
            val rels = readRels(z, "ppt/slides/_rels/" + name.substringAfterLast('/') + ".rels", "ppt/slides/")
            val p = Xml.newPullParser(); p.setInput(z.getInputStream(z.getEntry(name)), "UTF-8")
            val lines = ArrayList<String>(); val imgs = ArrayList<String>(); val sb = StringBuilder(); var inT = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    if (p.name == "a:p") sb.setLength(0)
                    else if (p.name == "a:t") inT = true
                    else if (p.name == "a:br") sb.append(' ')
                    else if (p.name == "a:blip") rels[p.getAttributeValue(null, "r:embed") ?: ""]?.let { if (it !in imgs && imgs.size < 10) imgs.add(it) }
                } else if (ev == XmlPullParser.TEXT) {
                    if (inT) sb.append(p.text)
                } else if (ev == XmlPullParser.END_TAG) {
                    if (p.name == "a:t") inT = false else if (p.name == "a:p" && sb.isNotBlank()) lines.add(sb.toString())
                }
                ev = p.next()
            }
            Slide(i + 1, lines, imgs.toList())
        }
    } finally { z.close() }
}

// ---------- Pantalla del visor ----------
@Composable
fun ViewerScreen(item: LibItem, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val file = remember(item.id) { libFile(ctx, item) }
    val kind by produceState<Kind?>(null, item.id) { value = withContext(Dispatchers.IO) { detectKind(file, item.ext) } }
    BackHandler { onBack() }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onBack, shape = RoundedCornerShape(14.dp)) { Text("Volver") }
            Text(item.name, Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            TextButton({ openLibItem(ctx, item) }) { Text("Abrir con…") }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (kind) {
                null -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                Kind.PDF -> PdfView(file)
                Kind.DOCX -> DocxView(file)
                Kind.PPTX -> PptxView(file)
                Kind.HTML -> HtmlView(file)
                Kind.TEXT -> TextFileView(file, item.ext in MONO_EXT)
                Kind.OTHER -> Message("Este formato aún no se puede ver aquí. Usa «Abrir con…» para verlo con otra app.")
            }
        }
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PdfView(f: File) {
    val opened = remember(f) {
        try { val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY); Pair(PdfRenderer(pfd), pfd) } catch (e: Exception) { null }
    }
    DisposableEffect(f) { onDispose { try { opened?.first?.close(); opened?.second?.close() } catch (_: Exception) {} } }
    if (opened == null) { Message("No pude abrir este PDF (puede estar protegido)."); return }
    val r = opened.first
    var zoom by remember { mutableStateOf(1f) }
    val hScroll = rememberScrollState()
    val renderW = if (zoom > 1.4f) 1800 else 1080

    // Pellizcar con dos dedos para acercar o alejar; doble toque para alternar; un dedo desplaza
    BoxWithConstraints(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        if (ev.changes.size >= 2) {
                            val z = ev.calculateZoom()
                            if (z != 1f) {
                                zoom = (zoom * z).coerceIn(1f, 4f)
                                ev.changes.forEach { it.consume() }
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { zoom = if (zoom > 1.2f) 1f else 2.5f }) }
    ) {
        val vw = maxWidth
        Row(Modifier.fillMaxSize().horizontalScroll(hScroll)) {
            LazyColumn(Modifier.width(vw * zoom).fillMaxHeight(), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(r.pageCount) { i ->
                    val page by produceState<ImageBitmap?>(null, i, renderW) { value = withContext(Dispatchers.IO) { renderPage(r, i, renderW) } }
                    val bm = page
                    if (bm == null) {
                        Box(Modifier.fillMaxWidth().height(420.dp).background(Color.White))
                    } else {
                        Image(bm, "Página ${i + 1}", Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                    }
                }
            }
        }
    }
}

private fun renderPage(r: PdfRenderer, i: Int, width: Int): ImageBitmap? = synchronized(r) {
    try {
        val p = r.openPage(i)
        try {
            val h = (width.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
            val bm = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            Canvas(bm).drawColor(android.graphics.Color.WHITE)
            p.render(bm, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bm.asImageBitmap()
        } finally { p.close() }
    } catch (e: Throwable) { null }
}

@Composable
private fun ZipImage(f: File, entry: String) {
    val bm by produceState<ImageBitmap?>(null, entry) { value = withContext(Dispatchers.IO) { decodeZipImage(f, entry) } }
    val b = bm
    if (b != null) Image(b, null, Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.FillWidth)
}

@Composable
private fun DocxView(f: File) {
    val paras by produceState<List<DocPara>?>(null, f) {
        value = withContext(Dispatchers.IO) { try { readDocx(f) } catch (e: Exception) { emptyList() } }
    }
    val list = paras
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> Message("No pude leer este documento.")
        else -> SelectionContainer {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(list) { p ->
                    if (p.image != null) {
                        ZipImage(f, p.image)
                    } else {
                        Text(
                            p.text, fontSize = when (p.heading) { 0 -> 16.sp; 1 -> 26.sp; 2 -> 22.sp; else -> 19.sp },
                            fontWeight = if (p.heading > 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PptxView(f: File) {
    val slides by produceState<List<Slide>?>(null, f) {
        value = withContext(Dispatchers.IO) { try { readPptx(f) } catch (e: Exception) { emptyList() } }
    }
    val list = slides
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> Message("No pude leer las diapositivas.")
        else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { s ->
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Diapositiva ${s.n}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    s.lines.forEachIndexed { i, l -> Text(l, fontSize = if (i == 0) 20.sp else 15.sp, fontWeight = if (i == 0) FontWeight.Bold else FontWeight.Normal) }
                    s.images.forEach { ZipImage(f, it) }
                    if (s.lines.isEmpty() && s.images.isEmpty()) Text("(vacía)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun HtmlView(f: File) {
    val html by produceState<String?>(null, f) { value = withContext(Dispatchers.IO) { try { readText(f) } catch (e: Exception) { "" } } }
    val content = html
    if (content == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
            WebView(c).apply {
                // Visor sin internet ni scripts: solo muestra el contenido del archivo
                settings.javaScriptEnabled = false
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.blockNetworkLoads = true
                settings.builtInZoomControls = true
                settings.displayZoomControls = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                setBackgroundColor(android.graphics.Color.WHITE)
                loadDataWithBaseURL(null, content, "text/html", "UTF-8", null)
            }
        })
    }
}

@Composable
private fun TextFileView(f: File, mono: Boolean) {
    val text by produceState<String?>(null, f) { value = withContext(Dispatchers.IO) { try { readText(f) } catch (e: Exception) { "" } } }
    val t = text
    if (t == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    } else {
        val lines = remember(t) { t.split('\n') }
        SelectionContainer {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                items(lines) { l ->
                    Text(l.ifEmpty { " " }, fontSize = 14.sp, fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)
                }
            }
        }
    }
}
