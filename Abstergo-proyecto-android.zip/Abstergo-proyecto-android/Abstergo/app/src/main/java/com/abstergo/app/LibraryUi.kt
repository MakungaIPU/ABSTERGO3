package com.abstergo.app

import android.graphics.BitmapFactory
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun BibliotecaTab(
    books: List<LibItem>, cols: Int, onCols: (Int) -> Unit,
    onAdd: () -> Unit, onOpen: (LibItem) -> Unit, onDelete: (LibItem) -> Unit, onMove: (LibItem, String) -> Unit
) {
    var menuFor by remember { mutableStateOf<LibItem?>(null) }
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Todos") }
    var colsMenu by remember { mutableStateOf(false) }
    val q = norm(query)
    val shown = books.filter { b ->
        (cat == "Todos" || b.cat == cat) && (q.isEmpty() || norm(b.name + " " + b.ext + " " + b.cat).contains(q))
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Biblioteca", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box {
                OutlinedButton(
                    { colsMenu = true }, Modifier.height(34.dp), shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                ) { Text("Columnas $cols ▾", fontSize = 13.sp) }
                DropdownMenu(expanded = colsMenu, onDismissRequest = { colsMenu = false }) {
                    listOf(2, 3, 4, 5).forEach { n ->
                        DropdownMenuItem(
                            text = { Text(if (n == cols) "✓  $n por fila" else "$n por fila") },
                            onClick = { onCols(n); colsMenu = false }
                        )
                    }
                }
            }
        }
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
            placeholder = { Text("Buscar en la biblioteca") }, singleLine = true, shape = RoundedCornerShape(14.dp),
            trailingIcon = { if (query.isNotEmpty()) Text("✕", Modifier.clickable { query = "" }.padding(12.dp)) }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (listOf("Todos") + LIB_CATS + "Sin categoría").forEach { c ->
                FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
            }
        }
        if (books.isNotEmpty() && shown.isEmpty()) {
            Text("No hay archivos que coincidan.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols), contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(shown, key = { it.id }) { b -> LibTile(b, onOpen) { menuFor = b } }
            item { AddTile(onAdd) } // el "+" siempre queda en la última posición
        }
    }

    menuFor?.let { b ->
        AlertDialog(
            onDismissRequest = { menuFor = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text(b.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mover a:", fontWeight = FontWeight.SemiBold)
                    LIB_CATS.chunked(2).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { c -> FilterChip(selected = b.cat == c, onClick = { onMove(b, c); menuFor = null }, label = { Text(c) }) }
                        }
                    }
                }
            },
            confirmButton = { TextButton({ onDelete(b); menuFor = null }) { Text("Eliminar") } },
            dismissButton = { TextButton({ menuFor = null }) { Text("Cancelar") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LibTile(b: LibItem, onOpen: (LibItem) -> Unit, onLong: () -> Unit) {
    val ctx = LocalContext.current
    val cover by produceState<ImageBitmap?>(null, b.id) {
        value = withContext(Dispatchers.IO) {
            coverFile(ctx, b)?.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
        }
    }
    Column(Modifier.combinedClickable(onClick = { onOpen(b) }, onLongClick = onLong)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            val c = cover
            if (c != null) {
                Image(c, b.name, Modifier.fillMaxSize(), alignment = Alignment.TopCenter, contentScale = ContentScale.Crop)
            } else {
                Text(b.ext.uppercase().ifEmpty { "ARCHIVO" }, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.primary)
            }
            if (b.isNew) RedDot(Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(b.name, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AddTile(onAdd: () -> Unit) {
    Column(Modifier.clickable { onAdd() }) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) { Text("+", fontSize = 40.sp, color = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.height(4.dp))
        Text("Importar", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
