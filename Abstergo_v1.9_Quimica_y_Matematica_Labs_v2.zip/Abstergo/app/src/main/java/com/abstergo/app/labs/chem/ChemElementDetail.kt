package com.abstergo.app.labs.chem

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Ficha completa de un elemento químico dentro de Química Labs:
 * - Foto real en la cabecera + navegación fluida Z-1 <-> Z+1
 * - Selector de temperatura (°C / K / °F)
 * - Pestañas técnicas completas (General, Atómicas, Físicas, Nucleares) + Bohr + Espectro
 * - Sección "¿Dónde está escondido?" (usos, objetos cotidianos sorprendentes y dato curioso)
 * - Favorito (★), nota personal rápida y botón interconectado "Enviar a Notas de Abstergo"
 * - Cierre con historia del descubrimiento e impacto real en la vida humana
 */
@Composable
fun ChemElementDetailScreen(
    element: ChemElement,
    allElements: List<ChemElement>,
    isFavorite: Boolean,
    personalNote: String,
    tempUnit: TempUnit,
    onTempUnitChange: (TempUnit) -> Unit,
    onNavigateElement: (ChemElement) -> Unit,
    onToggleFavorite: () -> Unit,
    onSavePersonalNote: (String) -> Unit,
    onSendToAbstergoNotes: (title: String, body: String) -> Unit,
    onStartCompare: (ChemElement) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val dark = chemIsDark()
    val accent = element.category.color(dark)
    val glass = chemGlassSurface()
    val flameColor = remember(element.flameHex) { parseHexColorOrNull(element.flameHex) }

    var propTab by remember(element.z) { mutableStateOf(0) } // 0=General, 1=Atómicas, 2=Físicas, 3=Nucleares
    var noteDraft by remember(element.z, personalNote) { mutableStateOf(personalNote) }
    var noteSavedFeedback by remember(element.z) { mutableStateOf(false) }

    val prevEl = remember(element.z, allElements) { allElements.firstOrNull { it.z == element.z - 1 } }
    val nextEl = remember(element.z, allElements) { allElements.firstOrNull { it.z == element.z + 1 } }

    Column(
        Modifier.fillMaxSize().background(chemCanvasBg())
    ) {
        // Barra superior con navegación rápida Z-1 / Z+1, Comparar, Favorito y Notas Abstergo
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChemCircleBtn(ChemIconKind.BACK, MaterialTheme.colorScheme.onSurface, onClick = onBack)
            Spacer(Modifier.width(8.dp))
            // Controles Z-1 y Z+1
            Row(
                Modifier.clip(RoundedCornerShape(50))
                    .background(glass)
                    .border(1.dp, chemGlassBorder(), RoundedCornerShape(50))
                    .padding(horizontal = 4.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(30.dp).clip(CircleShape)
                        .clickable(enabled = prevEl != null) { prevEl?.let(onNavigateElement) },
                    contentAlignment = Alignment.Center
                ) {
                    ChemIcon(
                        ChemIconKind.PREV,
                        if (prevEl != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                        Modifier.size(14.dp)
                    )
                }
                Text(
                    "#${element.z}",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                Box(
                    Modifier.size(30.dp).clip(CircleShape)
                        .clickable(enabled = nextEl != null) { nextEl?.let(onNavigateElement) },
                    contentAlignment = Alignment.Center
                ) {
                    ChemIcon(
                        ChemIconKind.NEXT,
                        if (nextEl != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                        Modifier.size(14.dp)
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            // Comparar
            ChemCircleBtn(ChemIconKind.COMPARE, accent) { onStartCompare(element) }
            Spacer(Modifier.width(6.dp))
            // Enviar resumen a Notas de Abstergo (interconexión directa)
            ChemCircleBtn(ChemIconKind.NOTE, MaterialTheme.colorScheme.onSurface) {
                val noteBody = buildString {
                    appendLine("${element.name} (${element.symbol}) — Z = ${element.z}, Masa = ${element.massText} u")
                    appendLine("Familia: ${element.category.label} · Grupo ${if (element.group > 0) "${element.group} (${element.groupRoman})" else "Bloque f"} · Período ${element.period}")
                    appendLine("Configuración: ${element.configShort} (${element.config})")
                    appendLine("Oxidación: ${element.oxidation} · EN Pauling: ${element.electronegativity ?: "—"}")
                    appendLine("Fusión: ${formatTemp(element.meltK, tempUnit)} · Ebullición: ${formatTemp(element.boilK, tempUnit)}")
                    appendLine()
                    appendLine("Usos: ${element.uses}")
                    appendLine("Dónde se encuentra: ${element.hiddenObjects}")
                    appendLine("Descubrimiento (${element.year}, ${element.discoverer}): ${element.discoveryStory}")
                    if (noteDraft.isNotBlank()) {
                        appendLine()
                        appendLine("Mi apunte: $noteDraft")
                    }
                }
                onSendToAbstergoNotes("Química · ${element.name} (${element.symbol})", noteBody)
            }
            Spacer(Modifier.width(6.dp))
            // Favorito
            ChemCircleBtn(
                if (isFavorite) ChemIconKind.STAR_FILLED else ChemIconKind.STAR_OUTLINE,
                if (isFavorite) Color(0xFFFACC15) else MaterialTheme.colorScheme.onSurface,
                onClick = onToggleFavorite
            )
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. CABECERA CON FOTO REAL DEL ELEMENTO
            ElementRealPhotoHero(element = element, accent = accent)

            // 2. TIRA DE MÉTRICAS RÁPIDAS + SELECTOR °C / K / °F
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickStatPill("Grupo", if (element.group > 0) "${element.group} (${element.groupRoman})" else "Bloque f", accent, Modifier.weight(1f))
                QuickStatPill("Período", "${element.period} · blq ${element.block}", accent, Modifier.weight(1f))
                QuickStatPill("Estado 25°C", element.phase25, accent, Modifier.weight(1f))
            }

            // 3. DIAGRAMA ATÓMICO DE BOHR + CONFIGURACIÓN + ESPECTRO
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(glass)
                    .border(1.dp, chemGlassBorder(accent), RoundedCornerShape(22.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    BohrAtomCanvas(
                        element = element,
                        accent = accent,
                        modifier = Modifier.size(124.dp)
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("ESTRUCTURA ELECTRÓNICA", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp, color = accent)
                        Text(element.configShort, fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        Text(element.config, fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            "Capas: ${element.shells.joinToString(" · ")}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            "Valencia: ${element.shells.lastOrNull() ?: 0} e⁻  ·  Ox.: ${element.oxidation}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (element.spectrumNm.isNotEmpty()) {
                    EmissionSpectrumBar(element.spectrumNm)
                }
                if (element.flameName.isNotBlank() && flameColor != null) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(flameColor.copy(alpha = 0.13f))
                            .border(1.dp, flameColor.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ChemIcon(ChemIconKind.FLAME, flameColor, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Ensayo a la llama: ${element.flameName}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // 4. PROPIEDADES COMPLETAS POR PESTAÑAS + SELECTOR DE UNIDAD DE TEMPERATURA
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(glass)
                    .border(1.dp, chemGlassBorder(), RoundedCornerShape(22.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Propiedades verificadas", fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    // Selector de unidad de temperatura
                    Row(
                        Modifier.clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(2.dp)
                    ) {
                        TempUnit.entries.forEach { u ->
                            val sel = u == tempUnit
                            Box(
                                Modifier.clip(RoundedCornerShape(50))
                                    .background(if (sel) accent else Color.Transparent)
                                    .clickable { onTempUnitChange(u) }
                                    .padding(horizontal = 9.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    u.symbol,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (sel) (if (dark) Color(0xFF07111A) else Color.White) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Selector de categoría de datos
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("General", "Atómicas", "Físicas", "Nucleares").forEachIndexed { idx, label ->
                        val sel = propTab == idx
                        Box(
                            Modifier.clip(RoundedCornerShape(10.dp))
                                .background(if (sel) accent.copy(alpha = 0.18f) else Color.Transparent)
                                .border(1.dp, if (sel) accent else chemGlassBorder(), RoundedCornerShape(10.dp))
                                .clickable { propTab = idx }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                label,
                                fontSize = 12.sp,
                                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                                color = if (sel) accent else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                val rows: List<Pair<String, String>> = when (propTab) {
                    0 -> listOf(
                        "Nombre en latín" to element.latin,
                        "Serie química" to element.category.label,
                        "Grupo / Período / Bloque" to "${if (element.group > 0) "Grupo ${element.group} (${element.groupRoman})" else "Serie f"} · Período ${element.period} · Bloque ${element.block}",
                        "Apariencia física" to element.appearance,
                        "Abundancia" to element.abundance
                    )
                    1 -> listOf(
                        "Número atómico (Z)" to "${element.z} protones · ${element.z} electrones",
                        "Masa atómica estándar" to "${element.massText} u (g/mol)",
                        "Configuración completa" to element.config,
                        "Estados de oxidación" to element.oxidation,
                        "Electronegatividad (Pauling)" to (element.electronegativity?.toString() ?: "No aplica"),
                        "Radio atómico" to (element.radiusPm?.let { "$it pm" } ?: "Desconocido"),
                        "1.ª energía de ionización" to (element.ionizationEv?.let { "$it eV" } ?: "Desconocida")
                    )
                    2 -> listOf(
                        "Estado a 25 °C" to element.phase25,
                        "Punto de fusión" to formatTemp(element.meltK, tempUnit),
                        "Punto de ebullición" to formatTemp(element.boilK, tempUnit),
                        "Densidad (STP)" to (element.density?.let { "$it g/cm³" } ?: "Desconocida"),
                        "Estructura cristalina" to element.crystal,
                        "Comportamiento magnético" to element.magnetism
                    )
                    else -> listOf(
                        "Radiactividad" to if (element.radioactive) "Sí (todos los isótopos son radiactivos)" else "No (posee isótopos estables)",
                        "Vida media principal" to element.halfLife,
                        "Isótopos destacados" to element.isotopes
                    )
                }

                rows.forEachIndexed { idx, (k, v) ->
                    if (idx > 0) HorizontalDivider(color = chemGlassBorder())
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                        Text(k, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.45f))
                        Spacer(Modifier.width(8.dp))
                        Text(v, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.55f))
                    }
                }
            }

            // 5. ¿DÓNDE ESTÁ ESCONDIDO? (USOS + OBJETOS COTIDIANOS + DATO CURIOSO)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(glass)
                    .border(1.2.dp, chemGlassBorder(accent), RoundedCornerShape(22.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) { ChemIcon(ChemIconKind.SPARKLE, accent, Modifier.size(18.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("¿DÓNDE ESTÁ ESCONDIDO?", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp, color = accent)
                        Text("Usos, objetos cotidianos y curiosidad", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }

                InfoSubBlock("Objetos que quizá no sabías que lo llevan", element.hiddenObjects, accent)
                InfoSubBlock("Usos principales en ciencia e industria", element.uses, MaterialTheme.colorScheme.onSurfaceVariant)
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(accent.copy(alpha = 0.10f))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Dato curioso", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = accent)
                        Text(element.funFact, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }

            // 6. APUNTE PERSONAL RÁPIDO DEL ESTUDIANTE
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(glass)
                    .border(1.dp, chemGlassBorder(), RoundedCornerShape(20.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Tu apunte sobre ${element.symbol}", fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(
                        onClick = {
                            onSavePersonalNote(noteDraft)
                            noteSavedFeedback = true
                        }
                    ) {
                        Text(if (noteSavedFeedback) "Guardado ✓" else "Guardar", color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                OutlinedTextField(
                    value = noteDraft,
                    onValueChange = { noteDraft = it; noteSavedFeedback = false },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ej: recordar sus estados de oxidación o excepciones para el examen…", fontSize = 12.sp) },
                    minLines = 2,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // 7. CIERRE: HISTORIA DEL DESCUBRIMIENTO E IMPACTO EN LA VIDA HUMANA
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(glass)
                    .border(1.dp, chemGlassBorder(), RoundedCornerShape(22.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("HISTORIA E IMPACTO HUMANO", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp, color = accent)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickStatPill("Descubridor", element.discoverer, accent, Modifier.weight(1.4f))
                    QuickStatPill("Año", element.year, accent, Modifier.weight(0.7f))
                }
                InfoSubBlock("Cómo se descubrió", element.discoveryStory, MaterialTheme.colorScheme.onSurfaceVariant)
                HorizontalDivider(color = chemGlassBorder())
                InfoSubBlock("Qué significó para la vida humana", element.humanImpact, accent)
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun InfoSubBlock(label: String, body: String, labelColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = labelColor)
        Text(body, fontSize = 13.sp, lineHeight = 20.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun QuickStatPill(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(chemGlassSurface())
            .border(1.dp, chemGlassBorder(), RoundedCornerShape(14.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ChemCircleBtn(icon: ChemIconKind, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).clip(CircleShape)
            .background(chemGlassSurface())
            .border(1.dp, chemGlassBorder(), CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        ChemIcon(icon, tint, Modifier.size(18.dp))
    }
}

// ==============================================================================
// COMPARADOR LADO A LADO DE ELEMENTOS QUÍMICOS
// ==============================================================================

@Composable
fun ChemCompareScreen(
    first: ChemElement,
    allElements: List<ChemElement>,
    tempUnit: TempUnit,
    onOpenElement: (ChemElement) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val dark = chemIsDark()
    var elA by remember(first) { mutableStateOf(first) }
    var elB by remember(first) {
        val partner = allElements.firstOrNull { it.z != first.z && it.group == first.group && first.group > 0 }
            ?: allElements.firstOrNull { it.z == (if (first.z < 118) first.z + 1 else first.z - 1) }
            ?: first
        mutableStateOf(partner)
    }
    var pickingSlot by remember { mutableStateOf<Int?>(null) } // 1 o 2
    var pickerQuery by remember { mutableStateOf("") }

    val colA = elA.category.color(dark)
    val colB = elB.category.color(dark)

    Column(Modifier.fillMaxSize().background(chemCanvasBg())) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChemCircleBtn(ChemIconKind.BACK, MaterialTheme.colorScheme.onSurface, onClick = onBack)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Comparador de elementos", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("TOCA CUALQUIER TARJETA PARA CAMBIAR", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = chemPrimaryAccent())
            }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Dos tarjetas seleccionables frente a frente
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CompareHeaderCard(elA, colA, Modifier.weight(1f), onPick = { pickingSlot = 1; pickerQuery = "" }, onInspect = { onOpenElement(elA) })
                CompareHeaderCard(elB, colB, Modifier.weight(1f), onPick = { pickingSlot = 2; pickerQuery = "" }, onInspect = { onOpenElement(elB) })
            }

            // Barras visuales comparativas
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(chemGlassSurface()).border(1.dp, chemGlassBorder(), RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Comparación cuantitativa", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                CompareBarRow("Masa atómica (u)", elA.mass, elB.mass, elA.massText, elB.massText, colA, colB)
                CompareBarRow(
                    "Electronegatividad (Pauling)",
                    elA.electronegativity ?: 0.0, elB.electronegativity ?: 0.0,
                    elA.electronegativity?.toString() ?: "—", elB.electronegativity?.toString() ?: "—",
                    colA, colB
                )
                CompareBarRow(
                    "Radio atómico (pm)",
                    elA.radiusPm?.toDouble() ?: 0.0, elB.radiusPm?.toDouble() ?: 0.0,
                    elA.radiusPm?.let { "$it pm" } ?: "—", elB.radiusPm?.let { "$it pm" } ?: "—",
                    colA, colB
                )
                CompareBarRow(
                    "Energía de ionización (eV)",
                    elA.ionizationEv ?: 0.0, elB.ionizationEv ?: 0.0,
                    elA.ionizationEv?.let { "$it eV" } ?: "—", elB.ionizationEv?.let { "$it eV" } ?: "—",
                    colA, colB
                )
                CompareBarRow(
                    "Densidad (g/cm³)",
                    elA.density ?: 0.0, elB.density ?: 0.0,
                    elA.density?.let { "$it" } ?: "—", elB.density?.let { "$it" } ?: "—",
                    colA, colB
                )
            }

            // Tabla comparativa detallada
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(chemGlassSurface()).border(1.dp, chemGlassBorder(), RoundedCornerShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Propiedades lado a lado", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                CompareTextRow("Familia", elA.category.shortLabel, elB.category.shortLabel)
                CompareTextRow("Grupo / Período", "G${elA.group} (${elA.groupRoman}) · P${elA.period}", "G${elB.group} (${elB.groupRoman}) · P${elB.period}")
                CompareTextRow("Configuración", elA.configShort, elB.configShort)
                CompareTextRow("Oxidación", elA.oxidation, elB.oxidation)
                CompareTextRow("Estado (25 °C)", elA.phase25, elB.phase25)
                CompareTextRow("Punto fusión", formatTemp(elA.meltK, tempUnit), formatTemp(elB.meltK, tempUnit))
                CompareTextRow("Punto ebullición", formatTemp(elA.boilK, tempUnit), formatTemp(elB.boilK, tempUnit))
                CompareTextRow("Magnetismo", elA.magnetism, elB.magnetism)
                CompareTextRow("Descubrimiento", elA.year, elB.year)
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    // Selector modal de elemento
    pickingSlot?.let { slot ->
        val filtered = remember(pickerQuery, allElements) {
            allElements.filter { it.matchesQuery(pickerQuery) }
        }
        AlertDialog(
            onDismissRequest = { pickingSlot = null },
            containerColor = chemGlassSurface(),
            title = { Text("Elegir elemento ${if (slot == 1) "A" else "B"}") },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pickerQuery,
                        onValueChange = { pickerQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Nombre, símbolo o Z…") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(filtered, key = { it.z }) { el ->
                            val c = el.category.color(dark)
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                                    .background(c.copy(alpha = 0.12f))
                                    .clickable {
                                        if (slot == 1) elA = el else elB = el
                                        pickingSlot = null
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(el.symbol, fontWeight = FontWeight.ExtraBold, color = c, fontSize = 16.sp, modifier = Modifier.width(34.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(el.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Z = ${el.z} · ${el.category.shortLabel}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton({ pickingSlot = null }) { Text("Cerrar") } }
        )
    }
}

@Composable
private fun CompareHeaderCard(
    el: ChemElement,
    accent: Color,
    modifier: Modifier,
    onPick: () -> Unit,
    onInspect: () -> Unit
) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(18.dp))
            .background(chemGlassSurface())
            .border(1.3.dp, chemGlassBorder(accent), RoundedCornerShape(18.dp))
            .clickable { onPick() }
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("#${el.z}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = accent, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("Cambiar", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(el.symbol, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = accent)
        Text(el.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("Ver ficha ›", fontSize = 11.sp, color = accent, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { onInspect() }.padding(top = 2.dp))
    }
}

@Composable
private fun CompareBarRow(label: String, vA: Double, vB: Double, tA: String, tB: String, colA: Color, colB: Color) {
    val maxV = maxOf(vA, vB, 1e-6)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tA, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.width(64.dp))
            Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                Box(Modifier.fillMaxHeight().fillMaxWidth((vA / maxV).toFloat().coerceIn(0f, 1f)).clip(RoundedCornerShape(4.dp)).background(colA))
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tB, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.width(64.dp))
            Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                Box(Modifier.fillMaxHeight().fillMaxWidth((vB / maxV).toFloat().coerceIn(0f, 1f)).clip(RoundedCornerShape(4.dp)).background(colB))
            }
        }
    }
}

@Composable
private fun CompareTextRow(label: String, a: String, b: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        HorizontalDivider(color = chemGlassBorder())
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(a, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(b, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        }
    }
}
