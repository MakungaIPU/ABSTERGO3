package com.abstergo.app.labs.chem

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.abstergo.app.writeTextAtomic
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.round

enum class ChemCategory(
    val key: String,
    val label: String,
    val shortLabel: String,
    val darkColor: Color,
    val lightColor: Color
) {
    ALKALI("alkali", "Metales alcalinos", "Alcalinos", Color(0xFFFF6B6B), Color(0xFFD93838)),
    ALKALINE_EARTH("alkaline_earth", "Alcalinotérreos", "Alcalinotér.", Color(0xFFFFA94D), Color(0xFFD97706)),
    TRANSITION("transition", "Metales de transición", "Transición", Color(0xFF4DABF7), Color(0xFF1D6FD6)),
    POST_TRANSITION("post_transition", "Metales postransición", "Postrans.", Color(0xFF38D9A9), Color(0xFF0D9488)),
    METALLOID("metalloid", "Metaloides", "Metaloides", Color(0xFF69DB7C), Color(0xFF16A34A)),
    NONMETAL("nonmetal", "No metales reactivos", "No metales", Color(0xFF22D3EE), Color(0xFF0284C7)),
    HALOGEN("halogen", "Halógenos", "Halógenos", Color(0xFFFACC15), Color(0xFFCA8A04)),
    NOBLE_GAS("noble_gas", "Gases nobles", "Gases nobles", Color(0xFFC084FC), Color(0xFF7C3AED)),
    LANTHANIDE("lanthanide", "Lantánidos", "Lantánidos", Color(0xFFF472B6), Color(0xFFDB2777)),
    ACTINIDE("actinide", "Actínidos", "Actínidos", Color(0xFFFB7185), Color(0xFFE11D48));

    fun color(dark: Boolean): Color = if (dark) darkColor else lightColor

    companion object {
        fun fromKey(k: String): ChemCategory = entries.firstOrNull { it.key == k } ?: TRANSITION
    }
}

enum class ChemColorMode(val label: String) {
    FAMILY("Familia"),
    BLOCK("Bloques s·p·d·f"),
    STATE("Estado físico"),
    ELECTRONEGATIVITY("Electroneg."),
    RADIUS("Radio atómico"),
    RADIOACTIVITY("Radiactividad")
}

enum class ChemCellMetric(val label: String) {
    MASS("Masa"),
    ELECTRONEGATIVITY("EN Pauling"),
    OXIDATION("Oxidación"),
    DENSITY("Densidad"),
    MELT("Fusión")
}

enum class TempUnit(val symbol: String) {
    CELSIUS("°C"),
    KELVIN("K"),
    FAHRENHEIT("°F")
}

enum class ChemSortMode(val label: String) {
    ATOMIC_NUM("Número Z"),
    NAME("Nombre A–Z"),
    MASS("Masa atómica"),
    DENSITY("Densidad"),
    MELT("Punto fusión"),
    ELECTRONEG("Electroneg."),
    YEAR("Descubrimiento")
}

@Immutable
data class ChemElement(
    val z: Int,
    val symbol: String,
    val name: String,
    val latin: String,
    val mass: Double,
    val massText: String,
    val category: ChemCategory,
    val period: Int,
    val group: Int,
    val groupRoman: String,
    val gridRow: Int,
    val gridCol: Int,
    val block: String,
    val config: String,
    val configShort: String,
    val shells: List<Int>,
    val oxidation: String,
    val electronegativity: Double?,
    val radiusPm: Int?,
    val ionizationEv: Double?,
    val density: Double?,
    val meltK: Double?,
    val boilK: Double?,
    val phase25: String,
    val crystal: String,
    val magnetism: String,
    val radioactive: Boolean,
    val halfLife: String,
    val isotopes: String,
    val abundance: String,
    val flameName: String,
    val flameHex: String,
    val spectrumNm: List<Int>,
    val appearance: String,
    val sampleCaption: String,
    val discoverer: String,
    val year: String,
    val discoveryStory: String,
    val humanImpact: String,
    val uses: String,
    val hiddenObjects: String,
    val funFact: String
) {
    fun phaseAtCelsius(tempC: Double): String {
        val tK = tempC + 273.15
        if (z >= 104 && meltK == null && boilK == null) return "Sintético"
        if (z == 33 && meltK != null && boilK != null) {
            return if (tK >= boilK) "Gas" else "Sólido"
        }
        return when {
            boilK != null && tK >= boilK -> "Gas"
            meltK != null && tK >= meltK -> "Líquido"
            meltK != null && tK < meltK -> "Sólido"
            boilK != null && tK < boilK -> if (z == 2) "Líquido" else "Sólido"
            else -> phase25
        }
    }

    fun discoveryYearInt(): Int {
        if (year.contains("Antigüedad", ignoreCase = true)) return -3000
        val neg = year.contains("a. C.", ignoreCase = true)
        val digits = Regex("\\d+").find(year)?.value?.toIntOrNull() ?: 2100
        return if (neg) -digits else digits
    }

    fun matchesQuery(rawQuery: String): Boolean {
        val q = rawQuery.trim().lowercase()
        if (q.isEmpty()) return true
        if (z.toString() == q) return true
        return name.lowercase().contains(q) ||
            symbol.lowercase().contains(q) ||
            latin.lowercase().contains(q) ||
            category.label.lowercase().contains(q) ||
            uses.lowercase().contains(q) ||
            hiddenObjects.lowercase().contains(q) ||
            discoverer.lowercase().contains(q) ||
            phase25.lowercase().contains(q) ||
            year.lowercase().contains(q)
    }

    fun metricLine(metric: ChemCellMetric, tempUnit: TempUnit): String = when (metric) {
        ChemCellMetric.MASS -> massText
        ChemCellMetric.ELECTRONEGATIVITY -> electronegativity?.let { "%.2f".format(Locale.US, it) } ?: "—"
        ChemCellMetric.OXIDATION -> oxidation.split(",").take(2).joinToString(",") { it.trim() }
        ChemCellMetric.DENSITY -> density?.let {
            if (it < 0.01) "%.4f".format(Locale.US, it) else "%.2f".format(Locale.US, it)
        } ?: "—"
        ChemCellMetric.MELT -> meltK?.let { formatTempCompact(it, tempUnit) } ?: "—"
    }
}

@Immutable
data class ChemUserData(
    val favorites: Set<Int> = emptySet(),
    val notes: Map<Int, String> = emptyMap()
)

fun formatTemp(kelvin: Double?, unit: TempUnit): String {
    if (kelvin == null) return "Desconocido"
    return when (unit) {
        TempUnit.KELVIN -> "${formatChemNum(kelvin, 2)} K"
        TempUnit.CELSIUS -> "${formatChemNum(kelvin - 273.15, 2)} °C"
        TempUnit.FAHRENHEIT -> "${formatChemNum((kelvin - 273.15) * 9.0 / 5.0 + 32.0, 2)} °F"
    }
}

fun formatTempCompact(kelvin: Double, unit: TempUnit): String = when (unit) {
    TempUnit.KELVIN -> "${round(kelvin).toInt()}K"
    TempUnit.CELSIUS -> "${round(kelvin - 273.15).toInt()}°"
    TempUnit.FAHRENHEIT -> "${round((kelvin - 273.15) * 9.0 / 5.0 + 32.0).toInt()}°F"
}

fun formatChemNum(v: Double, maxDec: Int = 3): String {
    val clean = if (abs(v) < 1e-10) 0.0 else v
    val r = round(clean)
    if (abs(clean - r) < 1e-6 && abs(r) < 1e12) return r.toLong().toString()
    return "%.${maxDec}f".format(Locale.US, clean).trimEnd('0').trimEnd('.')
}

// ==============================================================================
// REPOSITORIO OFFLINE (JSON DE 118 ELEMENTOS + CACHÉ SEGURA DE FOTOS REALES)
// ==============================================================================

object ChemRepository {
    @Volatile
    private var cachedElements: List<ChemElement>? = null

    private val imageCache = object : LruCache<Int, ImageBitmap>(24) {}

    fun loadElements(ctx: Context): List<ChemElement> {
        cachedElements?.let { return it }
        return synchronized(this) {
            cachedElements?.let { return it }
            val text = ctx.assets.open("labs/chem/elements_es.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONArray(text)
            val list = ArrayList<ChemElement>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val shellsArr = o.getJSONArray("shells")
                val shells = (0 until shellsArr.length()).map { shellsArr.getInt(it) }
                val specArr = o.optJSONArray("spectrumNm")
                val spec = if (specArr != null) (0 until specArr.length()).map { specArr.getInt(it) } else emptyList()
                list.add(
                    ChemElement(
                        z = o.getInt("z"),
                        symbol = o.getString("symbol"),
                        name = o.getString("name"),
                        latin = o.optString("latin"),
                        mass = o.getDouble("mass"),
                        massText = o.getString("massText"),
                        category = ChemCategory.fromKey(o.getString("category")),
                        period = o.getInt("period"),
                        group = o.getInt("group"),
                        groupRoman = o.optString("groupRoman"),
                        gridRow = o.getInt("gridRow"),
                        gridCol = o.getInt("gridCol"),
                        block = o.getString("block"),
                        config = o.getString("config"),
                        configShort = o.getString("configShort"),
                        shells = shells,
                        oxidation = o.optString("oxidation", "—"),
                        electronegativity = if (o.isNull("electronegativity")) null else o.getDouble("electronegativity"),
                        radiusPm = if (o.isNull("radiusPm")) null else o.getInt("radiusPm"),
                        ionizationEv = if (o.isNull("ionizationEv")) null else o.getDouble("ionizationEv"),
                        density = if (o.isNull("density")) null else o.getDouble("density"),
                        meltK = if (o.isNull("meltK")) null else o.getDouble("meltK"),
                        boilK = if (o.isNull("boilK")) null else o.getDouble("boilK"),
                        phase25 = o.optString("phase25", "Sólido"),
                        crystal = o.optString("crystal", "—"),
                        magnetism = o.optString("magnetism", "—"),
                        radioactive = o.optBoolean("radioactive", false),
                        halfLife = o.optString("halfLife", "Estable"),
                        isotopes = o.optString("isotopes", "—"),
                        abundance = o.optString("abundance", "—"),
                        flameName = o.optString("flameName", ""),
                        flameHex = o.optString("flameHex", ""),
                        spectrumNm = spec,
                        appearance = o.optString("appearance", ""),
                        sampleCaption = o.optString("sampleCaption", ""),
                        discoverer = o.optString("discoverer", ""),
                        year = o.optString("year", ""),
                        discoveryStory = o.optString("discoveryStory", ""),
                        humanImpact = o.optString("humanImpact", ""),
                        uses = o.optString("uses", ""),
                        hiddenObjects = o.optString("hiddenObjects", ""),
                        funFact = o.optString("funFact", "")
                    )
                )
            }
            cachedElements = list
            list
        }
    }

    /** Carga la foto real del elemento desde assets/labs/chem/img/e_XXX.jpg (si existe en el APK). */
    fun loadElementPhoto(ctx: Context, z: Int): ImageBitmap? {
        imageCache.get(z)?.let { return it }
        val num = String.format(Locale.US, "%03d", z)
        val candidates = listOf(
            "labs/chem/img/e_$num.jpg",
            "labs/chem/img/e_$num.webp",
            "labs/chem/img/e_$num.png"
        )
        for (path in candidates) {
            try {
                ctx.assets.open(path).use { inp ->
                    val opts = BitmapFactory.Options().apply { inPreferredConfig = android.graphics.Bitmap.Config.RGB_565 }
                    val bmp = BitmapFactory.decodeStream(inp, null, opts)?.asImageBitmap()
                    if (bmp != null) {
                        imageCache.put(z, bmp)
                        return bmp
                    }
                }
            } catch (_: Exception) { }
        }
        return null
    }
}

private fun chemUserFile(ctx: Context): File = File(ctx.filesDir, "chem_user_data.json")

fun loadChemUserData(ctx: Context): ChemUserData {
    val f = chemUserFile(ctx)
    if (!f.exists()) return ChemUserData()
    return try {
        val root = JSONObject(f.readText())
        val favs = HashSet<Int>()
        val favArr = root.optJSONArray("favorites")
        if (favArr != null) {
            for (i in 0 until favArr.length()) favs.add(favArr.getInt(i))
        }
        val notesMap = HashMap<Int, String>()
        val notesObj = root.optJSONObject("notes")
        if (notesObj != null) {
            val keys = notesObj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                k.toIntOrNull()?.let { z ->
                    val txt = notesObj.optString(k)
                    if (txt.isNotBlank()) notesMap[z] = txt
                }
            }
        }
        ChemUserData(favs, notesMap)
    } catch (_: Exception) {
        ChemUserData()
    }
}

fun saveChemUserData(ctx: Context, data: ChemUserData) {
    val favArr = JSONArray()
    data.favorites.sorted().forEach { favArr.put(it) }
    val notesObj = JSONObject()
    data.notes.forEach { (z, txt) -> if (txt.isNotBlank()) notesObj.put(z.toString(), txt.take(2000)) }
    val root = JSONObject().put("favorites", favArr).put("notes", notesObj)
    writeTextAtomic(chemUserFile(ctx), root.toString())
}
