package com.abstergo.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.abstergo.app.labs.ocr.MathOcrEngine
import com.abstergo.app.labs.ocr.OcrModelStatus

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
fun SettingsScreen(
    settings: Settings, onBack: () -> Unit,
    onClearSchedules: () -> Unit, onClearExercises: () -> Unit, onWipe: () -> Unit
) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf<String?>(null) }
    var tmpScale by remember { mutableStateOf(settings.scale) }
    val ocrStatus = remember { MathOcrEngine.checkStatus(ctx) }
    val sys = isSystemInDarkTheme()
    val dark = when (settings.mode) { "light" -> false; "dark" -> true; else -> sys }
    BackHandler { onBack() }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Configuración", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            OutlinedButton(onBack, shape = RoundedCornerShape(14.dp)) { Text("Volver") }
        }

        SettingsCard("Temas") {
            Text("Modo", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RoleButton("Claro", settings.mode == "light", Modifier.weight(1f)) { settings.changeMode("light") }
                RoleButton("Oscuro", settings.mode == "dark", Modifier.weight(1f)) { settings.changeMode("dark") }
                RoleButton("Sistema", settings.mode == "system", Modifier.weight(1f)) { settings.changeMode("system") }
            }
            Text("Color", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            THEMES.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { t ->
                        val selected = settings.theme == t.id
                        val scheme = remember(t.id, dark) { schemeFor(t, dark) }
                        Column(
                            Modifier.clip(RoundedCornerShape(12.dp)).clickable { settings.changeTheme(t.id) }.padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(56.dp).clip(CircleShape).background(scheme.primary)
                                    .border(if (selected) 3.dp else 0.dp, MaterialTheme.colorScheme.onBackground, CircleShape),
                                contentAlignment = Alignment.Center
                            ) { if (selected) Text("✓", color = scheme.onPrimary, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                            Spacer(Modifier.height(4.dp))
                            Text(t.name, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        SettingsCard("Pantalla") {
            Text("Escala de la interfaz: ${(tmpScale * 100).toInt()}%")
            Slider(
                value = tmpScale, onValueChange = { tmpScale = it },
                onValueChangeFinished = { settings.changeScale(tmpScale) },
                valueRange = 0.85f..1.3f, steps = 8
            )
            Text("Hora", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RoleButton("12 horas", !settings.time24, Modifier.weight(1f)) { settings.changeTime24(false) }
                RoleButton("24 horas", settings.time24, Modifier.weight(1f)) { settings.changeTime24(true) }
            }
        }

        SettingsCard("Datos") {
            OutlinedButton({ confirm = "s" }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Borrar historial de horarios") }
            OutlinedButton({ confirm = "e" }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Borrar ejercicios de Labs") }
            OutlinedButton({ confirm = "w" }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Restablecer la app") }
        }

        SettingsCard("Acerca de") {
            Text("Abstergo · versión 1.9 (Universal 32/64 bits)")
            Text(
                when (ocrStatus) {
                    is OcrModelStatus.Ready -> "OCR Matemático Nivel 2 (ONNX): Listo offline ✓"
                    is OcrModelStatus.MissingFiles -> "OCR Matemático Nivel 2: Faltan ${ocrStatus.missing.joinToString(", ")} en assets/labs/ocr/"
                    is OcrModelStatus.Error -> "OCR Matemático Nivel 2: ${ocrStatus.message}"
                },
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text("Todo se guarda solo en este teléfono.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Matemática Labs (clon de Photomath + Preuniversitario 10mo–12mo con Geometría 2D/3D y OCR offline) y Química Labs (Tabla Periódica de 118 elementos IUPAC/NIST con fotos reales y espectroscopía) operan 100% offline en 32 y 64 bits.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("El visor de HTML usa ajustes de HTMLOpen (MIT), de Gilzone.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Los visores de documentos vienen de Gander (MIT), de Arjun Maniyani, e incluyen pdf.js, docx-preview, SheetJS y PPTXjs. Licencias completas dentro de la app, en assets/viewer.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = MaterialTheme.colorScheme.surface,
            text = {
                Text(when (c) {
                    "s" -> "Se borrarán todos los horarios guardados."
                    "e" -> "Se borrarán todos los ejercicios guardados en Labs."
                    else -> "Se borrará todo (perfil, horarios, Labs, notas y ajustes) y la app volverá al inicio."
                })
            },
            confirmButton = {
                TextButton({
                    when (c) { "s" -> onClearSchedules(); "e" -> onClearExercises(); else -> onWipe() }
                    confirm = null
                }) { Text("Borrar") }
            },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancelar") } }
        )
    }
}
