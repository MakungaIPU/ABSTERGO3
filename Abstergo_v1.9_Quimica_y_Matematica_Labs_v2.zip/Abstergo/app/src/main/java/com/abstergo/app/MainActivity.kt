@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.abstergo.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import kotlinx.coroutines.launch
import java.io.File
import java.security.MessageDigest
import java.text.Normalizer
import kotlin.math.absoluteValue

class MainActivity : ComponentActivity() {
    private val pendingUri = mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIntent(intent)
        setContent { App(pendingUri) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // "Abrir con Abstergo" (VIEW) o "Compartir" (SEND) desde otra app
    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val u: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            else -> null
        }
        if (u != null) pendingUri.value = u
    }
}

// ---------- Tipografía (Nunito, licencia OFL: sencilla y redondeada) ----------
private fun serif(w: FontWeight) = Font(
    R.font.nunito, w, variationSettings = FontVariation.Settings(FontVariation.weight(w.weight))
)
private val AppFont = FontFamily(
    serif(FontWeight.Normal), serif(FontWeight.Medium), serif(FontWeight.SemiBold),
    serif(FontWeight.Bold), serif(FontWeight.Black)
)
private fun appTypography(): Typography {
    val d = Typography()
    fun TextStyle.f() = copy(fontFamily = AppFont)
    return Typography(
        displayLarge = d.displayLarge.f(), displayMedium = d.displayMedium.f(), displaySmall = d.displaySmall.f(),
        headlineLarge = d.headlineLarge.f(), headlineMedium = d.headlineMedium.f(), headlineSmall = d.headlineSmall.f(),
        titleLarge = d.titleLarge.f(), titleMedium = d.titleMedium.f(), titleSmall = d.titleSmall.f(),
        bodyLarge = d.bodyLarge.f(), bodyMedium = d.bodyMedium.f(), bodySmall = d.bodySmall.f(),
        labelLarge = d.labelLarge.f(), labelMedium = d.labelMedium.f(), labelSmall = d.labelSmall.f()
    )
}
internal val AppTypography = appTypography()

@Composable
fun AbstergoTheme(dark: Boolean, themeId: String, scale: Float, content: @Composable () -> Unit) {
    val def = remember(themeId) { THEMES.firstOrNull { it.id == themeId } ?: THEMES[0] }
    val scheme = remember(def.id, dark) { schemeFor(def, dark) }
    val base = LocalDensity.current
    val scaled = remember(base.density, base.fontScale, scale) { Density(base.density * scale, base.fontScale) }
    MaterialTheme(colorScheme = scheme, typography = AppTypography) {
        CompositionLocalProvider(LocalDensity provides scaled) { content() }
    }
}

// ---------- Datos y utilidades optimizadas ----------
@Immutable
data class Profile(val role: String, val name: String, val extra: String)

private fun loadProfile(p: SharedPreferences): Profile? {
    val n = p.getString("name", null) ?: return null
    return Profile(p.getString("role", "student")!!, n, p.getString("extra", "")!!)
}

private val REGEX_DIACRITICS = Regex("\\p{M}+")
private val REGEX_NON_ALNUM = Regex("[^a-z0-9 ]")
private val REGEX_MULTI_SPACE = Regex("\\s+")

internal fun norm(s: String): String {
    if (s.isEmpty()) return ""
    return Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(REGEX_DIACRITICS, "")
        .lowercase()
        .replace(REGEX_NON_ALNUM, " ")
        .replace(REGEX_MULTI_SPACE, " ")
        .trim()
}

internal fun loadBitmap(ctx: Context, uri: Uri, maxDim: Int = 512): ImageBitmap? = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
        null
    } else {
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxDim || bounds.outHeight / (sample * 2) >= maxDim) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    }
} catch (_: Throwable) { null }

// ---------- App ----------
private const val TEACHER_HASH = "cd1411bdcad33007216d3094dc32542129c42eacd4c915f9d9fe5d0c8099a6a3"

private fun sha256(s: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
    val hex = CharArray(bytes.size * 2)
    val digits = "0123456789abcdef"
    for (i in bytes.indices) {
        val v = bytes[i].toInt() and 0xFF
        hex[i * 2] = digits[v ushr 4]
        hex[i * 2 + 1] = digits[v and 0x0F]
    }
    return String(hex)
}

internal fun teacherError(prefs: SharedPreferences, pass: String): String? {
    val now = System.currentTimeMillis()
    val lock = prefs.getLong("lock_until", 0L)
    if (now < lock) return "Demasiados intentos. Espera ${(lock - now) / 1000 + 1} s."
    if (sha256("abstergo-v1:$pass") == TEACHER_HASH) { prefs.edit().putInt("fails", 0).apply(); return null }
    val f = prefs.getInt("fails", 0) + 1
    val e = prefs.edit()
    if (f >= 5) e.putInt("fails", 0).putLong("lock_until", now + 60_000) else e.putInt("fails", f)
    e.apply()
    return "Contraseña incorrecta."
}

@Composable
fun App(pendingUri: MutableState<Uri?>) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("abstergo", Context.MODE_PRIVATE) }
    val settings = remember { Settings(prefs) }
    val sysDark = isSystemInDarkTheme()
    val dark = when (settings.mode) { "light" -> false; "dark" -> true; else -> sysDark }
    var screen by remember { mutableStateOf("intro") }
    var profile by remember { mutableStateOf(loadProfile(prefs)) }

    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }

    val reset = remember(ctx, prefs) {
        {
            prefs.edit().remove("name").remove("role").remove("extra").apply()
            File(ctx.filesDir, "profile.jpg").delete()
            profile = null; screen = "profile"
        }
    }
    val wipe = remember(ctx, prefs, settings) {
        {
            listOf("profile.jpg", "schedules.json", "exercises.json", "library.json", "notes.json", "labs.json", "photomath_history.json", "chem_user_data.json")
                .forEach { File(ctx.filesDir, it).delete() }
            File(ctx.filesDir, "library").deleteRecursively()
            File(ctx.filesDir, "labs").deleteRecursively()
            CoverCache.clear()
            prefs.edit().clear().apply()
            settings.resetDefaults()
            profile = null; screen = "profile"
        }
    }

    AbstergoTheme(dark, settings.theme, settings.scale) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Crossfade(targetState = screen, animationSpec = tween(500), label = "screen") { current ->
                when (current) {
                    "intro" -> IntroScreen {
                        screen = when {
                            !prefs.getBoolean("onboarding_done", false) -> "onboarding"
                            profile != null -> "home"
                            else -> "profile"
                        }
                    }
                    "onboarding" -> OnboardingScreen {
                        prefs.edit().putBoolean("onboarding_done", true).apply()
                        screen = if (profile != null) "home" else "profile"
                    }
                    "profile" -> ProfileScreen { p -> profile = p; screen = "home" }
                    else -> profile?.let { pr ->
                        if (pr.role == "student") {
                            StudentHome(pr, settings, pendingUri.value, { pendingUri.value = null }, reset, wipe) { p -> profile = p }
                        } else {
                            TeacherHome(pr, settings, reset, wipe) { p -> profile = p }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Video de intro (tocar para saltar) ----------
@Composable
fun IntroScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    var finished by remember { mutableStateOf(false) }
    val finish = { if (!finished) { finished = true; onDone() } }
    val hasRealVideo = remember(ctx) {
        try {
            ctx.resources.openRawResourceFd(R.raw.intro).use { it.length > 1024L }
        } catch (_: Exception) {
            false
        }
    }
    if (!hasRealVideo) {
        LaunchedEffect(Unit) { finish() }
        Box(Modifier.fillMaxSize().background(Color.Black))
        return
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                VideoView(c).apply {
                    // No pedir el foco de audio: así no se pausa la música del teléfono
                    setAudioFocusRequest(AudioManager.AUDIOFOCUS_NONE)
                    setVideoURI(Uri.parse("android.resource://${c.packageName}/${R.raw.intro}"))
                    setOnPreparedListener { it.isLooping = false; it.setVolume(0f, 0f); start() }
                    setOnCompletionListener { finish() }
                    setOnErrorListener { _, _, _ -> finish(); true }
                }
            },
            onRelease = { it.stopPlayback() }
        )
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) { finish() }
        )
    }
}

// ---------- Componentes ----------
@Composable
fun TopBar() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("ABSTERGO", fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
    }
}

@Composable
fun RoleButton(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    if (selected) Button(onClick, modifier, shape = RoundedCornerShape(14.dp)) { Text(text) }
    else OutlinedButton(onClick, modifier, shape = RoundedCornerShape(14.dp)) { Text(text) }
}

@Composable
fun Avatar(bitmap: ImageBitmap?, size: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant)
            .border(2.dp, MaterialTheme.colorScheme.onBackground, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) Image(bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.Person, null, Modifier.size((size / 2).dp))
    }
}

// ---------- Introducción (solo la primera vez) ----------
@Immutable
data class OnbPage(val title: String, val text: String, val symbol: Int) // symbol -1 = logo

private val onboardingPages = listOf(
    OnbPage("Abstergo", "La mano derecha de los estudiantes y profesores del Preuniversitario", -1),
    OnbPage("Sigue tu horario al pie de la letra", "Consulta tus clases y el calendario de eventos, siempre al día.", 0),
    OnbPage("Trabajos y tareas, sin olvidos", "Organiza tus trabajos prácticos y tareas evaluativas y entrégalos a tiempo.", 1),
    OnbPage("Prepárate para cada prueba", "Ten a la vista tus pruebas parciales y finales y sigue tu progreso.", 2),
    OnbPage("Entrena tu mente", "Practica con los laboratorios interactivos y llega con confianza a cada evaluación.", 3)
)

private fun line(x1: Float, y1: Float, x2: Float, y2: Float) = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
private fun rrect(l: Float, t: Float, r: Float, b: Float, rad: Float) =
    Path().apply { addRoundRect(RoundRect(Rect(l, t, r, b), CornerRadius(rad, rad))) }
private fun polyline(vararg p: Float) = Path().apply {
    moveTo(p[0], p[1]); var i = 2; while (i < p.size) { lineTo(p[i], p[i + 1]); i += 2 }
}

/** Símbolos minimalistas en una cuadrícula de 100x100, cada trazo es un camino independiente. */
private fun symbolPaths(kind: Int): List<Path> = when (kind) {
    0 -> listOf( // reloj
        Path().apply { addOval(Rect(Offset(50f, 50f), 38f)) },
        line(50f, 50f, 50f, 28f), line(50f, 50f, 66f, 58f),
        line(50f, 16f, 50f, 22f), line(84f, 50f, 78f, 50f), line(50f, 84f, 50f, 78f), line(16f, 50f, 22f, 50f)
    )
    1 -> listOf( // lista de tareas
        rrect(22f, 10f, 78f, 90f, 8f),
        polyline(32f, 34f, 36f, 38f, 44f, 30f), line(52f, 34f, 68f, 34f),
        polyline(32f, 54f, 36f, 58f, 44f, 50f), line(52f, 54f, 68f, 54f),
        polyline(32f, 74f, 36f, 78f, 44f, 70f), line(52f, 74f, 68f, 74f)
    )
    2 -> listOf( // progreso
        line(10f, 88f, 90f, 88f), rrect(16f, 58f, 32f, 88f, 3f), rrect(42f, 40f, 58f, 88f, 3f), rrect(68f, 20f, 84f, 88f, 3f)
    )
    3 -> listOf( // laboratorio / entrenamiento escolar: matraz y cuaderno
        rrect(14f, 12f, 62f, 88f, 6f), line(26f, 34f, 50f, 34f), line(26f, 50f, 50f, 50f), line(26f, 66f, 40f, 66f),
        polyline(70f, 70f, 84f, 34f, 92f, 38f, 78f, 74f, 70f, 70f), polyline(70f, 70f, 69f, 82f, 78f, 74f)
    )
    4 -> listOf( // calendario
        rrect(14f, 20f, 86f, 88f, 8f), line(14f, 42f, 86f, 42f), line(34f, 10f, 34f, 28f), line(66f, 10f, 66f, 28f),
        line(30f, 58f, 38f, 58f), line(46f, 58f, 54f, 58f), line(62f, 58f, 70f, 58f), line(30f, 72f, 38f, 72f), line(46f, 72f, 54f, 72f)
    )
    5 -> listOf( // éxito
        Path().apply { addOval(Rect(Offset(50f, 50f), 40f)) }, polyline(30f, 52f, 45f, 66f, 70f, 36f)
    )
    7 -> listOf( // libro abierto
        polyline(50f, 26f, 28f, 20f, 12f, 24f, 12f, 80f, 28f, 76f, 50f, 84f),
        polyline(50f, 26f, 72f, 20f, 88f, 24f, 88f, 80f, 72f, 76f, 50f, 84f), line(50f, 26f, 50f, 84f)
    )
    8 -> listOf( // enviar
        line(50f, 70f, 50f, 18f), polyline(30f, 38f, 50f, 18f, 70f, 38f), polyline(18f, 62f, 18f, 86f, 82f, 86f, 82f, 62f)
    )
    9 -> listOf( // recibir
        line(50f, 14f, 50f, 66f), polyline(30f, 46f, 50f, 66f, 70f, 46f), polyline(18f, 62f, 18f, 86f, 82f, 86f, 82f, 62f)
    )
    10 -> listOf( // nota adhesiva con esquina doblada
        polyline(18f, 12f, 82f, 12f, 82f, 62f, 56f, 88f, 18f, 88f, 18f, 12f), polyline(56f, 88f, 56f, 62f, 82f, 62f),
        line(30f, 34f, 70f, 34f), line(30f, 48f, 70f, 48f), line(30f, 62f, 44f, 62f)
    )
    11 -> listOf( // carpeta
        polyline(10f, 24f, 38f, 24f, 46f, 34f, 90f, 34f, 90f, 82f, 10f, 82f, 10f, 24f), line(10f, 46f, 90f, 46f)
    )
    12 -> listOf( // cámara
        rrect(10f, 30f, 90f, 82f, 8f), Path().apply { addOval(Rect(Offset(50f, 56f), 15f)) }, polyline(34f, 30f, 40f, 20f, 60f, 20f, 66f, 30f)
    )
    13 -> listOf( // laboratorio matemático (función f(x) + ejes)
        line(16f, 82f, 88f, 82f), line(18f, 16f, 18f, 84f),
        polyline(24f, 72f, 42f, 34f, 60f, 62f, 82f, 24f)
    )
    else -> listOf( // compartir
        Path().apply { addOval(Rect(Offset(24f, 50f), 9f)) }, Path().apply { addOval(Rect(Offset(76f, 24f), 9f)) },
        Path().apply { addOval(Rect(Offset(76f, 76f), 9f)) }, line(32f, 46f, 68f, 28f), line(32f, 54f, 68f, 72f)
    )
}

@Composable
fun LineSymbol(kind: Int, progress: Float, color: Color, modifier: Modifier = Modifier, strokeW: Float = 3.2f) {
    val paths = remember(kind) { symbolPaths(kind) }
    val stroke = remember(strokeW) { Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round) }
    val measure = remember { PathMeasure() }
    val scratch = remember { Path() }
    Canvas(modifier) {
        val sc = size.minDimension / 100f
        withTransform({ scale(sc, sc, Offset.Zero) }) {
            if (progress >= 0.999f) {
                for (i in paths.indices) {
                    drawPath(paths[i], color, style = stroke)
                }
            } else if (progress > 0f) {
                for (i in paths.indices) {
                    measure.setPath(paths[i], false)
                    scratch.reset()
                    measure.getSegment(0f, measure.length * progress, scratch, true)
                    drawPath(scratch, color, style = stroke)
                }
            }
        }
    }
}

@Composable
fun OnboardingPage(page: OnbPage, active: Boolean, modifier: Modifier = Modifier) {
    val enter by animateFloatAsState(if (active) 1f else 0f, tween(900), label = "enter")
    Column(
        modifier.fillMaxSize().padding(horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.height(190.dp), contentAlignment = Alignment.Center) {
            if (page.symbol < 0) {
                Image(
                    painterResource(R.drawable.logo), "Logo Abstergo",
                    Modifier.size(180.dp)
                        .graphicsLayer { scaleX = 0.8f + 0.2f * enter; scaleY = 0.8f + 0.2f * enter; alpha = enter }
                        .clip(RoundedCornerShape(40.dp))
                )
            } else {
                LineSymbol(page.symbol, enter, MaterialTheme.colorScheme.onBackground, Modifier.size(160.dp))
            }
        }
        Spacer(Modifier.height(32.dp))
        Text(
            page.title, fontSize = if (page.symbol < 0) 40.sp else 28.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, lineHeight = if (page.symbol < 0) 46.sp else 34.sp,
            modifier = Modifier.graphicsLayer { alpha = enter; translationY = (1f - enter) * 40f }
        )
        Spacer(Modifier.height(12.dp))
        Text(
            page.text, fontSize = 17.sp, lineHeight = 26.sp, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.graphicsLayer { alpha = enter; translationY = (1f - enter) * 40f }
        )
    }
}

@Composable
fun PageDot(active: Boolean) {
    val w by animateDpAsState(if (active) 24.dp else 8.dp, tween(300), label = "dotW")
    val c by animateColorAsState(
        if (active) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outline, label = "dotC"
    )
    Box(Modifier.width(w).height(8.dp).clip(CircleShape).background(c))
}

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pager = rememberPagerState { onboardingPages.size }
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == onboardingPages.lastIndex
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp)) {
        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { i ->
            val off = ((pager.currentPage - i) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
            OnboardingPage(
                onboardingPages[i], pager.currentPage == i,
                Modifier.graphicsLayer { alpha = 1f - off; val sc = 1f - 0.12f * off; scaleX = sc; scaleY = sc }
            )
        }
        Row(
            Modifier.align(Alignment.CenterHorizontally).padding(vertical = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) { repeat(onboardingPages.size) { PageDot(it == pager.currentPage) } }
        Button(
            onClick = { if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
            modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp)
        ) {
            Crossfade(last, label = "btn") { Text(if (it) "Hecho" else "Continuar", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
