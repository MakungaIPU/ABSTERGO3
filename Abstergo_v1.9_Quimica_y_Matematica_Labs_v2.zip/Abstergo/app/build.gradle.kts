import java.awt.Image
import java.awt.image.BufferedImage
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import javax.imageio.ImageIO

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abstergo.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.abstergo.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 11
        versionName = "2.0"
        ndk {
            // Soporte universal para teléfonos Android de 32 bits y 64 bits
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }
    signingConfigs {
        getByName("debug") {
            val ks = file("debug.keystore")
            if (ks.exists()) {
                storeFile = ks
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }
    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    androidResources {
        // Evita recomprimir archivos ONNX dentro del APK (mejor arranque y menos RAM)
        noCompress += listOf("onnx")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/INDEX.LIST"
            )
        }
    }
}

// ==============================================================================
// Descarga automática durante la compilación en GitHub Actions (si faltan):
// 1) Modelo OCR Matemático Offline (ONNX INT8, 32 y 64 bits) -> assets/labs/ocr/
// 2) Fotos reales de elementos químicos (Z=1..99, 480px optimizadas) -> assets/labs/chem/img/
// ==============================================================================
val prepareLabsAssets by tasks.registering {
    val ocrDir = file("src/main/assets/labs/ocr")
    val chemImgDir = file("src/main/assets/labs/chem/img")
    doLast {
        System.setProperty("java.awt.headless", "true")
        ocrDir.mkdirs()
        chemImgDir.mkdirs()

        fun openFollowingRedirects(rawUrl: String, timeoutReadMs: Int = 60000): HttpURLConnection? {
            var current = URL(rawUrl)
            var redirects = 0
            while (redirects < 6) {
                val c = (current.openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 20000
                    readTimeout = timeoutReadMs
                    setRequestProperty("User-Agent", "AbstergoLabsBuilder/2.0 (Educational Android App)")
                }
                val code = c.responseCode
                if (code in 301..308) {
                    val loc = c.getHeaderField("Location") ?: run { c.disconnect(); return null }
                    c.disconnect()
                    current = URL(current, loc)
                    redirects++
                } else {
                    return c
                }
            }
            return null
        }

        fun downloadIfMissing(dest: File, minBytes: Long, urls: List<String>, label: String) {
            if (dest.exists() && dest.length() >= minBytes) {
                logger.lifecycle("[Abstergo Labs] OK (ya existe): ${dest.name} (${dest.length() / 1024} KB)")
                return
            }
            for (rawUrl in urls) {
                try {
                    logger.lifecycle("[Abstergo Labs] Descargando $label desde $rawUrl ...")
                    val c = openFollowingRedirects(rawUrl, 120000) ?: continue
                    try {
                        if (c.responseCode == 200) {
                            val tmp = File(dest.parentFile, "${dest.name}.part")
                            c.inputStream.use { inp ->
                                tmp.outputStream().use { out -> inp.copyTo(out, 65536) }
                            }
                            if (tmp.length() >= minBytes) {
                                if (dest.exists()) dest.delete()
                                if (!tmp.renameTo(dest)) {
                                    tmp.copyTo(dest, overwrite = true)
                                    tmp.delete()
                                }
                                logger.lifecycle("[Abstergo Labs] Listo: ${dest.name} (${dest.length() / 1024} KB)")
                                return
                            } else {
                                tmp.delete()
                            }
                        } else {
                            logger.warn("[Abstergo Labs] HTTP ${c.responseCode} en $rawUrl")
                        }
                    } finally {
                        c.disconnect()
                    }
                } catch (e: Exception) {
                    logger.warn("[Abstergo Labs] No se pudo bajar $label desde $rawUrl: ${e.message}")
                }
            }
            logger.warn("[Abstergo Labs] AVISO: $label no se descargó; la app compilará igual.")
        }

        // 1) Modelo OCR Matemático ONNX INT8 (Xenova/texify, universal 32/64 bits)
        downloadIfMissing(
            dest = File(ocrDir, "encoder.onnx"),
            minBytes = 1_000_000L,
            urls = listOf("https://huggingface.co/Xenova/texify/resolve/main/onnx/encoder_model_quantized.onnx"),
            label = "OCR encoder.onnx (INT8)"
        )
        downloadIfMissing(
            dest = File(ocrDir, "decoder.onnx"),
            minBytes = 1_000_000L,
            urls = listOf("https://huggingface.co/Xenova/texify/resolve/main/onnx/decoder_model_quantized.onnx"),
            label = "OCR decoder.onnx (INT8)"
        )
        downloadIfMissing(
            dest = File(ocrDir, "tokenizer.json"),
            minBytes = 10_000L,
            urls = listOf("https://huggingface.co/Xenova/texify/resolve/main/tokenizer.json"),
            label = "OCR tokenizer.json"
        )

        // 2) Fotos reales de elementos químicos (Z=1..99) optimizadas a <= 480px para mantener el APK ligero
        val existingPhotos = chemImgDir.listFiles()?.count { it.name.endsWith(".jpg") && it.length() >= 1500L } ?: 0
        if (existingPhotos >= 90) {
            logger.lifecycle("[Abstergo Química Labs] OK: ya existen $existingPhotos fotos reales de elementos.")
        } else {
            val metaUrls = listOf(
                "https://raw.githubusercontent.com/Bowserinator/Periodic-Table-JSON/master/PeriodicTableJSON.json",
                "https://cdn.jsdelivr.net/gh/Bowserinator/Periodic-Table-JSON@master/PeriodicTableJSON.json"
            )
            var metaJson: String? = null
            for (u in metaUrls) {
                try {
                    val c = openFollowingRedirects(u, 30000) ?: continue
                    try {
                        if (c.responseCode == 200) {
                            metaJson = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                            break
                        }
                    } finally {
                        c.disconnect()
                    }
                } catch (e: Exception) {
                    logger.warn("[Abstergo Química Labs] Fallo índice de fotos ($u): ${e.message}")
                }
            }

            val loadedMeta = metaJson
            if (loadedMeta != null) {
                val photoUrls = LinkedHashMap<Int, String>()
                val numRe = Regex("\"number\"\\s*:\\s*(\\d+)")
                val imgRe = Regex("\"image\"\\s*:\\s*\\{[^{}]*?\"url\"\\s*:\\s*\"([^\"]+)\"")
                val blocks = loadedMeta.split("\"name\":")
                for (blk in blocks) {
                    val nm = numRe.find(blk)?.groupValues?.get(1)?.toIntOrNull() ?: continue
                    if (nm !in 1..99) continue
                    val rawImg = imgRe.find(blk)?.groupValues?.get(1)?.replace("\\/", "/") ?: continue
                    if (rawImg.startsWith("http")) photoUrls[nm] = rawImg
                }

                fun toWikimediaThumb(raw: String): String? {
                    val m = Regex("^(https://upload\\.wikimedia\\.org/wikipedia/commons)/([0-9a-f]/[0-9a-f]{2})/([^/]+)$").find(raw)
                        ?: return null
                    val base = m.groupValues[1]
                    val hash = m.groupValues[2]
                    val fname = m.groupValues[3]
                    val lower = fname.lowercase(Locale.US)
                    val thumbName = if (lower.endsWith(".svg") || lower.endsWith(".tif") || lower.endsWith(".tiff")) {
                        "480px-$fname.png"
                    } else {
                        "480px-$fname"
                    }
                    return "$base/thumb/$hash/$fname/$thumbName"
                }

                fun saveOptimizedImage(rawBytes: ByteArray, dest: File): Boolean {
                    if (rawBytes.size < 1500) return false
                    // Descartar respuestas HTML accidentales
                    val head = String(rawBytes, 0, minOf(rawBytes.size, 16), Charsets.US_ASCII).trimStart()
                    if (head.startsWith("<")) return false
                    return try {
                        val src = ImageIO.read(rawBytes.inputStream())
                        if (src != null && src.width > 0 && src.height > 0) {
                            val maxW = 480
                            val targetW = if (src.width > maxW) maxW else src.width
                            val targetH = ((src.height.toDouble() / src.width.toDouble()) * targetW).toInt().coerceAtLeast(1)
                            val rgb = BufferedImage(targetW, targetH, BufferedImage.TYPE_INT_RGB)
                            val g = rgb.createGraphics()
                            g.drawImage(src.getScaledInstance(targetW, targetH, Image.SCALE_SMOOTH), 0, 0, null)
                            g.dispose()
                            ImageIO.write(rgb, "jpg", dest)
                            dest.exists() && dest.length() >= 1000L
                        } else {
                            // Si ImageIO no decodifica WebP, Android BitmapFactory sí lo soporta nativamente
                            dest.writeBytes(rawBytes)
                            true
                        }
                    } catch (_: Exception) {
                        dest.writeBytes(rawBytes)
                        true
                    }
                }

                val okCount = AtomicInteger(0)
                val pool = Executors.newFixedThreadPool(3)
                for ((z, urlStr) in photoUrls) {
                    val dest = File(chemImgDir, String.format(Locale.US, "e_%03d.jpg", z))
                    if (dest.exists() && dest.length() >= 1500L) {
                        okCount.incrementAndGet()
                        continue
                    }
                    pool.submit {
                        val candidates = buildList {
                            toWikimediaThumb(urlStr)?.let { add(it) }
                            add(urlStr)
                        }
                        for (cand in candidates) {
                            try {
                                val c = openFollowingRedirects(cand, 25000) ?: continue
                                try {
                                    if (c.responseCode == 200) {
                                        val bytes = c.inputStream.use { it.readBytes() }
                                        if (saveOptimizedImage(bytes, dest)) {
                                            okCount.incrementAndGet()
                                            break
                                        }
                                    }
                                } finally {
                                    c.disconnect()
                                }
                            } catch (_: Exception) { }
                        }
                    }
                }
                pool.shutdown()
                pool.awaitTermination(5, TimeUnit.MINUTES)
                logger.lifecycle("[Abstergo Química Labs] Fotos reales descargadas y optimizadas: ${okCount.get()} / ${photoUrls.size}")
            }
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(prepareLabsAssets)
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Escáner QR y utilidades existentes
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")

    // Motor Matemático (núcleo numérico Apache Commons Math3, 100% JVM universal)
    implementation("org.apache.commons:commons-math3:3.6.1")

    // OCR Matemático Nivel 2 Offline (ONNX Runtime universal 32/64 bits)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
}
