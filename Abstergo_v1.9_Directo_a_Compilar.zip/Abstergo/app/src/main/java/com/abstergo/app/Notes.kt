package com.abstergo.app

import android.content.Context
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// ---------- Datos ----------
@Immutable
data class Note(
    val id: String, val title: String, val body: String, val subject: String,
    val pinned: Boolean, val color: Int, val created: Long, val updated: Long
)

private fun notesFile(ctx: Context) = File(ctx.filesDir, "notes.json")

fun loadNotes(ctx: Context): List<Note> = try {
    val f = notesFile(ctx)
    if (!f.exists()) emptyList()
    else {
        val a = JSONArray(f.readText())
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            Note(
                o.getString("id"), o.optString("title"), o.optString("body"), o.optString("subject", "general"),
                o.optBoolean("pinned"), o.optInt("color"), o.optLong("created"), o.optLong("updated")
            )
        }
    }
} catch (_: Exception) { emptyList() }

fun saveNotes(ctx: Context, list: List<Note>) {
    val a = JSONArray()
    list.forEach { n ->
        a.put(JSONObject().put("id", n.id).put("title", n.title).put("body", n.body).put("subject", n.subject)
            .put("pinned", n.pinned).put("color", n.color).put("created", n.created).put("updated", n.updated))
    }
    writeTextAtomic(notesFile(ctx), a.toString())
}

private val DATE_FORMATS = object : ThreadLocal<HashMap<String, SimpleDateFormat>>() {
    override fun initialValue(): HashMap<String, SimpleDateFormat> = HashMap(4)
}
private val WORD_SPLIT_RE = Regex("\\s+")

private fun noteSubject(k: String) = if (k == "general") "General" else subjectLabel(k)
private fun fmtDate(ms: Long, pattern: String): String {
    val map = DATE_FORMATS.get()!!
    val sdf = map.getOrPut(pattern) { SimpleDateFormat(pattern, Locale("es")) }
    return sdf.format(Date(ms))
}

private val NOTE_HUES = listOf(50f, 150f, 200f, 280f, 350f)

/** Color de fondo de una nota: 0 = el de las tarjetas, 1 a 5 = tonos suaves que se adaptan al modo claro u oscuro. */
@Composable
private fun noteColor(i: Int): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    return if (i <= 0 || i > NOTE_HUES.size) MaterialTheme.colorScheme.surface
    else remember(i, dark) { hsl(NOTE_HUES[i - 1], if (dark) 0.28f else 0.60f, if (dark) 0.22f else 0.88f) }
}

// ---------- Pestaña Notas ----------
@Composable
fun NotasTab(notes: List<Note>, onNew: (String) -> Unit, onOpen: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("all") } // all, pinned, general o la clave de una asignatura
    val subjects = remember(notes) { notes.map { it.subject }.distinct().sortedBy { noteSubject(it) } }
    val shown = remember(notes, query, filter) {
        val q = norm(query)
        notes
            .filter { n ->
                (filter == "all" || (filter == "pinned" && n.pinned) || n.subject == filter) &&
                    (q.isEmpty() || norm("${n.title} ${n.body} ${noteSubject(n.subject)}").contains(q))
            }
            .sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updated })
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Notas", fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button({ onNew(if (filter == "all" || filter == "pinned") "general" else filter) }, shape = RoundedCornerShape(14.dp)) { Text("Nueva") }
        }
        if (notes.isEmpty()) {
            ComingSoon(10, "Aún no tienes notas", "Toca Nueva para escribir tu primera nota. Puedes clasificarlas por asignatura.")
            return@Column
        }
        OutlinedTextField(
            query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp),
            placeholder = { Text("Buscar en las notas") }, singleLine = true, shape = RoundedCornerShape(14.dp),
            trailingIcon = { if (query.isNotEmpty()) Text("✕", Modifier.clickable { query = "" }.padding(12.dp)) }
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = filter == "all", onClick = { filter = "all" }, label = { Text("Todas") })
            FilterChip(selected = filter == "pinned", onClick = { filter = "pinned" }, label = { Text("Fijadas") })
            subjects.forEach { s -> FilterChip(selected = filter == s, onClick = { filter = s }, label = { Text(noteSubject(s)) }) }
        }
        if (shown.isEmpty()) {
            Text("No hay notas que coincidan.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2), contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown, key = { it.id }) { n -> NoteCard(n) { onOpen(n.id) } }
        }
    }
}

@Composable
private fun NoteCard(n: Note, onClick: () -> Unit) {
    val dateLabel = remember(n.updated) { fmtDate(n.updated, "d MMM") }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(noteColor(n.color)).clickable { onClick() }.padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        if (n.pinned) Text("Fijada", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        if (n.title.isNotBlank()) Text(n.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (n.body.isNotBlank()) {
            Text(n.body, fontSize = 14.sp, maxLines = 6, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(noteSubject(n.subject), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
            Text(dateLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------- Editor de nota (pantalla completa) ----------
@Composable
fun NoteEditor(note: Note?, defaultSubject: String, onSave: (Note) -> Unit, onDelete: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val id = remember { note?.id ?: UUID.randomUUID().toString() }
    val created = remember { note?.created ?: System.currentTimeMillis() }
    var title by remember { mutableStateOf(note?.title ?: "") }
    var body by remember { mutableStateOf(note?.body ?: "") }
    var subject by remember { mutableStateOf(note?.subject ?: defaultSubject) }
    var pinned by remember { mutableStateOf(note?.pinned ?: false) }
    var color by remember { mutableStateOf(note?.color ?: 0) }
    var menu by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }

    // Se guarda sola al salir; una nota vacía no se guarda (y si ya existía y la vaciaste, se elimina)
    fun commit() {
        if (title.isBlank() && body.isBlank()) { if (note != null) onDelete(id); return }
        val changed = note == null || title != note.title || body != note.body || subject != note.subject || pinned != note.pinned || color != note.color
        if (changed) onSave(Note(id, title.trim(), body, subject, pinned, color, created, System.currentTimeMillis()))
    }
    BackHandler { commit(); onBack() }

    val words = remember(body) {
        val trimmed = body.trim()
        if (trimmed.isEmpty()) 0 else trimmed.split(WORD_SPLIT_RE).size
    }
    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent
    )

    Column(Modifier.fillMaxSize().background(noteColor(color)).systemBarsPadding().imePadding().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton({ commit(); onBack() }, shape = RoundedCornerShape(14.dp)) { Text("Listo") }
            Spacer(Modifier.weight(1f))
            if (pinned) Text("Fijada", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            Box {
                TextButton({ menu = true }) { Text("⋮", fontSize = 22.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text(if (pinned) "Quitar de fijadas" else "Fijar nota") }, onClick = { pinned = !pinned; menu = false })
                    DropdownMenuItem(text = { Text("Compartir") }, onClick = {
                        menu = false
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_SUBJECT, title).putExtra(Intent.EXTRA_TEXT, (if (title.isNotBlank()) title + "\n\n" else "") + body)
                        ctx.startActivity(Intent.createChooser(send, "Compartir nota"))
                    })
                    if (note != null) DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; askDelete = true })
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = subject == "general", onClick = { subject = "general" }, label = { Text("General") })
            SUBJECTS.forEach { (k, v) -> FilterChip(selected = subject == k, onClick = { subject = k }, label = { Text(v) }) }
        }
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Color", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            (0..NOTE_HUES.size).forEach { i ->
                Box(
                    Modifier.size(30.dp).clip(CircleShape).background(noteColor(i))
                        .border(if (color == i) 3.dp else 1.dp, if (color == i) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable { color = i }
                )
            }
        }
        TextField(
            title, { title = it }, Modifier.fillMaxWidth(), colors = fieldColors, singleLine = true,
            textStyle = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold),
            placeholder = { Text("Título", fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        )
        TextField(
            body, { body = it }, Modifier.fillMaxWidth().weight(1f), colors = fieldColors,
            textStyle = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
            placeholder = { Text("Escribe tu nota…") }
        )
        val editedPrefix = remember(note?.updated) {
            if (note != null) "Editada: ${fmtDate(note.updated, "d MMM yyyy, HH:mm")} · " else "Nueva · "
        }
        Text(
            "$editedPrefix$words palabras · ${body.length} caracteres",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
    }

    if (askDelete) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            containerColor = MaterialTheme.colorScheme.surface,
            text = { Text("¿Eliminar esta nota? No se puede deshacer.") },
            confirmButton = { TextButton({ askDelete = false; onDelete(id); onBack() }) { Text("Eliminar") } },
            dismissButton = { TextButton({ askDelete = false }) { Text("Cancelar") } }
        )
    }
}
