package com.abstergo.app.labs.math

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.WebViewAssetLoader
import com.abstergo.app.ASSET_HOST
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

private const val LAB_BOARD_CSP =
    "default-src 'none'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
    "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; " +
    "connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'"

private fun PlotSceneSpec.toJsonString(): String {
    val obj = JSONObject()
        .put("xMin", xMin)
        .put("xMax", xMax)
        .put("yMin", yMin)
        .put("yMax", yMax)
    val fArr = JSONArray()
    functions.forEach { f ->
        fArr.put(JSONObject().put("js", f.jsExpression).put("label", f.label).put("color", f.color))
    }
    val pArr = JSONArray()
    points.forEach { p ->
        pArr.put(JSONObject().put("x", p.x).put("y", p.y).put("label", p.label).put("color", p.color))
    }
    return obj.put("functions", fArr).put("points", pArr).toString()
}

private class BoardBridge(
    private val main: Handler,
    private val onInspectRef: () -> ((String, String) -> Unit)
) {
    @JavascriptInterface
    fun onInspect(title: String, detail: String) {
        main.post { onInspectRef().invoke(title, detail) }
    }
}

/**
 * Lienzo matemático 2D 100% offline impulsado por JSXGraph 1.14.3 local.
 * Sirve assets/labs/math/math_board.html y jsxgraphcore.js mediante WebViewAssetLoader
 * bloqueando cualquier tráfico externo y liberando el WebView al salir.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MathBoardView(
    scene: PlotSceneSpec,
    dark: Boolean,
    modifier: Modifier = Modifier,
    onInspect: (title: String, detail: String) -> Unit = { _, _ -> }
) {
    val sceneJson = remember(scene) { scene.toJsonString() }
    val latestInspect by rememberUpdatedState(onInspect)
    val latestScene by rememberUpdatedState(sceneJson)
    val latestDark by rememberUpdatedState(dark)
    var pageReady by remember { mutableStateOf(false) }
    val webRef = remember { arrayOfNulls<WebView>(1) }

    LaunchedEffect(sceneJson, dark, pageReady) {
        val w = webRef[0]
        if (w != null && pageReady) {
            val quoted = JSONObject.quote(sceneJson)
            w.evaluateJavascript("window.renderScene($quoted, $dark);", null)
        }
    }

    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { ctx: Context ->
            val loader = WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
                .build()
            val main = Handler(Looper.getMainLooper())
            WebView(ctx).apply {
                setBackgroundColor(AndroidColor.TRANSPARENT)
                with(settings) {
                    javaScriptEnabled = true
                    domStorageEnabled = false
                    allowFileAccess = false
                    allowContentAccess = false
                    builtInZoomControls = false
                    displayZoomControls = false
                    setSupportZoom(false)
                    loadWithOverviewMode = true
                    useWideViewPort = true
                }
                CookieManager.getInstance().apply {
                    setAcceptCookie(false)
                    setAcceptThirdPartyCookies(this@apply, false)
                }
                addJavascriptInterface(BoardBridge(main) { latestInspect }, "AbstergoBoard")
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val url = request.url
                        val res = loader.shouldInterceptRequest(url)
                        if (res != null) {
                            res.responseHeaders = res.responseHeaders.orEmpty() + ("Content-Security-Policy" to LAB_BOARD_CSP)
                            return res
                        }
                        return if (url.scheme == "http" || url.scheme == "https") {
                            WebResourceResponse("text/plain", "utf-8", 404, "Blocked", null, ByteArrayInputStream(ByteArray(0)))
                        } else null
                    }

                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true

                    override fun onPageFinished(view: WebView, url: String?) {
                        pageReady = true
                        val quoted = JSONObject.quote(latestScene)
                        view.evaluateJavascript("window.renderScene($quoted, $latestDark);", null)
                    }

                    override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean = true
                }
                webRef[0] = this
                loadUrl("https://$ASSET_HOST/assets/labs/math/math_board.html")
            }
        },
        onRelease = { w ->
            webRef[0] = null
            w.removeJavascriptInterface("AbstergoBoard")
            w.stopLoading()
            w.destroy()
        }
    )
}
